import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AgentCommonServiceService } from '../services/agent-common-service.service';
import { AgentDataServiceService } from '../services/agent-data-service.service';

@Component({
  selector: 'app-leads-dtls-incomplete-tbl',
  templateUrl: './leads-dtls-incomplete-tbl.component.html',
  styleUrls: ['./leads-dtls-incomplete-tbl.component.css']
})
export class LeadsDtlsIncompleteTblComponent implements OnInit {


  agentListData: any;
  agentsCreateDate: any;
  accntType: number = 1;
  newLeads: string = '';
  leadsUnderProcess: string = '';
  reviewedLeads: string = '';
   date = new Date();
  customerListDataArr: Array<any> = [
  //   {
  //   lead_number:1,
  //   customer_name:'arun',
  //   email:'arun@gmail.com',
  //   mobile_number:'+91 9655694396',
  //   date: this.date.setDate(this.date.getDate() + 1),

  // },
  //   {
  //   lead_number:2,
  //   customer_name:'jhon',
  //   email:'jhon@gmail.com',
  //   mobile_number:'7676980',
  //   date: this.date.setDate(this.date.getDate() + 2),

  // },
  //   {
  //   lead_number:3,
  //   customer_name:'rajini',
  //   email:'rajini@gmail.com',
  //   mobile_number:'7676980',
  //   date: this.date.setDate(this.date.getDate() + 3),

  // },
  //   {
  //   lead_number:4,
  //   customer_name:'kamal',
  //   email:'kamal@gmail.com',
  //   mobile_number:'7676980',
  //   date: this.date.setDate(this.date.getDate() + 4),

  // },
  //   {
  //   lead_number:5,
  //   customer_name:'vijay',
  //   email:'vijay@gmail.com',
  //   mobile_number:'7676980',
  //   date: this.date.setDate(this.date.getDate() + 5),

  // },
  //   {
  //   lead_number:6,
  //   customer_name:'arun',
  //   email:'arun@gmail.com',
  //   mobile_number:'+96 9655694396',
  //   date: this.date.setDate(this.date.getDate() + 6),

  // },
  //   {
  //   lead_number:7,
  //   customer_name:'jhon',
  //   email:'jhon@gmail.com',
  //   mobile_number:'7676980',
  //   date: this.date.setDate(this.date.getDate() + 7),

  // },
  //   {
  //   lead_number:8,
  //   customer_name:'rajini',
  //   email:'rajini@gmail.com',
  //   mobile_number:'7676980',
  //   date: this.date.setDate(this.date.getDate() + 8),

  // },
  //   {
  //   lead_number:9,
  //   customer_name:'kamal',
  //   email:'kamal@gmail.com',
  //   mobile_number:'7676990',
  //   date: this.date.setDate(this.date.getDate() + 9),

  // },
  //   {
  //   lead_number:10,
  //   customer_name:'vijay',
  //   email:'vijay@gmail.com',
  //   mobile_number:'76761080',
  //   date: this.date.setDate(this.date.getDate() + 10),

  // },
  //   {
  //   lead_number:11,
  //   customer_name:'vijay',
  //   email:'vijay@gmail.com',
  //   mobile_number:'7676980',
  //   date: this.date.setDate(this.date.getDate() + 11),

  // },
  //   {
  //   lead_number:12,
  //   customer_name:'arun',
  //   email:'arun@gmail.com',
  //   mobile_number:'+912 9125512943912',
  //   date: this.date.setDate(this.date.getDate() + 12),

  // },
  //   {
  //   lead_number:13,
  //   customer_name:'jhon',
  //   email:'jhon@gmail.com',
  //   mobile_number:'136136980',
  //   date: this.date.setDate(this.date.getDate() + 13),

  // },
  //   {
  //   lead_number:14,
  //   customer_name:'rajini',
  //   email:'rajini@gmail.com',
  //   mobile_number:'76769140',
  //   date: this.date.setDate(this.date.getDate() + 14),

  // },
  //   {
  //   lead_number:15,
  //   customer_name:'kamal',
  //   email:'kamal@gmail.com',
  //   mobile_number:'767615150',
  //   date: this.date.setDate(this.date.getDate() + 15),

  // },
  //   {
  //   lead_number:16,
  //   customer_name:'vijay',
  //   email:'vijay@gmail.com',
  //   mobile_number:'76761680',
  //   date: this.date.setDate(this.date.getDate() + 16),

  // },
];
  roleID: number = 0;

  page: number = 1;
  count: number = 0;
  tableSize: number = 10;
  tableSizes: any = [3, 6, 9, 12];

  constructor(private agentDataServiceService: AgentDataServiceService, private agentCommonServiceService: AgentCommonServiceService, private rt: Router) { }

  ngOnInit(): void {
   
    this.roleID = this.agentCommonServiceService.getUserFromLocalStorage()?.role_id
    var agent_id = this.agentCommonServiceService.getUserFromLocalStorage()?.user_id
      this.agentDataServiceService.postIncompleteAgentsLead({ agent_id: agent_id, lead_type: 'incomplete' }).subscribe((data) => {
        if (data?.data?.length) {
          this.customerListDataArr = data?.data;
        }
      })
  }

  veiwLeadsUnderProcess(applicantID: number, leadID: number) {
    this.agentCommonServiceService.storeInLocalStorage('agentData', { customerUserID: leadID })
    this.rt.navigate(['/dashboard', 'lead-dtls1', applicantID]);
  }

  onTableDataChange(event: any) {
    this.page = event;
  }
  onTableSizeChange(event: any): void {
    this.tableSize = event.target.value;
    this.page = 1;
  }
}

