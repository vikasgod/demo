import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LeadsDtlsIncompleteTblComponent } from './leads-dtls-incomplete-tbl.component';

describe('LeadsDtlsIncompleteTblComponent', () => {
  let component: LeadsDtlsIncompleteTblComponent;
  let fixture: ComponentFixture<LeadsDtlsIncompleteTblComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ LeadsDtlsIncompleteTblComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(LeadsDtlsIncompleteTblComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
