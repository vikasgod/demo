import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LeadsDtlsRejectedTblComponent } from './leads-dtls-rejected-tbl.component';

describe('LeadsDtlsRejectedTblComponent', () => {
  let component: LeadsDtlsRejectedTblComponent;
  let fixture: ComponentFixture<LeadsDtlsRejectedTblComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ LeadsDtlsRejectedTblComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(LeadsDtlsRejectedTblComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
