import { Component, OnInit } from '@angular/core';
import { AgentDataServiceService } from '../services/agent-data-service.service';
import { AgentCommonServiceService } from '../services/agent-common-service.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-leads-dtls-rejected-tbl',
  templateUrl: './leads-dtls-rejected-tbl.component.html',
  styleUrls: ['./leads-dtls-rejected-tbl.component.css']
})
export class LeadsDtlsRejectedTblComponent implements OnInit {

  agentListData: any;
  agentsCreateDate: any;
  accntType: number = 1;
  newLeads: string = '';
  leadsUnderProcess: string = '';
  reviewedLeads: string = '';
  agentListDataArr: Array<any> = [];

  roleID: number = 0;

  page: number = 1;
  count: number = 0;
  tableSize: number = 10;
  tableSizes: any = [3, 6, 9, 12];
  filterData:any
  fullagentListDataArr:any=[]

  constructor(private agentDataServiceService: AgentDataServiceService, private agentCommonServiceService: AgentCommonServiceService, private rt: Router) { }

  ngOnInit(): void {

    let Obj = {
      agent_id: this.agentCommonServiceService.getUserFromLocalStorage()?.user_id,
      lead_type: 'agent_review'
    }

    this.roleID = this.agentCommonServiceService.getUserFromLocalStorage()?.role_id

    if (this.roleID == 3) {
      var agent_id = this.agentCommonServiceService.getUserFromLocalStorage()?.user_id
      this.agentDataServiceService.postAgentLeadCount({ agent_id: agent_id, lead_type: 'rejected' }).subscribe((data) => {
        if (data?.data?.length) {
          this.agentListDataArr = data?.data;
          this.fullagentListDataArr = data?.data;
        }
      })
      // this.agentDataServiceService.getSuperAgentNewLeadList().subscribe((data) => {
      //   this.agentListDataArr = data?.data;
      //   console.log('This is super agent data', this.agentListDataArr);
      // })
    } else {

      var agent_id = this.agentCommonServiceService.getUserFromLocalStorage()?.user_id
      console.log('agent list');
      this.agentDataServiceService.getSuperAgentRejectedLeadList().subscribe((data) => {
        this.agentListDataArr = data?.data;
        this.fullagentListDataArr = data?.data;
      })
    }
  }

  veiwReviewLeads(applicantID: number, leadID: number) {
    this.agentCommonServiceService.storeInLocalStorage('agentData', { customerUserID: leadID })
    this.rt.navigate(['/dashboard', 'lead-dtls1', applicantID]);
  }

  onTableDataChange(event: any) {
    this.page = event;
  }
  onTableSizeChange(event: any): void {
    this.tableSize = event.target.value;
    this.page = 1;
  }

  getFilteredData(){
    this.agentListDataArr = this.fullagentListDataArr.filter((obj:any) =>{  
      return (obj.agent_name.includes(this.filterData) || obj.lead_number.includes(this.filterData) || obj.applicant_name.includes(this.filterData) || obj.account_type.includes(this.filterData))
    });
  }

}
