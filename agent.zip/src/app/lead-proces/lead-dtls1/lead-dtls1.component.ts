import { Component, ElementRef, OnInit, ViewChild, Output, EventEmitter } from '@angular/core';
import { AgentDataServiceService } from 'src/app/services/agent-data-service.service';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';
import { AgentCommonServiceService } from 'src/app/services/agent-common-service.service';
import { Router, ActivatedRoute } from '@angular/router';
import { data } from 'jquery';

@Component({
  selector: 'app-lead-dtls1',
  templateUrl: './lead-dtls1.component.html',
  styleUrls: ['./lead-dtls1.component.css']
})
export class LeadDtls1Component implements OnInit {

  @Output() showFatcaDivOut = new EventEmitter<string>();
  @Output() showKycDivOut = new EventEmitter<string>()
  @Output() isChecked = new EventEmitter<boolean>()

  personalDtlsForm1: any;
  personalDtlsForm2: any;
  deleteCommentInd: any
  procced: boolean = false

  isDisplayComment: boolean = false;
  applicantFullName: string = '';
  accountType: string = '';
  accountVariant: string = '';
  aadhaarrNo: string = '';
  religion: string = '';
  category: string = '';
  isPoliticallyExposed: string = '';
  dob: string = '';
  maritalStatus: string = '';
  gender: string = '';

  applicantMaidenFullName: string = '';
  applicantMothersFullName: string = '';
  applicantFatherOrSpouceFullName: string = ''
  nationality: string = '';
  dateOfBecomingNri: string = '';

  aadhaar_number: string = '';
  account_type_id: string = '';
  account_type_name: string = '';
  account_varient: string = '';
  applicant_first_name: string = '';
  applicant_last_name: string = '';
  applicant_middle_name: string = '';
  applicant_personal_id: string = '';
  applicant_title: string = '';
  applicant_title_name: string = '';
  countrie_name: string = '';
  country_id: string = '';
  date_of_birth: string = '';
  is_politically_exposed: string = '';
  is_politically_exposed_name: string = '';
  is_trading_facility_opt: string = '';
  is_trading_facility_opt_name: string = '';
  marital_status: string = '';
  process_id: string = '';
  process_name: string = '';
  religion_category_id: string = '';
  religion_category_name: string = '';
  religion_id: string = '';
  religion_name: string = '';
  customerUserID: number = 0;
  agentCommnentArrData: any;
  display: string = "none";
  displayCommentErr: string = "none";
  roleID:any

  processArr = [
    { process: 'Personal Details', processId: 4, commentData: '', commentID: 0, isDisplayAddComment: true, isDisplayAddApprove: true, isDislplayCommentTextArea: true, isDislplayCommentUpdateBtn: false, isDisplayEditDeleteCommentSection: false, isDisplayProceedNext: false, isApproved: false, approveMsg: '', approveDisable: false },
    { process: 'Additional Details', processId: 5, commentData: '', commentID: 0, isDisplayAddComment: true, isDisplayAddApprove: true, isDislplayCommentTextArea: true, isDislplayCommentUpdateBtn: false, isDisplayEditDeleteCommentSection: false, isDisplayProceedNext: false, isApproved: false, approveMsg: '', approveDisable: false }
  ]

  commentData: string = '';
  commentID: number = 0;
  isApproved: boolean = false;
  approveMsg: string = '';
  approveDisable: boolean = false;

  @ViewChild('commentSection') commentSection!: ElementRef<HTMLInputElement>;

  applicantID: number | null = 0;
  regObj: any;
  isMinor:boolean=false
  accountType1:any
  constructor(private agentDataServiceService: AgentDataServiceService, private agentCommonServiceService: AgentCommonServiceService, private fb: FormBuilder, private rt: Router, private activeRt: ActivatedRoute) { }

  async ngOnInit() {
    this.accountType1=localStorage.getItem('accountType')
    let minor=localStorage.getItem('isMinor')
    if(minor=='true'){
      this.isMinor=true
    }
    else{
      this.isMinor=false
    }

    if(this.accountType1=='Minor'){
      if(this.isMinor==true){
        this.processArr[0].processId = 33
        this.processArr[1].processId = 34
      }
      else{
        this.processArr[0].processId = 45
        this.processArr[1].processId = 46
      }
    }

    this.regObj = this.agentCommonServiceService.getUserFromLocalStorage();
    this.applicantID = Number(this.activeRt.snapshot.paramMap.get('applicantID'));
    this.personalDtlsForm1 = this.fb.group({
      comments: ['', Validators.required]
    })
    this.personalDtlsForm2 = this.fb.group({
      comments: ['', Validators.required]
    })

    this.roleID = this.agentCommonServiceService.getUserFromLocalStorage()?.role_id

    if(this.roleID == 2){
      this.processArr[0].isDislplayCommentTextArea = false
      this.processArr[0].isDisplayAddComment = false
      this.processArr[0].isDislplayCommentUpdateBtn = false
      this.processArr[0].isDisplayEditDeleteCommentSection = false
      this.processArr[0].approveDisable = true

      this.processArr[1].isDislplayCommentTextArea = false
      this.processArr[1].isDisplayAddComment = false
      this.processArr[1].isDislplayCommentUpdateBtn = false
      this.processArr[1].isDisplayEditDeleteCommentSection = false
      this.processArr[1].approveDisable = true

      this.procced = true
      this.isChecked.emit(true)
    }

    let Obj1 = {
      user_id: this.regObj?.user_id,
      process_id: 1,
      applicant_id: this.applicantID
    }
    this.agentDataServiceService.fetchCountry(Obj1).subscribe((value) => {
      this.accountType = value?.data?.[0]?.account_type_id
    })
    
    let Obj2 = {
      user_id: this.regObj?.user_id,
      process_id: 1,
      applicant_id: this.applicantID
    }
    this.agentDataServiceService.fetchAccntVariant(Obj2).subscribe((value) => {
      this.accountVariant = value?.data?.[0]?.account_varient
    })
    
    // let Obj3 = {
    //   user_id: this.regObj?.user_id,
    //   process_id: 4,
    //   applicant_id: this.applicantID
    // }

    let Obj3={}

    if(this.accountType1=='Minor'){
      if(this.isMinor==true){ // minor
        Obj3 = {
          user_id: this.regObj?.user_id,
          process_id: 33,
          applicant_id: this.applicantID
        }
      }else{ // Guardian 
        Obj3 = {
          user_id: this.regObj?.user_id,
          process_id: 45,
          applicant_id: this.applicantID
        }
      }
    }
    else{
      Obj3 = {
        user_id: this.regObj?.user_id,
        process_id: 4,
        applicant_id: this.applicantID
      }
    }
    
    this.agentDataServiceService.fetchPersonalDtls1(Obj3).subscribe((value) => {
      
      localStorage.setItem("Account type", value.data[0].account_type_name);
      if(value?.data.length>0){
        if (value?.data?.[0]?.lead_status != undefined) {
          if (value?.data?.[0]?.lead_status == 'agent_review') {
            // this.approveDisable = true;
            this.processArr[0].approveDisable = true
            this.processArr[1].approveDisable = true
            this.processArr[0].isDisplayAddComment = false
            this.processArr[1].isDisplayAddComment = false
            this.processArr[0].isDislplayCommentUpdateBtn = false
            this.processArr[1].isDislplayCommentUpdateBtn = false
            this.processArr[0].isDislplayCommentTextArea = false
            this.processArr[1].isDislplayCommentTextArea = false
          }
        }
  
        var adhar_no = String(value?.data?.[0]?.aadhaar_number);
        var last_adhar = adhar_no.substring(8, 12);
        this.applicantFullName = `${value?.data?.[0]?.applicant_first_name} ${value?.data?.[0]?.applicant_middle_name} ${value?.data?.[0]?.applicant_last_name}`
        this.aadhaarrNo = 'XXXX XXXX ' + last_adhar;
        this.religion = value?.data?.[0]?.religion_id;
        this.category = value?.data?.[0]?.religion_category_id;
        this.isPoliticallyExposed = value?.data?.[0]?.is_politically_exposed;
        let dateOfBirthObj = new Date(value?.data?.[0]?.date_of_birth);
  
        // this.dob = `${dateOfBirthObj.getDate()}/${dateOfBirthObj.getMonth()}/${dateOfBirthObj.getFullYear()}`;
        this.dob = new Date(value?.data?.[0]?.date_of_birth).toLocaleDateString();
        this.maritalStatus = value?.data?.[0]?.marital_status;
        this.gender = value?.data?.[0]?.gender;
        this.aadhaar_number = value?.data?.[0].aadhaar_number;
        this.account_type_id = value?.data?.[0].account_type_id;
        this.account_type_name = value?.data?.[0].account_type_name;
        this.account_varient = value?.data?.[0].account_varient;
        this.applicant_first_name = value?.data?.[0].applicant_first_name;
        this.applicant_last_name = value?.data?.[0].applicant_last_name;
        this.applicant_middle_name = value?.data?.[0].applicant_middle_name;
        this.applicant_personal_id = value?.data?.[0].applicant_personal_id;
        this.applicant_title = value?.data?.[0].applicant_title;
        this.applicant_title_name = value?.data?.[0].applicant_title_name;
        this.countrie_name = value?.data?.[0].countrie_name;
        this.country_id = value?.data?.[0].country_id;
        this.date_of_birth = value?.data?.[0].date_of_birth;
        this.is_politically_exposed = value?.data?.[0].is_politically_exposed;
        this.is_politically_exposed_name = value?.data?.[0].is_politically_exposed_name;
        this.is_trading_facility_opt = value?.data?.[0].is_trading_facility_opt;
        this.is_trading_facility_opt_name = value?.data?.[0].is_trading_facility_opt_name;
        this.marital_status = value?.data?.[0].marital_status;
        this.process_id = value?.data?.[0].process_id;
        this.process_name = value?.data?.[0].process_name;
        this.religion_category_id = value?.data?.[0].religion_category_id;
        this.religion_category_name = value?.data?.[0].religion_category_name;
        this.religion_id = value?.data?.[0].religion_id;
        this.religion_name = value?.data?.[0].religion_name;
      }
    
    })

    // let Obj4 = {
    //   user_id: this.regObj?.user_id,
    //   process_id: 5,
    //   applicant_id: this.applicantID
    // }

    let Obj4={}

    if(this.accountType1=='Minor'){
      if(this.isMinor==true){ // minor
        Obj4 = {
          user_id: this.regObj?.user_id,
          process_id: 34,
          applicant_id: this.applicantID
        }
      }else{ // Guardian 
        Obj4 = {
          user_id: this.regObj?.user_id,
          process_id: 46,
          applicant_id: this.applicantID
        }
      }
    }
    else{
      Obj4 = {
        user_id: this.regObj?.user_id,
        process_id: 4,
        applicant_id: this.applicantID
      }
    }

    console.log('personal details 2', Obj3);
    
    this.agentDataServiceService.fetchPersonalDtls2(Obj4).subscribe((value) => {
      if (value?.data?.[0]?.lead_status != undefined) {
        if (value?.data?.[0]?.lead_status == 'agent_review') {
          // this.approveDisable = true;
        }
      }

      this.applicantMaidenFullName = '';
      if (value?.data?.[0]?.maiden_title != null && value?.data?.[0]?.maiden_first_name != null && value?.data?.[0]?.maiden_middle_name != null && value?.data?.[0]?.maiden_last_name != null) {
        this.applicantMaidenFullName = `${value?.data?.[0]?.maiden_title}. ${value?.data?.[0]?.maiden_first_name} ${value?.data?.[0]?.maiden_middle_name} ${value?.data?.[0]?.maiden_last_name}`
      }

      this.applicantMothersFullName = `Mrs. ${value?.data?.[0]?.mother_first_name} ${value?.data?.[0]?.mother_middle_name}  ${value?.data?.[0]?.mother_last_name}`
      this.applicantFatherOrSpouceFullName = `${value?.data?.[0]?.in_relation_title}. ${value?.data?.[0]?.in_relation_first_name} ${value?.data?.[0]?.in_relation_middle_name} ${value?.data?.[0]?.in_relation_last_name}`;
      this.nationality = value?.data?.[0]?.nationality;

      let dtofbNri = new Date(value?.data?.[0]?.date_of_becoming_nri);
      // this.dateOfBecomingNri = `${dtofbNri.getDate()}/${dtofbNri.getMonth()}/${dtofbNri.getFullYear()}`
      this.dateOfBecomingNri = new Date(value?.data?.[0]?.date_of_becoming_nri).toLocaleDateString();
    })

    for (let i = 0; i < this.processArr.length; i++) {
      await this.setComments(i)
    }
  }

  async setComments(ind: number) {
    let ObjC = {
      applicant_id: this.applicantID,
      lead_id: this.regObj?.customerUserID,
      agent_id: this.regObj?.user_id,
      process_id: this.processArr[ind].processId
    }

    await this.agentDataServiceService.fetchAgentCommentSummary(ObjC).toPromise().then((data) => {
      if (data?.data?.agent_status == "approved") {
        this.processArr[ind].isDisplayAddComment = false;
        this.processArr[ind].isDisplayAddApprove = false;
        this.processArr[ind].isDislplayCommentTextArea = false;
        this.processArr[ind].isDislplayCommentUpdateBtn = false;
        this.processArr[ind].isDisplayEditDeleteCommentSection = false;
        this.processArr[ind].isDisplayProceedNext = true;

        this.processArr[ind].isApproved = true;
        this.processArr[ind].approveMsg = 'This section is approved';

        // this.showFatcaDivOut.emit()
        // this.showFatcaDivOut.emit()
        if(this.processArr[1].isDisplayProceedNext===true && this.processArr[0].isDisplayProceedNext===true){
          this.procced=true
          this.isChecked.emit(true)
        }
      }
      else if (data?.data?.comment_id) {
        this.processArr[ind].isDisplayAddComment = false;
        this.processArr[ind].isDisplayAddApprove = true;
        this.processArr[ind].isDislplayCommentTextArea = false;
        this.processArr[ind].isDislplayCommentUpdateBtn = false;
        this.processArr[ind].isDisplayEditDeleteCommentSection = true;
        this.processArr[ind].isDisplayProceedNext = true;
        this.processArr[ind].isApproved = false;
        this.agentCommnentArrData = data;
        this.processArr[ind].commentData = data?.data?.comment;
        this.processArr[ind].commentID = data?.data?.comment_id;
        if (ind == 0) {
          this.personalDtlsForm1.controls['comments'].setValue(data?.data?.comment)
        }
        else if (ind == 1) {
          this.personalDtlsForm2.controls['comments'].setValue(data?.data?.comment)
        }
        if(this.processArr[1].isDisplayProceedNext===true && this.processArr[0].isDisplayProceedNext===true){
          this.procced=true
          this.isChecked.emit(true)
        }

        //this.isApproved=true;
        // this.showFatcaDivOut.emit()
        // this.showFatcaDivOut.emit()
      }
    })

  }

  getProcessId(val: string) {
    let ans
    this.processArr.forEach((res: any) => {
      if (res.process == val)
        ans = res.processId
    })
    return ans
  }

  openModal() {
    this.display = "block";
  }

  onCloseHandled() {
    this.display = "none";
  }

  openModalComment() {
    this.displayCommentErr = "block";
  }

  closeModalComment() {
    this.displayCommentErr = "none";
  }


  get comments() { return this.personalDtlsForm1.get('comments') }

  addComment(val: string) {
    if (val == 'Personal Details') {
      if (this.personalDtlsForm1.valid) {
        let comment = this.personalDtlsForm1.get('comments').value
        let arrId = this.processArr.findIndex((res: any) => res.process == val)
        this.addCommentApi(comment, arrId)
      }
      else {
        this.openModalComment();
      }
    }

    else if (val == 'Additional Details') {
      if (this.personalDtlsForm2.valid) {
        // this.isDisplayAddComment3 = false;
        // this.isDisplayAddApprove3 = true;
        // this.isDislplayCommentTextArea3 = false;
        // this.isDislplayCommentUpdateBtn3 = false;
        // this.isDisplayEditDeleteCommentSection3 = true;
        // this.isDisplayProceedNext3 = true;
        let comment = this.personalDtlsForm2.get('comments').value
        let arrId = this.processArr.findIndex((res: any) => res.process == val)
        this.addCommentApi(comment, arrId)
      }
      else {
        this.openModalComment();
      }
    }
  }

  addCommentApi(getcomment: any, arrind: number) {
    this.processArr[arrind].isDisplayAddComment = false;
    this.processArr[arrind].isDisplayAddApprove = true;
    this.processArr[arrind].isDislplayCommentTextArea = false;
    this.processArr[arrind].isDislplayCommentUpdateBtn = false;
    this.processArr[arrind].isDisplayEditDeleteCommentSection = true;
    this.processArr[arrind].isDisplayProceedNext = true;

    let Obj = {
      process_id: this.processArr[arrind].processId,
      applicant_id: this.applicantID,
      parent_comment_id: 0,
      agent_id: this.agentCommonServiceService.getUserFromLocalStorage()?.user_id,
      comment: getcomment,
      lead_id: this.regObj?.customerUserID
    }

    this.agentDataServiceService.postAgentsComment(Obj).subscribe((value) => {
      let ObjC = {
        applicant_id: this.applicantID,
        lead_id: this.regObj?.customerUserID,
        agent_id: this.regObj?.user_id,
        "process_id": this.processArr[arrind].processId,
        "comment_id": value.comment_id
      }

      this.agentDataServiceService.fetchAgentCommentSummary(ObjC).subscribe((data) => {
        this.agentCommnentArrData = data;
        this.processArr[arrind].commentData = data?.data?.comment;
        this.processArr[arrind].commentID = data?.data?.comment_id;
      })
      if(this.processArr[1].isDisplayProceedNext===true && this.processArr[0].isDisplayProceedNext===true){
        this.procced=true
        this.isChecked.emit(true)
      }

    }, (err) => {
      console.log(err);
    })
  }

  updateComment(val: string) {

    if (val == 'Personal Details') {
      if (this.personalDtlsForm1.valid) {
        // this.isDisplayAddComment2 = false;
        // this.isDisplayAddApprove2 = true;
        // this.isDislplayCommentTextArea2 = false;
        // this.isDislplayCommentUpdateBtn2 = false;
        // this.isDisplayEditDeleteCommentSection2 = true;
        // this.isDisplayProceedNext2 = true;

        let comment = this.personalDtlsForm1.get('comments').value
        let arrId = this.processArr.findIndex((res: any) => res.process == val)
        this.updateCommentapi(comment, arrId)
      }
      else {
        this.openModalComment();
      }
    }

    else if (val == 'Additional Details') {
      if (this.personalDtlsForm2.valid) {
        // this.isDisplayAddComment3 = false;
        // this.isDisplayAddApprove3 = true;
        // this.isDislplayCommentTextArea3 = false;
        // this.isDislplayCommentUpdateBtn3 = false;
        // this.isDisplayEditDeleteCommentSection3 = true;
        // this.isDisplayProceedNext3 = true;

        let comment = this.personalDtlsForm2.get('comments').value
        let arrId = this.processArr.findIndex((res: any) => res.process == val)
        this.updateCommentapi(comment, arrId)
      }
      else {
        this.openModalComment();
      }
    }
  }

  updateCommentapi(comment: any, arrind: number) {
    this.processArr[arrind].isDisplayAddComment = false;
    this.processArr[arrind].isDisplayAddApprove = true;
    this.processArr[arrind].isDislplayCommentTextArea = false;
    this.processArr[arrind].isDislplayCommentUpdateBtn = false;
    this.processArr[arrind].isDisplayEditDeleteCommentSection = true;
    this.processArr[arrind].isDisplayProceedNext = true;

    let Obj = {
      process_id: this.processArr[arrind].processId,
      applicant_id: this.applicantID,
      parent_comment_id: 0,
      agent_id: this.agentCommonServiceService.getUserFromLocalStorage()?.user_id,
      comment: comment,
      lead_id: this.regObj?.customerUserID,
      comment_id: this.processArr[arrind].commentID
    }

    this.agentDataServiceService.postAgentsComment(Obj).subscribe((value) => {
      let ObjC = {
        applicant_id: this.applicantID,
        lead_id: this.regObj?.customerUserID,
        agent_id: this.regObj?.user_id,
        "process_id": this.processArr[arrind].processId,
        "comment_id": value.comment_id
      }

      this.agentDataServiceService.fetchAgentCommentSummary(ObjC).subscribe((data) => {
        this.agentCommnentArrData = data;
        this.processArr[arrind].commentData = data?.data?.comment;
        this.processArr[arrind].commentID = data?.data?.comment_id;
      })
    }, (err) => {
      console.log(err);
    })
  }

  editComment(ind: number) {
    this.processArr[ind].isDisplayAddComment = false;
    this.processArr[ind].isDisplayAddApprove = true;
    this.processArr[ind].isDislplayCommentTextArea = true;
    this.processArr[ind].isDislplayCommentUpdateBtn = true;
    this.processArr[ind].isDisplayEditDeleteCommentSection = false;
    this.processArr[ind].isDisplayProceedNext = false;

  }

  checkDeleteComment(val: any) {
    this.deleteCommentInd = val
    this.openModal();
  }

  deleteComment() {
    if (this.processArr[this.deleteCommentInd].commentID > 0) {
      let Obj = {
        comment_id: this.processArr[this.deleteCommentInd].commentID
      }
      this.agentDataServiceService.deleteComment(Obj).subscribe((value) => {
        // this.rt.navigate([this.rt.url])
        // window.location.reload();

        if (value.msg === "comments delete successfully") {
          if (this.deleteCommentInd == 0) {
            this.personalDtlsForm1.controls['comments'].setValue('')
          }
          else if (this.deleteCommentInd == 1) {
            this.personalDtlsForm2.controls['comments'].setValue('')
          }
          this.processArr[this.deleteCommentInd].isDisplayAddComment = true;
          this.processArr[this.deleteCommentInd].isDisplayAddApprove = true;
          this.processArr[this.deleteCommentInd].isDislplayCommentTextArea = true;
          this.processArr[this.deleteCommentInd].isDislplayCommentUpdateBtn = false;
          this.processArr[this.deleteCommentInd].isDisplayEditDeleteCommentSection = false;
          this.processArr[this.deleteCommentInd].isDisplayProceedNext = false;
          this.processArr[this.deleteCommentInd].commentData = '';
          this.processArr[this.deleteCommentInd].commentID = 0;
          this.display = "none";

          if(this.processArr[1].isDisplayProceedNext===true && this.processArr[0].isDisplayProceedNext===true){
            this.procced=true
            this.isChecked.emit(true)
          }else{
            this.procced=false
          }

        }

      });
    }
    else {
    }
  }

  proceedNext() {
   if(this.isMinor){
    setTimeout(() => {
    this.showKycDivOut.emit();
  });
   }else{
    setTimeout(() => {
      this.showFatcaDivOut.emit();
    });
   }
  }

  approveLead(ind: number) {
    let Obj = {
      applicant_id: this.applicantID,
      process_id: this.processArr[ind].processId,
      lead_id: this.regObj?.customerUserID
    }

    this.agentDataServiceService.approveLead(Obj).subscribe((value) => {
      this.processArr[ind].isDisplayAddComment = false;
      this.processArr[ind].isDisplayAddApprove = false;
      this.processArr[ind].isDislplayCommentTextArea = false;
      this.processArr[ind].isDislplayCommentUpdateBtn = false;
      this.processArr[ind].isDisplayEditDeleteCommentSection = false;
      this.processArr[ind].isDisplayProceedNext = true;
      this.processArr[ind].isApproved = true;
      this.processArr[ind].approveMsg = 'This section is approved';
      // location.href='#personalDtls';
      if (value.msg) {
        // this.isDisplayAddComment = false;
        // this.isDisplayAddApprove = false;
        // this.isDislplayCommentTextArea = false;
        // this.isDislplayCommentUpdateBtn = false;
        // this.isDisplayEditDeleteCommentSection = false;
        // this.isDisplayProceedNext = false;
        if(this.processArr[1].isDisplayProceedNext===true && this.processArr[0].isDisplayProceedNext===true){
          this.procced=true
          this.isChecked.emit(true)
        }

        if (this.processArr[0].isApproved && this.processArr[1].isApproved) {
          this.showFatcaDivOut.emit();
        }
      }
    })
  }
}