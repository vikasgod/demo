import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { AgentDataServiceService } from 'src/app/services/agent-data-service.service';
import { AgentCommonServiceService } from 'src/app/services/agent-common-service.service';
import { FormBuilder, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-lead-dtls2',
  templateUrl: './lead-dtls2.component.html',
  styleUrls: ['./lead-dtls2.component.css']
})
export class LeadDtls2Component implements OnInit {
  @Output() showKycDivOut = new EventEmitter<string>()
  @Output() isChecked = new EventEmitter<boolean>()

  fatcaForm: any;
  taxPurposeJurdction: string = '';
  taxIdNumber: string = '';
  tinDescNo: string = '';
  taxCountry: string = '';
  tinIssueCntry: string = '';
  cityofBirth: string = '';
  counrtryofBirth: string = '';
  applicantID: number | null = 0;
  regObj: any;
  birth_country: string = "";
  birth_county_id: string = "";
  city_of_birth: string = "";
  fatca_id: string = "";
  is_residence_for_tax: string = "";
  is_residence_for_tax_name: string = "";
  process_id: string = "";
  process_name: string = "";
  tax_identification_number: string = "";
  tin_country_id: string = "";
  tin_country_name: string = "";
  tin_description: string = "";
  tin_issue_county_id: string = "";
  tin_issues_country: string = "";
  agentCommnentArrData: any;
  display: string = "none";
  displayCommentErr = "none";
  commentID: number = 0;
  commentData: string = '';
  isDisplayAddComment: boolean = true;
  isDisplayAddApprove: boolean = true;
  isDislplayCommentTextArea: boolean = true;
  isDislplayCommentUpdateBtn: boolean = false;
  isDisplayEditDeleteCommentSection: boolean = false;
  isDisplayProceedNext: boolean = false;
  isApproved: boolean = false;
  approveMsg: string = 'This section is approved';
  roleID: any;
  accountType: any
  isMinor: any
  processId: any

  approveDisable: boolean = false;

  constructor(private agentDataServiceService: AgentDataServiceService, private agentCommonServiceService: AgentCommonServiceService, private fb: FormBuilder, private activeRt: ActivatedRoute) { }

  ngOnInit(): void {
    this.accountType = localStorage.getItem('accountType')
    let minor = localStorage.getItem('isMinor')
    if (minor == 'true') {
      this.isMinor = true
    }
    else {
      this.isMinor = false
    }

    if (this.accountType == 'Minor') {
      this.processId = 47
    }
    else {
      this.processId = 6
    }

    this.regObj = this.agentCommonServiceService.getUserFromLocalStorage();
    this.applicantID = Number(this.activeRt.snapshot.paramMap.get('applicantID'));
    this.fatcaForm = this.fb.group({
      comments: ['', Validators.required]
    })

    this.roleID = this.agentCommonServiceService.getUserFromLocalStorage()?.role_id
    if (this.roleID == 2) {
      this.isDislplayCommentTextArea = false
      this.isDisplayAddComment = false
      this.isDislplayCommentUpdateBtn = false
      this.isDisplayEditDeleteCommentSection = false
      this.approveDisable = true
      this.isDisplayAddApprove = false
      this.isDisplayProceedNext = true
      this.isChecked.emit(true)
      // this.approved = false
      // this.reviewed = false
    }

    let Obj = {
      user_id: this.regObj.user_id,
      process_id: this.processId,
      applicant_id: this.applicantID
    }

    console.log('fatca check', Obj);
    

    this.agentDataServiceService.fetchFatca(Obj).subscribe((value) => {
      if (value?.data?.[0]?.lead_status != undefined) {
        if (value?.data?.[0]?.lead_status == 'agent_review') {
          this.approveDisable = true;
          this.isDisplayAddComment = false
          this.isDislplayCommentUpdateBtn = false
          this.isDislplayCommentTextArea = false
        }
      }

      this.taxPurposeJurdction = value?.data?.[0]?.is_residence_for_tax;
      this.taxIdNumber = value?.data?.[0]?.tax_identification_number;
      this.tinDescNo = value?.data?.[0]?.tin_description;
      this.taxCountry = value?.data?.[0]?.tin_country_id;
      this.tinIssueCntry = value?.data?.[0]?.tin_issue_county_id;
      this.cityofBirth = value?.data?.[0]?.city_of_birth;
      this.counrtryofBirth = value?.data?.[0]?.birth_county_id;
      this.birth_country = value?.data?.[0]?.birth_country;
      this.birth_county_id = value?.data?.[0]?.birth_county_id;
      this.city_of_birth = value?.data?.[0]?.city_of_birth;
      this.fatca_id = value?.data?.[0]?.fatca_id;
      this.is_residence_for_tax = value?.data?.[0]?.is_residence_for_tax;
      this.is_residence_for_tax_name = value?.data?.[0]?.is_residence_for_tax_name;
      this.process_id = value?.data?.[0]?.process_id;
      this.process_name = value?.data?.[0]?.process_name;
      this.tax_identification_number = value?.data?.[0]?.tax_identification_number;
      this.tin_country_id = value?.data?.[0]?.tin_country_id;
      this.tin_country_name = value?.data?.[0]?.tin_country_name;
      this.tin_description = value?.data?.[0]?.tin_description;
      this.tin_issue_county_id = value?.data?.[0]?.tin_issue_county_id;
      this.tin_issues_country = value?.data?.[0]?.tin_issues_country;
    })

    let ObjC = {
      applicant_id: this.applicantID,
      lead_id: this.regObj?.customerUserID,
      agent_id: this.regObj?.user_id,
      process_id: this.processId
    }

    this.agentDataServiceService.fetchAgentCommentSummary(ObjC).subscribe((data) => {

      if (data?.data?.agent_status == "approved") {
        this.isDisplayAddComment = false;
        this.isDisplayAddApprove = false;
        this.isDislplayCommentTextArea = false;
        this.isDislplayCommentUpdateBtn = false;
        this.isDisplayEditDeleteCommentSection = false;
        this.isDisplayProceedNext = true;
        this.isApproved = true;
        this.approveMsg = 'This section is approved';
        this.isChecked.emit(true)
        // this.showKycDivOut.emit();
        // this.showKycDivOut.emit();

      }
      else if (data?.data?.comment_id) {
        this.isDisplayAddComment = false;
        this.isDisplayAddApprove = true;
        this.isDislplayCommentTextArea = false;
        this.isDislplayCommentUpdateBtn = false;
        this.isDisplayEditDeleteCommentSection = true;
        this.isDisplayProceedNext = true;
        this.commentData = data?.data?.comment;
        this.commentID = data?.data?.comment_id;
        this.agentCommnentArrData = data;
        // this.showKycDivOut.emit();
        // this.showKycDivOut.emit(); 
        this.isChecked.emit(true)
      }
    })
  }

  get comments() { return this.fatcaForm.get('comments').value }

  addComment() {
    if (this.fatcaForm.valid) {
      this.isDisplayAddComment = false;
      this.isDisplayAddApprove = true;
      this.isDislplayCommentTextArea = false;
      this.isDislplayCommentUpdateBtn = false;
      this.isDisplayEditDeleteCommentSection = true;
      this.isDisplayProceedNext = true;
      this.isChecked.emit(true)
      let Obj = {
        process_id: this.processId,
        applicant_id: this.applicantID,
        parent_comment_id: 0,
        agent_id: this.agentCommonServiceService.getUserFromLocalStorage()?.user_id,
        comment: this.fatcaForm.get('comments').value,
        lead_id: this.regObj?.customerUserID
      }

      this.agentDataServiceService.postAgentsComment(Obj).subscribe((value) => {
        let ObjC = {
          applicant_id: this.applicantID,
          lead_id: this.regObj?.customerUserID,
          agent_id: this.regObj?.user_id,
          process_id: this.processId
        }

        this.agentDataServiceService.fetchAgentCommentSummary(ObjC).subscribe((data) => {
          this.agentCommnentArrData = data;
          this.commentData = data?.data?.comment;
          this.commentID = data?.data?.comment_id;
        })
        console.log(value)
      }, (err) => {
        console.log(err);
      })
    }
    else {
      this.openModalComment();
    }
  }

  updateComment() {
    if (this.fatcaForm.valid) {
      this.isDisplayAddComment = false;
      this.isDisplayAddApprove = true;
      this.isDislplayCommentTextArea = false;
      this.isDislplayCommentUpdateBtn = false;
      this.isDisplayEditDeleteCommentSection = true;
      this.isDisplayProceedNext = true;
      this.isChecked.emit(true)
      let Obj = {
        process_id: this.processId,
        applicant_id: this.applicantID,
        parent_comment_id: 0,
        agent_id: this.agentCommonServiceService.getUserFromLocalStorage()?.user_id,
        comment: this.fatcaForm.get('comments').value,
        lead_id: this.regObj?.customerUserID,
        comment_id: this.commentID
      }

      this.agentDataServiceService.postAgentsComment(Obj).subscribe((value) => {
        this.commentID = value.comment_id
      }, (err) => {
        console.log(err);
      })

      let ObjC = {
        lead_id: this.regObj?.customerUserID,
        agent_id: this.regObj?.user_id,
        process_id: this.processId,
        applicant_id: this.applicantID,
        comment_id: this.commentID
      }

      this.agentDataServiceService.fetchAgentCommentSummary(ObjC).subscribe((data) => {
        this.agentCommnentArrData = data;
        this.commentData = data?.data?.comment;
        this.commentID = data?.data?.comment_id;
      })
    }
    else {
      this.openModalComment();
    }
  }

  editComment() {
    this.isDisplayAddComment = false;
    this.isDisplayAddApprove = true;
    this.isDislplayCommentTextArea = true;
    this.isDislplayCommentUpdateBtn = true;
    this.isDisplayEditDeleteCommentSection = false;
    this.isDisplayProceedNext = false;
    this.fatcaForm.controls['comments'].setValue(this.commentData)
    // let ObjC = {
    //   lead_id: this.regObj?.customerUserID,
    //   agent_id: this.agentCommonServiceService.getUserFromLocalStorage()?.user_id,
    //   process_id: 6
    // }

    // this.agentDataServiceService.fetchAgentCommentSummary(ObjC).subscribe((value) => {

    //   if (value?.data?.length > 0) {
    //     this.fatcaForm = this.fb.group({
    //       comments: [value?.data?.[0]?.comment, [Validators.required]]
    //     })
    //   }
    //   this.agentCommnentArrData = value?.data?.[0]?.agentCommnentArrData;
    // })
  }

  openModal() {
    this.display = "block";
  }
  onCloseHandled() {
    this.display = "none";
  }

  checkDeleteComment() {
    // this.isDisplayAddComment = true;
    // this.isDisplayAddApprove = true;
    // this.isDislplayCommentTextArea = true;
    // this.isDislplayCommentUpdateBtn = false;
    // this.isDisplayEditDeleteCommentSection = false;
    // this.isDisplayProceedNext = false;
    this.openModal();
  }

  deleteComment() {
    if (this.commentID > 0) {
      let Obj = {
        comment_id: this.commentID
      }
      this.agentDataServiceService.deleteComment(Obj).subscribe((value) => {
        // this.rt.navigate([this.rt.url])
        //window.location.reload();

        if (value.msg === "comments delete successfully") {
          this.fatcaForm.controls['comments'].setValue('')
          this.isDisplayAddComment = true;
          this.isDisplayAddApprove = true;
          this.isDislplayCommentTextArea = true;
          this.isDislplayCommentUpdateBtn = false;
          this.isDisplayEditDeleteCommentSection = false;

          this.isDisplayProceedNext = false;
          this.commentData = '';
          this.commentID = 0;
          this.display = "none";
        }
      });
    }
    else {
    }
  }

  proceedNext() {
    this.showKycDivOut.emit();
  }

  approveLead() {
    this.isDisplayAddComment = false;
    this.isDisplayAddApprove = false;
    this.isDislplayCommentTextArea = false;
    this.isDislplayCommentUpdateBtn = false;
    this.isDisplayEditDeleteCommentSection = false;
    this.isDisplayProceedNext = false;

    let Obj = {
      applicant_id: this.applicantID,
      process_id: this.processId,
      lead_id: this.regObj?.customerUserID
    }

    this.agentDataServiceService.approveLead(Obj).subscribe((value) => {
      this.isApproved = true;
      this.approveMsg = 'This section is approved';

      if (value?.msg) {
        this.isDisplayAddComment = false;
        this.isDisplayAddApprove = false;
        this.isDislplayCommentTextArea = false;
        this.isDislplayCommentUpdateBtn = false;
        this.isDisplayEditDeleteCommentSection = false;
        this.isDisplayProceedNext = true;
        this.isChecked.emit(true)
        // this.showKycDivOut.emit();
      }
      // location.href='#personalDtls';
    })
  }

  openModalComment() {
    this.displayCommentErr = "block";
  }

  closeModalComment() {
    this.displayCommentErr = "none";
  }
}