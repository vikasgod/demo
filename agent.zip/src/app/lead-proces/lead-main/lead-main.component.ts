import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { AgentCommonServiceService } from 'src/app/services/agent-common-service.service';
import { AgentDataServiceService } from 'src/app/services/agent-data-service.service';
import { Router } from '@angular/router';
import { FormBuilder } from '@angular/forms';

@Component({
  selector: 'app-lead-main',
  templateUrl: './lead-main.component.html',
  styleUrls: ['./lead-main.component.css']
})
export class LeadMainComponent implements OnInit {
  agentName: any;
  rejObj: any;
  applicantID: number | null = 0;
  iSshowCommentSummary: boolean = false;


  submitedDate: any;
  account_type_name: string = "";
  applicant_first_name: string = "";
  applicant_last_name: string = "";
  applicant_middle_name: string = "";


  isDisplayIndividual: boolean = true;
  isDisplayJoint: boolean = false;
  isDisplayMinor: boolean = false;


  displayRejectLeads: string = 'none';
  displayRejectLeadSuccess: string = 'none';
  commentData: any;
  comment: any;
  rejectComment: any;

  lead_reference_number: String = ''
  created_on: String = ''

  rejectDisable: boolean = false;
  dataLenght: any;
  applicantData: any=[]

  active1: boolean = true
  active2: boolean = false
  active3: boolean = false


  // tab disabled
  disabledBtn2: boolean = true;
  disabledBtn3: boolean = true;

  loader: boolean = true;

  roleID:any
  accountType:any
  isMinor:any
  processId:any

  constructor(private agentCommonServiceService: AgentCommonServiceService, private agentDataServiceService: AgentDataServiceService, private activeRt: ActivatedRoute, private rt: Router, private fb: FormBuilder) {
    this.rt.events.subscribe(() => {
    })

    this.agentCommonServiceService.applicantIndex.subscribe(res => {
      let enabledApplicant
      console.log("????????/////", res)
      let existArray = localStorage.getItem('enabledApplicant')
      if (existArray != null) {
        enabledApplicant = JSON.parse(existArray)
      }
      // let enabledApplicant=this.agentCommonServiceService.enabledApplicant
      enabledApplicant.forEach((ele: any) => {
        if (ele == 1) {
          this.disabledBtn2 = false
        } else if (ele == 2) {
          this.disabledBtn3 = false
        }
      })
      // this.getPersonalData(this.applicantData[res].applicant_personal_id)
    })
  }

  ngOnInit(): void {
    let minor=localStorage.getItem('isMinor')
    if(minor=='true'){
      this.isMinor=true
    }
    else{
      this.isMinor=false
    }
    this.accountType=localStorage.getItem('accountType')
    window.scroll(0, 0);
    this.rejectComment = this.fb.group({
      rejectcomments: ['', []]
    });

    this.roleID = this.agentCommonServiceService.getUserFromLocalStorage()?.role_id

    if(this.roleID == 2){
      this.rejectDisable = true
    }


    this.submitedDate = new Date().toLocaleDateString();
    this.rejObj = this.agentCommonServiceService.getUserFromLocalStorage();
    this.applicantID = Number(this.activeRt.snapshot.paramMap.get('applicantID'));

    this.agentName = `${this.rejObj?.first_name} ${this.rejObj?.middle_name} ${this.rejObj?.last_name}`;
    // this.getPersonalData(this.applicantID)

    this.getApplicantCount()
    setTimeout(() => {
      this.loader = false
    }, 1000);
  }

  getApplicantCount() {
    let applicantData = localStorage.getItem('applicantList')
    if (applicantData != null) {
      this.applicantData = JSON.parse(applicantData)
      this.dataLenght = this.applicantData.length
      this.getPersonalData(this.applicantID)
      this.checkApplicant()
    }
  }

  checkApplicant() {
    this.applicantData.forEach((el: any, i: number) => {
      console.log("????checkApplicant", el.applicant_personal_id, i)
      this.getUpdatedData(el.applicant_personal_id, i)
    })
  }

  getUpdatedData(applicantID: any, ind: any) {
    let unableCond1 = false
    let unableCond2 = false
    let Obj1 = {
      applicant_id: applicantID,
      lead_id: this.rejObj?.customerUserID,
      agent_id: this.rejObj?.user_id,
      process_id: 15
    }
    this.agentDataServiceService.fetchAgentCommentSummary(Obj1).toPromise().then((data) => {
      console.log('commentissssssssss', data);
      
      if (data?.data?.comment_id || data?.data?.agent_status=="approved") {
        unableCond1 = true
      } else {
        unableCond1 = false
      }
      // if (unableCond1 && unableCond2) {
      //   if (ind == 0) {
      //     this.disabledBtn2 = false
      //   } else if (ind == 1) {
      //     this.disabledBtn3 = false
      //   }
      // }
    })
    let Obj2 = {
      applicant_id: applicantID,
      lead_id: this.rejObj?.customerUserID,
      agent_id: this.rejObj?.user_id,
      process_id: 16
    }
    this.agentDataServiceService.fetchAgentCommentSummary(Obj2).toPromise().then((data) => {
      if (data?.data?.comment_id) {
        unableCond2 = true
      } else {
        unableCond2 = false
      }
    })
    if (unableCond1 && unableCond2) {
      if (ind == 0) {
        this.disabledBtn2 = false
      } else if (ind == 1) {
        this.disabledBtn3 = false
      }
    }
  }

  reload() {
    setTimeout(() => {
      window.location.reload();
    }, 300);
  }

  getPersonalData(val: any) {
    console.log(">>>>????<<<<<<<<",this.applicantData)
    var ind = this.applicantData.findIndex((el: any) => el.applicant_personal_id == val);

    if (ind == 0) {
      this.active1 = true
      this.active2 = false
      this.active3 = false
    }
    else if (ind == 1) {
      this.active1 = false
      this.active2 = true
      this.active3 = false
    }
    else if (ind == 2) {
      this.active1 = false
      this.active2 = false
      this.active3 = true
    }

    this.rt.navigate(['/dashboard', 'lead-dtls1', val]);

    // let Obj = {
    //   user_id: this.rejObj?.user_id,
    //   process_id: 4,
    //   applicant_id: val
    // }

    let Obj={}

    if(this.accountType=='Minor'){
      if(this.isMinor==true){ // minor
        Obj = {
          user_id: this.rejObj?.user_id,
          process_id: 33,
          applicant_id: this.applicantID
        }
      }else{ // Guardian 
        Obj = {
          user_id: this.rejObj?.user_id,
          process_id: 45,
          applicant_id: this.applicantID
        }
      }
    }else{
      Obj = {
        user_id: this.rejObj?.user_id,
        process_id: 4,
        applicant_id: val
      }
    }

    console.log('check main page issue ', Obj);
    
    this.agentDataServiceService.fetchPersonalDtls1(Obj).subscribe((value) => {
      console.log("/////", value)

      if (value?.data?.[0]?.lead_status != undefined) {
        if (value?.data?.[0]?.lead_status == 'agent_review') {
          this.rejectDisable = true;

        }
        if (value?.data?.[0]?.lead_status == 'approved') {
          this.rejectDisable = true;
        }
      }

      if (value?.data?.[0]?.lead_number != undefined) {
        this.lead_reference_number = value?.data?.[0]?.lead_number
        this.created_on = new Date(value?.data?.[0]?.created_on).toLocaleDateString();
      }

      this.account_type_name = value?.data?.[0]?.account_type_name;
      this.applicant_first_name = value?.data?.[0]?.applicant_first_name;
      this.applicant_last_name = value?.data?.[0]?.applicant_last_name;
      this.applicant_middle_name = value?.data?.[0]?.applicant_middle_name;

      // localStorage.setItem("account_type", JSON.stringify({type:this.account_type_name, id: val}))

      if (this.dataLenght == 1) {
        this.isDisplayIndividual = true;
        this.isDisplayJoint = false;
        this.isDisplayMinor = false;
      }

      else if (this.dataLenght == 2) {
        this.isDisplayIndividual = true;
        this.isDisplayJoint = true;
      }
      else if (this.dataLenght == 3) {
        this.isDisplayIndividual = true;
        this.isDisplayJoint = true;
        this.isDisplayMinor = true;
      }

      if (this.account_type_name === 'Individual') {
        this.isDisplayIndividual = true;
        this.isDisplayJoint = false;
        this.isDisplayMinor = false;
      }
    })
  }

  get comments() { return this.comment.get('comments') }
  agentRejectLeads() {

    // window.location.reload();
    let Obj = {
      comment: this.rejectComment.get('rejectcomments').value,
      lead_id: this.rejObj?.customerUserID,
    }
    this.agentDataServiceService.postRejectAgentLead(Obj).subscribe((data) => {
      // console.log('This is Rejected leads agent', data);
      this.commentData = data?.msg;
      this.closeRejectLeadsModal();
      this.openSuccessRejectedLeadModal();

      // setTimeout(()=>{
      //   this.closeSuccessRejectedLeadModal();

      // },1000)

      this.rt.navigate(["/dashboard"]);
      // window.location.reload();

    })
  }

  openRejectOpenModal() {
    this.displayRejectLeads = 'block';
  }

  closeRejectLeadsModal() {
    this.displayRejectLeads = 'none';
  }

  openSuccessRejectedLeadModal() {
    this.displayRejectLeadSuccess = 'block';

  }

  closeSuccessRejectedLeadModal() {
    this.displayRejectLeadSuccess = 'block';
    window.location.reload();
  }
}