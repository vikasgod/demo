import { Component, ElementRef, OnInit, ViewChild, AfterViewInit } from '@angular/core';
import { AgentDataServiceService } from 'src/app/services/agent-data-service.service';
import { ActivatedRoute } from '@angular/router';
import { AgentCommonServiceService } from 'src/app/services/agent-common-service.service';



@Component({
  selector: 'app-lead-main-content',
  templateUrl: './lead-main-content.component.html',
  styleUrls: ['./lead-main-content.component.css']
})
export class LeadMainContentComponent implements OnInit, AfterViewInit {
  // @ViewChild('UploadedocAccrBtn') UploadedocAccrBtn: ElementRef|any;
  @ViewChild('fatcaAccrdBtn') fatcaAccrdBtn: ElementRef | any;
  @ViewChild('kycAccrdBtn') kycAccrdBtn: ElementRef | any;
  @ViewChild('ContactAccrdBtn') ContactAccrdBtn: ElementRef | any;
  @ViewChild('AddressAccrdBtn') AddressAccrdBtn: ElementRef | any;
  @ViewChild('CustomerProfilerAccrdBtn') CustomerProfilerAccrdBtn: ElementRef | any;
  @ViewChild('InternetBankingAccrdBtn') InternetBankingAccrdBtn: ElementRef | any;
  @ViewChild('RelativeAccrdBtn') RelativeAccrdBtn: ElementRef | any;
  @ViewChild('NominationAccrdBtn') NominationAccrdBtn: ElementRef | any;
  //ContactAccrdBtn
  // attrTargetUploadedoc:string='';
  attrTargetFatca: string = '';
  attrTargetKyc: string = '';
  attrTargetContact: string = '';
  attrTargetAddress: string = '';
  attrTargetCustomerProfiler: string = '';
  attrTargetInternetBanking: string = '';
  attrTargetRelative: string = '';
  attrTargetNomination: string = '';
  applicantID: any;
  displayrelativeSec: boolean = false
  displayNominieeSec: boolean = false
  applicantList: any = [];
  isMinor: boolean = false
  isperSonalCheked = false
  isfatkaCheked = false
  isKycChecked = false
  isContactChecked = false
  isCustChecked = false
  isAddressChecked = false
  isinternetChecked = false
  isNominationChecked = false
  relativeChecked = false
  regObj: any
  approved: boolean = true
  reviewed: boolean = true
  allsectionReviewed: boolean = true
  allsectionapproved: boolean = true
  accountType: any

  constructor(private agentDataServiceService: AgentDataServiceService, private activeRt: ActivatedRoute, private agentCommonServiceService: AgentCommonServiceService) { }

  ngAfterViewInit(): void {
    //this.fatcaAccrdBtn.nativeElement
    // alert('This is fatca HTML element');
    // throw new Error('Method not implemented.');
  }

  ngOnInit(): void {
    this.accountType = localStorage.getItem('accountType')
    this.regObj = this.agentCommonServiceService.getUserFromLocalStorage();
    // localStorage.setItem('isMinor','false')
    this.applicantID = Number(this.activeRt.snapshot.paramMap.get('applicantID'));

    /// check minor

    let applicantData = localStorage.getItem('applicantList')
    if (applicantData != null) {
      this.applicantList = JSON.parse(applicantData)
      var index = this.applicantList.findIndex((el: any) => el.applicant_personal_id == this.applicantID);  
      if (this.accountType == 'Minor' && index == 0) {
        this.isMinor = true
        localStorage.setItem('isMinor', 'true')
      } else {
        this.isMinor = false
        localStorage.setItem('isMinor', 'false')
      }
      console.log("isminor", this.isMinor)
    }

    let Obj = {
      applicant_id: this.applicantID
    }
    this.agentDataServiceService.postAgentRelativeAgent(Obj).subscribe((data) => {
      if (data?.data.length > 0) {
        if (data?.data?.[0] != undefined && data?.data?.[0]?.applicant_relative_id != undefined) {
          this.displayrelativeSec = true;
          this.showRelativeDiv()
        } else {
          this.displayrelativeSec = false;
        }
      }
      // console.log("applicant_relative_idapplicant_relative_idapplicant_relative_id",data?.data?.[0],this.displayrelativeSec)
      // console.log("applicant_relative_idapplicant_relative_idapplicant_relative_id",data?.data?.[0]?.applicant_relative_id)
    })
    let Obj1 = {
      process_id: this.accountType =='Minor' ? 68 :25,
      applicant_id: this.applicantID
    }
    this.agentDataServiceService.fetchNomination1(Obj1).subscribe((value) => {
      if (value?.data.length > 0) {
        if (!!value?.data?.[0]?.nominee_first_name?.length) {
          this.displayNominieeSec = true
        } else {
          this.displayNominieeSec = false
        }
      }
    })

    let Obj3 = {}

    if (this.accountType == 'Minor') {
      if(this.isMinor==true){ // minor
        Obj3 = {
          user_id: this.regObj?.user_id,
          process_id: 33,
          applicant_id: this.applicantID
        }
      }else{ // Guardian 
        Obj3 = {
          user_id: this.regObj?.user_id,
          process_id: 45,
          applicant_id: this.applicantID
        }
      }
    }
    else {
      Obj3 = {
        process_id: 5,
        applicant_id: this.applicantID
      }
    }
    console.log('check main ref id and no.', Obj3);
    
    setTimeout(() => {
      this.agentDataServiceService.fetchPersonalDtls1(Obj3).subscribe((value) => {
        console.log("fetchPersonalDtls1", value)
        if (value?.data.length > 0) {
          console.log("????????????//////////////", value, value?.data[0].account_type_name.toLowerCase())
          if (value?.data[0].account_type_name == 'Minor') {
           
          }
        }
      })
    },);


    this.buttonDisabled()
  }

  // showUploadedDocDiv()
  // {
  //   this.attrTargetUploadedoc="#uploadeddoc";
  //   this.UploadedocAccrBtn.nativeElement.click();
  // }

  showFatcaDiv() {
    if (!this.isMinor) {
      this.fatcaAccrdBtn.nativeElement.click();
      this.attrTargetFatca = "#fatca";
    } else {
      this.showKycDiv()
    }
  }

  showKycDiv() {
    this.attrTargetKyc = "#kycDetails";
    this.kycAccrdBtn.nativeElement.click();
  }

  showContactDiv() {
    this.attrTargetContact = "#Contact";
    this.ContactAccrdBtn.nativeElement.click();
  }

  showAddressDiv() {
    this.attrTargetAddress = "#addressDetails";
    this.AddressAccrdBtn.nativeElement.click();
  }

  showCustomerProfilerDiv() {
    this.attrTargetCustomerProfiler = "#customerProfiler";
    this.CustomerProfilerAccrdBtn.nativeElement.click();
  }

  showInternetBankingDiv() {
    this.attrTargetInternetBanking = "#internetBanking";
    this.InternetBankingAccrdBtn.nativeElement.click();
  }

  showRelativeDiv() {
    if (this.displayrelativeSec) {
      this.attrTargetRelative = "#relatives";
      this.RelativeAccrdBtn.nativeElement.click();
    }
    else {
      this.showNominationDiv()
    }
  }

  showNominationDiv() {
    this.attrTargetNomination = "#Nominations";
    this.NominationAccrdBtn.nativeElement.click();
  }

  personalDetailsCheck(value: any) {
    this.isperSonalCheked = value
  }

  fatkaCheck(value: any) {
    this.isfatkaCheked = value;
    this.attrTargetFatca = "#fatca";
  }

  kycCheck(value: any) {
    this.isKycChecked = value;
    this.attrTargetKyc = "#kycDetails";
  }

  contactCheck(value: any) {
    this.isContactChecked = value;
    this.attrTargetContact = "#Contact";

  }

  addressCheck(value: any) {
    this.isAddressChecked = value;
    this.attrTargetAddress = "#addressDetails";
  }

  custmerCheck(value: any) {
    this.isCustChecked = value;
    this.attrTargetCustomerProfiler = "#customerProfiler";

  }

  internetCheck(value: any) {
    this.isinternetChecked = value
    this.attrTargetInternetBanking = "#internetBanking";
  }

  nominationCheck(value: any) {
    this.isNominationChecked = value
    this.attrTargetNomination = "#Nominations";
  }

  relativeCheck(value: any) {
    this.relativeChecked = value
    this.attrTargetRelative = "#relatives";
  }

  buttonDisabled() {
    let req = {
      applicant_id: this.applicantID
    }

    this.agentDataServiceService.fetchApprovedStatus(req).subscribe((value) => {
      console.log('approved', value.data);

      if (value.data.is_reviewed == 1) {
        this.allsectionReviewed = true
      }

      if (value.data.is_approved == 1) {
        this.allsectionapproved = true
      }
    })
  }

  agentApprovedLead() {
    let Obj = {
      lead_id: this.regObj?.customerUserID,
    }
    let ObjE = {
      applicant_id: this.applicantID
    }
    this.agentDataServiceService.emailPdf(ObjE).subscribe((value) => { })
    this.agentDataServiceService.postApprovedAgentLead(Obj).subscribe((data) => {
      location.href = 'dashboard';
    })
  }

  agentReviewedLead() {
    let Obj = {
      lead_id: this.regObj?.customerUserID,
    }
    this.agentDataServiceService.postReviewedAgentLead(Obj).subscribe((data) => {
      location.href = 'dashboard';
    })
  }
}