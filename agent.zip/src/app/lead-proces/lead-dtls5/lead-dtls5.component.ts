import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { AgentDataServiceService } from 'src/app/services/agent-data-service.service';
import { AgentCommonServiceService } from 'src/app/services/agent-common-service.service';
import { FormBuilder, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';


@Component({
  selector: 'app-lead-dtls5',
  templateUrl: './lead-dtls5.component.html',
  styleUrls: ['./lead-dtls5.component.css']
})
export class LeadDtls5Component implements OnInit {
  @Output() showCustomerProfilerDivOut = new EventEmitter<string>()
  @Output() isChecked = new EventEmitter<boolean>()

  addressDtlsForm1: any;
  addressDtlsForm2: any;

  addressId: string = '';
  applicantId: string = '';
  currentAddressType: string = '';
  currentAddressTypeName: string = '';
  currentCity: string = '';
  currentCountryId: string = '';
  currentCountryName: string = '';
  currentHouseNumber: string = '';
  currentHouseOrBuildingName: string = '';
  currentLandmark: string = '';
  currentPincode: string = '';
  currentRoadOrStreetName: string = '';
  currentState: string = '';
  overseasAddressType: string = '';
  overseasAddressTypeName: string = '';
  overseasCity: string = '';
  overseasCountryId: string = '';
  overseasCountryName: string = '';
  overseasHouseNumber: string = '';
  overseasHouseOrBuildingName: string = '';
  overseasLandmark: string = '';
  overseasPincode: string = '';
  overseasRoadOrStreetName: string = '';
  overseasState: string = '';
  processId: string = '';
  processName: string = '';
  jurisdictionAddressType: string = '';
  jurisdictionAddressTypeName: string = '';
  jurisdictionCity: string = '';
  jurisdictionCountrieName: string = '';
  jurisdictionCountryId: string = '';
  jurisdictionHouseNumber: string = '';
  jurisdictionHouseOrBuildingName: string = '';
  jurisdictionLandmark: string = '';
  jurisdictionPincode: string = '';
  jurisdictionRoadOrStreetName: string = '';
  jurisdictionState: string = '';
  permanentAddressType: string = '';
  permanentCountryName: string = '';
  permenantAddressType: string = '';
  permenantCity: string = '';
  permenantCountryId: string = '';
  permenantHouseNumber: string = '';
  permenantHouseOrBuildingName: string = '';
  permenantLandmark: string = '';
  permenantPincode: string = '';
  permenantRoadOrStreetName: string = '';
  permenantState: string = '';
  prefferedMailing: string = '';
  regObj: any;
  applicantID: any;
  agentCommnentArrData: any;
  display: string = "none";
  commentID: number = 0;
  commentData: string = '';
  displayCommentErr: string = "none";
  isDisplayAddComment: boolean = true;
  isDisplayAddApprove: boolean = true;
  isDislplayCommentTextArea: boolean = true;
  isDislplayCommentUpdateBtn: boolean = false;
  isDisplayEditDeleteCommentSection: boolean = false;
  isDisplayProceedNext: boolean = false;

  isApproved: boolean = true;
  approveMsg: string = '';
  approveDisable: boolean = false;
  roleID: any
  accountType: any
  isMinor: any

  processArr = [
    { process: 'Current Address', processId: 12, commentData: '', commentID: 0, isDisplayAddComment: true, isDisplayAddApprove: true, isDislplayCommentTextArea: true, isDislplayCommentUpdateBtn: false, isDisplayEditDeleteCommentSection: false, isDisplayProceedNext: false, isApproved: false, approveMsg: '', approveDisable: false },
    { process: 'Permanent Address', processId: 13, commentData: '', commentID: 0, isDisplayAddComment: true, isDisplayAddApprove: true, isDislplayCommentTextArea: true, isDislplayCommentUpdateBtn: false, isDisplayEditDeleteCommentSection: false, isDisplayProceedNext: false, isApproved: false, approveMsg: '', approveDisable: false },
  ]
  deleteCommentInd: any;
  procced: boolean = false;

  constructor(private agentDataServiceService: AgentDataServiceService, private fb: FormBuilder, private agentCommonServiceService: AgentCommonServiceService, private activeRt: ActivatedRoute) { }

  async ngOnInit() {
    this.accountType = localStorage.getItem('accountType')
    let minor = localStorage.getItem('isMinor')
    if (minor == 'true') {
      this.isMinor = true
    }
    else {
      this.isMinor = false
    }

    if (this.accountType == 'Minor') {
      this.processArr[0].processId = 53
      this.processArr[1].processId = 54
    }

    this.regObj = this.agentCommonServiceService.getUserFromLocalStorage();
    this.applicantID = Number(this.activeRt.snapshot.paramMap.get('applicantID'));

    this.addressDtlsForm1 = this.fb.group({
      comments: ['', [Validators.required]]
    })
    this.addressDtlsForm2 = this.fb.group({
      comments: ['', [Validators.required]]
    })

    this.roleID = this.agentCommonServiceService.getUserFromLocalStorage()?.role_id

    if (this.roleID == 2) {
      this.processArr[0].isDislplayCommentTextArea = false
      this.processArr[0].isDisplayAddComment = false
      this.processArr[0].isDislplayCommentUpdateBtn = false
      this.processArr[0].isDisplayEditDeleteCommentSection = false
      this.processArr[0].approveDisable = true
      this.processArr[0].isDisplayAddApprove = false

      this.processArr[1].isDislplayCommentTextArea = false
      this.processArr[1].isDisplayAddComment = false
      this.processArr[1].isDislplayCommentUpdateBtn = false
      this.processArr[1].isDisplayEditDeleteCommentSection = false
      this.processArr[1].approveDisable = true
      this.processArr[1].isDisplayAddApprove = false

      this.procced = true
      this.isChecked.emit(true)
    }

    // let Obj1 = {
    //   user_id: this.regObj.user_id,
    //   process_id: 12,
    //   applicant_id: this.applicantID
    // }

    let Obj1 = {}

    if (this.accountType == 'Minor') {
      Obj1 = {
        user_id: this.regObj?.user_id,
        process_id: 53,
        applicant_id: this.applicantID
      }
    }
    else {
      Obj1 = {
        user_id: this.regObj?.user_id,
        process_id: 12,
        applicant_id: this.applicantID
      }
    }



    this.agentDataServiceService.fetchAddressDtls1(Obj1).subscribe((value) => {

      if (value.data.length > 0) {
        if (value?.data?.[0]?.lead_status != undefined) {

          if (value?.data?.[0]?.lead_status == "approved") {
            this.processArr[0].approveDisable = true;
            this.processArr[0].isDisplayEditDeleteCommentSection = false
            this.processArr[0].approveMsg = 'This section is approved';

          }

          if (value?.data?.[0]?.lead_status == 'agent_review') {
            this.processArr[0].approveDisable = true
            this.processArr[1].approveDisable = true
            this.processArr[0].isDisplayAddComment = false
            this.processArr[1].isDisplayAddComment = false
            this.processArr[0].isDislplayCommentUpdateBtn = false
            this.processArr[1].isDislplayCommentUpdateBtn = false
            this.processArr[0].isDislplayCommentTextArea = false
            this.processArr[1].isDislplayCommentTextArea = false
          }
        }

        this.addressId = value?.data?.[0].address_id
        this.applicantId = value?.data?.[0].applicant_id
        this.currentAddressType = value?.data?.[0].current_address_type
        this.currentAddressTypeName = value?.data?.[0].current_address_type_name
        this.currentCity = value?.data?.[0].current_city
        this.currentCountryId = value?.data?.[0].current_country_id
        this.currentCountryName = value?.data?.[0].current_country_name
        this.currentHouseNumber = value?.data?.[0].current_house_number
        this.currentHouseOrBuildingName = value?.data?.[0].current_house_or_building_name
        this.currentLandmark = value?.data?.[0].current_landmark
        this.currentPincode = value?.data?.[0].current_pincode
        this.currentRoadOrStreetName = value?.data?.[0].current_road_or_street_name
        this.currentState = value?.data?.[0].current_state
        this.overseasAddressType = value?.data?.[0].overseas_address_type
        this.overseasAddressTypeName = value?.data?.[0].overseas_address_type_name
        this.overseasCity = value?.data?.[0].overseas_city
        this.overseasCountryId = value?.data?.[0].overseas_country_id
        this.overseasCountryName = value?.data?.[0].overseas_country_name
        this.overseasHouseNumber = value?.data?.[0].overseas_house_number
        this.overseasHouseOrBuildingName = value?.data?.[0].overseas_house_or_building_name
        this.overseasLandmark = value?.data?.[0].overseas_landmark
        this.overseasPincode = value?.data?.[0].overseas_pincode
        this.overseasRoadOrStreetName = value?.data?.[0].overseas_road_or_street_name
        this.overseasState = value?.data?.[0].overseas_state
        this.processId = value?.data?.[0].process_id
        this.processName = value?.data?.[0].process_name
      }
    })

    // let Obj2 = {
    //   user_id: this.regObj.user_id,
    //   process_id: 13,
    //   applicant_id: this.applicantID
    // }

    let Obj2 = {}

    if (this.accountType == 'Minor') {
      Obj2 = {
        user_id: this.regObj?.user_id,
        process_id: 54,
        applicant_id: this.applicantID
      }
    }
    else {
      Obj2 = {
        user_id: this.regObj?.user_id,
        process_id: 13,
        applicant_id: this.applicantID
      }
    }

    this.agentDataServiceService.fetchAddressDtls2(Obj2).subscribe((value) => {
      if (value?.data.length > 0) {
        if (value?.data?.[0]?.lead_status != undefined) {
          if (value?.data?.[0]?.lead_status == "approved") {
            this.processArr[1].approveDisable = true;
            this.processArr[1].isDisplayEditDeleteCommentSection = false
            this.processArr[1].approveMsg = 'This section is approved';
          }
        }

        this.jurisdictionAddressType = value?.data?.[0].jurisdiction_address_type
        this.jurisdictionAddressTypeName = value?.data?.[0].jurisdiction_address_type_name
        this.jurisdictionCity = value?.data?.[0].jurisdiction_city
        this.jurisdictionCountrieName = value?.data?.[0].jurisdiction_countrie_name
        this.jurisdictionCountryId = value?.data?.[0].jurisdiction_country_id
        this.jurisdictionHouseNumber = value?.data?.[0].jurisdiction_house_number
        this.jurisdictionHouseOrBuildingName = value?.data?.[0].jurisdiction_house_or_building_name
        this.jurisdictionLandmark = value?.data?.[0].jurisdiction_landmark
        this.jurisdictionPincode = value?.data?.[0].jurisdiction_pincode
        this.jurisdictionRoadOrStreetName = value?.data?.[0].jurisdiction_road_or_street_name
        this.jurisdictionState = value?.data?.[0].jurisdiction_state
        this.permenantAddressType = value?.data?.[0].permanent_address_type
        this.permanentCountryName = value?.data?.[0].permanent_country_name
        this.permenantCity = value?.data?.[0].permenant_city
        this.permenantCountryId = value?.data?.[0].permenant_country_id
        this.permenantHouseNumber = value?.data?.[0].permenant_house_number
        this.permenantHouseOrBuildingName = value?.data?.[0].permenant_house_or_building_name
        this.permenantLandmark = value?.data?.[0].permenant_landmark
        this.permenantPincode = value?.data?.[0].permenant_pincode
        this.permenantRoadOrStreetName = value?.data?.[0].permenant_road_or_street_name
        this.permenantState = value?.data?.[0].permenant_state
        this.prefferedMailing = value?.data?.[0].preffered_mailing
      }
    })

    for (let i = 0; i < this.processArr.length; i++) {
      await this.setComments(i)
    }
  }

  async setComments(val: number) {
    let ObjC = {
      applicant_id: this.applicantID,
      lead_id: this.regObj?.customerUserID,
      agent_id: this.regObj?.user_id,
      process_id: this.processArr[val].processId
    }

    this.agentDataServiceService.fetchAgentCommentSummary(ObjC).subscribe((data) => {
      if (data?.data?.agent_status == "approved") {
        this.processArr[val].isDisplayAddComment = false;
        this.processArr[val].isDisplayAddApprove = false;
        this.processArr[val].isDislplayCommentTextArea = false;
        this.processArr[val].isDislplayCommentUpdateBtn = false;
        this.processArr[val].isDisplayEditDeleteCommentSection = false;
        this.processArr[val].isDisplayProceedNext = true;
        // this.showCustomerProfilerDivOut.emit();

        this.processArr[val].isApproved = true;
        this.processArr[val].approveMsg = 'This section is approved';
        if (this.processArr[1].isDisplayProceedNext === true && this.processArr[0].isDisplayProceedNext === true) {
          this.procced = false
        }
      }
      else if (data?.data?.comment_id) {
        this.processArr[val].isDisplayAddComment = false;
        this.processArr[val].isDisplayAddApprove = true;
        this.processArr[val].isDislplayCommentTextArea = false;
        this.processArr[val].isDislplayCommentUpdateBtn = false;
        this.processArr[val].isDisplayEditDeleteCommentSection = true;
        this.processArr[val].isDisplayProceedNext = true;
        this.agentCommnentArrData = data;
        this.processArr[val].commentData = data?.data?.comment;
        this.processArr[val].commentID = data?.data?.comment_id;
      }

      if (val == 0) {
        this.addressDtlsForm1.controls['comments'].setValue(data?.data?.comment)
      }
      else if (val == 1) {
        this.addressDtlsForm2.controls['comments'].setValue(data?.data?.comment)
      }
      if (this.processArr[1].isDisplayProceedNext === true && this.processArr[0].isDisplayProceedNext === true) {
        this.procced = true
        this.isChecked.emit(true)
      }
    })
  }

  get comments1() { return this.addressDtlsForm1.get('comments').value }
  get comments2() { return this.addressDtlsForm2.get('comments').value }

  addComment(val: string) {
    if (val == 'Current Address') {
      if (this.addressDtlsForm1.valid) {
        let comment = this.addressDtlsForm1.get('comments').value
        let arrId = this.processArr.findIndex((res: any) => res.process == val)
        this.addCommantAPI(comment, arrId)
      }
      else {
        this.openModalComment();
      }
    }
    else if (val == 'Permanent Address') {
      if (this.addressDtlsForm2.valid) {
        let comment = this.addressDtlsForm2.get('comments').value
        let arrId = this.processArr.findIndex((res: any) => res.process == val)
        this.addCommantAPI(comment, arrId)
      }
      else {
        this.openModalComment();
      }
    }


  }

  addCommantAPI(getcomment: any, ind: number) {
    this.processArr[ind].isDisplayAddComment = false;
    this.processArr[ind].isDisplayAddApprove = true;
    this.processArr[ind].isDislplayCommentTextArea = false;
    this.processArr[ind].isDislplayCommentUpdateBtn = false;
    this.processArr[ind].isDisplayEditDeleteCommentSection = true;
    this.processArr[ind].isDisplayProceedNext = true;

    let Obj = {
      process_id: this.processArr[ind].processId,
      applicant_id: this.applicantID,
      parent_comment_id: 0,
      agent_id: this.agentCommonServiceService.getUserFromLocalStorage()?.user_id,
      comment: getcomment,
      lead_id: this.regObj?.customerUserID
    }

    this.agentDataServiceService.postAgentsComment(Obj).subscribe((value) => {
      let ObjC = {
        applicant_id: this.applicantID,
        lead_id: this.regObj?.customerUserID,
        agent_id: this.regObj?.user_id,
        process_id: this.processArr[ind].processId,
        comment_id: value.comment_id
      }

      this.agentDataServiceService.fetchAgentCommentSummary(ObjC).subscribe((data) => {
        this.agentCommnentArrData = data;
        this.processArr[ind].commentData = data?.data?.comment;
        this.processArr[ind].commentID = data?.data?.comment_id;
      })

      if (this.processArr[1].isDisplayProceedNext === true && this.processArr[0].isDisplayProceedNext === true) {
        this.procced = true
        this.isChecked.emit(true)
      }

    }, (err) => {
      console.log(err);
    })
  }

  updateComment(val: string) {
    if (val == 'Current Address') {
      if (this.addressDtlsForm1.valid) {
        let comment = this.addressDtlsForm1.get('comments').value
        let arrId = this.processArr.findIndex((res: any) => res.process == val)
        this.updateCommentAPI(comment, arrId)
      }
      else {
        this.openModalComment();
      }
    }
    else if (val == 'Permanent Address') {
      if (this.addressDtlsForm2.valid) {
        let comment = this.addressDtlsForm2.get('comments').value
        let arrId = this.processArr.findIndex((res: any) => res.process == val)
        this.updateCommentAPI(comment, arrId)
      }
      else {
        this.openModalComment();
      }
    }
  }

  updateCommentAPI(comment: string, ind: number) {
    this.processArr[ind].isDisplayAddComment = false;
    this.processArr[ind].isDisplayAddApprove = true;
    this.processArr[ind].isDislplayCommentTextArea = false;
    this.processArr[ind].isDislplayCommentUpdateBtn = false;
    this.processArr[ind].isDisplayEditDeleteCommentSection = true;
    this.processArr[ind].isDisplayProceedNext = true;

    let Obj = {
      process_id: this.processArr[ind].processId,
      applicant_id: this.applicantID,
      parent_comment_id: 0,
      agent_id: this.agentCommonServiceService.getUserFromLocalStorage()?.user_id,
      comment: comment,
      lead_id: this.regObj?.customerUserID,
      comment_id: this.commentID
    }

    this.agentDataServiceService.postAgentsComment(Obj).subscribe((value) => {
      let ObjC = {
        applicant_id: this.applicantID,
        lead_id: this.regObj?.customerUserID,
        agent_id: this.regObj?.user_id,
        process_id: this.processArr[ind].processId,
        comment_id: value.comment_id
      }

      this.agentDataServiceService.fetchAgentCommentSummary(ObjC).subscribe((data) => {
        if (data?.data?.comment_id) {
          this.processArr[ind].isDisplayAddComment = false;
          this.processArr[ind].isDisplayAddApprove = true;
          this.processArr[ind].isDislplayCommentTextArea = false;
          this.processArr[ind].isDislplayCommentUpdateBtn = false;
          this.processArr[ind].isDisplayEditDeleteCommentSection = true;
          this.processArr[ind].isDisplayProceedNext = true;

          this.agentCommnentArrData = data;
          this.processArr[ind].commentData = data?.data?.comment;
          this.processArr[ind].commentID = data?.data?.comment_id;
        }
      })
      //console.log(value)
    }, (err) => {
      console.log(err);
    })
  }

  openModal() {
    this.display = "block";
  }

  onCloseHandled() {
    this.display = "none";
  }

  editComment(ind: number) {
    this.processArr[ind].isDisplayAddComment = false;
    this.processArr[ind].isDisplayAddApprove = true;
    this.processArr[ind].isDislplayCommentTextArea = true;
    this.processArr[ind].isDislplayCommentUpdateBtn = true;
    this.processArr[ind].isDisplayEditDeleteCommentSection = false;
    this.processArr[ind].isDisplayProceedNext = false;
    // let ObjC = {
    //   lead_id: this.regObj?.customerUserID,
    //   agent_id: this.agentCommonServiceService.getUserFromLocalStorage()?.user_id,
    //   process_id: 7
    // }
    // this.agentDataServiceService.fetchAgentCommentSummary(ObjC).subscribe((value) => {
    //   if (value?.data?.length > 0) {
    //     this.addressDtlsForm1 = this.fb.group({
    //       comments: [value?.data?.[0]?.comment, [Validators.required]]
    //     })
    //   }
    //   this.agentCommnentArrData = value?.data?.[0]?.agentCommnentArrData;
    // })
  }

  checkDeleteComment(ind: number) {
    // this.isDisplayAddComment = true;
    // this.isDisplayAddApprove = true;
    // this.isDislplayCommentTextArea = true;
    // this.isDislplayCommentUpdateBtn = false;
    // this.isDisplayEditDeleteCommentSection = false;
    // this.isDisplayProceedNext = false;
    this.deleteCommentInd = ind

    this.openModal();
  }

  deleteComment() {
    if (this.processArr[this.deleteCommentInd].commentID > 0) {
      let Obj = {
        comment_id: this.processArr[this.deleteCommentInd].commentID
      }
      this.agentDataServiceService.deleteComment(Obj).subscribe((value) => {
        // window.location.reload();
        if (value.msg === "comments delete successfully") {

          if (this.deleteCommentInd == 0) {
            this.addressDtlsForm1.controls['comments'].setValue('')
          }
          else if (this.deleteCommentInd == 1) {
            this.addressDtlsForm2.controls['comments'].setValue('')
          }
          this.processArr[this.deleteCommentInd].isDisplayAddComment = true;
          this.processArr[this.deleteCommentInd].isDisplayAddApprove = true;
          this.processArr[this.deleteCommentInd].isDislplayCommentTextArea = true;
          this.processArr[this.deleteCommentInd].isDislplayCommentUpdateBtn = false;
          this.processArr[this.deleteCommentInd].isDisplayEditDeleteCommentSection = false;
          this.processArr[this.deleteCommentInd].isDisplayProceedNext = false;
          this.processArr[this.deleteCommentInd].commentData = '';
          this.processArr[this.deleteCommentInd].commentID = 0;
          this.display = "none";
          if (this.processArr[1].isDisplayProceedNext === true && this.processArr[0].isDisplayProceedNext === true) {
            this.procced = true
            this.isChecked.emit(true)
          } else {
            this.procced = false
          }
        }
      });
    }
    else {

    }

  }

  proceedNext() {
    this.showCustomerProfilerDivOut.emit();
  }

  approveLead(ind: number) {

    let Obj = {
      applicant_id: this.applicantID,
      process_id: this.processArr[ind].processId,
      lead_id: this.regObj?.customerUserID
    }

    this.agentDataServiceService.approveLead(Obj).subscribe((value) => {
      this.processArr[ind].isApproved = true;
      this.processArr[ind].approveMsg = 'This section is approved';
      this.processArr[ind].isDisplayAddComment = false;
      this.processArr[ind].isDisplayAddApprove = false;
      this.processArr[ind].isDislplayCommentTextArea = false;
      this.processArr[ind].isDislplayCommentUpdateBtn = false;
      this.processArr[ind].isDisplayEditDeleteCommentSection = false;
      this.processArr[ind].isDisplayProceedNext = false;

      if (value?.msg) {
        this.processArr[ind].isDisplayAddComment = false;
        this.processArr[ind].isDisplayAddApprove = false;
        this.processArr[ind].isDislplayCommentTextArea = false;
        this.processArr[ind].isDislplayCommentUpdateBtn = false;
        this.processArr[ind].isDisplayEditDeleteCommentSection = false;
        this.processArr[ind].isDisplayProceedNext = true;
        if (this.processArr[1].isDisplayProceedNext === true && this.processArr[0].isDisplayProceedNext === true) {
          this.procced = true
          this.isChecked.emit(true)
        }
        if (this.processArr[0].isApproved && this.processArr[1].isApproved) {
          this.showCustomerProfilerDivOut.emit();
        }
      }
      // location.href='#personalDtls';
    })
  }

  openModalComment() {
    this.displayCommentErr = "block";
  }

  closeModalComment() {
    this.displayCommentErr = "none";
  }
}