import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LeadDtlsUploadedDocComponent } from './lead-dtls-uploaded-doc.component';

describe('LeadDtlsUploadedDocComponent', () => {
  let component: LeadDtlsUploadedDocComponent;
  let fixture: ComponentFixture<LeadDtlsUploadedDocComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ LeadDtlsUploadedDocComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(LeadDtlsUploadedDocComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
