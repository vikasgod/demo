import { Component, OnInit,Output,EventEmitter} from '@angular/core';
// import { AgentDataServiceService } from 'src/app/services/agent-data-service.service';
// import { FormBuilder, Validators, FormGroup } from '@angular/forms';
// import { AgentCommonServiceService } from 'src/app/services/agent-common-service.service';
// import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-lead-dtls-uploaded-doc',
  templateUrl: './lead-dtls-uploaded-doc.component.html',
  styleUrls: ['./lead-dtls-uploaded-doc.component.css']
})
export class LeadDtlsUploadedDocComponent implements OnInit {

  // @Output() showFatcaDivOut = new EventEmitter<string>()

  // constructor(private agentDataServiceService: AgentDataServiceService, private agentCommonServiceService: AgentCommonServiceService, private fb: FormBuilder, private rt: Router, private activeRt: ActivatedRoute) { }

  ngOnInit(): void {
    
  }

}
