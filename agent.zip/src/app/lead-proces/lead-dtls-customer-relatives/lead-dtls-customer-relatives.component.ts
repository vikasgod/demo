import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { AgentCommonServiceService } from 'src/app/services/agent-common-service.service';
import { AgentDataServiceService } from 'src/app/services/agent-data-service.service';
import { FormBuilder, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-lead-dtls-customer-relatives',
  templateUrl: './lead-dtls-customer-relatives.component.html',
  styleUrls: ['./lead-dtls-customer-relatives.component.css']
})
export class LeadDtlsCustomerRelativesComponent implements OnInit {

  @Output() showNominationDivOut = new EventEmitter<string>()
  @Output() isChecked = new EventEmitter<boolean>()
  relativeForm: any;
  applicantId: string = '';
  applicant_relative_id: number = 1
  countrie_name: string = "";
  declarant_city: string = "";
  declarant_country_id: string = "";
  declarant_first_name: string = "";
  declarant_house_and_building_name: string = "";
  declarant_house_number: string = "";
  declarant_landmark: string = "";
  declarant_last_name: string = "";
  declarant_middle_name: string = "";
  declarant_pincode: string = "";
  declarant_relation: string = "";
  declarant_road_or_street_name: string = "";
  declarant_state: string = "";
  declarant_title: string = "";
  processId: string = '';
  relationship: string = '';
  regObj: any;
  applicantID: any;
  agentCommnentArrData: any;
  display: string = "none";
  commentID: number = 0;
  commentData: string = '';
  displayCommentErr = "none";
  isDisplayAddComment: boolean = true;
  isDisplayAddApprove: boolean = true;
  isDislplayCommentTextArea: boolean = true;
  isDislplayCommentUpdateBtn: boolean = false;
  isDisplayEditDeleteCommentSection: boolean = false;
  isDisplayProceedNext: boolean = false;
  isApproved: boolean = true;
  approveMsg: string = '';

  displayNominieeSec = false;

  approveDisable: boolean = false;

  constructor(private agentDataServiceService: AgentDataServiceService, private agentCommonServiceService: AgentCommonServiceService, private activeRt: ActivatedRoute, private fb: FormBuilder) { }

  ngOnInit(): void {

    this.regObj = this.agentCommonServiceService.getUserFromLocalStorage();
    this.applicantID = Number(this.activeRt.snapshot.paramMap.get('applicantID'));


    this.relativeForm = this.fb.group({
      comments: ['', Validators.required]
    })

    let Obj = {
      applicant_id: this.applicantID
    }

    this.agentDataServiceService.postAgentRelativeAgent(Obj).subscribe((data) => {
      if (data?.data?.[0]?.lead_status != undefined) {
        if (data?.data?.[0]?.lead_status == 'agent_review') {
          this.approveDisable = true;
        }
      }

      this.applicant_relative_id = data?.data[0]?.applicant_relative_id
      this.countrie_name = data?.data[0]?.countrie_name;
      this.declarant_city = data?.data[0]?.declarant_city;
      this.declarant_country_id = data?.data[0]?.declarant_country_id;
      this.declarant_first_name = data?.data[0]?.declarant_first_name;
      this.declarant_house_and_building_name = data?.data[0]?.declarant_house_and_building_name;
      this.declarant_house_number = data?.data[0]?.declarant_house_number;
      this.declarant_landmark = data?.data[0]?.declarant_landmark;
      this.declarant_last_name = data?.data[0]?.declarant_last_name;
      this.declarant_middle_name = data?.data[0]?.declarant_middle_name;
      this.declarant_pincode = data?.data[0]?.declarant_pincode;
      this.declarant_relation = data?.data[0]?.declarant_relation;
      this.declarant_road_or_street_name = data?.data[0]?.declarant_road_or_street_name;
      this.declarant_state = data?.data[0]?.declarant_state;
      this.declarant_title = data?.data[0]?.declarant_title;
    })

    let ObjC = {
      applicant_id: this.applicantID,
      lead_id: this.regObj?.customerUserID,
      agent_id: this.regObj?.user_id,
      process_id: 21
    }

    this.agentDataServiceService.fetchAgentCommentSummary(ObjC).subscribe((data) => {
      if (data?.data?.agent_status == "approved") {
        this.isDisplayAddComment = false;
        this.isDisplayAddApprove = false;
        this.isDislplayCommentTextArea = false;
        this.isDislplayCommentUpdateBtn = false;
        this.isDisplayEditDeleteCommentSection = false;
        this.isDisplayProceedNext = false;

        this.isApproved = true;
        this.approveMsg = 'This section is approved';

        this.showNominationDivOut.emit();
        this.showNominationDivOut.emit();
      }
      else if (data?.data?.comment_id) {
        this.isDisplayAddComment = false;
        this.isDisplayAddApprove = true;
        this.isDislplayCommentTextArea = false;
        this.isDislplayCommentUpdateBtn = false;
        this.isDisplayEditDeleteCommentSection = true;
        this.isDisplayProceedNext = true;
        this.isChecked.emit(true)
        this.agentCommnentArrData = data;
        this.commentData = data?.data?.comment;
        this.commentID = data?.data?.comment_id;
        console.log('relative comment data', data)

      }
    })

    let Obj1 = {
      process_id: this.regObj.accountType =='Minor' ? 68 :25,
      applicant_id: this.applicantID
    }
    this.agentDataServiceService.fetchNomination1(Obj1).subscribe((value) => {
      if (value?.data.length > 0) {
        if (value?.data?.[0].nominee_first_name != null && value?.data?.[0].nominee_first_name != undefined) {
          this.displayNominieeSec = true
        } else {
          this.displayNominieeSec = false
        }
      }
    })
  }

  get comments() { return this.relativeForm.get('comments').value }

  addComment() {
    if (this.relativeForm.valid) {
      this.isDisplayAddComment = false;
      this.isDisplayAddApprove = true;
      this.isDislplayCommentTextArea = false;
      this.isDislplayCommentUpdateBtn = false;
      this.isDisplayEditDeleteCommentSection = true;
      this.isDisplayProceedNext = true;
      this.isChecked.emit(true)

      let Obj = {
        process_id: 21,
        applicant_id: this.applicantID,
        parent_comment_id: 0,
        agent_id: this.agentCommonServiceService.getUserFromLocalStorage()?.user_id,
        comment: this.relativeForm.get('comments').value,
        lead_id: this.regObj?.customerUserID
      }

      this.agentDataServiceService.postAgentsComment(Obj).subscribe((value) => {
        console.log(value);
        let ObjC = {
          applicant_id: this.applicantID,
          lead_id: this.regObj?.customerUserID,
          agent_id: this.regObj?.user_id,
          process_id: 21,
          comment_id: this.commentID
        }

        this.agentDataServiceService.fetchAgentCommentSummary(ObjC).subscribe((data) => {
          console.log("This is agents comment", data);
          this.agentCommnentArrData = data;
          this.commentData = data?.data?.comment;
          this.commentID = data?.data?.comment_id;
        })
      }, (err) => {
        console.log(err);
      })
    } else {
      this.openModalComment()
    }
  }

  updateComment() {
    if (this.relativeForm.valid) {
      this.isDisplayAddComment = false;
      this.isDisplayAddApprove = true;
      this.isDislplayCommentTextArea = false;
      this.isDislplayCommentUpdateBtn = false;
      this.isDisplayEditDeleteCommentSection = true;
      this.isDisplayProceedNext = true;
      this.isChecked.emit(true)
      let Obj = {
        process_id: 21,
        applicant_id: this.applicantID,
        parent_comment_id: 0,
        agent_id: this.agentCommonServiceService.getUserFromLocalStorage()?.user_id,
        comment: this.relativeForm.get('comments').value,
        lead_id: this.regObj?.customerUserID,
        comment_id: this.commentID
      }

      this.agentDataServiceService.postAgentsComment(Obj).subscribe((value) => {
        this.commentID = value.comment_id
        let ObjC = {
          lead_id: this.regObj?.customerUserID,
          agent_id: this.regObj?.user_id,
          process_id: 21,
          applicant_id: this.applicantID,
        }

        this.agentDataServiceService.fetchAgentCommentSummary(ObjC).subscribe((data) => {
          console.log("This is agents comment", data);
          if (data?.data?.comment_id) {
            this.isDisplayAddComment = false;
            this.isDisplayAddApprove = true;
            this.isDislplayCommentTextArea = false;
            this.isDislplayCommentUpdateBtn = false;
            this.isDisplayEditDeleteCommentSection = true;
            this.isDisplayProceedNext = true;
            this.isChecked.emit(true)
            this.agentCommnentArrData = data;
            this.commentData = data?.data.comment;
            this.commentID = data?.data?.comment_id;
          }
        })
        //console.log(value)
      }, (err) => {
        console.log(err);
      })
    }
    else {

      this.openModalComment();
    }

  }

  openModal() {
    this.display = "block";
  }

  onCloseHandled() {
    this.display = "none";
  }

  editComment() {
    this.isDisplayAddComment = false;
    this.isDisplayAddApprove = true;
    this.isDislplayCommentTextArea = true;
    this.isDislplayCommentUpdateBtn = true;
    this.isDisplayEditDeleteCommentSection = false;
    this.isDisplayProceedNext = false;

    this.relativeForm.controls['comments'].setValue(this.commentData)


    // let ObjC = {
    //   lead_id: this.regObj?.customerUserID,
    //   agent_id: this.agentCommonServiceService.getUserFromLocalStorage()?.user_id,
    //   process_id: 7
    // }

    // this.agentDataServiceService.fetchAgentCommentSummary(ObjC).subscribe((value) => {

    //   if (value?.data?.length > 0) {
    //     // this.relativeForm = this.fb.group({
    //     //   comments: [value?.data?.[0]?.comment, [Validators.required]]
    //     // })
    //     this.relativeForm.controls['comments'].setValue(value?.data?.comment)
    //   }
    //   this.agentCommnentArrData = value?.data?.agentCommnentArrData;
    // })

    console.log(this.commentData);
  }

  checkDeleteComment() {
    // this.isDisplayAddComment = true;
    // this.isDisplayAddApprove = true;
    // this.isDislplayCommentTextArea = true;
    // this.isDislplayCommentUpdateBtn = false;
    // this.isDisplayEditDeleteCommentSection = false;
    // this.isDisplayProceedNext = false;

    this.openModal();
  }

  deleteComment() {
    if (this.commentID > 0) {
      let Obj = {
        comment_id: this.commentID
      }
      this.agentDataServiceService.deleteComment(Obj).subscribe((value) => {
        if (value.msg === "comments delete successfully") {
          this.relativeForm.controls['comments'].setValue('')
          this.isDisplayAddComment = true;
          this.isDisplayAddApprove = true;
          this.isDislplayCommentTextArea = true;
          this.isDislplayCommentUpdateBtn = false;
          this.isDisplayEditDeleteCommentSection = false;

          this.isDisplayProceedNext = false;
          this.commentData = '';
          this.commentID = 0;
          this.display = "none";
        }
      });
    } else {

    }

  }

  proceedNext() {
    if (this.displayNominieeSec) {
      this.showNominationDivOut.emit();
      return;
    }
    window.alert(' Review Doc Section !');
    window.scroll({
      top: 0,
      left: 0,
      behavior: 'smooth'
    });

  }

  approveLead() {

    let Obj = {
      applicant_id: this.applicantID,
      process_id: 21,
      lead_id: this.regObj?.customerUserID
    }

    this.agentDataServiceService.approveLead(Obj).subscribe((value) => {
      this.isApproved = true;
      this.approveMsg = 'This section is approved'

      // location.href='#personalDtls';

      if (value?.msg) {
        this.isDisplayAddComment = false;
        this.isDisplayAddApprove = false;
        this.isDislplayCommentTextArea = false;
        this.isDislplayCommentUpdateBtn = false;
        this.isDisplayEditDeleteCommentSection = false;
        this.isDisplayProceedNext = false;

        this.showNominationDivOut.emit();
      }

    })

  }


  openModalComment() {
    this.displayCommentErr = "block";
  }

  closeModalComment() {
    this.displayCommentErr = "none";
  }

}
