import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { AgentDataServiceService } from 'src/app/services/agent-data-service.service';
import { AgentCommonServiceService } from 'src/app/services/agent-common-service.service';
import { FormBuilder, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-lead-dtls8',
  templateUrl: './lead-dtls8.component.html',
  styleUrls: ['./lead-dtls8.component.css']
})
export class LeadDtls8Component implements OnInit {

  @Output() isChecked = new EventEmitter<boolean>()

  nominationForm: any;
  applicantId: string = '';
  isOpted: string = '';
  isOpted_value: string = '';
  nominationId: string = '';
  nomineeAddressType: string = '';
  nomineeCity: string = '';
  nomineeCountry: string = '';
  nomineeDateOfBirth: string = '';
  nomineeFirstName: string = '';
  nomineeHouseNumber: string = '';
  nomineeHouseOrBuildingName: string = '';
  nomineeLandkmark: string = '';
  nomineeLastName: string = '';
  nomineeMiddleName: string = '';
  nomineePincode: string = '';
  nomineeRoadOrStreetName: string = '';
  nomineeState: string = '';
  nomineeTitle: string = '';
  processId: string = '';
  processName: string = '';
  relationship: string = '';
  regObj: any;
  applicantID: any;
  agentCommnentArrData: any;
  display: string = "none";
  commentID: number = 0;
  commentData: string = '';
  displayCommentErr = "none";
  isDisplayAddComment: boolean = true;
  isDisplayAddApprove: boolean = true;
  isDislplayCommentTextArea: boolean = true;
  isDislplayCommentUpdateBtn: boolean = false;
  isDisplayEditDeleteCommentSection: boolean = false;
  // isDisplayProceedNext: boolean = false;
  isDisplayReviewed: boolean = true;
  isApproved: boolean = true;
  approveMsg: string = '';
  approveDisable: boolean = false;
  rejectedDisable: boolean = false;
  approvedDisable: boolean = false;
  reviewDisabled: boolean = false;
  displayNominieeSec: boolean = false;
  applicantList: any = [];
  showProceed: boolean = false;
  roleID: any
  reviewed: boolean = true
  approved: boolean = true
  accountType:any
  isMinor:any
  process_Id:any
  constructor(private agentDataServiceService: AgentDataServiceService, private fb: FormBuilder, private agentCommonServiceService: AgentCommonServiceService, private activeRt: ActivatedRoute, private rt: Router) { }

  ngOnInit(): void {
    this.accountType = localStorage.getItem('accountType')
    let minor = localStorage.getItem('isMinor')
    if (minor == 'true') {
      this.isMinor = true
    }
    else {
      this.isMinor = false
    }

    if (this.accountType == 'Minor') {
      this.process_Id = 68
    }
    else {
      this.process_Id = 26
    }

    this.regObj = this.agentCommonServiceService.getUserFromLocalStorage();
    this.applicantID = Number(this.activeRt.snapshot.paramMap.get('applicantID'));
    this.nominationForm = this.fb.group({
      comments: ['', Validators.required]
    })


    this.roleID = this.agentCommonServiceService.getUserFromLocalStorage()?.role_id

    if (this.roleID == 2) {
      this.isDislplayCommentTextArea = false
      this.isDisplayAddComment = false
      this.isDislplayCommentUpdateBtn = false
      this.isDisplayEditDeleteCommentSection = false
      this.approveDisable = true
      this.isDisplayAddApprove = false
      this.approved = false
      this.reviewed = false
    }

    // let Obj1 = {
    //   user_id: this.regObj.user_id,
    //   process_id: 25,
    //   applicant_id: this.applicantID
    // }

    let Obj1 = {}

    // if (this.accountType == 'Minor') {
    //   if (!this.isMinor) { // Guardian 
    //     Obj1 = {
    //       user_id: this.regObj?.user_id,
    //       // process_id: 67,
    //       process_id: 68,
    //       applicant_id: this.applicantID
    //     }
    //   }
    // }
    // else {
      Obj1 = {
        user_id: this.regObj?.user_id,
        process_id: this.accountType =='Minor' ? 68 :25,
        applicant_id: this.applicantID
      }
    // }


    this.agentDataServiceService.fetchNomination1(Obj1).subscribe((value) => {
      if (value?.data?.[0].nomination_id != null && value?.data?.[0].nomination_id != undefined) {
        this.displayNominieeSec = true
      } else {
        this.displayNominieeSec = false
      }

      if (value?.data?.[0]?.lead_status != undefined) {
        if (value?.data?.[0]?.lead_status == 'agent_review') {
          this.approveDisable = true;
          this.reviewDisabled = true;
          this.isDisplayAddApprove = false
          this.isDisplayAddComment = false
          this.isDislplayCommentUpdateBtn = false
          this.isDislplayCommentTextArea = false
        }
        else if (value?.data?.[0]?.lead_status == 'approved') {
          this.rejectedDisable = true;
          this.approvedDisable = true;
          this.reviewDisabled = true;
        }
      }

      this.applicantId = value?.data?.[0].applicant_id
      this.isOpted = value?.data?.[0].is_opted
      this.isOpted_value = value?.data?.[0].is_opted_value
      this.nominationId = value?.data?.[0].nomination_id
      this.nomineeAddressType = value?.data?.[0].nominee_address_type
      this.nomineeCity = value?.data?.[0].nominee_city
      this.nomineeCountry = value?.data?.[0].nominee_country

      let nomineeDateOfBirthType = new Date(value?.data?.[0].nominee_date_of_birth);
      this.nomineeDateOfBirth = `${nomineeDateOfBirthType.getDate()}/${nomineeDateOfBirthType.getMonth()}/${nomineeDateOfBirthType.getFullYear()}`;
      this.nomineeFirstName = value?.data?.[0].nominee_first_name
      this.nomineeHouseNumber = value?.data?.[0].nominee_house_number
      this.nomineeHouseOrBuildingName = value?.data?.[0].nominee_house_or_building_name
      this.nomineeLandkmark = value?.data?.[0].nominee_landkmark
      this.nomineeLastName = value?.data?.[0].nominee_last_name
      this.nomineeMiddleName = value?.data?.[0].nominee_middle_name
      this.nomineePincode = value?.data?.[0].nominee_pincode
      this.nomineeRoadOrStreetName = value?.data?.[0].nominee_roaNor_street_name
      this.nomineeState = value?.data?.[0].nominee_state
      this.nomineeTitle = value?.data?.[0].nominee_title
      this.processId = value?.data?.[0].process_id
      this.processName = value?.data?.[0].process_name
      this.relationship = value?.data?.[0].relationship
    })

    // let Obj2 = {
    //   user_id: this.regObj.user_id,
    //   process_id: this.process_Id,
    //   applicant_id: this.applicantID
    // }

    let Obj2 = {}

    if (this.accountType == 'Minor') {
      if (this.isMinor == true) { // Guardian 
        Obj2 = {
          user_id: this.regObj?.user_id,
          process_id: 68,
          applicant_id: this.applicantID
        }
      }
    }
    else {
      Obj2 = {
        user_id: this.regObj?.user_id,
        process_id: 26,
        applicant_id: this.applicantID
      }
    }

    this.agentDataServiceService.fetchNomination2(Obj2).subscribe((value) => { })

    // let Obj3 = {
    //   user_id: this.regObj.user_id,
    //   process_id: 27,
    //   applicant_id: this.applicantID
    // }

    let Obj3 = {}

    if (this.accountType == 'Minor') {
      if (this.isMinor == true) { // Guardian 
        Obj3 = {
          user_id: this.regObj?.user_id,
          process_id: 69,
          applicant_id: this.applicantID
        }
      }
    }
    else {
      Obj3 = {
        user_id: this.regObj?.user_id,
        process_id: 27,
        applicant_id: this.applicantID
      }
    }


    this.agentDataServiceService.fetchNomination3(Obj3).subscribe((value) => { })

    let ObjD = {
      applicant_id: this.applicantID,
      lead_id: this.regObj?.customerUserID,
      agent_id: this.regObj?.user_id,
      process_id: this.process_Id
    }

    this.agentDataServiceService.fetchAgentCommentSummary(ObjD).subscribe((data) => {

      if (data?.data?.agent_status == "approved") {
        this.isDisplayAddComment = false;
        this.isDisplayAddApprove = false;
        this.isDislplayCommentTextArea = false;
        this.isDislplayCommentUpdateBtn = false;
        this.isDisplayEditDeleteCommentSection = false;
        this.isApproved = true;
        this.approveMsg = 'This section is approved';
        this.isChecked.emit(true)

      }

      else if (data?.data?.comment_id) {
        this.isDisplayAddComment = false;
        this.isDisplayAddApprove = true;
        this.isDislplayCommentTextArea = false;
        this.isDislplayCommentUpdateBtn = false;
        this.isDisplayEditDeleteCommentSection = true;
        // this.isDisplayProceedNext = true;
        this.isDisplayReviewed = true;
        this.agentCommnentArrData = data;
        this.commentData = data?.data?.comment;
        this.commentID = data?.data?.comment_id;
        this.isChecked.emit(true)
        console.log(">>>>>>>>>>>>>>>>>>>data?.data?.comment", data?.data?.comment, this.isDisplayEditDeleteCommentSection)
      }
    })

    let applicantData = localStorage.getItem('applicantList')
    if (applicantData != null) {
      this.applicantList = JSON.parse(applicantData)
      var index = this.applicantList.findIndex((el: any) => el.applicant_personal_id == this.applicantID);
      if (this.applicantList.length > 1 && (index != this.applicantList.length - 1)) {
        this.showProceed = true
      } else {
        this.showProceed = false
      }
    }
  }

  get comments() { return this.nominationForm.get('comments').value }

  addComment() {
    if (this.nominationForm.valid) {
      this.isDisplayAddComment = false;
      this.isDisplayAddApprove = true;
      this.isDislplayCommentTextArea = false;
      this.isDislplayCommentUpdateBtn = false;
      this.isDisplayEditDeleteCommentSection = true;
      // this.isDisplayProceedNext = true;
      this.isDisplayReviewed = true;

      let Obj = {
        process_id: this.process_Id,
        applicant_id: this.applicantID,
        parent_comment_id: 0,
        agent_id: this.agentCommonServiceService.getUserFromLocalStorage()?.user_id,
        comment: this.nominationForm.get('comments').value,
        lead_id: this.regObj?.customerUserID
      }

      this.agentDataServiceService.postAgentsComment(Obj).subscribe((value) => {
        let ObjC = {
          applicant_id: this.applicantID,
          lead_id: this.regObj?.customerUserID,
          agent_id: this.regObj?.user_id,
          process_id: this.process_Id
        }

        this.agentDataServiceService.fetchAgentCommentSummary(ObjC).subscribe((data) => {
          this.agentCommnentArrData = data;
          this.commentData = data?.data?.comment;
          this.commentID = data?.data?.comment_id;
        })
      }, (err) => {
        console.log(err);
      })
    } else {
      this.openModalComment();
    }
  }

  updateComment() {
    if (this.nominationForm.valid) {
      this.isDisplayAddComment = false;
      this.isDisplayAddApprove = true;
      this.isDislplayCommentTextArea = false;
      this.isDislplayCommentUpdateBtn = false;
      this.isDisplayEditDeleteCommentSection = true;
      // this.isDisplayProceedNext = true;
      this.isChecked.emit(true)
      this.isDisplayReviewed = false;

      let Obj = {
        process_id: this.process_Id,
        applicant_id: this.applicantID,
        parent_comment_id: 0,
        agent_id: this.agentCommonServiceService.getUserFromLocalStorage()?.user_id,
        comment: this.nominationForm.get('comments').value,
        lead_id: this.regObj?.customerUserID,
        comment_id: this.commentID
      }

      this.agentDataServiceService.postAgentsComment(Obj).subscribe((value) => {
        //console.log(value)
      }, (err) => {
        console.log(err);
      })

      let ObjC = {
        applicant_id: this.applicantID,
        lead_id: this.regObj?.customerUserID,
        agent_id: this.regObj?.user_id,
        process_id: this.process_Id,
        comment_id: this.commentID
      }

      this.agentDataServiceService.fetchAgentCommentSummary(ObjC).subscribe((data) => {
        if (data?.data?.agent_status == "approved") {
          this.isDisplayAddComment = false;
          this.isDisplayAddApprove = false;
          this.isDislplayCommentTextArea = false;
          this.isDislplayCommentUpdateBtn = false;
          this.isDisplayEditDeleteCommentSection = false;
          // this.isDisplayProceedNext = false;
          this.isDisplayReviewed = false;
          this.isApproved = true;
          this.approveMsg = 'This section is approved';
          this.isChecked.emit(true)


        }
        else if (data?.data?.comment_id) {
          this.isDisplayAddComment = false;
          this.isDisplayAddApprove = true;
          this.isDislplayCommentTextArea = false;
          this.isDislplayCommentUpdateBtn = false;
          this.isDisplayEditDeleteCommentSection = true;
          // this.isDisplayProceedNext = true;
          this.isDisplayReviewed = false;
          this.commentData = data?.data.comment;
          this.commentID = data?.data?.comment_id;
          this.agentCommnentArrData = data;
          this.isChecked.emit(true)

        }
      })
    }
    else {
      this.openModalComment();
    }
  }

  openModal() {
    this.display = "block";
  }

  onCloseHandled() {
    this.display = "none";
  }

  editComment() {
    this.nominationForm.controls['comments'].setValue(this.commentData)
    this.isDisplayAddComment = false;
    this.isDisplayAddApprove = true;
    this.isDislplayCommentTextArea = true;
    this.isDislplayCommentUpdateBtn = true;
    this.isDisplayEditDeleteCommentSection = false;
    // this.isDisplayProceedNext = false;
    this.isDisplayReviewed = false;
    this.isChecked.emit(true)


    let ObjC = {
      applicant_id: this.applicantID,
      lead_id: this.regObj?.customerUserID,
      agent_id: this.agentCommonServiceService.getUserFromLocalStorage()?.user_id,
      process_id: this.process_Id,
      comment_id: this.commentID
    }

    this.agentDataServiceService.fetchAgentCommentSummary(ObjC).subscribe((value) => {
      if (value?.data?.length > 0) {
        // this.nominationForm = this.fb.group({
        //   comments: [value?.data?.[0]?.comment, [Validators.required]]
        // })
        this.nominationForm.controls['comments'].setValue(value?.data?.comment)
      }
      this.agentCommnentArrData = value?.data?.[0]?.agentCommnentArrData;
    })
  }

  checkDeleteComment() {
    this.openModal();
  }

  deleteComment() {
    if (this.commentID > 0) {
      let Obj = {
        comment_id: this.commentID
      }
      this.agentDataServiceService.deleteComment(Obj).subscribe((value) => {
        if (value.msg === "comments delete successfully") {
          this.nominationForm.controls['comments'].setValue('')
          this.isDisplayAddComment = true;
          this.isDisplayAddApprove = true;
          this.isDislplayCommentTextArea = true;
          this.isDislplayCommentUpdateBtn = false;
          this.isDisplayEditDeleteCommentSection = false;

          this.showProceed = false;
          this.commentData = '';
          this.commentID = 0;
          this.display = "none";

        }
      });
    }
    else {
    }
  }

  proceedNext() {
  }

  approveLead() {
    this.isDisplayAddComment = false;
    this.isDisplayAddApprove = false;
    this.isDislplayCommentTextArea = false;
    this.isDislplayCommentUpdateBtn = false;
    this.isDisplayEditDeleteCommentSection = false;
    // this.isDisplayProceedNext = false;
    this.isDisplayReviewed = true;
    this.isChecked.emit(true)

    let Obj = {
      applicant_id: this.applicantID,
      process_id: this.process_Id,
      lead_id: this.regObj?.customerUserID
    }

    this.agentDataServiceService.approveLead(Obj).subscribe((value) => {
      this.isApproved = true;
      this.approveMsg = 'This section is approved'
      // location.href='#personalDtls';
    })
  }

  agentReviewedLead() {
    let Obj = {
      lead_id: this.regObj?.customerUserID,
    }
    this.agentDataServiceService.postReviewedAgentLead(Obj).subscribe((data) => {
      location.href = 'dashboard';
    })
  }

  agentApprovedLead() {
    let Obj = {
      lead_id: this.regObj?.customerUserID,
    }
    let ObjE = {
      applicant_id: this.applicantID
    }
    this.agentDataServiceService.emailPdf(ObjE).subscribe((value) => { })
    this.agentDataServiceService.postApprovedAgentLead(Obj).subscribe((data) => {
      location.href = 'dashboard';
    })
  }

  openModalComment() {
    this.displayCommentErr = "block";
    console.log("block");

  }

  closeModalComment() {
    this.displayCommentErr = "none";
    console.log("none");

  }

  nextApplicant() {
    // let existArray
    // let enabledApplicant = localStorage.getItem('enabledApplicant')
    // if (enabledApplicant != null) {
    //   existArray = JSON.parse(enabledApplicant)
    // }
    // var index = this.applicantList.findIndex((el: any) => el.applicant_personal_id == this.applicantID);
    // console.log("?????????", this.applicantID, index + 1, this.agentCommonServiceService.enabledApplicant);
    // //  existArray=this.agentCommonServiceService.enabledApplicant
    // if (existArray.indexOf(index + 1) === -1) {
    //   existArray.push(index + 1)
    // }
    // // this.agentCommonServiceService.enabledApplicant=existArray
    // localStorage.setItem('enabledApplicant', JSON.stringify(existArray))
    // setTimeout(() => {
    //   this.agentCommonServiceService.applicantIndex.next(index + 1)
    //   this.rt.navigate(['/dashboard', 'lead-dtls1', this.applicantList[index + 1].applicant_personal_id]);
    //   setTimeout(() => {
    //     window.location.reload();
    //   }, 300);
    // }, 500);

    window.alert(' Review Doc Section !')
    window.scroll({ 
            top: 0, 
            left: 0, 
            behavior: 'smooth' 
     });
  }
}
