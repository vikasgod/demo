import { Component, OnInit, ViewChild, ElementRef, AfterViewInit } from '@angular/core';
import { AgentCommonServiceService } from 'src/app/services/agent-common-service.service';
import { AgentDataServiceService } from 'src/app/services/agent-data-service.service';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
//import Drift from 'drift-zoom';

@Component({
  selector: 'app-lead-doc-img',
  templateUrl: './lead-doc-img.component.html',
  styleUrls: ['./lead-doc-img.component.css']
})
export class LeadDocImgComponent implements OnInit, AfterViewInit {
  constructor(private agentDataServiceService: AgentDataServiceService, private agentCommonServiceService: AgentCommonServiceService, private fb: FormBuilder, private activeRt: ActivatedRoute, private rt: Router) {
  }
  demoTrgiggerElement: any;
  iSinlinePane: any = false;
  @ViewChild('demoTrgigger') demoTrigger: ElementRef<HTMLInputElement> | undefined;
  @ViewChild('details') paneContainer: ElementRef<HTMLInputElement> | undefined;

  imgSrcPsportFront: string = '';
  imgSrcPsportBack: string = '';
  imgSrcAddressProof: string = '';
  imgSrcFrom60: string = '';
  imgSrcVisaOrOci: string = '';
  imgSrcPio1: string = '';
  imgSrcPio2: string = '';
  imgSrcOci: string = '';
  imgSrcVisa: string = '';
  imgSrcOtherDoc: string = '';
  applicantID: any;
  addressProofData: any;
  popUpImgSrc: string = '';
  regObj: any;
  documentCommentForm: any;
  agentCommnentArrData: any;
  isUpdateCommentDisplay: boolean = false;
  isCommentSuccessfull: boolean = false;
  isDisplayUpdateBtn: boolean = false;
  isDisplayCommentTextarea: boolean = true;
  isDisplayCommentEditArea: boolean = false;

  isDisplayProceedNext: boolean = false;
  isDisplayApproveBtn: boolean = true;
  isDislplayCommentTextArea: boolean = true;
  isDisplayAddComment: boolean = true;
  isDislplayCommentUpdateBtn: boolean = false;
  isDisplayAddApprove: boolean = true;
  isDisplayEditDeleteCommentSection: boolean = false;
  approveDisable: boolean = true

  isApproved: boolean = false;
  commentID: number = 0;
  display: string = "none";
  approveMsg: string = '';
  commentData: any;
  comment: any;
  rejectComment: any;
  currentLeadID: number = 0;
  displayRejectLeads: string = 'none';
  displayRejectLeadSuccess: string = 'none';
  agentID: number = 0;
  superAgentListDataArr: Array<any> = [];
  customerUserID: number = 0
  passportsection: any
  addressProof: any
  form60: any
  imgoci: any
  imgVisa: any
  imgPio: any
  otherDoc: any
  deleteCommentInd: any

  displayCommentErr: any
  roleID: any;
  modalImage: any;
  imagemodal: any
  accountType: any
  isMinor: any;
  rejectDisable: boolean = false;
  rejObj: any;
  applicantList: any;
  applicantData: any;
  showProceed = false;
  is_review_loading = false;
  is_approve_loading = false;
  processArr = [
    { process: 'Password', processId: 18, commentData: '', commentID: 0, isDisplayAddComment: true, isDisplayAddApprove: true, isDislplayCommentTextArea: true, isDislplayCommentUpdateBtn: false, isDisplayEditDeleteCommentSection: false, isDisplayProceedNext: false, isApproved: false, approveMsg: '', approveDisable: false },
    { process: 'Address Proof', processId: 19, commentData: '', commentID: 0, isDisplayAddComment: true, isDisplayAddApprove: true, isDislplayCommentTextArea: true, isDislplayCommentUpdateBtn: false, isDisplayEditDeleteCommentSection: false, isDisplayProceedNext: false, isApproved: false, approveMsg: '', approveDisable: false },
    { process: 'Form 60', processId: 22, commentData: '', commentID: 0, isDisplayAddComment: true, isDisplayAddApprove: true, isDislplayCommentTextArea: true, isDislplayCommentUpdateBtn: false, isDisplayEditDeleteCommentSection: false, isDisplayProceedNext: false, isApproved: false, approveMsg: '', approveDisable: false },
    { process: 'OCI', processId: 73, commentData: '', commentID: 0, isDisplayAddComment: true, isDisplayAddApprove: true, isDislplayCommentTextArea: true, isDislplayCommentUpdateBtn: false, isDisplayEditDeleteCommentSection: false, isDisplayProceedNext: false, isApproved: false, approveMsg: '', approveDisable: false },
    { process: 'Visa', processId: 23, commentData: '', commentID: 0, isDisplayAddComment: true, isDisplayAddApprove: true, isDislplayCommentTextArea: true, isDislplayCommentUpdateBtn: false, isDisplayEditDeleteCommentSection: false, isDisplayProceedNext: false, isApproved: false, approveMsg: '', approveDisable: false },
    { process: 'PIO', processId: 32, commentData: '', commentID: 0, isDisplayAddComment: true, isDisplayAddApprove: true, isDislplayCommentTextArea: true, isDislplayCommentUpdateBtn: false, isDisplayEditDeleteCommentSection: false, isDisplayProceedNext: false, isApproved: false, approveMsg: '', approveDisable: false },
    { process: 'Other Doc', processId: 72, commentData: '', commentID: 0, isDisplayAddComment: true, isDisplayAddApprove: true, isDislplayCommentTextArea: true, isDislplayCommentUpdateBtn: false, isDisplayEditDeleteCommentSection: false, isDisplayProceedNext: false, isApproved: false, approveMsg: '', approveDisable: false }
  ]

  async ngOnInit() {
    this.applicantID = Number(this.activeRt.snapshot.paramMap.get('applicantID'));

    this.rejObj = this.agentCommonServiceService.getUserFromLocalStorage();
    this.applicantData = localStorage.getItem('applicantList');
    this.applicantList = JSON.parse(this.applicantData);
    let applicantData = localStorage.getItem('applicantList')
    if (applicantData != null) {
      this.applicantList = JSON.parse(applicantData)
      var index = this.applicantList.findIndex((el: any) => el.applicant_personal_id == this.applicantID);
      if (this.applicantList.length > 1 && (index != this.applicantList.length - 1)) {
        this.showProceed = true
      } else {
        this.showProceed = false
      }
    }

    this.rejectComment = this.fb.group({
      rejectcomments: ['', []]
    });
    this.roleID = this.agentCommonServiceService.getUserFromLocalStorage()?.role_id
    if (this.roleID == 2) {
      this.rejectDisable = true
    }
    let Obj = {}

    if (this.accountType == 'Minor') {
      if (this.isMinor == true) { // minor
        Obj = {
          user_id: this.rejObj?.user_id,
          process_id: 33,
          applicant_id: this.applicantID
        }
      } else { // Guardian 
        Obj = {
          user_id: this.rejObj?.user_id,
          process_id: 45,
          applicant_id: this.applicantID
        }
      }
    } else {
      Obj = {
        user_id: this.rejObj?.user_id,
        process_id: 4,
        applicant_id: this.applicantID
      }
    }

    this.agentDataServiceService.fetchPersonalDtls1(Obj).subscribe((value) => {
      if (value?.data?.[0]?.lead_status != undefined) {
        if (value?.data?.[0]?.lead_status == 'agent_review') {
          this.rejectDisable = true;
        }
        if (value?.data?.[0]?.lead_status == 'approved') {
          this.rejectDisable = true;
        }
      }
    })
    this.accountType = localStorage.getItem('accountType')
    let minor = localStorage.getItem('isMinor')
    if (minor == 'true') {
      this.isMinor = true
    }
    else {
      this.isMinor = false
    }

    if (this.accountType == 'Minor') {
      if (this.isMinor == true) {
        this.processArr[0].processId = 39
        this.processArr[4].processId = 41
        this.processArr[5].processId = 42
        this.processArr[6].processId = 43
      }
      else {
        this.processArr[0].processId = 59
        this.processArr[1].processId = 60
        this.processArr[2].processId = 63
        this.processArr[4].processId = 64
        this.processArr[5].processId = 65
        this.processArr[6].processId = 66
      }
    }


    // var demoTrigger = demoTrigger.querySelector('.demo-trigger');
    // var paneContainer = document.querySelector('.detail');
    // new Drift(demoTrigger, {
    //   paneContainer: paneContainer,
    //   inlinePane: false
    // });
    this.roleID = this.agentCommonServiceService.getUserFromLocalStorage()?.role_id
    if (this.roleID == 2) {
      this.processArr[0].isDislplayCommentTextArea = false
      this.processArr[0].isDisplayAddComment = false
      this.processArr[0].isDislplayCommentUpdateBtn = false
      this.processArr[0].isDisplayEditDeleteCommentSection = false
      this.processArr[0].approveDisable = true
      this.processArr[0].isDisplayAddApprove = false

      this.processArr[1].isDislplayCommentTextArea = false
      this.processArr[1].isDisplayAddComment = false
      this.processArr[1].isDislplayCommentUpdateBtn = false
      this.processArr[1].isDisplayEditDeleteCommentSection = false
      this.processArr[1].approveDisable = true
      this.processArr[1].isDisplayAddApprove = false

      this.processArr[2].isDislplayCommentTextArea = false
      this.processArr[2].isDisplayAddComment = false
      this.processArr[2].isDislplayCommentUpdateBtn = false
      this.processArr[2].isDisplayEditDeleteCommentSection = false
      this.processArr[2].approveDisable = true
      this.processArr[2].isDisplayAddApprove = false

      this.processArr[3].isDislplayCommentTextArea = false
      this.processArr[3].isDisplayAddComment = false
      this.processArr[3].isDislplayCommentUpdateBtn = false
      this.processArr[3].isDisplayEditDeleteCommentSection = false
      this.processArr[3].approveDisable = true
      this.processArr[3].isDisplayAddApprove = false

      this.processArr[4].isDislplayCommentTextArea = false
      this.processArr[4].isDisplayAddComment = false
      this.processArr[4].isDislplayCommentUpdateBtn = false
      this.processArr[4].isDisplayEditDeleteCommentSection = false
      this.processArr[4].approveDisable = true
      this.processArr[4].isDisplayAddApprove = false

      this.processArr[5].isDislplayCommentTextArea = false
      this.processArr[5].isDisplayAddComment = false
      this.processArr[5].isDislplayCommentUpdateBtn = false
      this.processArr[5].isDisplayEditDeleteCommentSection = false
      this.processArr[5].approveDisable = true
      this.processArr[5].isDisplayAddApprove = false

      this.processArr[6].isDislplayCommentTextArea = false
      this.processArr[6].isDisplayAddComment = false
      this.processArr[6].isDislplayCommentUpdateBtn = false
      this.processArr[6].isDisplayEditDeleteCommentSection = false
      this.processArr[6].approveDisable = true
      this.processArr[6].isDisplayAddApprove = false
    }

    this.regObj = this.agentCommonServiceService.getUserFromLocalStorage();

    this.passportsection = this.fb.group({
      comments: ['', Validators.required]
    })

    this.addressProof = this.fb.group({
      comments: ['', Validators.required]
    })

    this.form60 = this.fb.group({
      comments: ['', Validators.required]
    })

    this.imgoci = this.fb.group({
      comments: ['', Validators.required]
    })

    this.imgVisa = this.fb.group({
      comments: ['', Validators.required]
    })

    this.imgPio = this.fb.group({
      comments: ['', Validators.required]
    })

    this.otherDoc = this.fb.group({
      comments: ['', Validators.required]
    })

    let ObjC = {
      lead_id: this.regObj?.customerUserID,
      agent_id: this.regObj?.user_id,
      process_id: 23
    }

    this.agentDataServiceService.fetchAgentCommentSummary(ObjC).subscribe((data) => {
      this.commentData = data?.data?.comment;
      this.commentID = data?.data?.comment_id;
      if (data?.data?.comment) {
        this.isCommentSuccessfull = true;
        this.isDisplayProceedNext = true;
        this.isDisplayUpdateBtn = false;
        this.isDisplayCommentTextarea = false;
        this.isDisplayCommentEditArea = true;
        this.isDisplayApproveBtn = true;
      } else {
        this.isCommentSuccessfull = false;
      }

      this.documentCommentForm = this.fb.group({
        comment: [this.commentData, []]
      })
      this.commentData = data?.data?.comment;
      this.commentID = data?.data?.comment_id;
    })

    this.applicantID = Number(this.activeRt.snapshot.paramMap.get('applicantID'));

    let Obj1 = {
      applicant_id: this.applicantID,
      document: "passport_front"
    }
    this.agentDataServiceService.postCustomerGetDoc(Obj1).subscribe((value) => {
      if (value.lead_status == 'agent_review') {

        this.processArr[0].approveDisable = true
        this.processArr[1].approveDisable = true
        this.processArr[2].approveDisable = true
        this.processArr[3].approveDisable = true
        this.processArr[4].approveDisable = true
        this.processArr[5].approveDisable = true
        this.processArr[6].approveDisable = true

        this.processArr[0].isDisplayAddComment = false
        this.processArr[1].isDisplayAddComment = false
        this.processArr[2].isDisplayAddComment = false
        this.processArr[3].isDisplayAddComment = false
        this.processArr[4].isDisplayAddComment = false
        this.processArr[5].isDisplayAddComment = false
        this.processArr[6].isDisplayAddComment = false

        this.processArr[0].isDislplayCommentUpdateBtn = false
        this.processArr[1].isDislplayCommentUpdateBtn = false
        this.processArr[2].isDislplayCommentUpdateBtn = false
        this.processArr[3].isDislplayCommentUpdateBtn = false
        this.processArr[4].isDislplayCommentUpdateBtn = false
        this.processArr[5].isDislplayCommentUpdateBtn = false
        this.processArr[6].isDislplayCommentUpdateBtn = false

        this.processArr[0].isDislplayCommentTextArea = false
        this.processArr[1].isDislplayCommentTextArea = false
        this.processArr[2].isDislplayCommentTextArea = false
        this.processArr[3].isDislplayCommentTextArea = false
        this.processArr[4].isDislplayCommentTextArea = false
        this.processArr[5].isDislplayCommentTextArea = false
        this.processArr[6].isDislplayCommentTextArea = false
      }
      this.imgSrcPsportFront = value?.file_path;
    });

    let Obj2 = {
      applicant_id: this.applicantID,
      document: "passport_back"
    }
    this.agentDataServiceService.postCustomerGetDoc(Obj2).subscribe((value) => {
      this.imgSrcPsportBack = value?.file_path;
    });

    let Obj3 = {
      applicant_id: this.applicantID,
      document: "address_proof"
    }

    this.agentDataServiceService.postCustomerGetDoc(Obj3).subscribe((value) => {
      this.imgSrcAddressProof = value?.[0]?.file_path;
      this.addressProofData = value?.[0];
      //this.agentCommonServiceService.getDateFormatYMD(value?.[0])
    });

    let Obj4 = {
      applicant_id: this.applicantID,
      document: "form_sixty"
    }
    this.agentDataServiceService.postCustomerGetDoc(Obj4).subscribe((value) => {
      this.imgSrcFrom60 = value?.file_path;
    });

    let Obj5 = {
      applicant_id: this.applicantID,
      document: "oci"
    }
    this.agentDataServiceService.postCustomerGetDoc(Obj5).subscribe((value) => {
      this.imgSrcOci = value?.file_path;
    }, (err) => {

    });

    let Obj6 = {
      applicant_id: this.applicantID,
      document: "visa"
    }

    this.agentDataServiceService.postCustomerGetDoc(Obj6).subscribe((value) => {
      this.imgSrcVisa = value?.file_path;
    }, (err) => {

    });
    let Obj7 = {
      applicant_id: this.applicantID,
      document: "old_indian_passport_front"
    }
    this.agentDataServiceService.postCustomerGetDoc(Obj7).subscribe((value) => {
      this.imgSrcPio1 = value?.file_path;
    }, (err) => {

    });

    let Obj8 = {
      applicant_id: this.applicantID,
      document: "old_indian_passport_back"
    }
    this.agentDataServiceService.postCustomerGetDoc(Obj8).subscribe((value) => {
      this.imgSrcPio2 = value?.file_path;
    }, (err) => {
    });
    let Obj9 = {
      applicant_id: this.applicantID,
      document: "other"
    }
    this.agentDataServiceService.postCustomerGetDoc(Obj9).subscribe((value) => {
      this.imgSrcOtherDoc = value[0]?.file_path;
    }, (err) => {
    });

    for (let i = 0; i < this.processArr.length; i++) {
      await this.setComments(i)
    }

  }


  agentReviewedLead() {
    this.is_review_loading = true;
    let Obj = {
      lead_id: this.regObj?.customerUserID,
    }
    let ObjP = {
      applicant_id: this.applicantID,
      status: 'review'
    }
    this.agentDataServiceService.postProcessStatus(ObjP).subscribe((res) => {
      if (res?.reviewed) {
        const reviewedFn = () => {
          this.agentDataServiceService.postReviewedAgentLead(Obj).subscribe((data) => {
            this.is_review_loading = false;
            location.href = 'dashboard';
          })
        }

        if (localStorage.getItem('accountType') == 'Joint' || localStorage.getItem('Account type') == 'Joint') {
          var index = this.applicantList.findIndex((el: any) => el.applicant_personal_id == this.applicantID);
          if (this.applicantList.length == index + 1) {
            reviewedFn();
          } else {
            this.is_review_loading = false;
            window.alert(`Please Review Application ${index + 2} !`);
            return
          }
        }

        if (JSON.parse(localStorage.getItem('isMinor') || '') || localStorage.getItem('accountType') == 'Minor') {
          var index = this.applicantList.findIndex((el: any) => el.applicant_personal_id == this.applicantID);
          if (this.applicantList.length == index + 1) {
            reviewedFn();
          } else {
            this.is_review_loading = false;
            window.alert(`Please Review Application ${index + 2} !`);
            return
          }
        }
        if (localStorage.getItem('accountType') == 'Individual') {
          reviewedFn();
        }
      } else {
        this.is_review_loading = false;
        window.alert(`Please Review ${res.data?.form_name} !`)
      }

    })

  }

  nextApplicant() {
    let Obj = {
      lead_id: this.regObj?.customerUserID,
    }
    let ObjP = {
      applicant_id: this.applicantID,
      status: 'review'
    }
    this.agentDataServiceService.postProcessStatus(ObjP).subscribe((res) => {
      if (res?.reviewed) {
        let existArray
        let enabledApplicant = localStorage.getItem('enabledApplicant')
        if (enabledApplicant != null) {
          existArray = JSON.parse(enabledApplicant)
        }
        var index = this.applicantList.findIndex((el: any) => el.applicant_personal_id == this.applicantID);
        console.log("?????????", this.applicantID, index + 1, this.agentCommonServiceService.enabledApplicant);
        //  existArray=this.agentCommonServiceService.enabledApplicant
        if (existArray.indexOf(index + 1) === -1) {
          existArray.push(index + 1)
        }
        // this.agentCommonServiceService.enabledApplicant=existArray
        localStorage.setItem('enabledApplicant', JSON.stringify(existArray))
        setTimeout(() => {
          this.agentCommonServiceService.applicantIndex.next(index + 1)
          this.rt.navigate(['/dashboard', 'lead-dtls1', this.applicantList[index + 1].applicant_personal_id]);
          setTimeout(() => {
            window.location.reload();
          }, 300);
        }, 500);

      } else {
        window.alert(`Please Review ${res.data?.form_name} !`)
      }
    })



  }

  agentApprovedLead() {
    this.is_approve_loading = true;
    let Obj = {
      lead_id: this.regObj?.customerUserID,
    }
    let ObjE = {
      applicant_id: this.applicantID
    }
    let ObjP = {
      applicant_id: this.applicantID,
      status: 'approved'
    }


    this.agentDataServiceService.postProcessStatus(ObjP).subscribe((res) => {
      if (res?.approved) {

        const approveFn = () => {
          this.agentDataServiceService.emailPdf(ObjE).subscribe((value) => { })
          this.agentDataServiceService.postApprovedAgentLead(Obj).subscribe((data) => {
            this.is_approve_loading = false;
            location.href = 'dashboard';
          })
        }

        if (localStorage.getItem('accountType') == 'Joint') {
          var index = this.applicantList.findIndex((el: any) => el.applicant_personal_id == this.applicantID);
          if (this.applicantList.length == index + 1) {
            approveFn();
          } else {
            this.is_approve_loading = false;
            window.alert(`Please Review Application ${index + 2} !`);
          }
        }

        if (JSON.parse(localStorage.getItem('isMinor') || '') || localStorage.getItem('accountType') == 'Minor') {
          var index = this.applicantList.findIndex((el: any) => el.applicant_personal_id == this.applicantID);
          if (this.applicantList.length == index + 1) {
            approveFn();
          } else {
            this.is_approve_loading = false;
            window.alert(`Please Review Application ${index + 2} !`);
          }
        }

        if (localStorage.getItem('accountType') == 'Individual') {
          approveFn();
        }

      } else {
        this.is_approve_loading = false;
        window.alert(`Please Approve ${res.data?.form_name} !`)
      }

    })

  }

  async setComments(ind: number) {
    let ObjC = {
      applicant_id: this.applicantID,
      lead_id: this.regObj?.customerUserID,
      agent_id: this.regObj?.user_id,
      process_id: this.processArr[ind].processId
    }

    await this.agentDataServiceService.fetchAgentCommentSummary(ObjC).toPromise().then((data) => {
      console.log("???????????///////////", ind, data)
      if (data?.data?.agent_status == "approved") {
        this.processArr[ind].isDisplayAddComment = false;
        this.processArr[ind].isDisplayAddApprove = false;
        this.processArr[ind].isDislplayCommentTextArea = false;
        this.processArr[ind].isDislplayCommentUpdateBtn = false;
        this.processArr[ind].isDisplayEditDeleteCommentSection = false;
        this.processArr[ind].isDisplayProceedNext = true;

        this.processArr[ind].isApproved = true;
        this.processArr[ind].approveMsg = 'This section is approved';
      }
      else if (data?.data?.comment_id) {
        this.processArr[ind].isDisplayAddComment = false;
        if (this.roleID == 2) {
          this.processArr[ind].isDisplayAddApprove = false;
        } else {
          this.processArr[ind].isDisplayAddApprove = true;
        }
        this.processArr[ind].isDislplayCommentTextArea = false;
        this.processArr[ind].isDislplayCommentUpdateBtn = false;
        this.processArr[ind].isDisplayEditDeleteCommentSection = true;
        this.processArr[ind].isDisplayProceedNext = true;
        this.processArr[ind].isApproved = false;
        this.agentCommnentArrData = data;
        this.processArr[ind].commentData = data?.data?.comment;
        this.processArr[ind].commentID = data?.data?.comment_id;
        if (ind == 0) {
          this.passportsection.controls['comments'].setValue(data?.data?.comment)
        }
        else if (ind == 1) {
          this.addressProof.controls['comments'].setValue(data?.data?.comment)
        }
        else if (ind == 2) {
          this.form60.controls['comments'].setValue(data?.data?.comment)
        }
        else if (ind == 3) {
          this.imgoci.controls['comments'].setValue(data?.data?.comment)
        }
        else if (ind == 4) {
          this.imgVisa.controls['comments'].setValue(data?.data?.comment)
        }
        else if (ind == 5) {
          this.imgPio.controls['comments'].setValue(data?.data?.comment)
        }
        else if (ind == 6) {
          this.otherDoc.controls['comments'].setValue(data?.data?.comment)
        }
      }
    })

  }

  get comments() { return this.comment.get('comments') }


  //new 

  // agentRejectLeads() {

  //   // window.location.reload();
  //   let Obj = {
  //     comment: this.rejectComment.get('rejectcomments').value,
  //     lead_id: this.rejObj?.customerUserID,
  //   }
  //   this.agentDataServiceService.postRejectAgentLead(Obj).subscribe((data) => {
  //     // console.log('This is Rejected leads agent', data);
  //     this.commentData = data?.msg;
  //     this.closeRejectLeadsModal();
  //     this.openSuccessRejectedLeadModal();

  //     // setTimeout(()=>{
  //     //   this.closeSuccessRejectedLeadModal();

  //     // },1000)

  //     this.rt.navigate(["/dashboard"]);
  //     // window.location.reload();

  //   })
  // }

  // this.rejectComment = this.fb.group({
  //   rejectcomments: ['', []]
  // });


  agentRejectLeads() {
    let Obj = {
      comment: this.rejectComment.get('rejectcomments').value,
      lead_id: this.regObj?.customerUserID,
    }
    this.agentDataServiceService.postRejectAgentLead(Obj).subscribe((data) => {
      this.closeRejectLeadsModal();
      this.openSuccessRejectedLeadModal();
      this.rt.navigate(["/dashboard"]);
      // window.location.reload();
    })
  }

  openRejectOpenModal() {
    this.displayRejectLeads = 'block';
  }

  closeRejectLeadsModal() {
    this.displayRejectLeads = 'none';
  }

  openSuccessRejectedLeadModal() {
    this.displayRejectLeadSuccess = 'block';
  }

  closeSuccessRejectedLeadModal() {
    this.displayRejectLeadSuccess = 'block';
    window.location.reload();
  }

  ngAfterViewInit() {
    // this.divHello.nativeElement.innerHTML = "Hello Angular";
    this.demoTrgiggerElement = this.demoTrigger?.nativeElement;
    let paneContainerElement = this.paneContainer?.nativeElement;
    // new Drift(this.demoTrgiggerElement, {
    //   paneContainer: paneContainerElement,
    //   inlinePane: this.iSinlinePane
    // });
  }

  editComment(ind: number) {
    this.processArr[ind].isDisplayAddComment = false;
    this.processArr[ind].isDisplayAddApprove = true;
    this.processArr[ind].isDislplayCommentTextArea = true;
    this.processArr[ind].isDislplayCommentUpdateBtn = true;
    this.processArr[ind].isDisplayEditDeleteCommentSection = false;
    this.processArr[ind].isDisplayProceedNext = false;
  }

  checkDeleteComment(val: any) {
    this.deleteCommentInd = val
    this.openModal();
  }

  openModal() {
    this.display = "block";
  }

  onCloseHandled() {
    this.display = "none";
  }

  openModalComment() {
    this.displayCommentErr = "block";
  }

  closeModalComment() {
    this.displayCommentErr = "none";
  }

  deleteComment() {
    if (this.processArr[this.deleteCommentInd].commentID > 0) {
      let Obj = {
        comment_id: this.processArr[this.deleteCommentInd].commentID
      }
      this.agentDataServiceService.deleteComment(Obj).subscribe((value) => {
        // this.rt.navigate([this.rt.url])
        // window.location.reload();

        if (value.msg === "comments delete successfully") {

          if (this.deleteCommentInd == 0) {
            this.passportsection.controls['comments'].setValue('')
          }
          else if (this.deleteCommentInd == 1) {
            this.addressProof.controls['comments'].setValue('')
          }
          else if (this.deleteCommentInd == 2) {
            this.form60.controls['comments'].setValue('')
          }
          else if (this.deleteCommentInd == 3) {
            this.imgoci.controls['comments'].setValue('')
          }
          else if (this.deleteCommentInd == 4) {
            this.imgVisa.controls['comments'].setValue('')
          }
          else if (this.deleteCommentInd == 5) {
            this.imgPio.controls['comments'].setValue('')
          }
          else if (this.deleteCommentInd == 6) {
            this.otherDoc.controls['comments'].setValue('')
          }
          this.processArr[this.deleteCommentInd].isDisplayAddComment = true;
          this.processArr[this.deleteCommentInd].isDisplayAddApprove = true;
          this.processArr[this.deleteCommentInd].isDislplayCommentTextArea = true;
          this.processArr[this.deleteCommentInd].isDislplayCommentUpdateBtn = false;
          this.processArr[this.deleteCommentInd].isDisplayEditDeleteCommentSection = false;
          this.processArr[this.deleteCommentInd].isDisplayProceedNext = false;
          this.processArr[this.deleteCommentInd].commentData = '';
          this.processArr[this.deleteCommentInd].commentID = 0;
          this.display = "none";
        }

      });
    }
    else {
    }
  }

  approveLead(ind: number) {
    let Obj = {
      applicant_id: this.applicantID,
      process_id: this.processArr[ind].processId,
      lead_id: this.regObj?.customerUserID
    }

    this.agentDataServiceService.approveLead(Obj).subscribe((value) => {
      console.log("?????...>>>>>>>>>>>>>>>>>>>>", value)
      this.processArr[ind].isDisplayAddComment = false;
      this.processArr[ind].isDisplayAddApprove = false;
      this.processArr[ind].isDislplayCommentTextArea = false;
      this.processArr[ind].isDislplayCommentUpdateBtn = false;
      this.processArr[ind].isDisplayEditDeleteCommentSection = false;
      this.processArr[ind].isDisplayProceedNext = true;
      this.processArr[ind].isApproved = true;
      this.processArr[ind].approveMsg = 'This section is approved';

    })
  }

  updateComment(val: string) {
    if (val == 'Password') {
      if (this.passportsection.valid) {
        let comment = this.passportsection.get('comments').value
        let arrId = this.processArr.findIndex((res: any) => res.process == val)
        this.updateCommentapi(comment, arrId)
      } else {
        // this.openModalComment();
      }
    }
    else if (val == 'Address Proof') {
      if (this.addressProof.valid) {
        let comment = this.addressProof.get('comments').value
        let arrId = this.processArr.findIndex((res: any) => res.process == val)
        this.updateCommentapi(comment, arrId)
      }
      else {
        // this.openModalComment();
      }
    }
    else if (val == 'Form 60') {
      if (this.form60.valid) {
        let comment = this.form60.get('comments').value
        let arrId = this.processArr.findIndex((res: any) => res.process == val)
        this.updateCommentapi(comment, arrId)
      }
      else {
        // this.openModalComment();
      }
    }
    else if (val == 'OCI') {
      if (this.imgoci.valid) {
        let comment = this.imgoci.get('comments').value
        let arrId = this.processArr.findIndex((res: any) => res.process == val)
        this.updateCommentapi(comment, arrId)
      } else {
        // this.openModalComment();
      }
    }
    else if (val == 'Visa') {
      if (this.imgVisa.valid) {
        let comment = this.imgVisa.get('comments').value
        let arrId = this.processArr.findIndex((res: any) => res.process == val)
        this.updateCommentapi(comment, arrId)
      }
      else {
        // this.openModalComment();
      }
    }
    else if (val == 'PIO') {
      if (this.imgPio.valid) {
        let comment = this.imgPio.get('comments').value
        let arrId = this.processArr.findIndex((res: any) => res.process == val)
        this.updateCommentapi(comment, arrId)
      }
      else {
        // this.openModalComment();
      }
    }
    else if (val == 'Other Doc') {
      if (this.otherDoc.valid) {
        let comment = this.otherDoc.get('comments').value
        let arrId = this.processArr.findIndex((res: any) => res.process == val)
        this.updateCommentapi(comment, arrId)
      }
      else {
        // this.openModalComment();
      }
    }
  }

  updateCommentapi(comment: any, arrind: number) {
    this.processArr[arrind].isDisplayAddComment = false;
    this.processArr[arrind].isDisplayAddApprove = true;
    this.processArr[arrind].isDislplayCommentTextArea = false;
    this.processArr[arrind].isDislplayCommentUpdateBtn = false;
    this.processArr[arrind].isDisplayEditDeleteCommentSection = true;
    this.processArr[arrind].isDisplayProceedNext = true;

    let Obj = {
      process_id: this.processArr[arrind].processId,
      applicant_id: this.applicantID,
      parent_comment_id: 0,
      agent_id: this.regObj?.user_id,
      comment: comment,
      lead_id: this.regObj?.customerUserID,
      comment_id: this.processArr[arrind].commentID
    }

    this.agentDataServiceService.postAgentsComment(Obj).subscribe((value) => {
      let ObjC = {
        applicant_id: this.applicantID,
        lead_id: this.regObj?.customerUserID,
        agent_id: this.regObj?.user_id,
        "process_id": this.processArr[arrind].processId,
        "comment_id": value.comment_id
      }

      this.agentDataServiceService.fetchAgentCommentSummary(ObjC).subscribe((data) => {
        this.agentCommnentArrData = data;
        this.processArr[arrind].commentData = data?.data?.comment;
        this.processArr[arrind].commentID = data?.data?.comment_id;
      })
    }, (err) => {
      console.log(err);
    })
  }

  addComment(val: string) {
    if (val == 'Password') {
      if (this.passportsection.valid) {
        let comment = this.passportsection.get('comments').value
        let arrId = this.processArr.findIndex((res: any) => res.process == val)
        this.addCommentApi(comment, arrId)
      } else {
        // this.openModalComment();
      }
    }
    else if (val == 'Address Proof') {
      if (this.addressProof.valid) {
        let comment = this.addressProof.get('comments').value
        let arrId = this.processArr.findIndex((res: any) => res.process == val)
        this.addCommentApi(comment, arrId)
      }
      else {
        // this.openModalComment();
      }
    }
    else if (val == 'Form 60') {
      if (this.form60.valid) {
        let comment = this.form60.get('comments').value
        let arrId = this.processArr.findIndex((res: any) => res.process == val)
        this.addCommentApi(comment, arrId)
      }
      else {
        // this.openModalComment();
      }
    }
    else if (val == 'OCI') {
      if (this.imgoci.valid) {
        let comment = this.imgoci.get('comments').value
        let arrId = this.processArr.findIndex((res: any) => res.process == val)
        this.addCommentApi(comment, arrId)
      } else {
        // this.openModalComment();
      }
    }
    else if (val == 'Visa') {
      if (this.imgVisa.valid) {
        let comment = this.imgVisa.get('comments').value
        let arrId = this.processArr.findIndex((res: any) => res.process == val)
        this.addCommentApi(comment, arrId)
      }
      else {
        // this.openModalComment();
      }
    }
    else if (val == 'PIO') {
      if (this.imgPio.valid) {
        let comment = this.imgPio.get('comments').value
        let arrId = this.processArr.findIndex((res: any) => res.process == val)
        this.addCommentApi(comment, arrId)
      }
      else {
        // this.openModalComment();
      }
    }
    else if (val == 'Other Doc') {
      if (this.otherDoc.valid) {
        let comment = this.otherDoc.get('comments').value
        let arrId = this.processArr.findIndex((res: any) => res.process == val)
        this.addCommentApi(comment, arrId)
      }
      else {
        // this.openModalComment();
      }
    }
  }

  addCommentApi(getcomment: any, arrind: number) {
    this.processArr[arrind].isDisplayAddComment = false;
    this.processArr[arrind].isDisplayAddApprove = true;
    this.processArr[arrind].isDislplayCommentTextArea = false;
    this.processArr[arrind].isDislplayCommentUpdateBtn = false;
    this.processArr[arrind].isDisplayEditDeleteCommentSection = true;
    this.processArr[arrind].isDisplayProceedNext = true;

    let Obj = {
      process_id: this.processArr[arrind].processId,
      applicant_id: this.applicantID,
      parent_comment_id: 0,
      agent_id: this.agentCommonServiceService.getUserFromLocalStorage()?.user_id,
      comment: getcomment,
      lead_id: this.regObj?.customerUserID
    }

    this.agentDataServiceService.postAgentsComment(Obj).subscribe((value) => {
      let ObjC = {
        applicant_id: this.applicantID,
        lead_id: this.regObj?.customerUserID,
        agent_id: this.regObj?.user_id,
        "process_id": this.processArr[arrind].processId,
        "comment_id": value.comment_id
      }

      this.agentDataServiceService.fetchAgentCommentSummary(ObjC).subscribe((data) => {
        this.agentCommnentArrData = data;
        this.processArr[arrind].commentData = data?.data?.comment;
        this.processArr[arrind].commentID = data?.data?.comment_id;
      })

    }, (err) => {
      console.log(err);
    })
  }

  openmodal(val: any) {
    if (val == 'passportfront') {
      this.modalImage = this.imgSrcPsportFront
    }
    else if (val == 'passportback') {
      this.modalImage = this.imgSrcPsportBack
    }
    else if (val == 'addressproof') {
      this.modalImage = this.imgSrcAddressProof
    }
    else if (val == 'form60') {
      this.modalImage = this.imgSrcFrom60
    }
    else if (val == 'oci') {
      this.modalImage = this.imgSrcOci
    }
    else if (val == 'visa') {
      this.modalImage = this.imgSrcVisa
    }
    else if (val == 'piofront') {
      this.modalImage = this.imgSrcPio1
    }
    else if (val == 'pioback') {
      this.modalImage = this.imgSrcPio2
    }
    else if (val == 'other') {
      this.modalImage = this.imgSrcOtherDoc
    }

  }

  // addComment(val: string) {
  //   this.isDisplayAddComment = false;
  //   this.isDisplayAddApprove = true;
  //   this.isDislplayCommentTextArea = false;
  //   this.isDislplayCommentUpdateBtn = false;
  //   this.isDisplayEditDeleteCommentSection = true;
  //   this.isDisplayProceedNext = true;
  //   let Obj = {
  //     process_id: 6,
  //     applicant_id: this.applicantID,
  //     parent_comment_id: 0,
  //     agent_id: this.agentCommonServiceService.getUserFromLocalStorage()?.user_id,
  //     comment: this.passportsection.get('comments').value,
  //     lead_id: this.regObj?.customerUserID
  //   }

  //   this.agentDataServiceService.postAgentsComment(Obj).subscribe((value) => {
  //     let ObjC = {
  //       applicant_id: this.applicantID,
  //       lead_id: this.regObj?.customerUserID,
  //       agent_id: this.regObj?.user_id,
  //       process_id: 6
  //     }

  //     this.agentDataServiceService.fetchAgentCommentSummary(ObjC).subscribe((data) => {
  //       this.agentCommnentArrData = data;
  //       this.commentData = data?.data?.comment;
  //       this.commentID = data?.data?.comment_id;
  //     })
  //     console.log(value)
  //   }, (err) => {
  //     console.log(err);
  //   })
  // }


}