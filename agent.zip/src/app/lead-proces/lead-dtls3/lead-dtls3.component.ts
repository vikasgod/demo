import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { AgentDataServiceService } from 'src/app/services/agent-data-service.service';
import { AgentCommonServiceService } from 'src/app/services/agent-common-service.service';
import { FormBuilder, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { data } from 'jquery';

@Component({
  selector: 'app-lead-dtls3',
  templateUrl: './lead-dtls3.component.html',
  styleUrls: ['./lead-dtls3.component.css']
})
export class LeadDtls3Component implements OnInit {

  @Output() showContactDivOut = new EventEmitter<string>()
  @Output() isChecked = new EventEmitter<boolean>()

  otherPassport: string = '';
  issueDate: string = '';
  expiryDate: string = '';
  issuingAuth: string = '';
  placeOfIssue: string = '';
  passportNo: string = '';
  typeOfVisa: string = '';
  residentPermit: string = '';
  visaresipermitExpiryDate = '';
  panNo: string = '';
  form60: string = '';
  tempVisaChk1: string = '';
  docIssueDate: string = '';
  docExpiryDate: string = '';
  tempVisaChk2: string = '';
  temporaryVisaDec: string = '';

  regObj: any;
  kycDtlsForm1: any;
  kycDtlsForm2: any;
  kycDtlsForm3: any;
  applicantID: any;
  agentCommnentArrData: any;
  deleteCommentInd: any
  procced: boolean = false

  display: string = "none";
  displayCommentErr: string = "none";
  commentID: number = 0;
  commentData: string = '';

  isApproved: boolean = false;
  approveMsg: string = 'This section is approved';

  approveDisable: boolean = false;
  kycTempDetails: boolean = false;
  visaType: any
  applicantList: any;
  showProceed: boolean = false
  isMinor: boolean = false

  roleID: any;
  accountType:any

  processArr = [
    { process: 'Visa type / Residence Permit', processId: 7, commentData: '', commentID: 0, isDisplayAddComment: true, isDisplayAddApprove: true, isDislplayCommentTextArea: true, isDislplayCommentUpdateBtn: false, isDisplayEditDeleteCommentSection: false, isDisplayProceedNext: false, isApproved: false, approveMsg: '', approveDisable: false },
    { process: 'Temporary Visa Declaration', processId: 9, commentData: '', commentID: 0, isDisplayAddComment: true, isDisplayAddApprove: true, isDislplayCommentTextArea: true, isDislplayCommentUpdateBtn: false, isDisplayEditDeleteCommentSection: false, isDisplayProceedNext: false, isApproved: false, approveMsg: '', approveDisable: false }
  ]

  constructor(private agentDataServiceService: AgentDataServiceService, private agentCommonServiceService: AgentCommonServiceService, private fb: FormBuilder, private activeRt: ActivatedRoute, private rt: Router) { }

  async ngOnInit() {
    this.accountType=localStorage.getItem('accountType')
    let minor=localStorage.getItem('isMinor')
    if(minor=='true'){
      this.isMinor=true
    }
    else{
      this.isMinor=false
    }

    if(this.accountType=='Minor'){
      if(this.isMinor==true){
        this.processArr[0].processId = 35
        this.processArr[1].processId = 36
      }
      else{
        this.processArr[0].processId = 48
        this.processArr[1].processId = 49
      }
    }

    this.regObj = this.agentCommonServiceService.getUserFromLocalStorage();
    this.applicantID = Number(this.activeRt.snapshot.paramMap.get('applicantID'));

    this.kycDtlsForm1 = this.fb.group({
      comments: ['', Validators.required]
    })
    this.kycDtlsForm2 = this.fb.group({
      comments: ['', Validators.required]
    })

    this.roleID = this.agentCommonServiceService.getUserFromLocalStorage()?.role_id

    if (this.roleID == 2) {
      this.processArr[0].isDislplayCommentTextArea = false
      this.processArr[0].isDisplayAddComment = false
      this.processArr[0].isDislplayCommentUpdateBtn = false
      this.processArr[0].isDisplayEditDeleteCommentSection = false
      this.processArr[0].approveDisable = true
      // this.processArr[0].isDisplayAddApprove = false

      this.processArr[1].isDislplayCommentTextArea = false
      this.processArr[1].isDisplayAddComment = false
      this.processArr[1].isDislplayCommentUpdateBtn = false
      this.processArr[1].isDisplayEditDeleteCommentSection = false
      this.processArr[1].approveDisable = true
      this.procced = true
      this.isChecked.emit(true)
    }

    // let Obj1 =
    // {
    //   user_id: this.regObj?.user_id,
    //   process_id: 7,
    //   applicant_id: this.applicantID
    // }

    let Obj1={}

    if(this.accountType=='Minor'){
      if(this.isMinor==true){ // minor
        Obj1 = {
          user_id: this.regObj?.user_id,
          process_id: 35,
          applicant_id: this.applicantID
        }
      }else{ // Guardian 
        Obj1 = {
          user_id: this.regObj?.user_id,
          process_id: 48,
          applicant_id: this.applicantID
        }
      }
    }
    else{
      Obj1 = {
        user_id: this.regObj?.user_id,
        process_id: 7,
        applicant_id: this.applicantID
      }
    }

    console.log('check kyc 1', Obj1);

    this.agentDataServiceService.fetchKycDtls1(Obj1).subscribe((value) => {
      console.log("KYC data", value);

      if (value?.data.length > 0) {
        this.visaType = value.data[0].visa_type
        if (value.data[0].visa_type == 1) {
          this.kycTempDetails = true;
        }
        if (value?.data?.[0]?.lead_status != undefined) {
          if (value?.data?.[0]?.lead_status == 'agent_review') {
            this.processArr[0].approveDisable = true
            this.processArr[1].approveDisable = true
          }
        }

        this.otherPassport = value?.data?.[0]?.is_other_than_indian_passport_name;
        let isseDateType = new Date(value?.data?.[0]?.issue_date);
        // this.issueDate = `${isseDateType.getDate()}/${isseDateType.getMonth()}/${isseDateType.getFullYear()}`;
        this.issueDate = new Date(value?.data?.[0]?.issue_date).toLocaleDateString();
        let expiryDateType = new Date(value?.data?.[0]?.issue_date);
        // this.expiryDate = `${expiryDateType.getDate()}/${expiryDateType.getMonth()}/${expiryDateType.getFullYear()}`;
        this.expiryDate = new Date(value?.data?.[0]?.expiry_date).toLocaleDateString();
        this.issuingAuth = value?.data?.[0]?.issueing_authority;
        this.placeOfIssue = value?.data?.[0]?.place_of_issue;
        this.passportNo = value?.data?.[0]?.passport_number;
        this.typeOfVisa = value?.data?.[0]?.visa_type_name;
        this.residentPermit = '';
        let visaresipermitExpiryDateType = new Date(value?.data?.[0]?.visa_permit_expiry_date);

        // this.visaresipermitExpiryDate = `${visaresipermitExpiryDateType.getDate()}/ ${visaresipermitExpiryDateType.getMonth()}/${visaresipermitExpiryDateType.getFullYear()}`;
        this.visaresipermitExpiryDate = new Date(value?.data?.[0]?.visa_permit_expiry_date).toLocaleDateString();

        this.panNo = value?.data?.[0]?.pan_number;
        this.form60 = value?.data?.[0]?.is_form_60;
      }
    })


    let Obj2={}

    if(this.accountType=='Minor'){
      if(this.isMinor==true){ // minor
        Obj2 = {
          user_id: this.regObj?.user_id,
          process_id: 36,
          applicant_id: this.applicantID
        }
      }else{ // Guardian 
        Obj2 = {
          user_id: this.regObj?.user_id,
          process_id: 49,
          applicant_id: this.applicantID
        }
      }
    }
    else{
      Obj2 = {
        user_id: this.regObj?.user_id,
        process_id: 9,
        applicant_id: this.applicantID
      }
    }


    // let Obj2 = {
    //   user_id: this.agentCommonServiceService.getUserFromLocalStorage()?.user_id,
    //   process_id: 9,
    //   applicant_id: this.applicantID
    // }
    

    this.agentDataServiceService.fetchKycDtls2(Obj2).subscribe((value) => {
      if (value?.data?.[0]?.lead_status != undefined) {
        if (value?.data?.[0]?.lead_status == 'agent_review') {
          this.approveDisable = true;
          this.processArr[0].isDisplayAddComment = false
          this.processArr[1].isDisplayAddComment = false
          this.processArr[0].isDislplayCommentUpdateBtn = false
          this.processArr[1].isDislplayCommentUpdateBtn = false
          this.processArr[0].isDislplayCommentTextArea = false
          this.processArr[1].isDislplayCommentTextArea = false
        }
      }
      this.tempVisaChk1 = value?.data?.[0]?.kyc_dtls_chk1;

      let docIssueDateType = new Date(value?.data?.[0]?.temporary_visa_declare_issue_date);
      this.docIssueDate = `${docIssueDateType.getDate()}/${docIssueDateType.getMonth()}/${docIssueDateType.getFullYear()}`;
      let docExpiryDateType = new Date(value?.data?.[0]?.temporary_visa_declare_expiry_date);
      this.docExpiryDate = `${docExpiryDateType.getDate()}/${docExpiryDateType.getMonth()}/${docExpiryDateType.getFullYear()}`;
      this.tempVisaChk2 = value?.data?.[0]?.kyc_dtls_chk2;
      this.temporaryVisaDec = value?.data?.[0]?.is_temporary_visa_declaration_name
    })

    for (let i = 0; i < this.processArr.length; i++) {
      await this.setComments(i)
    }


    setTimeout(() => {
      let minor = localStorage.getItem('isMinor')
      if (minor == "true") {
        this.isMinor = true
      } else {
        this.isMinor = false
      }
      console.log("?????????////minor", minor, this.isMinor)
      if (this.isMinor) {
        let applicantData = localStorage.getItem('applicantList')
        if (applicantData != null) {
          this.applicantList = JSON.parse(applicantData)
          var index = this.applicantList.findIndex((el: any) => el.applicant_personal_id == this.applicantID);
          if (this.applicantList.length > 1 && (index != this.applicantList.length - 1)) {
            this.showProceed = true
          } else {
            this.showProceed = false
          }
        }
      }
    }, 1000);
  }

  async setComments(ind: number) {
    let ObjC = {
      applicant_id: this.applicantID,
      lead_id: this.regObj?.customerUserID,
      agent_id: this.regObj?.user_id,
      process_id: this.processArr[ind].processId
    }

    this.agentDataServiceService.fetchAgentCommentSummary(ObjC).subscribe((data) => {
      if (data?.data?.agent_status == "approved") {
        this.processArr[ind].isDisplayAddComment = false;
        this.processArr[ind].isDisplayAddApprove = false;
        this.processArr[ind].isDislplayCommentTextArea = false;
        this.processArr[ind].isDislplayCommentUpdateBtn = false;
        this.processArr[ind].isDisplayEditDeleteCommentSection = false;
        this.processArr[ind].isDisplayProceedNext = true;

        this.showContactDivOut.emit();

        this.processArr[ind].isApproved = true;
        this.processArr[ind].approveMsg = 'This section is approved';
        if (this.visaType == 0) {
          if (this.processArr[0].isDisplayProceedNext === true) {
            this.procced = true
            this.isChecked.emit(true)
          }
        }
        else if (this.processArr[1].isDisplayProceedNext === true || this.processArr[0].isDisplayProceedNext === true) {
          this.procced = true
          this.isChecked.emit(true)
        }
      }
      else if (data?.data?.comment_id) {
        this.processArr[ind].isDisplayAddComment = false;
        this.processArr[ind].isDisplayAddApprove = true;
        this.processArr[ind].isDislplayCommentTextArea = false;
        this.processArr[ind].isDislplayCommentUpdateBtn = false;
        this.processArr[ind].isDisplayEditDeleteCommentSection = true;
        this.processArr[ind].isDisplayProceedNext = true;
        this.processArr[ind].commentData = data?.data?.comment;
        this.processArr[ind].commentID = data?.data?.comment_id;
        this.agentCommnentArrData = data;

        if (ind == 0) {
          this.kycDtlsForm1.controls['comments'].setValue(data?.data?.comment)
        }
        if (ind == 1) {
          this.kycDtlsForm2.controls['comments'].setValue(data?.data?.comment)
        }
      }
      if (this.visaType == 0) {
        if (this.processArr[0].isDisplayProceedNext === true) {
          this.procced = true
          this.isChecked.emit(true)
        }
      }
      else if (this.processArr[1].isDisplayProceedNext === true || this.processArr[0].isDisplayProceedNext === true) {
        this.procced = true
        this.isChecked.emit(true)
      }

    })
  }

  // get comments1() { return this.kycDtlsForm1.get('comments').value }
  get comments2() { return this.kycDtlsForm2.get('comments').value }
  get comments3() { return this.kycDtlsForm3.get('comments').value }

  addComment(val: string) {
    // if (val == 'Indentity Document') {
    //   if (this.kycDtlsForm1.valid) {
    //     let comment = this.kycDtlsForm1.get('comments').value
    //     let arrId = this.processArr.findIndex((res: any) => res.process == val)
    //     this.addCommentApi(comment, arrId)
    //   }
    //   else {
    //     this.openModalComment();
    //   }
    // }
    if (val == 'Visa type / Residence Permit') {
      if (this.kycDtlsForm1.valid) {
        let comment = this.kycDtlsForm1.get('comments').value
        let arrId = this.processArr.findIndex((res: any) => res.process == val)
        this.addCommentApi(comment, arrId)
      }
      else {
        this.openModalComment();
      }
    }

    else if (val == 'Temporary Visa Declaration') {
      if (this.kycDtlsForm2.valid) {
        let comment = this.kycDtlsForm2.get('comments').value
        let arrId = this.processArr.findIndex((res: any) => res.process == val)
        this.addCommentApi(comment, arrId)
      }
      else {
        this.openModalComment();
      }
    }
  }

  addCommentApi(getcomment: any, ind: number) {
    this.processArr[ind].isDisplayAddComment = false;
    this.processArr[ind].isDisplayAddApprove = true;
    this.processArr[ind].isDislplayCommentTextArea = false;
    this.processArr[ind].isDislplayCommentUpdateBtn = false;
    this.processArr[ind].isDisplayEditDeleteCommentSection = true;
    this.processArr[ind].isDisplayProceedNext = true;
    let Obj = {
      process_id: this.processArr[ind].processId,
      applicant_id: this.applicantID,
      parent_comment_id: 0,
      agent_id: this.agentCommonServiceService.getUserFromLocalStorage()?.user_id,
      comment: getcomment,
      lead_id: this.regObj?.customerUserID
    }

    this.agentDataServiceService.postAgentsComment(Obj).subscribe((value) => {
      let ObjC = {
        applicant_id: this.applicantID,
        lead_id: this.regObj?.customerUserID,
        agent_id: this.regObj?.user_id,
        process_id: this.processArr[ind].processId,
        "comment_id": value.comment_id
      }

      this.agentDataServiceService.fetchAgentCommentSummary(ObjC).subscribe((data) => {
        this.agentCommnentArrData = data;
        this.processArr[ind].commentData = data?.data?.comment;
        this.processArr[ind].commentID = data?.data?.comment_id;
      })

      if (this.visaType == 0) {
        if (this.processArr[0].isDisplayProceedNext === true) {
          this.procced = true
          this.isChecked.emit(true)
        }
      }
      else if (this.processArr[1].isDisplayProceedNext === true || this.processArr[0].isDisplayProceedNext === true) {
        this.procced = true
        this.isChecked.emit(true)
      }

    }, (err) => {
      console.log(err);
    })
  }

  updateComment(val: string) {
    // if (val == 'Indentity Document') {
    //   if (this.kycDtlsForm1.valid) {
    //     let comment = this.kycDtlsForm1.get('comments').value
    //     let arrId = this.processArr.findIndex((res: any) => res.process == val)
    //     this.updateCommentApi(comment, arrId)
    //   }
    //   else {
    //     this.openModalComment();
    //   }
    // }
    if (val == 'Visa type / Residence Permit') {
      if (this.kycDtlsForm1.valid) {
        let comment = this.kycDtlsForm1.get('comments').value
        let arrId = this.processArr.findIndex((res: any) => res.process == val)
        this.updateCommentApi(comment, arrId)
      }
      else {
        this.openModalComment();
      }
    }

    else if (val == 'Temporary Visa Declaration') {
      if (this.kycDtlsForm2.valid) {
        let comment = this.kycDtlsForm2.get('comments').value
        let arrId = this.processArr.findIndex((res: any) => res.process == val)
        this.updateCommentApi(comment, arrId)
      }
      else {
        this.openModalComment();
      }
    }
  }

  updateCommentApi(comment: string, ind: number) {
    this.processArr[ind].isDisplayAddComment = false;
    this.processArr[ind].isDisplayAddApprove = true;
    this.processArr[ind].isDislplayCommentTextArea = false;
    this.processArr[ind].isDislplayCommentUpdateBtn = false;
    this.processArr[ind].isDisplayEditDeleteCommentSection = true;
    this.processArr[ind].isDisplayProceedNext = true;

    let Obj = {
      process_id: this.processArr[ind].processId,
      applicant_id: this.applicantID,
      parent_comment_id: 0,
      agent_id: this.agentCommonServiceService.getUserFromLocalStorage()?.user_id,
      comment: comment,
      lead_id: this.regObj?.customerUserID,
      comment_id: this.processArr[ind].commentID
    }

    this.agentDataServiceService.postAgentsComment(Obj).subscribe((value) => {

      let ObjC = {
        lead_id: this.regObj?.customerUserID,
        agent_id: this.regObj?.user_id,
        applicant_id: this.applicantID,
        process_id: this.processArr[ind].processId,
        comment_id: value.comment_id
      }

      this.agentDataServiceService.fetchAgentCommentSummary(ObjC).subscribe((data) => {
        this.agentCommnentArrData = data;
        this.processArr[ind].commentData = data?.data.comment;
        this.processArr[ind].commentID = data?.data.comment_id;
      })
    }, (err) => {
      console.log(err);
    })
  }

  openModal() {
    this.display = "block";
  }

  onCloseHandled() {
    this.display = "none";
  }

  editComment(ind: number) {
    this.processArr[ind].isDisplayAddComment = false;
    this.processArr[ind].isDisplayAddApprove = true;
    this.processArr[ind].isDislplayCommentTextArea = true;
    this.processArr[ind].isDislplayCommentUpdateBtn = true;
    this.processArr[ind].isDisplayEditDeleteCommentSection = false;
    this.processArr[ind].isDisplayProceedNext = false;

    // let ObjC = {
    //   lead_id: this.regObj?.customerUserID,
    //   agent_id: this.agentCommonServiceService.getUserFromLocalStorage()?.user_id,
    //   process_id: 7
    // }

    // this.agentDataServiceService.fetchAgentCommentSummary(ObjC).subscribe((value) => {
    //   if (value?.data?.length > 0) {
    //     this.kycDtlsForm1 = this.fb.group({
    //       comments: [value?.data?.[0]?.comment, [Validators.required]]
    //     })
    //   }
    //   this.agentCommnentArrData = value?.data?.[0]?.agentCommnentArrData;
    // })
  }

  checkDeleteComment(val: number) {
    this.deleteCommentInd = val
    this.openModal();
  }

  deleteComment() {
    if (this.processArr[this.deleteCommentInd].commentID > 0) {
      let Obj = {
        comment_id: this.processArr[this.deleteCommentInd].commentID
      }
      this.agentDataServiceService.deleteComment(Obj).subscribe((value) => {
        // window.location.reload();
        // this.rt.navigate([this.rt.url])
        if (value.msg === "comments delete successfully") {

          if (this.deleteCommentInd == 0) {
            this.kycDtlsForm1.controls['comments'].setValue('')
          }
          if (this.deleteCommentInd == 1) {
            this.kycDtlsForm2.controls['comments'].setValue('')
          }
          this.processArr[this.deleteCommentInd].isDisplayAddComment = true;
          this.processArr[this.deleteCommentInd].isDisplayAddApprove = true;
          this.processArr[this.deleteCommentInd].isDislplayCommentTextArea = true;
          this.processArr[this.deleteCommentInd].isDislplayCommentUpdateBtn = false;
          this.processArr[this.deleteCommentInd].isDisplayEditDeleteCommentSection = false;
          this.processArr[this.deleteCommentInd].isDisplayProceedNext = false;
          this.processArr[this.deleteCommentInd].commentData = '';
          this.processArr[this.deleteCommentInd].commentID = 0;
          this.display = "none";
          if (this.processArr[1].isDisplayProceedNext === true || this.processArr[0].isDisplayProceedNext === true) {
            this.procced = true
            this.isChecked.emit(true)
          }
          else {
            this.procced = false
          }
        }
      });
    }
    else {
    }
  }

  proceedNext() {
    this.showContactDivOut.emit();
  }

  nextApplicant() {
    // let existArray
    // let enabledApplicant = localStorage.getItem('enabledApplicant')
    // if (enabledApplicant != null) {
    //   existArray = JSON.parse(enabledApplicant)
    // }
    // var index = this.applicantList.findIndex((el: any) => el.applicant_personal_id == this.applicantID);
    // //  existArray=this.agentCommonServiceService.enabledApplicant
    // if (existArray.indexOf(index + 1) === -1) {
    //   existArray.push(index + 1)
    // }
    // // this.agentCommonServiceService.enabledApplicant=existArray
    // localStorage.setItem('enabledApplicant', JSON.stringify(existArray))
    // setTimeout(() => {
    //   this.agentCommonServiceService.applicantIndex.next(index + 1)
    //   this.rt.navigate(['/dashboard', 'lead-dtls1', this.applicantList[index + 1].applicant_personal_id]);
    //   setTimeout(() => {
    //     window.location.reload();
    //   }, 300);
    // }, 300);
      // window.scroll(0,0);
   
      window.alert(' Review Doc Section !')
      window.scroll({ 
              top: 0, 
              left: 0, 
              behavior: 'smooth' 
       });
   
  }

  approveLead(ind: number) {
    this.processArr[ind].isDisplayAddComment = false;
    this.processArr[ind].isDisplayAddApprove = false;
    this.processArr[ind].isDislplayCommentTextArea = false;
    this.processArr[ind].isDislplayCommentUpdateBtn = false;
    this.processArr[ind].isDisplayEditDeleteCommentSection = false;
    this.processArr[ind].isDisplayProceedNext = true;

    let Obj = {
      applicant_id: this.applicantID,
      process_id: this.processArr[ind].processId,
      lead_id: this.regObj?.customerUserID
    }

    this.agentDataServiceService.approveLead(Obj).subscribe((value) => {
      this.processArr[ind].isApproved = true;
      this.processArr[ind].approveMsg = 'This section is approved'

      if (value?.msg) {
        // this.processArr[ind].isDisplayAddComment = false;
        // this.processArr[ind].isDisplayAddApprove = false;
        // this.processArr[ind].isDislplayCommentTextArea = false;
        // this.processArr[ind].isDislplayCommentUpdateBtn = false;
        // this.processArr[ind].isDisplayEditDeleteCommentSection = false;
        // this.processArr[ind].isDisplayProceedNext = false;
        if (this.visaType == 0) {
          if (this.processArr[0].isDisplayProceedNext === true) {
            this.procced = true
            this.isChecked.emit(true)
          }
        }
        else if (this.processArr[1].isDisplayProceedNext === true || this.processArr[0].isDisplayProceedNext === true) {
          this.procced = true
          this.isChecked.emit(true)
        }
        if (this.processArr[0].isApproved && this.processArr[1].isApproved) {
          this.showContactDivOut.emit();
        }
      }
      // location.href='#personalDtls';
    })
  }

  openModalComment() {
    this.displayCommentErr = "block";
  }

  closeModalComment() {
    this.displayCommentErr = "none";
  }
}