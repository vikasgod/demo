import { Component, OnInit } from '@angular/core';
// import { DataTablesModule } from 'angular-datatables';
import { AgentDataServiceService } from '../services/agent-data-service.service';
import { AgentCommonServiceService } from '../services/agent-common-service.service';
import { Router } from '@angular/router';
import * as $ from 'jquery';


@Component({
  selector: 'app-leads-dtls-review-tbl',
  templateUrl: './leads-dtls-review-tbl.component.html',
  styleUrls: ['./leads-dtls-review-tbl.component.css']
})
export class LeadsDtlsReviewTblComponent implements OnInit {
  agentListData: any;
  agentsCreateDate: any;
  accntType: number = 1;
  newLeads: string = '';
  leadsUnderProcess: string = '';
  reviewedLeads: string = '';
  agentListDataArr: Array<any> = [];

  roleID: number = 0;

  page: number = 1;
  count: number = 0;
  tableSize: number = 10;
  tableSizes: any = [3, 6, 9, 12];
  filterData: any
  fullagentListDataArr: any = []

  constructor(private agentDataServiceService: AgentDataServiceService, private agentCommonServiceService: AgentCommonServiceService, private rt: Router) { }


  ngOnInit(): void {

    // $('#datatable').DataTable();

    // this.http.get('https://jsonplaceholder.typicode.com/posts').subscribe((resp: Response) => {
    //   this.empData = resp;
    //   this.temp = true;
    // });

    // $('#dataTable tfoot th').each(function () {
    //   var title = $(this).text();
    //   $(this).html('<input type="text" placeholder="Search ' + title + '" />');
    // });

    // var table = $('#dataTable').DataTable({
    //   initComplete: function () {
    //     this.api()
    //       .columns()
    //       .every(function () {
    //         var that = this;

    //         $('input', this.footer()).on('keyup change clear', function () {
    //           if (that.search() !== this.value) {
    //             that.search(this.value).draw();
    //           }
    //         });
    //       });
    //   },
    // });

    let Obj = {
      agent_id: this.agentCommonServiceService.getUserFromLocalStorage()?.user_id,
      lead_type: 'agent_review'
    }

    this.roleID = this.agentCommonServiceService.getUserFromLocalStorage()?.role_id

    if (this.roleID == 3) {
      var agent_id = this.agentCommonServiceService.getUserFromLocalStorage()?.user_id
      this.agentDataServiceService.postAgentLeadCount({ agent_id: agent_id, lead_type: 'reviewed' }).subscribe((data) => {
        if (data?.data?.length) {
          this.agentListDataArr = data?.data;
          this.fullagentListDataArr = data?.data;
        }
      })

    } else {
      var agent_id = this.agentCommonServiceService.getUserFromLocalStorage()?.user_id
      console.log('agent list');
      this.agentDataServiceService.getSuperAgentReviewedLeadList().subscribe((data) => {
        this.agentListDataArr = data?.data;
        this.fullagentListDataArr = data?.data;
      })
    }
  }

  veiwReviewLeads(applicantID: number, leadID: number, type:string) {
    localStorage.setItem('accountType',type)
    this.getApplicantCount(applicantID)
    localStorage.removeItem("isMinor");
    this.agentCommonServiceService.storeInLocalStorage('agentData', { customerUserID: leadID })
    this.rt.navigate(['/dashboard', 'lead-dtls1', applicantID]).then(() => {
      window.location.reload();
    });
  }

  onTableDataChange(event: any) {
    this.page = event;
  }
  onTableSizeChange(event: any): void {
    this.tableSize = event.target.value;
    this.page = 1;
  }

  getFilteredData() {
    this.agentListDataArr = this.fullagentListDataArr.filter((obj: any) => {
      return (obj.agent_name.includes(this.filterData) || obj.lead_number.includes(this.filterData) || obj.applicant_name.includes(this.filterData) || obj.account_type.includes(this.filterData))
    });
  }

  // get applicant list
  getApplicantCount(applicantID: any) {
    let Obj = {
      applicant_id: applicantID
    }
    this.agentDataServiceService.getApplicantData(Obj).subscribe((res) => {
      localStorage.setItem('applicantList', JSON.stringify(res.data))
      localStorage.setItem('enabledApplicant', JSON.stringify([0]))
    })
  }
}
