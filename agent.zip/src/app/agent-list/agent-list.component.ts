import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { AgentDataServiceService } from '../services/agent-data-service.service';
import { AgentCommonServiceService } from '../services/agent-common-service.service';

@Component({
  selector: 'app-agent-list',
  templateUrl: './agent-list.component.html',
  styleUrls: ['./agent-list.component.css']
})
export class AgentListComponent implements OnInit {
  agent: any;
  addSuperAgent: any;
  manager:any;
  editingAgentId: number | null = null;
  userID:any;
  page: number = 1;
  count: number = 0;
  tableSize: number = 5;
  searchList:any;
  filterData:any;
  length:any;

  constructor(private agentDataServiceService: AgentDataServiceService,private commonService: AgentCommonServiceService, private fb: FormBuilder,) { }

  ngOnInit(): void {
    this.addSuperAgent = this.fb.group({
      firstName: ['', Validators.required],
      middleName: ['', Validators.required],
      lastName: ['', Validators.required],
      mobileNo: ['', [Validators.required, Validators.pattern(/[0-9]{10}/)]],
      username: ['', Validators.required],
      reporting: ['', Validators.required],

      // password: ['', Validators.required]
    })
    this.getAgent()
    this.getManager()
  }

  getManager(){
    this.agentDataServiceService.getReporingManager().subscribe((res)=>{
      this.manager = res
    })
  }

  getAgent(){
    this.agentDataServiceService.getAgentList().subscribe((res) => {
      this.agent = res.data
      this.searchList = res.data
      this.length = res.data.length
    })
  }

  deleteUser(id: number) {
    this.userID = id
  }

  onClick(value:any){
    if(value == true){
      this.agentDataServiceService.postDeleteAgent({ user_id: this.userID }).subscribe(() => {
        this.getAgent();
      });
    }
  }

  getEditAgent(agent: any) {
    this.editingAgentId = agent.user_id;
    this.addSuperAgent.patchValue({
      firstName: agent.first_name,
      middleName: agent.middle_name,
      lastName: agent.last_name,
      mobileNo: agent.mobile_no,
      username: agent.username,
      reporting: agent.reporting_manager,
    });
  }
   //Filter Only Numbers  
   kypressNumber(event: any) {
    return this.commonService.MobileNumberEnterOnly(event);
  }

  onTableDataChange(event: any) {
    this.page = event;
  }

  closeModal() {
    location.reload()
    this.editingAgentId = null;
    this.addSuperAgent.reset();
    (document.getElementById('closeModal') as HTMLElement).click();
  }

  cancelEdit() {
    this.editingAgentId = null;
    this.addSuperAgent.reset();
  }

  get username() { return this.addSuperAgent.get('username') }
  get firstName() { return this.addSuperAgent.get('firstName') }
  get middleName() { return this.addSuperAgent.get('middleName') }
  get lastName() { return this.addSuperAgent.get('lastName') }
  get mobileNo() { return this.addSuperAgent.get('mobileNo') }
  get reporting(){return this.addSuperAgent.get('reporting')}

  submitLogin() {
    if (this.addSuperAgent.valid) {
      const formData = this.addSuperAgent.value;
      const agentData = {
        role_id: 3,
        first_name: formData.firstName,
        middle_name: formData.middleName,
        last_name: formData.lastName,
        mobile_no: formData.mobileNo,
        username: formData.username,
        reporting_manager: formData.reporting,
      };

      if (this.editingAgentId !== null) {
        agentData.role_id = this.editingAgentId;
        this.agentDataServiceService.postUpdateAgent(agentData).subscribe(() => {
          this.closeModal();
          this.getAgent();
        });
      } else {
        this.agentDataServiceService.postAddAgent(agentData).subscribe(() => {
          this.closeModal();
          this.getAgent();
        });
      }
    }
  }
  getFilterData(){
    this.agent = this.searchList.filter((obj:any)=>{
      return (obj.username.includes(this.filterData))
    })
  }
}
