import { Component, OnInit, AfterViewInit } from '@angular/core';
import { AgentDataServiceService } from '../services/agent-data-service.service';
import { AgentCommonServiceService } from '../services/agent-common-service.service';
import { Router } from '@angular/router';
import { Observable, of } from 'rxjs';
import { FormBuilder, Validators } from '@angular/forms';


@Component({
  selector: 'app-leads-dtls-tbl',
  templateUrl: './leads-dtls-tbl.component.html',
  styleUrls: ['./leads-dtls-tbl.component.css']
})
export class LeadsDtlsTblComponent implements OnInit {

  agentListData: any;
  agentsCreateDate: any;
  accntType: number = 1;
  newLeads: string = '';
  leadsUnderProcess: string = '';
  reviewedLeads: string = '';
  agentListDataArr: Array<any> = [];
  agentListDataArr$: Observable<any> = of();
  superAgentListDataArr: Array<any> = [];
  roleID: number = 0;
  displayAssignLeads: string = 'none';
  displayAssignLeadSuccess: string = 'none';
  currentLeadID: number = 0;
  currentLeadName: string = '';
  allAgentList: any = '';
  agentID: number = 0;
  assignForm:any;

  page: number = 1;
  count: number = 0;
  tableSize: number = 10;
  tableSizes: any = [3, 6, 9, 12];
  filterData:any
  fullagentListDataArr:any=[]

  constructor(private agentDataServiceService: AgentDataServiceService, private agentCommonServiceService: AgentCommonServiceService, private rt: Router, private fb: FormBuilder) { 
  
  }

  ngOnInit(): void {

    this.assignForm = this.fb.group({
      assignAgent: ['', Validators.required]
    })

    let Obj = {
      agent_id: this.agentCommonServiceService.getUserFromLocalStorage()?.user_id,
      lead_type: 'lead'
    }
    

    this.roleID = this.agentCommonServiceService.getUserFromLocalStorage()?.role_id
    this.agentID = this.agentCommonServiceService.getUserFromLocalStorage()?.user_id
    console.log("4756464",this.agentID)
  
    if (this.roleID == 2) {
      this.agentDataServiceService.getSuperAgentAllAgentsList(this.agentID).subscribe((data) => {
        this.allAgentList = data?.agent_list;
        console.log('This is agent List', this.allAgentList);
      })
    }

    if (this.roleID == 2) {
      var agent_id = this.agentCommonServiceService.getUserFromLocalStorage()?.user_id
      this.agentDataServiceService.getSuperAgentNewLeadList().subscribe((data) => {
        this.superAgentListDataArr = data?.data;
        this.fullagentListDataArr = data?.data;
        // this.superAgentListDataArr = data?.data;
        // console.log('This is super agent data', this.superAgentListDataArr);
      })
    } 
    else {
      var agent_id = this.agentCommonServiceService.getUserFromLocalStorage()?.user_id
      console.log('agent list');
      this.agentDataServiceService.postAgentLeadCount({ agent_id: agent_id, lead_type: 'assigned' }).subscribe((data) => {
        this.agentListDataArr = data?.data;
        this.fullagentListDataArr=data?.data;
      })

      // this.agentDataServiceService.getNewLeadList(Obj).subscribe((data) => {

      //   this.agentListData = data?.data;

      //   this.agentListData.map((data: any) => {
      //     console.log('This is agent data', data);
      //     let agentDate = new Date(data?.created_on);
      //     let agentDateAppliedOn = `${agentDate.getDate()}/${agentDate.getMonth()}/${agentDate.getFullYear()}  ${agentDate.getHours()}:${agentDate.getMinutes()}:${agentDate.getSeconds()}`;
      //     let Obj = Object.assign(data, { 'created_on': agentDateAppliedOn })
      //     this.agentListDataArr.push(Obj);

      //   })

      // })
    }

    // let Obj={
    //   //agent_id: this.agentCommonServiceService.getUserFromLocalStorage()?.user_id
    //   agent_id: this.agentCommonServiceService.getUserFromLocalStorage()?.user_id,
    //   lead_type:'lead'
    // }

    // this.agentListDataArr$=this.agentDataServiceService.getNewLeadList(Obj);

    // console.log(this.agentListDataArr$);

    // this.agentDataServiceService.getNewLeadList(Obj).subscribe((data)=>{

    //   this.agentListData=data?.data;

    //   this.agentListData.map((data:any)=>{
    //     console.log('This is agent data',data)
    //     let agentDate=new Date(data?.created_on);
    //     let agentDateAppliedOn=`${agentDate.getDate()}/${agentDate.getMonth()}/${agentDate.getFullYear()}  ${agentDate.getHours()}:${agentDate.getMinutes()}:${agentDate.getSeconds()}`;
    //     let Obj=Object.assign(data,{'created_on':agentDateAppliedOn})
    //     this.agentListDataArr.push(Obj);
    //   })
    // })
  }

  // ngAfterViewInit(): void {
  //   let Obj = {
  //     agent_id: this.agentCommonServiceService.getUserFromLocalStorage()?.user_id,
  //     lead_type: 'lead'
  //   }
  //   this.roleID = this.agentCommonServiceService.getUserFromLocalStorage()?.role_id
  //   if (this.roleID === 2) {
  //     this.agentDataServiceService.getSuperAgentLeadList().subscribe((data) => {
  //       this.superAgentListDataArr = data?.data;
  //       console.log('This is super agent data', this.superAgentListDataArr);
  //     })
  //   } else {

  //     this.agentDataServiceService.getNewLeadList(Obj).subscribe((data) => {

  //       this.agentListData = data?.data;

  //       this.agentListData.map((data: any) => {
  //         console.log('This is agent data', data)
  //         let agentDate = new Date(data?.created_on);
  //         let agentDateAppliedOn = `${agentDate.getDate()}/${agentDate.getMonth()}/${agentDate.getFullYear()}  ${agentDate.getHours()}:${agentDate.getMinutes()}:${agentDate.getSeconds()}`;
  //         let Obj = Object.assign(data, { 'created_on': agentDateAppliedOn })
  //         this.agentListDataArr.push(Obj);
  //       })
  //     })
  //   }
  // }

  acceptLead(lead_id: number, applicantID: number, type: string) {

    localStorage.setItem('accountType',type)
    this.getApplicantCount(applicantID)
    localStorage.removeItem("isMinor");
    let rejObj = this.agentCommonServiceService.getUserFromLocalStorage()
    let agentID = rejObj?.user_id;
    let Obj = {
      agent_id: agentID,
      lead_id: lead_id
    }

    this.agentCommonServiceService.storeInLocalStorage('agentData', { customerUserID: lead_id });

    this.agentDataServiceService.postAcceptAgentsLead(Obj).subscribe((data) => {
      this.rt.navigate(['/dashboard', 'lead-dtls1', applicantID]).then(() => {
        window.location.reload();
      });
    })
  }

  // rejectedLead(lead_id: number, applicantID: number) {
  //   let rejObj = this.agentCommonServiceService.getUserFromLocalStorage()
  //   let agentID = rejObj?.user_id;
  //   let Obj = {
  //     agent_id: agentID,
  //     lead_id: lead_id
  //   }

  //   this.agentCommonServiceService.storeInLocalStorage('agentData', { customerUserID: lead_id });

  //   this.agentDataServiceService.RejectAgentList(Obj).subscribe((data) => {
  //     console.log("Data is successfully accepted", data);

  //     this.rt.navigate(['/dashboard', '#', applicantID]);
  //   })
  // }

  superAgentAssignLeads() {
    let Obj = {
      agent_id: this.agentID,
      lead_id: this.currentLeadID
    }
    this.agentDataServiceService.postAssignSuperAgentLead(Obj).subscribe((data) => {
      console.log('This is assign leads agent', data);
      this.closeAssignLeadsModal();
      this.openSuccessLeadAssignLeadModal();

      setTimeout(() => {
        this.closeSuccessLeadAssignLeadModal();
      }, 1000)
      //window.location.reload();
    })
  }

  openAssignLeadsOpenModal(id: number, firstName: string) {
    this.currentLeadID = id;
    this.displayAssignLeads = 'block';
    this.currentLeadName = `${firstName}`;
    console.log('THis is lead ID', id)
  }

  closeAssignLeadsModal() {
    this.displayAssignLeads = 'none';
  }

  getAgentID(event: any) {
    this.agentID = Number(event.target.value);
  }

  openSuccessLeadAssignLeadModal() {
    this.displayAssignLeadSuccess = 'block';
  }

  closeSuccessLeadAssignLeadModal() {
    this.displayAssignLeadSuccess = 'block';
    window.location.reload();
  }

  onTableDataChange(event: any) {
    this.page = event;
  }
  onTableSizeChange(event: any): void {
    this.tableSize = event.target.value;
    this.page = 1;
  }

  getFilteredData(){
    this.agentListDataArr = this.fullagentListDataArr.filter((obj:any) =>{  
      return (obj.lead_number.includes(this.filterData) || obj.applicant_name?.toLowerCase().includes(this.filterData?.toLowerCase()) || obj.account_type?.toLowerCase().includes(this.filterData?.toLowerCase()))
    });

    this.superAgentListDataArr = this.fullagentListDataArr.filter((obj:any) =>{ 
      return (obj.lead_number.includes(this.filterData) || obj.applicant_name?.toLowerCase().includes(this.filterData?.toLowerCase()) || obj.account_type?.toLowerCase().includes(this.filterData?.toLowerCase()))
    });
  }

  // get applicant list
  getApplicantCount(applicantID: any) {
    let Obj = {
      applicant_id: applicantID
    }
    this.agentDataServiceService.getApplicantData(Obj).subscribe((res) => {
      localStorage.setItem('applicantList', JSON.stringify(res.data))
      localStorage.setItem('enabledApplicant', JSON.stringify([0]))
    })
  }
}