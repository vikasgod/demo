import { Component, OnInit } from '@angular/core';
import { AgentDataServiceService } from '../services/agent-data-service.service';
import { AgentCommonServiceService } from '../services/agent-common-service.service';
import { Router } from '@angular/router';
import { Observable, of } from 'rxjs';
import { FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-assign-list-dtls',
  templateUrl: './assign-list-dtls.component.html',
  styleUrls: ['./assign-list-dtls.component.css']
})
export class AssignListDtlsComponent implements OnInit {


  roleID: number = 0;
  superAgentListDataArr: Array<any> = [];
  allAgentList: any = '';
  agentListData: any;

  agentListDataArr: Array<any> = [];
  agentListDataArr$: Observable<any> = of();

  displayReassignLeadSuccess: string = 'none';

  displayReassignLeads: string = 'none';
  currentLeadID: number = 0;
  agentID: number = 0;

  currentLeadName: string = '';
  agentName: string = '';
  assignForm: any;

  page: number = 1;
  count: number = 0;
  tableSize: number = 10;
  tableSizes: any = [3, 6, 9, 12];
  filterData:any
  fullagentListDataArr:any=[]

  constructor(private agentDataServiceService: AgentDataServiceService, private agentCommonServiceService: AgentCommonServiceService, private rt: Router, private fb: FormBuilder) { }

  ngOnInit(): void {

    this.assignForm = this.fb.group({
      assignAgent: ['', Validators.required]
    })

    let Obj = {
      agent_id: this.agentCommonServiceService.getUserFromLocalStorage()?.user_id,
      lead_type: 'lead'
    }

    this.roleID = this.agentCommonServiceService.getUserFromLocalStorage()?.role_id
    this.agentID = this.agentCommonServiceService.getUserFromLocalStorage()?.user_id
    if (this.roleID == 2) {
      this.agentDataServiceService.getSuperAgentAllAgentsList(this.agentID).subscribe((data) => {
        this.allAgentList = data?.agent_list;
        console.log('This is agent List', this.allAgentList);
      })
    }



    if (this.roleID === 2) {
      this.agentDataServiceService.getSuperAgentAssignedLeadList().subscribe((data) => {
        this.superAgentListDataArr = data?.data;
        this.fullagentListDataArr = data?.data;
        console.log('This is super agent data', this.superAgentListDataArr);
      })
    } else {

      this.agentDataServiceService.getNewLeadList(Obj).subscribe((data) => {
        this.agentListData = data?.data;
        this.agentListData.map((data: any) => {
          console.log('This is agent data', data);
          let agentDate = new Date(data?.created_on);
          let agentDateAppliedOn = `${agentDate.getDate()}/${agentDate.getMonth()}/${agentDate.getFullYear()}  ${agentDate.getHours()}:${agentDate.getMinutes()}:${agentDate.getSeconds()}`;
          let Obj = Object.assign(data, { 'created_on': agentDateAppliedOn })
          this.agentListDataArr.push(Obj);

        })

      })
    }
  }


  superAgentReassignLeads() {
    let Obj = {
      agent_id: this.agentID,
      lead_id: this.currentLeadID
    }
    this.agentDataServiceService.postReassignSuperAgentLead(Obj).subscribe((data) => {
      console.log('This is assign leads agent', data);
      this.closeReassignLeadsModal();
      this.openSuccessLeadReassignLeadModal();

      setTimeout(() => {
        this.closeSuccessLeadReassignLeadModal();
      }, 1000)
      //window.location.reload();
    })
  }

  openReassignLeadsOpenModal(id: number, firstName: string, secondName: string) {
    this.currentLeadID = id;
    this.displayReassignLeads = 'block';
    this.currentLeadName = `${firstName}`;
    this.agentName = `${secondName}`
    console.log('THis is lead name', this.currentLeadName)
  }

  closeReassignLeadsModal() {
    this.displayReassignLeads = 'none';
  }

  getAgentID(event: any) {

    this.agentID = Number(event.target.value);
  }

  openSuccessLeadReassignLeadModal() {
    this.displayReassignLeadSuccess = 'block';

  }

  closeSuccessLeadReassignLeadModal() {
    this.displayReassignLeadSuccess = 'block';
    window.location.reload();
  }

  onTableDataChange(event: any) {
    this.page = event;
  }
  onTableSizeChange(event: any): void {
    this.tableSize = event.target.value;
    this.page = 1;
  }

  getFilteredData(){
    this.superAgentListDataArr = this.fullagentListDataArr.filter((obj:any) =>{  
      return (obj.agent_name.includes(this.filterData) || obj.lead_number.includes(this.filterData) || obj.applicant_name.includes(this.filterData) || obj.account_type.includes(this.filterData))
    });
  }

}
