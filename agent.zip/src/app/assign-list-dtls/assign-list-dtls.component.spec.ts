import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AssignListDtlsComponent } from './assign-list-dtls.component';

describe('AssignListDtlsComponent', () => {
  let component: AssignListDtlsComponent;
  let fixture: ComponentFixture<AssignListDtlsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AssignListDtlsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AssignListDtlsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
