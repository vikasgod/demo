import { Component, OnInit } from '@angular/core';
import { AgentDataServiceService } from '../services/agent-data-service.service';
import { AgentCommonServiceService } from '../services/agent-common-service.service';
import { data } from 'jquery';

@Component({
  selector: 'app-agent-lead-count',
  templateUrl: './agent-lead-count.component.html',
  styleUrls: ['./agent-lead-count.component.css']
})
export class AgentLeadCountComponent implements OnInit {

  superAgentAssignedLeadsList: any;
  superAgentAassignLeads: any;
  superAgentReviwedLeadsList: any;
  superAgentRejectedLeadsList: any;
  superAgentApprovedLeadsList: any;
  superAgentUnderProcessLeadsList:any

  agentsCount: any;
  leadsUnderProcess: any;
  agentID: any;
  roleID: number = 0;
  superAgentNewLeadsList: number = 0;

  //nihal
  assignedLeadsCount: number = 0;
  underProcessLeadCount: number = 0;
  reviewedLeadCount: number = 0;
  rejectedLeadCount: number = 0;
  approvedLeadCount: number = 0;
  incompleteOrDropOutLeadCount: number = 0;
  agent: any;
  superAgent: any;

  //nihal
  constructor(private agentDataServiceService: AgentDataServiceService, private agentCommonServiceService: AgentCommonServiceService) { }

  ngOnInit(): void {
    this.agentID = this.agentCommonServiceService.getUserFromLocalStorage()?.user_id;
    this.roleID = this.agentCommonServiceService.getUserFromLocalStorage()?.role_id;
    // this.agentDataServiceService.postSuperAgentProcessLeadsCount({agent_id:this.agentID}).subscribe((value)=>{
    //   this.superAgentAassignLeads=value?.superAgentAassignLeads_lead_count;
    // })

    this.roleID = this.agentCommonServiceService.getUserFromLocalStorage()?.role_id

    if(this.roleID == 1){
      this.agentDataServiceService.getSuperAgentAndAgentCount().subscribe((res) => {
        this.agent = res.data.agent
        this.superAgent = res.data.super_agent
        console.log("check", res.data);
        
      })
    }

    if (this.roleID == 2) {
      this.agentDataServiceService.getSuperAgentNewLeadList().subscribe((data) => {
        if (data?.data?.length) {
          this.superAgentNewLeadsList = data?.data?.length;
        }
        else {
          this.superAgentNewLeadsList = 0;
        }

      })

      this.agentDataServiceService.getSuperAgentAssignedLeadList().subscribe((data) => {
        if (data?.data?.length) {
          this.superAgentAssignedLeadsList = data?.data?.length;
        } 
        else {
          this.superAgentAssignedLeadsList = 0;
        }

      })

      this.agentDataServiceService.getSuperAgentReviewedLeadList().subscribe((data) => {
        if (data?.data?.length) {
          this.superAgentReviwedLeadsList = data?.data?.length;
        } 
        else {
          this.superAgentReviwedLeadsList = 0;
        }
      })

      this.agentDataServiceService.getSuperAgentRejectedLeadList().subscribe((data) => {
        if (data?.data?.length) {
          this.superAgentRejectedLeadsList = data?.data?.length;
        } 
        else {
          this.superAgentRejectedLeadsList = 0;
        }

      })

      this.agentDataServiceService.getSuperAgentApprovedLeadList().subscribe((data) => {
        if (data?.data?.length) {
          this.superAgentApprovedLeadsList = data?.data?.length;
        } 
        else {
          this.superAgentApprovedLeadsList = 0;
        }
      })

      this.agentDataServiceService.getSuperAgentUnderProcessLeadList().subscribe((data) => {
        if (data?.data?.length > 0) {
          this.superAgentUnderProcessLeadsList = data?.data?.length;
        } 
        else {
          this.superAgentUnderProcessLeadsList = 0;
        }
      })
    }

    if (this.roleID == 3) {
      this.agentDataServiceService.postIncompleteAgentsLead({ lead_type: 'incomplete' }).subscribe((data) => {
          this.incompleteOrDropOutLeadCount = data?.data?.length;
      })
      this.agentDataServiceService.postAgentLeadCount({ agent_id: this.agentID, lead_type: 'assigned' }).subscribe((data) => {
        if (data?.data?.length) {
          this.assignedLeadsCount = data?.data?.length;
        }
      })

      this.agentDataServiceService.postAgentLeadCount({ agent_id: this.agentID, lead_type: 'agent_process' }).subscribe((data) => {
        if (data?.data?.length) {
          this.underProcessLeadCount = data?.data?.length;
        }
      })

      this.agentDataServiceService.postAgentLeadCount({ agent_id: this.agentID, lead_type: 'reviewed' }).subscribe((data) => {
        if (data?.data?.length) {
          this.reviewedLeadCount = data?.data?.length;
        }
      })

      this.agentDataServiceService.postAgentLeadCount({ agent_id: this.agentID, lead_type: 'rejected' }).subscribe((data) => {
        if (data?.data?.length) {
          this.rejectedLeadCount = data?.data?.length;
        }
      })

      this.agentDataServiceService.postAgentLeadCount({ agent_id: this.agentID, lead_type: 'approved' }).subscribe((data) => {
        if (data?.data?.length) {
          this.approvedLeadCount = data?.data?.length;
        }
      })
    }
  }
}