import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SuperAgentListComponent } from './super-agent-list.component';

describe('SuperAgentListComponent', () => {
  let component: SuperAgentListComponent;
  let fixture: ComponentFixture<SuperAgentListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SuperAgentListComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SuperAgentListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
