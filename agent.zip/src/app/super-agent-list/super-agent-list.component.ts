import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AgentDataServiceService } from '../services/agent-data-service.service';
import { AgentCommonServiceService } from '../services/agent-common-service.service';

@Component({
  selector: 'app-super-agent-list',
  templateUrl: './super-agent-list.component.html',
  styleUrls: ['./super-agent-list.component.css']
})
export class SuperAgentListComponent implements OnInit {
  length: any;
  superAgent: any;
  addSuperAgent: any;
  userID:any;
  page: number = 1;
  count: number = 0;
  tableSize: number = 10;
  searchList:any;
  filterData:any;

  constructor(private agentDataServiceService: AgentDataServiceService,private commonService: AgentCommonServiceService, private fb: FormBuilder) { }

  ngOnInit(): void {
    this.addSuperAgent = this.fb.group({
      firstName: ['', Validators.required],
      middleName: ['', Validators.required],
      lastName: ['', Validators.required],
      mobileNo: ['', Validators.required],
      username: ['', Validators.required],
      // password: ['', Validators.required]
    })
    this.getAgent()
  }

  getAgent() {
    this.agentDataServiceService.getSuperAgentList().subscribe((res) => {
      this.superAgent = res.data
      this.length = res.data.length
      this.searchList = res.data
    })
  }

  deleteUser(id:any){
    this.userID = id
  }
  onClick(value:any){
    if(value == true){
      this.agentDataServiceService.postDeleteAgent({user_id:this.userID}).subscribe((data)=>{
        this.getAgent()
      })
    }
  }

  kypressNumber(event: any) {
    return this.commonService.MobileNumberEnterOnly(event);
  }

  onTableDataChange(event: any) {
    this.page = event;
  }

  get username() { return this.addSuperAgent.get('username') }
  get firstName() { return this.addSuperAgent.get('firstName') }
  get middleName() { return this.addSuperAgent.get('middleName') }
  get lastName() { return this.addSuperAgent.get('lastName') }
  get mobileNo() { return this.addSuperAgent.get('mobileNo') }

  submitLogin() {
    if (this.addSuperAgent.valid) {
      let Obj = {
        role_id: 2,
        first_name: this.addSuperAgent.controls['firstName'].value,
        middle_name: this.addSuperAgent.controls['middleName'].value,
        last_name: this.addSuperAgent.controls['lastName'].value,
        username:this.addSuperAgent.controls['username'].value,
        mobile_no: this.addSuperAgent.controls['mobileNo'].value,
        // email_address: this.addSuperAgent.controls['username'].value,
        // password: this.addSuperAgent.controls['username'].value,
      }

      this.agentDataServiceService.postAddAgent(Obj).subscribe((data) => {
        document.getElementById('closeModal')?.click()
        this.getAgent()
      })
    }
  }

  getFilterData(){
    this.superAgent = this.searchList.filter((obj:any)=>{
      return (obj.username.includes(this.filterData))
    })
  }
}