import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LeadsDtlsApproveTblComponent } from './leads-dtls-approve-tbl.component';

describe('LeadsDtlsApproveTblComponent', () => {
  let component: LeadsDtlsApproveTblComponent;
  let fixture: ComponentFixture<LeadsDtlsApproveTblComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ LeadsDtlsApproveTblComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(LeadsDtlsApproveTblComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
