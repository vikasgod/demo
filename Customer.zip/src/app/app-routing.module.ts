import { Component, NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CustomerAuthGuard } from '../app/auth-gard/customer-auth-guard';
import { CustomerSignUpAuthGuard } from './auth-gard/customer-signup-auth-guard';

import { SignupAuthComponent } from './shared/signup-auth/signup-auth.component';
import { LoginComponent } from './shared/login/login.component';
import { CountryTypeComponent } from './shared/country-type/country-type.component';
import { AccountTypeComponent } from './shared/account-type/account-type.component';
import { RegistrationComponent } from './shared/registration/registration.component';

import { PersonalDtls1Component } from './individual-accnt/personal-dtls1/personal-dtls1.component';
import { PersonalDtls2Component } from './individual-accnt/personal-dtls2/personal-dtls2.component';
import { FatcaComponent } from './individual-accnt/fatca/fatca.component';
import { KycDtls1Component } from './individual-accnt/kyc-dtls1/kyc-dtls1.component';
import { KycDtls2Component } from './individual-accnt/kyc-dtls2/kyc-dtls2.component';
import { KycDtls3Component } from './individual-accnt/kyc-dtls3/kyc-dtls3.component';
import { KycDtls4Component } from './individual-accnt/kyc-dtls4/kyc-dtls4.component';
import { ContactDtlsComponent } from './individual-accnt/contact-dtls/contact-dtls.component';
import { CustomerProfileComponent } from './individual-accnt/customer-profile/customer-profile.component';
import { InterBank1Component } from './individual-accnt/inter-bank1/inter-bank1.component';
import { InterBank2Component } from './individual-accnt/inter-bank2/inter-bank2.component';
import { AddrsDtls1Component } from './individual-accnt/addrs-dtls1/addrs-dtls1.component';
import { AddrsDtls2Component } from './individual-accnt/addrs-dtls2/addrs-dtls2.component';
import { DocumentUpload1Component } from './individual-accnt/document-upload1/document-upload1.component';
import { DocIndentityProofComponent } from './individual-accnt/doc-indentity-proof/doc-indentity-proof.component';
import { DocAddressProof1Component } from './individual-accnt/doc-address-proof1/doc-address-proof1.component';
import { DocAddressProof2Component } from './individual-accnt/doc-address-proof2/doc-address-proof2.component';
import { DocAddressProof3Component } from './individual-accnt/doc-address-proof3/doc-address-proof3.component';
import { DocOtherProofComponent } from './individual-accnt/doc-other-proof/doc-other-proof.component';
import { Nomination1Component } from './individual-accnt/nomination1/nomination1.component';
import { Nomination2Component } from './individual-accnt/nomination2/nomination2.component';
import { Nomination3Component } from './individual-accnt/nomination3/nomination3.component';
import { Declaration1Component } from './individual-accnt/declaration1/declaration1.component';
import { Declaration2Component } from './individual-accnt/declaration2/declaration2.component';
import { ThankPageComponent } from './shared/thank-page/thank-page.component';
import { ThankPersonComponent } from './shared/thank-person/thank-person.component';

import { ApplicantJointAcccntComponent } from './joint-accnt/applicant-joint-acccnt/applicant-joint-acccnt.component'
import { HomeComponent } from './agents/home/home.component';
import { AgentsLoginComponent } from './agents/agents-login/agents-login.component';

import { FeedbackSummaryComponent } from './feedback/feedback-summary/feedback-summary.component';
import { DocForm60Component } from './individual-accnt/doc-form60/doc-form60.component';
import { DocVisaComponent } from './individual-accnt/doc-visa/doc-visa.component';
import { DocPioComponent } from './individual-accnt/doc-pio/doc-pio.component';
import { DocOciComponent } from './individual-accnt/doc-oci/doc-oci.component';

import { PersonalDtls1MinorComponent } from './minor-accnt/personal-dtls1-minor/personal-dtls1-minor.component';
import { PersonalDtls2MinorComponent } from './minor-accnt/personal-dtls2-minor/personal-dtls2-minor.component';
import { KycDtls1MinorComponent } from './minor-accnt/kyc-dtls1-minor/kyc-dtls1-minor.component';
import { KycDtls2MinorComponent } from './minor-accnt/kyc-dtls2-minor/kyc-dtls2-minor.component';
import { KycDtls3MinorComponent } from './minor-accnt/kyc-dtls3-minor/kyc-dtls3-minor.component';
import { KycDtls4MinorComponent } from './minor-accnt/kyc-dtls4-minor/kyc-dtls4-minor.component';
import { DocumentUpload1MinorComponent } from './minor-accnt/document-upload1-minor/document-upload1-minor.component';
import { DocVisaMinorComponent } from './minor-accnt/doc-visa-minor/doc-visa-minor.component';
import { DocIdentityProofMinorComponent } from './minor-accnt/doc-identity-proof-minor/doc-identity-proof-minor.component';
import { DocPioMinorComponent } from './minor-accnt/doc-pio-minor/doc-pio-minor.component';
import { DocOtherProofMinorComponent } from './minor-accnt/doc-other-proof-minor/doc-other-proof-minor.component';

import { PersonalDtls1GuardianComponent } from './minor-accnt/A-guardian-form/personal-dtls1-guardian/personal-dtls1-guardian.component';
import { PersonalDtls2GuardianComponent } from './minor-accnt/A-guardian-form/personal-dtls2-guardian/personal-dtls2-guardian.component';
import { FatcaGuardianComponent } from './minor-accnt/A-guardian-form/fatca-guardian/fatca-guardian.component';
import { KycDtls1GuardianComponent } from './minor-accnt/A-guardian-form/kyc-dtls1-guardian/kyc-dtls1-guardian.component';
import { KycDtls2GuardianComponent } from './minor-accnt/A-guardian-form/kyc-dtls2-guardian/kyc-dtls2-guardian.component';
import { KycDtls3GuardianComponent } from './minor-accnt/A-guardian-form/kyc-dtls3-guardian/kyc-dtls3-guardian.component';
import { KycDtls4GuardianComponent } from './minor-accnt/A-guardian-form/kyc-dtls4-guardian/kyc-dtls4-guardian.component';
import { ContactDtlsGuardianComponent } from './minor-accnt/A-guardian-form/contact-dtls-guardian/contact-dtls-guardian.component';
import { CustomerProfileGuardianComponent } from './minor-accnt/A-guardian-form/customer-profile-guardian/customer-profile-guardian.component';
import { InterBank1GuardianComponent } from './minor-accnt/A-guardian-form/inter-bank1-guardian/inter-bank1-guardian.component';
import { InterBank2GuardianComponent } from './minor-accnt/A-guardian-form/inter-bank2-guardian/inter-bank2-guardian.component';
import { AddrsDtls1GuardianComponent } from './minor-accnt/A-guardian-form/addrs-dtls1-guardian/addrs-dtls1-guardian.component';
import { AddrsDtls2GuardianComponent } from './minor-accnt/A-guardian-form/addrs-dtls2-guardian/addrs-dtls2-guardian.component';
import { DocumentUpload1GuardianComponent } from './minor-accnt/A-guardian-form/document-upload1-guardian/document-upload1-guardian.component';
import { DocIdentityProofGuardianComponent } from './minor-accnt/A-guardian-form/doc-identity-proof-guardian/doc-identity-proof-guardian.component';
import { DocAddrsProof1GuardianComponent } from './minor-accnt/A-guardian-form/doc-addrs-proof1-guardian/doc-addrs-proof1-guardian.component';
import { DocAddrsProof2GuardianComponent } from './minor-accnt/A-guardian-form/doc-addrs-proof2-guardian/doc-addrs-proof2-guardian.component';
import { DocAddrsProof3GuardianComponent } from './minor-accnt/A-guardian-form/doc-addrs-proof3-guardian/doc-addrs-proof3-guardian.component';
import { DocForm60GuardianComponent } from './minor-accnt/A-guardian-form/doc-form60-guardian/doc-form60-guardian.component';
import { DocVisaGuardianComponent } from './minor-accnt/A-guardian-form/doc-visa-guardian/doc-visa-guardian.component';
import { DocPioGuardianComponent } from './minor-accnt/A-guardian-form/doc-pio-guardian/doc-pio-guardian.component';
import { DocOtherGuardianComponent } from './minor-accnt/A-guardian-form/doc-other-guardian/doc-other-guardian.component';
import { Nomination1GuardianComponent } from './minor-accnt/A-guardian-form/nomination1-guardian/nomination1-guardian.component';
import { Nomination2GuardianComponent } from './minor-accnt/A-guardian-form/nomination2-guardian/nomination2-guardian.component';
import { Nomination3GuardianComponent } from './minor-accnt/A-guardian-form/nomination3-guardian/nomination3-guardian.component';
import { Diclaration1GuardianComponent } from './minor-accnt/A-guardian-form/diclaration1-guardian/diclaration1-guardian.component';
import { Diclaration2GuardianComponent } from './minor-accnt/A-guardian-form/diclaration2-guardian/diclaration2-guardian.component';
import { GuardianDtlsComponent } from './minor-accnt/A-guardian-form/guardian-dtls/guardian-dtls.component';
import { TermsOfUseComponent } from './shared/terms-of-use/terms-of-use.component';
import { RejectedPageComponent } from './shared/rejected-page/rejected-page.component';

const routes: Routes = [
  { path: "", component: RegistrationComponent },
  { path: "signup-authentication", component: SignupAuthComponent, canActivate: [CustomerSignUpAuthGuard] },
  { path: "login", component: LoginComponent },
  { path: "country", component: CountryTypeComponent, canActivate: [CustomerAuthGuard] },
  { path: "account", component: AccountTypeComponent, canActivate: [CustomerAuthGuard] },
  { path: "rejected-page", component: RejectedPageComponent, canActivate: [CustomerAuthGuard] },
  { path: "terms-of-use", component: TermsOfUseComponent },
  {
    path: "individual-account", children: [
      { path: "personal-dtls1", component: PersonalDtls1Component, canActivate: [CustomerAuthGuard] },
      { path: "personal-dtls2", component: PersonalDtls2Component, canActivate: [CustomerAuthGuard] },
      { path: "fatca", component: FatcaComponent, canActivate: [CustomerAuthGuard] },
      { path: "kyc-dtls1", component: KycDtls1Component, canActivate: [CustomerAuthGuard] },
      { path: "kyc-dtls2", component: KycDtls2Component, canActivate: [CustomerAuthGuard] },
      { path: "kyc-dtls3", component: KycDtls3Component, canActivate: [CustomerAuthGuard] },
      { path: "kyc-dtls4", component: KycDtls4Component, canActivate: [CustomerAuthGuard] },
      { path: "contact-details", component: ContactDtlsComponent, canActivate: [CustomerAuthGuard] },
      { path: "customer-profile", component: CustomerProfileComponent, canActivate: [CustomerAuthGuard] },
      { path: "internet-banking", component: InterBank1Component, canActivate: [CustomerAuthGuard] },
      { path: "internet-banking2", component: InterBank2Component, canActivate: [CustomerAuthGuard] },
      { path: "addrs-dtls1", component: AddrsDtls1Component, canActivate: [CustomerAuthGuard] },
      { path: "addrs-dtls2", component: AddrsDtls2Component, canActivate: [CustomerAuthGuard] },
      { path: "doc-upload1", component: DocumentUpload1Component, canActivate: [CustomerAuthGuard] },
      { path: "doc-identity-proof", component: DocIndentityProofComponent, canActivate: [CustomerAuthGuard] },
      { path: "doc-address-proof1", component: DocAddressProof1Component, canActivate: [CustomerAuthGuard] },
      { path: "doc-address-proof2", component: DocAddressProof2Component, canActivate: [CustomerAuthGuard] },
      { path: "doc-address-proof3", component: DocAddressProof3Component, canActivate: [CustomerAuthGuard] },
      { path: "doc-fomr60", component: DocForm60Component, canActivate: [CustomerAuthGuard] },
      { path: "doc-visa", component: DocVisaComponent, canActivate: [CustomerAuthGuard] },
      { path: "doc-oci", component: DocOciComponent, canActivate: [CustomerAuthGuard] },
      { path: "doc-pio", component: DocPioComponent, canActivate: [CustomerAuthGuard] },
      { path: "other-docs-proof", component: DocOtherProofComponent, canActivate: [CustomerAuthGuard] },
      { path: "nomination1", component: Nomination1Component, canActivate: [CustomerAuthGuard] },
      { path: "nomination2", component: Nomination2Component, canActivate: [CustomerAuthGuard] },
      { path: "nomination3", component: Nomination3Component, canActivate: [CustomerAuthGuard] },
      { path: "declaration1", component: Declaration1Component, canActivate: [CustomerAuthGuard] },
      { path: "declaration2", component: Declaration2Component, canActivate: [CustomerAuthGuard] },
      { path: "thanks", component: ThankPersonComponent, canActivate: [CustomerAuthGuard] },
      { path: "ending", component: ThankPageComponent, canActivate: [CustomerAuthGuard] },
      { path: "feedback", component: FeedbackSummaryComponent }
    ]
  },
  {
    path: 'joint-account', children: [
      { path: "applicant-form", component: ApplicantJointAcccntComponent, canActivate: [CustomerAuthGuard] },
      { path: "personal-dtls1", component: PersonalDtls1Component, canActivate: [CustomerAuthGuard] },
      { path: "personal-dtls2", component: PersonalDtls2Component, canActivate: [CustomerAuthGuard] },
      { path: "fatca", component: FatcaComponent, canActivate: [CustomerAuthGuard] },
      { path: "kyc-dtls1", component: KycDtls1Component, canActivate: [CustomerAuthGuard] },
      { path: "kyc-dtls2", component: KycDtls2Component, canActivate: [CustomerAuthGuard] },
      { path: "kyc-dtls3", component: KycDtls3Component, canActivate: [CustomerAuthGuard] },
      { path: "kyc-dtls4", component: KycDtls4Component, canActivate: [CustomerAuthGuard] },
      { path: "contact-details", component: ContactDtlsComponent, canActivate: [CustomerAuthGuard] },
      { path: "customer-profile", component: CustomerProfileComponent, canActivate: [CustomerAuthGuard] },
      { path: "internet-banking", component: InterBank1Component, canActivate: [CustomerAuthGuard] },
      { path: "internet-banking2", component: InterBank2Component, canActivate: [CustomerAuthGuard] },
      { path: "addrs-dtls1", component: AddrsDtls1Component, canActivate: [CustomerAuthGuard] },
      { path: "addrs-dtls2", component: AddrsDtls2Component, canActivate: [CustomerAuthGuard] },
      { path: "doc-upload1", component: DocumentUpload1Component, canActivate: [CustomerAuthGuard] },
      { path: "doc-identity-proof", component: DocIndentityProofComponent, canActivate: [CustomerAuthGuard] },
      { path: "doc-address-proof1", component: DocAddressProof1Component, canActivate: [CustomerAuthGuard] },
      { path: "doc-address-proof2", component: DocAddressProof2Component, canActivate: [CustomerAuthGuard] },
      { path: "doc-address-proof3", component: DocAddressProof3Component, canActivate: [CustomerAuthGuard] },
      { path: "doc-fomr60", component: DocAddressProof3Component, canActivate: [CustomerAuthGuard] },
      { path: "doc-visa", component: DocAddressProof3Component, canActivate: [CustomerAuthGuard] },
      { path: "doc-pio", component: DocAddressProof3Component, canActivate: [CustomerAuthGuard] },
      { path: "other-docs-proof", component: DocOtherProofComponent, canActivate: [CustomerAuthGuard] },
      { path: "nomination1", component: Nomination1Component, canActivate: [CustomerAuthGuard] },
      { path: "nomination2", component: Nomination2Component, canActivate: [CustomerAuthGuard] },
      { path: "nomination3", component: Nomination3Component, canActivate: [CustomerAuthGuard] },
      { path: "declaration1", component: Declaration1Component, canActivate: [CustomerAuthGuard] },
      { path: "declaration2", component: Declaration2Component, canActivate: [CustomerAuthGuard] },
      { path: "thanks", component: ThankPersonComponent, canActivate: [CustomerAuthGuard] },
      { path: "ending", component: ThankPageComponent, canActivate: [CustomerAuthGuard] },
    ]
  },
  {
    path: 'agent', component: HomeComponent, children: [
      { path: 'login', component: AgentsLoginComponent }
    ]
  },
  {
    path: 'feedback', children: [
      { path: 'feedback-summary', component: FeedbackSummaryComponent },
      { path: "personal-dtls1", component: PersonalDtls1Component, canActivate: [CustomerAuthGuard] },
      { path: "personal-dtls2", component: PersonalDtls2Component, canActivate: [CustomerAuthGuard] },
      { path: "fatca", component: FatcaComponent, canActivate: [CustomerAuthGuard] },
      { path: "kyc-dtls1", component: KycDtls1Component, canActivate: [CustomerAuthGuard] },
      { path: "kyc-dtls2", component: KycDtls2Component, canActivate: [CustomerAuthGuard] },
      { path: "kyc-dtls3", component: KycDtls3Component, canActivate: [CustomerAuthGuard] },
      { path: "kyc-dtls4", component: KycDtls4Component, canActivate: [CustomerAuthGuard] },
      { path: "contact-details", component: ContactDtlsComponent, canActivate: [CustomerAuthGuard] },
      { path: "customer-profile", component: CustomerProfileComponent, canActivate: [CustomerAuthGuard] },
      { path: "internet-banking", component: InterBank1Component, canActivate: [CustomerAuthGuard] },
      { path: "internet-banking2", component: InterBank2Component, canActivate: [CustomerAuthGuard] },
      { path: "addrs-dtls1", component: AddrsDtls1Component, canActivate: [CustomerAuthGuard] },
      { path: "addrs-dtls2", component: AddrsDtls2Component, canActivate: [CustomerAuthGuard] },
      { path: "doc-upload1", component: DocumentUpload1Component, canActivate: [CustomerAuthGuard] },
      { path: "doc-identity-proof", component: DocIndentityProofComponent, canActivate: [CustomerAuthGuard] },
      { path: "doc-address-proof1", component: DocAddressProof1Component, canActivate: [CustomerAuthGuard] },
      { path: "doc-address-proof2", component: DocAddressProof2Component, canActivate: [CustomerAuthGuard] },
      { path: "doc-address-proof3", component: DocAddressProof3Component, canActivate: [CustomerAuthGuard] },
      { path: "doc-fomr60", component: DocForm60Component, canActivate: [CustomerAuthGuard] },
      { path: "doc-visa", component: DocVisaComponent, canActivate: [CustomerAuthGuard] },
      { path: "doc-oci", component: DocOciComponent, canActivate: [CustomerAuthGuard] },
      { path: "doc-pio", component: DocPioComponent, canActivate: [CustomerAuthGuard] },
      { path: "other-docs-proof", component: DocOtherProofComponent, canActivate: [CustomerAuthGuard] },
      { path: "nomination1", component: Nomination1Component, canActivate: [CustomerAuthGuard] },
      { path: "nomination2", component: Nomination2Component, canActivate: [CustomerAuthGuard] },
      { path: "nomination3", component: Nomination3Component, canActivate: [CustomerAuthGuard] },
      { path: "declaration1", component: Declaration1Component, canActivate: [CustomerAuthGuard] },
      { path: "declaration2", component: Declaration2Component, canActivate: [CustomerAuthGuard] },
      { path: "thanks", component: ThankPersonComponent, canActivate: [CustomerAuthGuard] },
      { path: "ending", component: ThankPageComponent, canActivate: [CustomerAuthGuard] },
      { path: "rejected-page", component: RejectedPageComponent, canActivate: [CustomerAuthGuard] },
      { path: "feedback", component: FeedbackSummaryComponent },

      // minor
      { path: "personal-dtls1-minor", component: PersonalDtls1MinorComponent, canActivate: [CustomerAuthGuard] },
      { path: "personal-dtls2-minor", component: PersonalDtls2MinorComponent },
      { path: "kyc-dtls1-minor", component: KycDtls1MinorComponent },
      { path: "kyc-dtls2-minor", component: KycDtls2MinorComponent },
      { path: "kyc-dtls3-minor", component: KycDtls3MinorComponent },
      { path: "kyc-dtls4-minor", component: KycDtls4MinorComponent },
      { path: "document-upload1-minor", component: DocumentUpload1MinorComponent },
      { path: "doc-identity-proof-minor", component: DocIdentityProofMinorComponent },
      { path: "doc-visa-minor", component: DocVisaMinorComponent },
      { path: "doc-pio-minor", component: DocPioMinorComponent },
      { path: "doc-other-proof-minor", component: DocOtherProofMinorComponent },

      { path: "guardian-dtls", component: GuardianDtlsComponent },
      { path: "personal-dtls1-guardian", component: PersonalDtls1GuardianComponent },
      { path: "personal-dtls2-guardian", component: PersonalDtls2GuardianComponent },
      { path: "fatca-guardian", component: FatcaGuardianComponent },
      { path: "kyc-dtls1-guardian", component: KycDtls1GuardianComponent },
      { path: "kyc-dtls2-guardian", component: KycDtls2GuardianComponent },
      { path: "kyc-dtls3-guardian", component: KycDtls3GuardianComponent },
      { path: "kyc-dtls4-guardian", component: KycDtls4GuardianComponent },
      { path: "contact-details-guardian", component: ContactDtlsGuardianComponent },
      { path: "addrs-dtls1-guardian", component: AddrsDtls1GuardianComponent },
      { path: "addrs-dtls2-guardian", component: AddrsDtls2GuardianComponent },
      { path: "customer-profile-guardian", component: CustomerProfileGuardianComponent },
      { path: "internet-banking1-guardian", component: InterBank1GuardianComponent },
      { path: "internet-banking2-guardian", component: InterBank2GuardianComponent },
      { path: "document-upload1-guardian", component: DocumentUpload1GuardianComponent },
      { path: "doc-identity-proof-guardian", component: DocIdentityProofGuardianComponent },
      { path: "doc-address-proof1-guardian", component: DocAddrsProof1GuardianComponent },
      { path: "doc-address-proof2-guardian", component: DocAddrsProof2GuardianComponent },
      { path: "doc-address-proof3-guardian", component: DocAddrsProof3GuardianComponent },
      { path: "doc-form60-guardian", component: DocForm60GuardianComponent },
      { path: "doc-visa-guardian", component: DocVisaGuardianComponent },
      { path: "doc-pio-guardian", component: DocPioGuardianComponent },
      { path: "docs-other-proof-guardian", component: DocOtherGuardianComponent },
      { path: "nomination1-guardian", component: Nomination1GuardianComponent },
      { path: "nomination2-guardian", component: Nomination2GuardianComponent },
      { path: "nomination3-guardian", component: Nomination3GuardianComponent },
      { path: "declaration1-guardian", component: Diclaration1GuardianComponent },
      { path: "declaration2-guardian", component: Diclaration2GuardianComponent },
    ]
  },

  {
    path: "minor-accnt", children: [
      { path: "personal-dtls1-minor", component: PersonalDtls1MinorComponent, canActivate: [CustomerAuthGuard] },
      { path: "personal-dtls2-minor", component: PersonalDtls2MinorComponent },
      { path: "kyc-dtls1-minor", component: KycDtls1MinorComponent },
      { path: "kyc-dtls2-minor", component: KycDtls2MinorComponent },
      { path: "kyc-dtls3-minor", component: KycDtls3MinorComponent },
      { path: "kyc-dtls4-minor", component: KycDtls4MinorComponent },
      { path: "document-upload1-minor", component: DocumentUpload1MinorComponent },
      { path: "doc-identity-proof-minor", component: DocIdentityProofMinorComponent },
      { path: "doc-visa-minor", component: DocVisaMinorComponent },
      { path: "doc-pio-minor", component: DocPioMinorComponent },
      { path: "doc-other-proof-minor", component: DocOtherProofMinorComponent },

      { path: "guardian-dtls", component: GuardianDtlsComponent },
      { path: "personal-dtls1-guardian", component: PersonalDtls1GuardianComponent },
      { path: "personal-dtls2-guardian", component: PersonalDtls2GuardianComponent },
      { path: "fatca-guardian", component: FatcaGuardianComponent },
      { path: "kyc-dtls1-guardian", component: KycDtls1GuardianComponent },
      { path: "kyc-dtls2-guardian", component: KycDtls2GuardianComponent },
      { path: "kyc-dtls3-guardian", component: KycDtls3GuardianComponent },
      { path: "kyc-dtls4-guardian", component: KycDtls4GuardianComponent },
      { path: "contact-details-guardian", component: ContactDtlsGuardianComponent },
      { path: "addrs-dtls1-guardian", component: AddrsDtls1GuardianComponent },
      { path: "addrs-dtls2-guardian", component: AddrsDtls2GuardianComponent },
      { path: "customer-profile-guardian", component: CustomerProfileGuardianComponent },
      { path: "internet-banking1-guardian", component: InterBank1GuardianComponent },
      { path: "internet-banking2-guardian", component: InterBank2GuardianComponent },
      { path: "document-upload1-guardian", component: DocumentUpload1GuardianComponent },
      { path: "doc-identity-proof-guardian", component: DocIdentityProofGuardianComponent },
      { path: "doc-address-proof1-guardian", component: DocAddrsProof1GuardianComponent },
      { path: "doc-address-proof2-guardian", component: DocAddrsProof2GuardianComponent },
      { path: "doc-address-proof3-guardian", component: DocAddrsProof3GuardianComponent },
      { path: "doc-form60-guardian", component: DocForm60GuardianComponent },
      { path: "doc-visa-guardian", component: DocVisaGuardianComponent },
      { path: "doc-pio-guardian", component: DocPioGuardianComponent },
      { path: "docs-other-proof-guardian", component: DocOtherGuardianComponent },
      { path: "nomination1-guardian", component: Nomination1GuardianComponent },
      { path: "nomination2-guardian", component: Nomination2GuardianComponent },
      { path: "nomination3-guardian", component: Nomination3GuardianComponent },
      { path: "declaration1-guardian", component: Diclaration1GuardianComponent },
      { path: "declaration2-guardian", component: Diclaration2GuardianComponent },
      { path: "thanks", component: ThankPersonComponent },
      { path: "ending", component: ThankPageComponent },
      { path: "feedback", component: FeedbackSummaryComponent }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
