import { Component,OnInit } from '@angular/core';
import { Router } from '@angular/router';
import {Idle, DEFAULT_INTERRUPTSOURCES} from '@ng-idle/core';
import {Keepalive} from '@ng-idle/keepalive';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'RBL_Client';
  constructor(private idle:Idle,private keepalive:Keepalive,
    private route:Router){}
  ngOnInit(): void {

     this.idle.setIdle(60*60);
     this.idle.setTimeout(10);
     this.idle.setInterrupts(DEFAULT_INTERRUPTSOURCES);
     this.idle.onTimeout.subscribe(() => {
       console.log('Logout!');
       localStorage.clear();
       window.location.reload();
     });
     this.idle.onIdleStart.subscribe(() =>console.log('You\'ve gone idle!')
     );
     this.idle.onTimeoutWarning.subscribe((countdown) =>console.log('You will time out in ' + countdown + ' seconds!'))
     this.keepalive.interval(15);
     this.keepalive.onPing.subscribe(() => {
      console.log('Active!');
      
     });
     this.idle.watch();
   }
  
}
