import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import {
  CanActivate,
  ActivatedRouteSnapshot,
  RouterStateSnapshot, 
  UrlTree
} from '@angular/router';
import { Observable, of } from 'rxjs';
import { CustomerDataService} from '../services/customer-data.service';

@Injectable()
export class CustomerSignUpAuthGuard implements CanActivate {
  constructor(private customerDataService: CustomerDataService,private rt:Router) { }
  
  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot):
   |boolean 
   | UrlTree
   | Observable<boolean 
   | UrlTree> 
   | Promise<boolean 
   | UrlTree>
   {

    if (!this.customerDataService.customerSignUpAuthentication()) {
      this.rt.navigate(['/']);
      return false;
    }
    return true;
  
    }
}
