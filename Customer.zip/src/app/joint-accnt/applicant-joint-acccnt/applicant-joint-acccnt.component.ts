import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { CommonService } from 'src/app/services/common.service';
import { CustomerDataService } from 'src/app/services/customer-data.service';

@Component({
  selector: 'app-applicant-joint-acccnt',
  templateUrl: './applicant-joint-acccnt.component.html',
  styleUrls: ['./applicant-joint-acccnt.component.css']
})
export class ApplicantJointAcccntComponent implements OnInit {

  jointAccntApplcntForm: any;
  titleArrData: any;
  regObj: any;
  Obj: any
  firstName: any;
  firstTitle: any;
  middleName: any;
  lastName: any;
  secondTitle: any;
  sfirstName: any;
  smiddleName: any;
  slastName: any;
  thirdTitle: any;
  tfirstName: any;
  tmiddleName: any;
  tlastName: any;
  selectionOptionId:any;
  public modeOfoperations:any =[];

  constructor(private rt: Router, private fb: FormBuilder, private commonService: CommonService, private customerDataService: CustomerDataService) { }

  ngOnInit(): void {
    this.regObj = this.commonService.getUserFromLocalStorage();
    // const saveOption = localStorage.getItem('modeofOpration')
    // if(saveOption){
    //   this.selectionOptionId =+saveOption
    // }
    if (this.regObj.isSubmitted != undefined) {
      this.rt.navigate(["/joint-account", "ending"]);
    }

    let firstName = this.regObj?.first_name;
    let middleName = this.regObj?.middle_name;
    let lastName = this.regObj?.last_name;
    let operationData = localStorage.getItem('modeofOpration')
    this.jointAccntApplcntForm = this.fb.group({
      jointAccntApplcnt1Title: ['', [Validators.required]],
      jointAccntApplcnt1FirstName: [firstName, Validators.required],
      jointAccntApplcnt1MiddleName: [middleName],
      jointAccntApplcnt1LastName: [lastName],

      jointAccntApplcnt2Title: ['', [Validators.required]],
      jointAccntApplcnt2FirstName: ['', [Validators.required]],
      jointAccntApplcnt2MiddleName: [''],
      jointAccntApplcnt2LastName: [''],

      jointAccntApplcnt3Title: [''],
      jointAccntApplcnt3FirstName: [''],
      jointAccntApplcnt3MiddleName: [''],
      jointAccntApplcnt3LastName: [''],

      jointAccntApplcnt3jointMode: [operationData]
    })

    this.customerDataService.getTitle().subscribe((data) => {
      this.titleArrData = data
    })

    let Obj = {
      user_id: this.regObj?.user_id,
    }
    
    this.customerDataService.fetchJointUserData(Obj).subscribe((value) => {
      this.jointAccntApplcntForm.controls['jointAccntApplcnt3jointMode'].setValue(localStorage.getItem('modeofOpration'))
      if (value?.result?.length > 0) {
        
        this.jointAccntApplcntForm.controls['jointAccntApplcnt1Title'].setValue(value.result[0]?.applicant_title);
        this.jointAccntApplcntForm.controls['jointAccntApplcnt1FirstName'].setValue(value.result[0]?.applicant_first_name);
        this.jointAccntApplcntForm.controls['jointAccntApplcnt1MiddleName'].setValue(value.result[0]?.applicant_middle_name);
        this.jointAccntApplcntForm.controls['jointAccntApplcnt1LastName'].setValue(value.result[0]?.applicant_last_name);
        
        this.jointAccntApplcntForm.controls['jointAccntApplcnt2Title'].setValue(value.result[1]?.applicant_title);
        this.jointAccntApplcntForm.controls['jointAccntApplcnt2FirstName'].setValue(value.result[1]?.applicant_first_name);
        this.jointAccntApplcntForm.controls['jointAccntApplcnt2MiddleName'].setValue(value.result[1]?.applicant_middle_name);
        this.jointAccntApplcntForm.controls['jointAccntApplcnt2LastName'].setValue(value.result[1]?.applicant_last_name);

        this.jointAccntApplcntForm.controls['jointAccntApplcnt3Title'].setValue(value.result[2]?.applicant_title);
        this.jointAccntApplcntForm.controls['jointAccntApplcnt3FirstName'].setValue(value.result[2]?.applicant_first_name);
        this.jointAccntApplcntForm.controls['jointAccntApplcnt3MiddleName'].setValue(value.result[2]?.applicant_middle_name);
        this.jointAccntApplcntForm.controls['jointAccntApplcnt3LastName'].setValue(value.result[2]?.applicant_last_name);
      }
    })
  }

  enableOption(){
    // const options:any[] = ['Either or Survivor','Anyone or Survivor',];
    const isTrue = this.jointAccntApplcnt3Title?.value?.length && this.jointAccntApplcnt3FirstName?.value?.length
    if(isTrue){
      // this.modeOfoperations = options;
      this.modeOfoperations = ['Jointly','Anyone or Survivor'];
    } else {
      // this.modeOfoperations = options.filter((mode:any)=>{
      //  return mode.includes('Either or Survivor')
      // })
      this.modeOfoperations = ['Jointly','Either or Survivor'];
    }
    // this.modeOfoperations =
    //   {
    //     "data": [
    //         {
    //             "title_id": "1",
    //             "title_name": "Jointly"
    //         },
    //         {
    //             "title_id": "2",
    //             "title_name": "Either or Survivor"
    //         }
    //       ]
    //   }
   
  }

  get jointAccntApplcnt1Title() { return this.jointAccntApplcntForm.get("jointAccntApplcnt1Title") }
  get jointAccntApplcnt1FirstName() { return this.jointAccntApplcntForm.get("jointAccntApplcnt1FirstName") }
  get jointAccntApplcnt1MiddleName() { return this.jointAccntApplcntForm.get("jointAccntApplcnt1MiddleName") }
  get jointAccntApplcnt1LastName() { return this.jointAccntApplcntForm.get("jointAccntApplcnt1LastName") }

  get jointAccntApplcnt2Title() { return this.jointAccntApplcntForm.get("jointAccntApplcnt2Title") }
  get jointAccntApplcnt2FirstName() { return this.jointAccntApplcntForm.get("jointAccntApplcnt2FirstName") }
  get jointAccntApplcnt2MiddleName() { return this.jointAccntApplcntForm.get("jointAccntApplcnt2MiddleName") }
  get jointAccntApplcnt2LastName() { return this.jointAccntApplcntForm.get("jointAccntApplcnt2LastName") }

  get jointAccntApplcnt3Title() { return this.jointAccntApplcntForm.get("jointAccntApplcnt3Title") }
  get jointAccntApplcnt3FirstName() { return this.jointAccntApplcntForm.get("jointAccntApplcnt3FirstName") }
  get jointAccntApplcnt3MiddleName() { return this.jointAccntApplcntForm.get("jointAccntApplcnt3MiddleName") }
  get jointAccntApplcnt3LastName() { return this.jointAccntApplcntForm.get("jointAccntApplcnt3LastName") }

  get jointAccntApplcnt3jointMode() { return this.jointAccntApplcntForm.get("jointAccntApplcnt3jointMode") }

  keypressLetters(event: any) {
    return this.commonService.enterOnlyAlphabetsNoSpace(event)
  }

  submitApplicantJointForm() {

    if (this.jointAccntApplcntForm.valid) {
      this.commonService.storeInLocalStorage('registerData', { 'middle_name': this.jointAccntApplcntForm.controls['jointAccntApplcnt1MiddleName'].value })
      this.commonService.storeInLocalStorage('registerData', { 'jointApplicantData': this.jointAccntApplcntForm.value })

      if ((this.jointAccntApplcntForm.get("jointAccntApplcnt1Title").value == null || this.jointAccntApplcntForm.get("jointAccntApplcnt1Title").value == "") ||
        (this.jointAccntApplcntForm.get("jointAccntApplcnt3FirstName").value == null ||
          this.jointAccntApplcntForm.get("jointAccntApplcnt3FirstName").value == "")) {

        this.Obj = {
          user_id: this.regObj?.user_id,
          process_id: 2,
          applicant_id: this.regObj?.applicant_id,
          account_type_id: this.regObj?.account_type_id,
          applicant_serial_num: this.regObj?.applicant_serial_num,
          applicant_title: this.jointAccntApplcntForm.get("jointAccntApplcnt1Title").value,
          applicant_first_name: this.jointAccntApplcntForm.get("jointAccntApplcnt1FirstName").value,
          applicant_middle_name: this.jointAccntApplcntForm.get("jointAccntApplcnt1MiddleName").value,
          applicant_last_name: this.jointAccntApplcntForm.get("jointAccntApplcnt1LastName").value,

          sec_applicant_title: this.jointAccntApplcntForm.get("jointAccntApplcnt2Title").value,
          sec_applicant_first_name: this.jointAccntApplcntForm.get("jointAccntApplcnt2FirstName").value,
          sec_applicant_middle_name: this.jointAccntApplcntForm.get("jointAccntApplcnt2MiddleName").value,
          sec_applicant_last_name: this.jointAccntApplcntForm.get("jointAccntApplcnt2LastName").value,
          applicant_joint_mode: this.jointAccntApplcntForm.get("jointAccntApplcnt3jointMode").value === ''?'Jointly':this.modeOfoperations[0]  // if user doesn't select any option default will be Jointly or else
          // applicant_joint_mode: this.jointAccntApplcntForm.get("jointAccntApplcnt3jointMode").value
        
        }
    localStorage.setItem('modeofOpration', this.jointAccntApplcntForm.get("jointAccntApplcnt3jointMode").value);

      }

      else {
        
        this.Obj = {
          user_id: this.regObj?.user_id,
          process_id: 2,
          applicant_id: this.regObj?.applicant_id,
          account_type_id: this.regObj?.account_type_id,
          applicant_serial_num: this.regObj?.applicant_serial_num,
          applicant_title: this.jointAccntApplcntForm.get("jointAccntApplcnt1Title").value,
          applicant_first_name: this.jointAccntApplcntForm.get("jointAccntApplcnt1FirstName").value,
          applicant_middle_name: this.jointAccntApplcntForm.get("jointAccntApplcnt1MiddleName").value,
          applicant_last_name: this.jointAccntApplcntForm.get("jointAccntApplcnt1LastName").value,

          sec_applicant_title: this.jointAccntApplcntForm.get("jointAccntApplcnt2Title").value,
          sec_applicant_first_name: this.jointAccntApplcntForm.get("jointAccntApplcnt2FirstName").value,
          sec_applicant_middle_name: this.jointAccntApplcntForm.get("jointAccntApplcnt2MiddleName").value,
          sec_applicant_last_name: this.jointAccntApplcntForm.get("jointAccntApplcnt2LastName").value,

          thrd_applicant_title: this.jointAccntApplcntForm.get("jointAccntApplcnt3Title").value,
          thrd_applicant_first_name: this.jointAccntApplcntForm.get("jointAccntApplcnt3FirstName").value,
          thrd_applicant_middle_name: this.jointAccntApplcntForm.get("jointAccntApplcnt3MiddleName").value,
          thrd_applicant_last_name: this.jointAccntApplcntForm.get("jointAccntApplcnt3LastName").value,
          applicant_joint_mode: this.jointAccntApplcntForm.get("jointAccntApplcnt3jointMode").value
        }
        localStorage.setItem('modeofOpration', this.jointAccntApplcntForm.get("jointAccntApplcnt3jointMode").value);
      }

      this.customerDataService.postJointAccntApplcnt(this.Obj).subscribe((data) => {
        this.rt.navigate(['/individual-account', 'personal-dtls1']);
      })
    }
  }
}