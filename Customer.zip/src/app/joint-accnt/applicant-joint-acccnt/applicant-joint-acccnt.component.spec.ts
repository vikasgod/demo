import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ApplicantJointAcccntComponent } from './applicant-joint-acccnt.component';

describe('ApplicantJointAcccntComponent', () => {
  let component: ApplicantJointAcccntComponent;
  let fixture: ComponentFixture<ApplicantJointAcccntComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ApplicantJointAcccntComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ApplicantJointAcccntComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
