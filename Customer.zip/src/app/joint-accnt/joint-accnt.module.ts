import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule,ReactiveFormsModule} from '@angular/forms';
import { ApplicantJointAcccntComponent } from './applicant-joint-acccnt/applicant-joint-acccnt.component';
import { RouterModule } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';
import { MatInputModule } from '@angular/material/input';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatNativeDateModule } from '@angular/material/core';
import { MatDatepickerModule } from '@angular/material/datepicker';


//FormsModule
//ReactiveFormsModule
@NgModule({
  declarations: [
    ApplicantJointAcccntComponent
  ],
  imports: [
    HttpClientModule,
    CommonModule,
    RouterModule,
    ReactiveFormsModule,
    FormsModule,
    MatInputModule,
    MatFormFieldModule,
    MatDatepickerModule,
    MatNativeDateModule
    
  ],
  exports:[
    ApplicantJointAcccntComponent
  ]
})
export class JointAccntModule { }
