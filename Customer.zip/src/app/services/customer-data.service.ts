import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class CustomerDataService {

    // baseURL: string = 'http://10.80.92.195:3232';
 baseURL: string = 'http://localhost:3232';
  
  headers = new HttpHeaders({ credentials: 'include', 'Content-Type': 'application/json' });
  constructor(private http: HttpClient) { }


  registerCustomer(Obj: any): Observable<any> {
    let Obj1 = {
      first_name: Obj.firstname,
      middle_name: "",
      last_name: Obj.lastname,
      isd_code: "+" + Obj.isd,
      mobile_no: Obj.mobile,
      email_address: Obj.emailID
    };
    let url = `${this.baseURL}/user/customersignup`;
    return this.http.post<any>(url, Obj1);
  }


  customerAuthentication() {
    const userDataString = localStorage.getItem('registerData');
    if (userDataString) {
      const userData = JSON.parse(userDataString);
      return true;
    }
    return false;
  }

  checkCustomerLoginAuth() {
    const userDataString = localStorage.getItem('registerData');
    if (userDataString) {
      const userData = JSON.parse(userDataString);
      return true;
    }
    return false;
  }

  customerSignUpAuthentication() {
    const userDataString = localStorage.getItem('signup');
    if (userDataString) {
      const userData = JSON.parse(userDataString);
      return true;
    }
    return false;
  }






  generateEmailOTP(id: any, otpType: any, email: any): Observable<any> {
    let Obj1 = {
      email_ass: id,
      otp_type: "email",
      email_address: email

    }
    let url = `${this.baseURL}/user/send_email_otp`;
    return this.http.post<any>(url, Obj1);
  }

  generateOTP(otpType: any, id: any): Observable<any> {
    let Obj1 = {
      mobile_no: id,
      otp_type: otpType,

    }
    let url = `${this.baseURL}/user/send_mobile_otp`;
    return this.http.post<any>(url, Obj1);
  }

  emailVerifyOTP( requestId: any, opt: any, rt: any): Observable<any> {
    let Obj1 = {
      email_address: requestId,
      email_otp: opt,
      rt: rt
    }
    //intra api
    // let Obj1 = {
    //   requestId:`${requestId}`,
    //   email_otp:`${opt}`,
    //   rt: rt
    // }
    let url = `${this.baseURL}/user/email-verify-otp`;
    return this.http.post<any>(url, Obj1)
  }

  mobileVerifyOTP(requestId: any, otp: any, mobile_no: any): Observable<any> {
    let Obj1 = {
      user_id: requestId,
      mobile_otp: otp,
      mobile_no: mobile_no
    }
    // intra api
    // let Obj1 = {
    //   requestId:`${requestId}`,
    //   mobile_otp:`${otp}`,
    //   mobile_no: mobile_no
    // }
    let url = `${this.baseURL}/user/mobile_no_verifyotp`;
    return this.http.post<any>(url, Obj1)
  }


  postCountryType(applicant_id: any, user_id: any, country_id: any, account_type_id: any, is_trading: any, process_id: any): Observable<any> {

    let Obj1 = {
      applicant_id: applicant_id,
      user_id: user_id,
      country_id: country_id,
      account_type_id: account_type_id,
      is_trading_facility_opt: is_trading,
      process_id: process_id
    }

    let url = `${this.baseURL}/customer/submit_country_account`;
    return this.http.post<any>(url, Obj1);
  }


  postAccountVariant(applicant_id: any, account_varient: any, process_id: any,saving_account:any): Observable<any> {

    let Obj1 = {
      applicant_id: applicant_id,
      account_varient: account_varient,
      process_id: process_id,
      saving_account
    }

    let url = `${this.baseURL}/customer/submit_account_varient`;
    return this.http.post<any>(url, Obj1);
  }

  formatDob(dobDate: string | number | Date) {
    if(dobDate!=''&&dobDate!=null&&dobDate!=undefined){
      let dob_date = new Date(dobDate);
      var day = ('0' + dob_date.getDate()).slice(-2);
      var month = ('0' + (dob_date.getMonth() + 1)).slice(-2);
      var year = dob_date.getFullYear();
      return `${year}-${month}-${day}`
    }else{
      return ''
    }
  }

  postPersonalDtls1(Obj: any) {
    let url = `${this.baseURL}/customer/submit_personal_details_1`;
    return this.http.post<any>(url, Obj);
  }


  postPersonalDtls2(Obj: any) {

    let url = `${this.baseURL}/customer/submit_personal_details_2`;
    return this.http.post<any>(url, Obj);
  }

  postFatca(Obj: any) {
    let url = `${this.baseURL}/customer/submit_factas`;
    return this.http.post<any>(url, Obj);
  }

  postKycDtls1(Obj: any) {
    let url = `${this.baseURL}/customer/submit_kyc_details_1`;
    return this.http.post<any>(url, Obj);
  }


  postCustomerProfile(Obj: any) {
    let url = `${this.baseURL}/customer/submit_customer_profilers`;
    return this.http.post<any>(url, Obj);
  }


  postKycDtls2(Obj: any) {

    let url = `${this.baseURL}/customer/submit_kyc_details_2`;
    return this.http.post<any>(url, Obj);
  }


  postKycDtls4(Obj: any) {

    let url = `${this.baseURL}/customer/submit_kyc_poi_dec`;
    return this.http.post<any>(url, Obj);
  }


  postContactDtls(Obj: any) {

    let url = `${this.baseURL}/customer/submit_contact_details`;
    return this.http.post<any>(url, Obj);
  }


  postAddressDtls1(Obj: any) {

    let url = `${this.baseURL}/customer/submit_address_details_1`;
    return this.http.post<any>(url, Obj);
  }


  postAddressDtls2(Obj: any) {

    let url = `${this.baseURL}/customer/submit_address_details_2`;
    return this.http.post<any>(url, Obj);
  }


  postCustomerProfiler(Obj: any) {

    let url = `${this.baseURL}/customer/submit_customer_profilers`;
    return this.http.post<any>(url, Obj);
  }


  postInternetBanking1(Obj: any) {

    let url = `${this.baseURL}/customer/submit_banking_facilities_1`;
    return this.http.post<any>(url, Obj);
  }


  postInternetBanking2(Obj: any): Observable<any> {

    let url = `${this.baseURL}/customer/submit_banking_facilities_2`;
    return this.http.post<any>(url, Obj);
  }



  postNomination1(Obj: any): Observable<any> {



    let url = `${this.baseURL}/customer/submit_nominations_details_1`;
    return this.http.post<any>(url, Obj);
  }



  postNomination2(Obj: any): Observable<any> {



    let url = `${this.baseURL}/customer/submit_nominations_details_2`;
    return this.http.post<any>(url, Obj);
  }

  postNomination3(Obj: any): Observable<any> {



    let url = `${this.baseURL}/customer/submit_nominations_details_3`;
    return this.http.post<any>(url, Obj);
  }


  postConsentDeclared(Obj: any): Observable<any> {


    let url = `${this.baseURL}/customer/submit_consent_declared`;
    return this.http.post<any>(url, Obj);

  }



  ///Document Upload starts
  postCustomerBankingDoc(Obj: any): Observable<any> {


    let url = `${this.baseURL}/customer/submit_passport_doc`;
    return this.http.post<any>(url, Obj);
  }



  postCustomerAddressDoc(Obj: any): Observable<any> {


    //let url = `${this.baseURL}/customer/submit_banking_doc_1`;
    let url = `${this.baseURL}/customer/submit_address_proof_doc`;
    return this.http.post<any>(url, Obj);
  }


  postCustomerAddressProofRelative(Obj: any): Observable<any> {
    let url = `${this.baseURL}/customer/submit_applicant_relative_data`;
    return this.http.post<any>(url, Obj);
  }


  postCustomerForm60Doc(Obj: any): Observable<any> {
    let url = `${this.baseURL}/customer/submit_form_sixty_doc`;
    return this.http.post<any>(url, Obj);
  }

  postCustomerVisaDoc(Obj: any): Observable<any> {
    let url = `${this.baseURL}/customer/submit_visa_doc`;
    return this.http.post<any>(url, Obj);
  }

  postCustomerPioDoc(Obj: any): Observable<any> {
    let url = `${this.baseURL}/customer/submit_pio_doc`;
    return this.http.post<any>(url, Obj);
  }


  postCustomerOciDoc(Obj: any): Observable<any> {
    let url = `${this.baseURL}/customer/submit_oci_doc`;
    return this.http.post<any>(url, Obj);
  }


  postCustomerOtherDoc(Obj: any): Observable<any> {
    let url = `${this.baseURL}/customer/submit_other_doc`;
    return this.http.post<any>(url, Obj);
  }

  ///Document Upload ends
  ///Get Documents starts

  postCustomerGetDoc(Obj: any): Observable<any> {
    let url = `${this.baseURL}/customer/get_document`;
    return this.http.post<any>(url, Obj);
  }

  postCustomerDocumentCondition(Obj: any): Observable<any> {
    let url = `${this.baseURL}/customer/get-all-documents`;
    return this.http.post<any>(url, Obj);
  }
  

  ///Get Documents ends

  postVerifySignupUser(Obj: any): Observable<any> {
    let url = `${this.baseURL}/user/process-jwt`;
    return this.http.post<any>(url, Obj);
  }


  postJointAccntApplcnt(Obj: any): Observable<any> {


    let url = `${this.baseURL}/customer/submit_joint_applicant_details`;
    return this.http.post<any>(url, Obj);
  }


  postJointAccntTermsCndnt(Obj: any): Observable<any> {


    let url = `${this.baseURL}/customer/submit_terms_conditions`;
    return this.http.post<any>(url, Obj);
  }

  postJointAccntLead(Obj: any): Observable<any> {
    let url = `${this.baseURL}/customer/submit_lead`;
    return this.http.post<any>(url, Obj);
  }


  postLeadSubmit(Obj: any): Observable<any> {
    let url = `${this.baseURL}/customer/submit_lead`;
    return this.http.post<any>(url, Obj);
  }


  postFeedBackComment(Obj: any): Observable<any> {
    let url = `${this.baseURL}/customer/get-lead-comments`;
    return this.http.post<any>(url, Obj);
  }

  //////Minor Account Post API  Starts///////////

  postPersonalDtls1Minor(Obj: any): Observable<any> {
    let url = `${this.baseURL}/customer/minor/personal-detail-first`;
    return this.http.post<any>(url, Obj);
  }


  postPersonalDtls2Minor(Obj: any): Observable<any> {
    let url = `${this.baseURL}/customer/minor/personal-detail-second`;
    return this.http.post<any>(url, Obj);
  }

  //////Minor Account Post API  End///////////


  //////Minor Account Post API  Starts///////////


  postGuardianDtls(Obj: any): Observable<any> {
    let url = `${this.baseURL}/customer/minor/gaurdian_detail`;
    return this.http.post<any>(url, Obj)
  }
  //////Minor Account Post API  End///////////


  //////////////GET API Starts/////////////////////////////
  getTitle(): Observable<any> {
    let url = `${this.baseURL}/customer/getall_titles`;
    return this.http.get<any>(url)
  }

  getCountry(): Observable<any> {
    let url = `${this.baseURL}/customer/countries`;
    return this.http.get<any>(url)
  }

  getAccountType(): Observable<any> {
    let url = `${this.baseURL}/customer/account_type`;
    return this.http.get<any>(url)
  }

  getReligion(): Observable<any> {
    let url = `${this.baseURL}/customer/religion`;
    return this.http.get<any>(url)
  }

  getCategory(): Observable<any> {
    let url = `${this.baseURL}/customer/religion_category`;
    return this.http.get<any>(url)
  }

  getVisaType(): Observable<any> {
    let url = `${this.baseURL}/customer/visa`;
    return this.http.get<any>(url)
  }

  getAddressType(): Observable<any> {
    let url = `${this.baseURL}/customer/address_type`;
    return this.http.get<any>(url)
  }

  getEmploymentType(): Observable<any> {
    let url = `${this.baseURL}/customer/employment_type`;
    return this.http.get<any>(url)
  }

  getOccupationType(): Observable<any> {
    let url = `${this.baseURL}/customer/occupation_type`;
    return this.http.get<any>(url)
  }

  getGrossAnualIncomeType(): Observable<any> {
    let url = `${this.baseURL}/customer/gross_annual_income`;
    return this.http.get<any>(url)
  }

  getIndustryType(): Observable<any> {
    let url = `${this.baseURL}/customer/industry_type`;
    return this.http.get<any>(url)
  }


  getCardVariant(): Observable<any> {
    let url = `${this.baseURL}/customer/card_variant`;
    return this.http.get<any>(url)
  }

  getAddressProofDoc(): Observable<any> {
    let url = `${this.baseURL}/customer/address_proof_types`;
    return this.http.get<any>(url)
  }


  //////////////GET API Ends/////////////////////////////

  ///////////////////////////Fetch API//////////////////////////////////
  fetchCountry(Obj: any): Observable<any> {
    let url = `${this.baseURL}/customer/get_country_form`;
    return this.http.post<any>(url, Obj);
  }

  fetchFirstApplicantName(Obj: any): Observable<any> {
    let url = `${this.baseURL}/customer/get-applicant-name`;
    return this.http.post<any>(url, Obj);
  }

  fetchAccntVariant(Obj: any): Observable<any> {
    let url = `${this.baseURL}/customer/get_account_varient`;
    return this.http.post<any>(url, Obj);
  }


  fetchPersonalDtls1(Obj: any): Observable<any> {
    console.log('fetchPersonalDtls1');
    
    let url = `${this.baseURL}/customer/personal_details_form_1`;
    return this.http.post<any>(url, Obj);
  }

  fetchPersonalName(Obj: any): Observable<any> {
    let url = `${this.baseURL}/customer/get-applicant-data`;
    return this.http.post<any>(url, Obj);
  }

  fetchPersonalDtls2(Obj: any): Observable<any> {
    let url = `${this.baseURL}/customer/personal_details_form_2`;
    return this.http.post<any>(url, Obj);
  }

  fetchAllID(Obj: any): Observable<any> {
    let url = `${this.baseURL}/customer/get-all-data`;
    return this.http.post<any>(url, Obj);
  }

  fetchSameAddress(Obj: any): Observable<any> {
    let url = `${this.baseURL}/customer/address-same-as`;
    return this.http.post<any>(url, Obj);
  }

  fetchFatca(Obj: any): Observable<any> {
    let url = `${this.baseURL}/customer/customer_fatca_form`;
    return this.http.post<any>(url, Obj);
  }

  fetchKycDtls1(Obj: any): Observable<any> {
    let url = `${this.baseURL}/customer/customer_kyc_deatil`;
    return this.http.post<any>(url, Obj);
  }

  updateKycDtls1(Obj: any): Observable<any> {
    let url = `${this.baseURL}/customer/update_kyc_details_1`;
    return this.http.post<any>(url, Obj);
  }

  fetchKycDtls2(Obj: any): Observable<any> {
    let url = `${this.baseURL}/customer/customer_kyc_deatil_temp_visa_dec`;
    return this.http.post<any>(url, Obj);
  }



  fetchKycDtls4(Obj: any): Observable<any> {
    let url = `${this.baseURL}/customer/customer_kyc_pio_dec`;
    return this.http.post<any>(url, Obj);
  }


  fetchContactDtls(Obj: any) {
    let url = `${this.baseURL}/customer/customer_contact_details`;
    return this.http.post<any>(url, Obj);
  }



  fetchAddressDtls1(Obj: any) {
    let url = `${this.baseURL}/customer/customer_overseas_current_address`;
    return this.http.post<any>(url, Obj);
  }

  fetchAddressDtls2(Obj: any) {
    let url = `${this.baseURL}/customer/customer_permanent_Jurisdiction_address`;
    return this.http.post<any>(url, Obj);
  }

  fetchCustomerProfiler(Obj: any) {
    let url = `${this.baseURL}/customer/customer_profile`;
    return this.http.post<any>(url, Obj);
  }


  fetchInternetBank1(Obj: any): Observable<any> {
    let url = `${this.baseURL}/customer/customer_banking_facilities`;
    return this.http.post<any>(url, Obj);
  }

  fetchInternetBank2(Obj: any): Observable<any> {
    let url = `${this.baseURL}/customer/customer_banking_facilities_1`;
    return this.http.post<any>(url, Obj);
  }

  fetchNomination1(Obj: any): Observable<any> {
    let url = `${this.baseURL}/customer/nominee_details`;
    return this.http.post<any>(url, Obj);
  }

  fetchNomination2(Obj: any): Observable<any> {
    let url = `${this.baseURL}/customer/nominee_details`;
    return this.http.post<any>(url, Obj);
  }


  fetchNomination3(Obj: any): Observable<any> {
    let url = `${this.baseURL}/customer/gaurdian_details`;
    return this.http.post<any>(url, Obj);
  }


  fetchConcentDeclared(Obj: any): Observable<any> {
    let url = `${this.baseURL}/customer/get_consent_declared`;
    return this.http.post<any>(url, Obj);
    //get_consent_declared
  }


  fetchGetDoc(Obj: any): Observable<any> {
    let url = `${this.baseURL}/customer/get_document`;
    return this.http.post<any>(url, Obj);
  }

  fetchAddressProofDocRelative(Obj: any): Observable<any> {
    let url = `${this.baseURL}/customer/customer-relative-details`;
    return this.http.post<any>(url, Obj);
  }


  fetchGuardianDtls(Obj: any): Observable<any> {

    let url = `${this.baseURL}/customer/minor/fetch_gaurdian_detail`;
    return this.http.post<any>(url, Obj);

  }

  fetchApplicantDtls(Obj: any): Observable<any> {
    let url = `${this.baseURL}/customer/fetch_applicant_details`;
    return this.http.post<any>(url, Obj);

  }

  fetchJointUserData(Obj: any): Observable<any> {
    let url = `${this.baseURL}/customer/fetch_joints_applicants_data`;
    return this.http.post<any>(url, Obj);
  }

  fetchSelectedAccountType(Obj: any): Observable<any> {
    let url = `${this.baseURL}/customer/selected-account-type`;
    return this.http.post<any>(url, Obj);
  }

  fetchsigninVerfied(Obj: any): Observable<any> {
    let url = `${this.baseURL}/user/is-both-otp-verify`;
    return this.http.post<any>(url, Obj);
  }

  /// url to base64

  async getBase64ImageFromUrl(imageUrl: any) {
    var res = await fetch(imageUrl);
    var blob = await res.blob();

    return new Promise((resolve, reject) => {
      var reader = new FileReader();
      reader.addEventListener("load", function () {
        const base64String = String(reader.result)
          .replace('data:', '')
          .replace(/^.+,/, '');
        resolve(base64String);
      }, false);

      reader.onerror = () => {
        return reject(this);
      };
      reader.readAsDataURL(blob);
    })
  }


}

