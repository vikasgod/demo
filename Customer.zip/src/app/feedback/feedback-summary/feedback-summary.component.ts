import { Component, OnInit } from '@angular/core';
import { Observable, of } from 'rxjs';
import { CommonService } from 'src/app/services/common.service';
import { CustomerDataService } from 'src/app/services/customer-data.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-feedback-summary',
  templateUrl: './feedback-summary.component.html',
  styleUrls: ['./feedback-summary.component.css']
})
export class FeedbackSummaryComponent implements OnInit {
  //comment_id:any
  applicantArr:any=[]
  regObj:any
  isReplied:boolean=false
  custFeedbackComments$:Observable<any>=of();
  abort:boolean = false;

  constructor(private commonService:CommonService, private customerDataService:CustomerDataService, private rt:Router) { 
    this.regObj = this.commonService.getUserFromLocalStorage();
    let Obj1 = {
      'applicant_id':this.regObj.applicant_id,
    };
    this.customerDataService.fetchApplicantDtls(Obj1).subscribe((data) => {

      if(data?.data?.length>0){
        this.commonService.storeInLocalStorage('registerData', { leadReviewStatus: data?.data?.[0]?.lead_status })
        if(data?.data?.[0]?.lead_status=='rejected' ||data?.data?.[0]?.lead_status=='approved' ){
          this.rt.navigate(['/rejected-page']);
        }
        
      }

    })
  }

  ngOnInit(): void {
  
    if(!!!this.regObj){
      this.rt.navigate(["/login"]);
      return;
    }

  
  
    let Obj={
      applicant_id : this.commonService.getUserFromLocalStorage()?.applicant_id
    }

    this.custFeedbackComments$=this.customerDataService.postFeedBackComment(Obj)
    this.custFeedbackComments$.subscribe((res)=>{
      this.applicantArr=[]
      if(res.data.applicant_1 && res.data.applicant_1!=null && res.data.applicant_1!=undefined){
         this.applicantArr[0]=res.data.applicant_1   
      }

      if(res.data.applicant_2 && res.data.applicant_2!=null && res.data.applicant_2!=undefined){
        this.applicantArr[1]=res.data.applicant_2
      }

      if(res.data.applicant_3 && res.data.applicant_3!=null && res.data.applicant_3!=undefined){
        this.applicantArr[2]=res.data.applicant_3 
      }
      this.allAdded()
      this.commonService.storeInLocalStorage('registerData', { commentId: res?.data[0]?.comment_id })
    }); 
    
  }

  redirectToProcess(current_process_id:any, applicantID:any){
    this.regObj.applicant_id = applicantID
    this.commonService.storeInLocalStorage('registerData', { 'applicant_id': applicantID});
    this.commonService.storeInLocalStorage('registerData', { guardianApplicantID: applicantID});
    
    if (current_process_id === 1) {
      this.rt.navigate(["/country"]);
    }    

    if (current_process_id === 2) {
      this.rt.navigate(["/account"]);
    }

    if (current_process_id === 3) {
      this.rt.navigate(['/feedback', 'personal-dtls1'])
    }

    if (current_process_id === 4) {
      this.rt.navigate(['/feedback', 'personal-dtls1'])
    }

    if (current_process_id === 5) {
      this.rt.navigate(['/feedback', 'personal-dtls2'])
    }

    if (current_process_id === 6) {
      this.rt.navigate(['/feedback', 'fatca'])
    }

    if (current_process_id === 7) {
      this.rt.navigate(['/feedback', 'kyc-dtls1'])
    }

    if (current_process_id === 8) {
      this.rt.navigate(['/feedback', 'kyc-dtls2'])
    }

    if (current_process_id === 9) {
      this.rt.navigate(['/feedback', 'kyc-dtls2'])
    }

    if (current_process_id === 10) {
      this.rt.navigate(['/feedback', 'kyc-dtls4'])
    }

    if (current_process_id === 11) {
      this.rt.navigate(['/feedback', 'contact-details'])
    }

    if (current_process_id === 12) {
      this.rt.navigate(['/feedback', 'addrs-dtls1'])
    }

    if (current_process_id === 13) {
      this.rt.navigate(['/feedback', 'addrs-dtls2'])
    }

    if (current_process_id === 14) {
      this.rt.navigate(['/feedback', 'customer-profile'])
    }

    if (current_process_id === 15) {
      this.rt.navigate(['/feedback', 'internet-banking'])
    }

    if (current_process_id === 16) {
      this.rt.navigate(['/feedback', 'internet-banking2'])
    }

    if (current_process_id === 18) {
      this.rt.navigate(['/feedback', 'doc-identity-proof'])
    }

    if (current_process_id === 19) {
      this.rt.navigate(['/feedback', 'doc-address-proof1'])
    }

    if (current_process_id === 21) {
      this.rt.navigate(['/individual-account', 'doc-address-proof3'])
    }
    if (current_process_id === 22) {
      this.rt.navigate(['/feedback', 'doc-fomr60'])
    }

    if (current_process_id === 23) {
      this.rt.navigate(['/feedback', 'doc-visa'])
    }

    if (current_process_id === 25) {
      this.rt.navigate(['/individual-account', 'nomination1'])
    }

    if (current_process_id === 26) {
      this.rt.navigate(['/feedback', 'nomination2'])
    }

    if (current_process_id === 27) {
      this.rt.navigate(['/feedback', 'nomination3'])
    }

    if (current_process_id === 28) {
      this.rt.navigate(['/feedback', 'declaration1'])
    }

    if (current_process_id === 29) {
      this.rt.navigate(['/feedback', 'declaration1'])
    }

    if (current_process_id === 32) {
      this.rt.navigate(['/feedback', 'doc-pio'])
    }

    if (current_process_id === 72) {
      this.rt.navigate(['/feedback', 'other-docs-proof'])
    }

    if (current_process_id === 73) {
      this.rt.navigate(['/feedback', 'doc-oci'])
    }

    if (current_process_id === 33) {
      this.rt.navigate(['/feedback', 'personal-dtls1-minor'])
    }

    if (current_process_id === 34) {
      this.rt.navigate(['/feedback', 'personal-dtls2-minor'])
    }

    if (current_process_id === 35) {
      this.rt.navigate(['/feedback', 'kyc-dtls1-minor'])
    }

    if (current_process_id === 36) {
      this.rt.navigate(['/feedback', 'kyc-dtls2-minor'])
    }

    if (current_process_id === 38) {
      this.rt.navigate(['/feedback', 'kyc-dtls4-minor'])
    }

    if (current_process_id === 39) {
      this.rt.navigate(['/feedback', 'doc-identity-proof-minor'])
    }

    if (current_process_id === 40) {
      this.rt.navigate(['/feedback', 'doc-identity-proof-minor'])
    }

    if (current_process_id === 41) {
      this.rt.navigate(['/feedback', 'doc-visa-minor'])
    }

    if (current_process_id === 42) {
      this.rt.navigate(['/feedback', 'doc-pio-minor'])
    }

    if (current_process_id === 43) {
      this.rt.navigate(['/feedback', 'doc-other-proof-minor'])
    }

    if (current_process_id === 44) {
      this.rt.navigate(['/feedback', 'guardian-dtls'])
    }

    if (current_process_id === 45) {
      this.rt.navigate(['/feedback', 'personal-dtls1-guardian'])
    }

    if (current_process_id === 46) {
      this.rt.navigate(['/feedback', 'personal-dtls2-guardian'])
    }

    if (current_process_id === 47) {
      this.rt.navigate(['/feedback', 'fatca-guardian'])
    }

    if (current_process_id === 48) {
      this.rt.navigate(['/feedback', 'kyc-dtls1-guardian'])
    }

    if (current_process_id === 49) {
      this.rt.navigate(['/feedback', 'kyc-dtls2-guardian'])
    }

    if (current_process_id === 51) {
      this.rt.navigate(['/feedback', 'kyc-dtls4-guardian'])
    }

    if (current_process_id === 52) {
      this.rt.navigate(['/feedback', 'contact-details-guardian'])
    }

    if (current_process_id === 53) {
      this.rt.navigate(['/feedback', 'addrs-dtls1-guardian'])
    }

    if (current_process_id === 54) {
      this.rt.navigate(['/feedback', 'addrs-dtls2-guardian'])
    }

    if (current_process_id === 55) {
      this.rt.navigate(['/feedback', 'customer-profile-guardian'])
    }

    if (current_process_id === 56) {
      this.rt.navigate(['/feedback', 'internet-banking1-guardian'])
    }

    if (current_process_id === 57) {
      this.rt.navigate(['/feedback', 'internet-banking2-guardian'])
    }

    if (current_process_id === 59) {
      this.rt.navigate(['/feedback', 'doc-identity-proof-guardian'])
    }

    if (current_process_id === 60) {
      this.rt.navigate(['/feedback', 'doc-address-proof1-guardian'])
    }

    if (current_process_id === 63) {
      this.rt.navigate(['/feedback', 'doc-form60-guardian'])
    }

    if (current_process_id === 64) {
      this.rt.navigate(['/feedback', 'doc-visa-guardian'])
    }

    if (current_process_id === 65) {
      this.rt.navigate(['/feedback', 'doc-pio-guardian'])
    }

    if (current_process_id === 66) {
      this.rt.navigate(['/feedback', 'docs-other-proof-guardian'])
    }

    if (current_process_id === 67) {
      this.rt.navigate(['/feedback', 'nomination1-guardian'])
    }

    if (current_process_id === 68) {
      this.rt.navigate(['/feedback', 'nomination2-guardian'])
    }

    if (current_process_id === 69) {
      this.rt.navigate(['/feedback', 'nomination3-guardian'])
    }

    if (current_process_id === 69) {
      this.rt.navigate(['/feedback', 'nomination3-guardian'])
    }
  }

  allAdded(){
    console.log("addddddddd",this.applicantArr)
    // this.applicantArr.forEach((element: any) => {
    //   element.forEach((ele:any)=>{
    //     console.log("//////",ele.status)
    //     if(ele.status=='added'){
    //       this.isReplied=false
    //     console.log("in added",ele.status)
           
    //     }else{
    //       this.isReplied=true
    //     }
    //   })
    // });

    for (let a = 0; a < this.applicantArr.length && !this.abort; a++) {
      for (let b = 0; b < this.applicantArr[a].length && !this.abort; b++) {
        let ele=this.applicantArr[a][b]
          if(ele.status=='added'){
            this.isReplied=false
            this.abort = true;
          }else{
            this.isReplied=true
          }
      }
  }

  }

  isApplicantRpl(data:any){
    let ind= data.findIndex((el:any)=> el.status=='added')
    if(ind<0){
      return false
    }else{
      return true
    }
  }
}