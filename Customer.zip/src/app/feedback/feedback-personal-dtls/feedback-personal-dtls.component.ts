import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-feedback-personal-dtls',
  templateUrl: './feedback-personal-dtls.component.html',
  styleUrls: ['./feedback-personal-dtls.component.css']
})
export class FeedbackPersonalDtlsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
