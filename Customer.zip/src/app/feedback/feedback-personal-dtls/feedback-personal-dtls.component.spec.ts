import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FeedbackPersonalDtlsComponent } from './feedback-personal-dtls.component';

describe('FeedbackPersonalDtlsComponent', () => {
  let component: FeedbackPersonalDtlsComponent;
  let fixture: ComponentFixture<FeedbackPersonalDtlsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ FeedbackPersonalDtlsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(FeedbackPersonalDtlsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
