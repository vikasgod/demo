import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FeedbackSummaryComponent } from './feedback-summary/feedback-summary.component';
import { FeedbackPersonalDtlsComponent } from './feedback-personal-dtls/feedback-personal-dtls.component';
import { RouterModule } from '@angular/router';



@NgModule({
  declarations: [
    FeedbackSummaryComponent,
    FeedbackPersonalDtlsComponent
  ],
  imports: [
    CommonModule,
    RouterModule
  ],
  exports:[
    FeedbackSummaryComponent
  ]
})
export class FeedbackModule { }
