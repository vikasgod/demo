import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule, HTTP_INTERCEPTORS} from '@angular/common/http';
import {CustomerAuthGuard} from '../app/auth-gard/customer-auth-guard';
import {CustomerSignUpAuthGuard} from '../app/auth-gard/customer-signup-auth-guard';

import { AppRoutingModule } from './app-routing.module';
import { SharedModule } from './shared/shared.module';
import { IndividualAccntModule } from './individual-accnt/individual-accnt.module';
import { JointAccntModule } from './joint-accnt/joint-accnt.module';
import { AgentsModule } from './agents/agents.module'; 


import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MAT_DATE_LOCALE } from '@angular/material/core';

import { FeedbackModule } from './feedback/feedback.module';
import { MinorAccntModule } from './minor-accnt/minor-accnt.module';
import { NgIdleKeepaliveModule } from '@ng-idle/keepalive';

@NgModule({
  declarations: [
    AppComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    AppRoutingModule,
    ReactiveFormsModule,
    FormsModule,
    BrowserAnimationsModule,
    SharedModule,
    IndividualAccntModule,
    JointAccntModule,
    MinorAccntModule,
    AgentsModule,
    FeedbackModule,
    NgIdleKeepaliveModule.forRoot()



  ],
  providers: [{ provide: MAT_DATE_LOCALE, useValue: 'en-GB' },CustomerAuthGuard,CustomerSignUpAuthGuard],
  bootstrap: [AppComponent]
})
export class AppModule { }
