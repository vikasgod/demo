import { Component, OnInit } from '@angular/core';
import { CommonService } from 'src/app/services/common.service';
import { Router } from '@angular/router';
import { CustomerDataService } from 'src/app/services/customer-data.service';

@Component({
  selector: 'app-thank-page',
  templateUrl: './thank-page.component.html',
  styleUrls: ['./thank-page.component.css']
})
export class ThankPageComponent implements OnInit {
  regObj:any;
  titleName:any;
  lead_reference_number:String=''

  constructor( private commonService: CommonService, private rt: Router, private customerDataService: CustomerDataService) { }

  ngOnInit(): void {
    this.regObj=this.commonService.getUserFromLocalStorage();
    this.titleName = this.regObj.nameTitle.charAt(0).toUpperCase() + this.regObj.nameTitle.slice(1).toLowerCase()
    if(this.regObj.applicant_id!=undefined){
      let Obj = {
        'applicant_id':this.regObj.applicant_id,
      };
      this.customerDataService.fetchApplicantDtls(Obj).subscribe((data) => {
        
        if(data?.data?.length>0){
          if(data?.data?.[0]?.lead_number!=undefined){
            this.lead_reference_number=data?.data?.[0]?.lead_number
          }
          this.commonService.storeInLocalStorage('registerData', { leadReviewStatus: data?.data?.[0]?.lead_status })
          if(data?.data?.[0]?.lead_status=='agent_review'){
            this.rt.navigate(["/feedback", "feedback-summary"]);
          }
          if(data?.data?.[0]?.lead_status=='rejected'||data?.data?.[0]?.lead_status=='approved'){
            this.rt.navigate(["/rejected-page"]);
          }
        }
      })
    }
    
    var is_feedback_show = 0;
    if(this.regObj?.leadReviewStatus!= undefined){
      if(this.regObj?.leadReviewStatus=='agent_review'){
        is_feedback_show+=1;
      }
    }
    if(is_feedback_show!=0){
      this.rt.navigate(["/feedback", "feedback-summary"]);
    }  
  }
}