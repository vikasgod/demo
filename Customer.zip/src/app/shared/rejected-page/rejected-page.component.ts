import { Component, OnInit } from '@angular/core';
import { CommonService } from 'src/app/services/common.service';
import { Router } from '@angular/router';
import { CustomerDataService } from 'src/app/services/customer-data.service';

@Component({
  selector: 'app-rejected-page',
  templateUrl: './rejected-page.component.html',
  styleUrls: ['./rejected-page.component.css']
})
export class RejectedPageComponent implements OnInit {

  regObj:any;

  headerString:string = '';
  messageString:string = '';
  showTickSpan:boolean = false;

  lead_reference_number:String=''

  constructor( private commonService: CommonService, private rt: Router, private customerDataService: CustomerDataService) { }

  ngOnInit(): void {
    this.regObj=this.commonService.getUserFromLocalStorage();

    if(this.regObj.applicant_id!=undefined){
      let Obj = {
        'applicant_id':this.regObj.applicant_id,
      };
      this.customerDataService.fetchApplicantDtls(Obj).subscribe((data) => {
        
        if(data?.data?.length>0){
          if(data?.data?.[0]?.lead_number!=undefined){
            this.lead_reference_number=data?.data?.[0]?.lead_number
          }
          this.commonService.storeInLocalStorage('registerData', { leadReviewStatus: data?.data?.[0]?.lead_status })
          if(data?.data?.[0]?.lead_status=='agent_review'){
            this.rt.navigate(["/feedback", "feedback-summary"]);
          }

          if(data?.data?.[0]?.lead_status=='rejected'){
            this.headerString = 'Sorry! Your application is rejected.';
            this.messageString = 'We are sorry to inform you that your application has been rejected for reason : mismatched data found';
            this.showTickSpan = true;
          }
          if(data?.data?.[0]?.lead_status=='approved'){
            this.headerString = 'Congratulations! Your application is approved.';
            this.messageString = 'We have shared a download link with you on your register email address. Please Print the form, sign the sections mention in the form and our agent will contact you for free Courier Pickup from your residence to collect all the Physical Documents to be submitted to the Bank. Thank you';
            this.showTickSpan = false;
          }

        }
      })
    }
    this.regObj=this.commonService.getUserFromLocalStorage();
    var is_feedback_show = 0;
    if(this.regObj?.leadReviewStatus!= undefined){
      if(this.regObj?.leadReviewStatus=='agent_review'){
        is_feedback_show+=1;
      }
    }
    if(is_feedback_show!=0){
      this.rt.navigate(["/feedback", "feedback-summary"]);
    } 
 
  }
}

