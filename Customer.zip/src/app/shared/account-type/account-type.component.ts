import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { CommonService } from 'src/app/services/common.service';
import { CustomerDataService } from 'src/app/services/customer-data.service';

@Component({
  selector: 'app-account-type',
  templateUrl: './account-type.component.html',
  styleUrls: ['./account-type.component.css']
})
export class AccountTypeComponent implements OnInit {
  regObj: any;
  accountTypeForm: any;
  nre: boolean = false;
  nro: boolean = false;
  both: boolean = false;
  constructor(private fb: FormBuilder, private rt: Router, private customerDataService: CustomerDataService, private commonService: CommonService) { }

  ngOnInit(): void {
    this.regObj = this.commonService.getUserFromLocalStorage();

    if ((this.regObj.isSubmitted != undefined && this.regObj.isSubmitted != 0) || (this.regObj.leadReviewStatus != undefined && this.regObj.leadReviewStatus != "customer_process")) {
      this.rt.navigate(["/individual-account", "ending"]);
    }

    let Obj = {
      user_id: this.regObj.user_id,
      process_id: 2,
      applicant_id: this.regObj.applicant_id
    }

    this.customerDataService.fetchAccntVariant(Obj).subscribe((value) => {
      console.log("This is Account Variant", value);
      this.commonService.storeInLocalStorage('registerData', {
        leadReviewStatus: value?.lead_result
          ?.[0]?.lead_status
      })
      if (value?.data?.length > 0) {
        this.nre = value?.data?.[0]?.account_varient == 'nre';
        this.nro = value?.data?.[0]?.account_varient == 'nro';
        this.both = value?.data?.[0]?.account_varient == 'both';
        this.accountTypeForm = this.fb.group({
          accountType: [value?.data?.[0]?.account_varient, [Validators.required]]
        })
      }
    })
    let accountTypevar = localStorage.getItem("account_varient")
    console.log("check", accountTypevar);

    this.accountTypeForm = this.fb.group({
      accountType: ['', [Validators.required]]
    })

    if (accountTypevar != null) {
      this.accountTypeForm.get("accountType").setValue(accountTypevar)
      this.selectAccount()
    }

  }

  get accountType() { return this.accountTypeForm.get("accountType"); }


  submitAccountType(saving_account?: any) {
    if (this.accountTypeForm.valid) {
      this.regObj = this.commonService.getUserFromLocalStorage();
      let applicant_id = Number(this.regObj.applicant_id);
      let account_varient = this.accountTypeForm.get("accountType").value
      let process_id = 2;

      this.customerDataService.postAccountVariant(applicant_id, account_varient, process_id, saving_account).subscribe((data) => {
        // localStorage.setItem("account_varient", account_varient)
        if (this.regObj?.account_type_id === 1 || this.regObj?.account_type === 1) {
          this.rt.navigate(['/individual-account', 'personal-dtls1']).then(() => {
            window.location.reload();
          });
        }
        else if (this.regObj?.account_type_id === 2 || this.regObj?.account_type === 2) {
          this.rt.navigate(['/joint-account', 'applicant-form']).then(() => {
            window.location.reload();
          });
        }
        else if (this.regObj?.account_type_id === 3|| this.regObj?.account_type === 3) {
          this.rt.navigate(['/minor-accnt', 'personal-dtls1-minor']).then(() => {
            window.location.reload();
          });
        }
      })
    }
    else {
    }
  }

  selectAccount() {
    let val = this.accountTypeForm.controls['accountType'].value
    if (val == "nre") {
      this.nre = true;
      this.nro = false;
      this.both = false;
    }
    else if (val == "nro") {
      this.nro = true;
      this.nre = false;
      this.both = false;
    }
    else if (val == 'both') {
      this.both = true;
      this.nre = false;
      this.nro = false;

    }
  }
}