import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { Router } from '@angular/router';
import { CommonService } from 'src/app/services/common.service';
import { CustomerDataService } from 'src/app/services/customer-data.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

  loginAuth: boolean = false;
  isDisplay: boolean = false;

  @Input() myinputMsg: string = "";
  @Output() myOutput: EventEmitter<string> = new EventEmitter();

  errMsg: any;
  regObj: any;
  accountType: any;
  constructor(private rt: Router, private customerDataService: CustomerDataService,private commonService: CommonService) {

    this.rt.events.subscribe(() => {
      const regex1 = new RegExp('individual-account*');
      const regex2 = new RegExp('joint-account*');
      const regex3 = new RegExp('minor-accnt*');
      this.isDisplay=regex1.test(this.rt.url) || regex2.test(this.rt.url) || regex3.test(this.rt.url);

    })

    if(this.rt.url == 'individual-account*' || this.rt.url == 'minor-accnt*'){
      this.isDisplay = true
    }
  }
  diplayDiv: boolean = true;
  ngOnInit(): void {

    
    

    this.regObj = this.commonService.getUserFromLocalStorage();

    let Obj = {
      applicant_id: this.regObj?.applicant_id,
    }

    this.customerDataService.fetchSelectedAccountType(Obj).subscribe((res) => {
      this.accountType = res.data[0];      
    })


    this.loginAuth = this.customerDataService.checkCustomerLoginAuth();

    this.rt.events.subscribe(() => {
      /* console.log('rreerer', this.rt.url);
      if (this.rt.url != '/') {
        this.isDisplay = true;
      } */
      //console.log(String(this.rt.url.indexOf('individual-account')))

      let ch = this.rt.url;
      switch (ch) {
        case "/feedback/feedback-summary":
          this.isDisplay = true;
          break;
        case '/country': 
          this.diplayDiv = false; 
          console.log('This router test', this.diplayDiv)
          break;
        case '/account': 
          this.diplayDiv = false; 
          console.log('This router test', this.diplayDiv)
          break;
        default: 
          this.diplayDiv = true;//console.log('This router test',this.diplayDiv);
          break;
      }

    })

  }
}