import { Component, OnInit,Input } from '@angular/core';

@Component({
  selector: 'app-err-popup',
  templateUrl: './err-popup.component.html',
  styleUrls: ['./err-popup.component.css']
})
export class ErrPopupComponent implements OnInit {
  display:string = "none";
  @Input('errMsg') errMsg:string='';  
  errMessage:String='';
  constructor() { }

  ngOnInit(): void {

    this.errMessage='THi si errr'
    //this.errMessage=this.myinputMsg;
  }

  openModal() {
    this.display = "block";
  }
  onCloseHandled() {
    this.display = "none";
  }


}
