import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ErrPopupComponent } from './err-popup.component';

describe('ErrPopupComponent', () => {
  let component: ErrPopupComponent;
  let fixture: ComponentFixture<ErrPopupComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ErrPopupComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ErrPopupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
