import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { CommonService } from '../../services/common.service';
import { CustomerDataService } from 'src/app/services/customer-data.service';
import { Router } from '@angular/router';
import { interval, timer } from 'rxjs';
import { map } from 'rxjs/operators'

@Component({
  selector: 'app-signup-auth',
  templateUrl: './signup-auth.component.html',
  styleUrls: ['./signup-auth.component.css']
})
export class SignupAuthComponent implements OnInit {

  emailStr: string = '';
  afterEmailStr: string = '';
  afterEmailArr: Array<string> = [];
  mobileStr: string = '';
  afterMobileStr: string = '';
  afterMobileArr: Array<string> = [];
  emailAuthForm: any;
  mobileAuthForm: any;
  iSsubmittedEmailOTP: boolean = false;
  iSsubmittedMobileOTP: boolean = false;
  regObj: any;
  display: string = "none";
  loginFailedErr: string = "";
  requestId:any;
  countDown1: any;
  countDown2: any;
  counter1 = 100;
  counter2 = 100;
  tick = 1000;

  isDisplayTimer1: boolean = false;
  isDisplayTimer2: boolean = false;
  timeLeft: number = 60;
  interval: any;

  constructor(private fb: FormBuilder, private commonService: CommonService, private customerDataService: CustomerDataService, private rt: Router) { }

  ngOnInit(): void {
    //console.log('THis is count down',this.countDown1)

    this.emailAuthForm = this.fb.group({
      eamilOtp: ['', [Validators.required, Validators.maxLength(6), Validators.pattern(/[0-9]{6}/)]]
    })

    this.mobileAuthForm = this.fb.group({
      mobileOtp: ['', [Validators.required, Validators.maxLength(6), Validators.pattern(/[0-9]{6}/)]]
    })

    this.regObj = this.commonService.getUserSignUpFromLocalStorage();
    this.emailStr = String(this.regObj?.email_address).slice(0, 3);
    this.afterEmailArr = String(this.regObj?.email_address).split('@');
    this.afterEmailStr = this.afterEmailArr[1];
    this.emailStr = String(this.regObj?.email_address).slice(0, 3);
    this.afterMobileArr = String(this.regObj?.mobile_no).split('').splice(7, 3);
    this.afterMobileStr = this.afterMobileArr.join('');

    this.checkVerified()
  }

  checkVerified(){
    let Obj = {
      user_id: this.regObj.user_id
    }

    this.customerDataService.fetchsigninVerfied(Obj).subscribe((value) => {
      console.log(value.data[0]);

      if(value.data[0].is_email_verify == 1){
        this.iSsubmittedEmailOTP = true
      }

      if(value.data[0].is_mobile_verify == 1){
        this.iSsubmittedMobileOTP = true
      }
    })
  }

  openModal() {
    this.display = "block";
  }
  onCloseHandled() {
    this.display = "none";
  }

  get eamilOtp() { return this.emailAuthForm.get("eamilOtp") }
  get mobileOtp() { return this.mobileAuthForm.get("mobileOtp") }

  keyPressOTP(event: any) {
    return this.commonService.enterOnlyNumber(event);
  }

  sendEmailOTP() {
    if (this.emailAuthForm.valid) {
      //this.emailAuthForm.value
      this.customerDataService.emailVerifyOTP(this.regObj.email_address, Number(this.emailAuthForm.get("eamilOtp").value), 'customer' + this.rt.url).subscribe((data) => {
        //  this.customerDataService.emailVerifyOTP(this.requestId, Number(this.emailAuthForm.get("eamilOtp").value), 'customer' + this.rt.url).subscribe((data) => {
        this.iSsubmittedEmailOTP = true;
        this.countDown1.unsubscribe()
      }, (err) => {
        if (err?.status === 401) {
          this.loginFailedErr = err?.error?.msg;
          alert(err?.error?.msg);
          //this.openModal();
        }
      })
    }
    else {
      this.iSsubmittedEmailOTP = false;
      console.log("Send Email OTP invalid", this.emailAuthForm.value);
    }
  }

  getEmailOTP() {
    //alert(this.regObj?.email_address)
    //this.openModal()
    this.customerDataService.generateEmailOTP(this.regObj?.user_id, "email", this.regObj?.email_address).subscribe((data) => {
      //let counter1=120;
      //Start timer and disable send OTP
      //After 2 mins or 120 seconds 
      //sendOTP will appear
      this.requestId = data.data
      this.isDisplayTimer1 = true;
      this.countDown1 = timer(0, 1000)
        .subscribe(() => {
          if (this.counter1 == 0) {
            this.counter1 = 100;
            this.isDisplayTimer1 = false;
            this.countDown1.unsubscribe()
          }else{
            this.counter1=this.counter1-1
          }
          return this.counter1;
        });
      //this.startTimer();

      this.loginFailedErr = data?.msg;
      // alert(data?.msg)
      //this.openModal();
    }, (err) => {
      if (err?.status === 401) {
        alert(err?.error?.msg)
        this.loginFailedErr = err?.error?.msg;
        //this.openModal();
      }
    })
  }

  getMobileOTP() {
    this.customerDataService.generateOTP("mobile", this.regObj?.mobile_no).subscribe((data) => {
      // alert(data?.msg);
      //this.loginFailedErr = data?.msg;
      //this.openModal();
      //Start timer and disable send OTP
      //After 2 mins or 120 seconds 
      //sendOTP will appear
      this.requestId = data.data
      this.isDisplayTimer2 = true;
      this.countDown2 = timer(0, 1000)
        .subscribe(() => {
          //console.log('This is counter timer2',this.counter2);
          if (this.counter2 == 0) {
            this.counter2 = 100;
            this.isDisplayTimer2 = false;
            this.countDown2.unsubscribe();
          }else{
             this.counter2 = this.counter2 - 1;
          }
           return this.counter2;
        });
    }, (err) => {
      if (err?.status === 401) {
        alert(err?.error?.msg)
        this.loginFailedErr = err?.error?.msg;
        //this.openModal();
      }
    })
  }

  // startTimer() {
  //   this.interval = setInterval(() => {
  //     if(this.timeLeft > 0) {
  //       this.timeLeft--;
  //       console.log('Email Timer',this.timeLeft)
  //     } else {
  //       this.timeLeft = 60;
  //     }
  //   },1000)
  // }

  // pauseTimer() {
  //   clearInterval(this.interval);
  // }

  sendMobilelOTP() {
    if (this.mobileAuthForm.valid) {
      this.customerDataService.mobileVerifyOTP(this.regObj.user_id, Number(this.mobileAuthForm.get("mobileOtp").value), this.regObj?.mobile_no).subscribe((data) => {
        //  this.customerDataService.mobileVerifyOTP(this.requestId, Number(this.mobileAuthForm.get("mobileOtp").value), this.regObj?.mobile_no).subscribe((data) => {
        this.iSsubmittedMobileOTP = true;
        this.countDown2.unsubscribe();
      }, (err) => {
        if (err?.status === 401) {
          this.loginFailedErr = err?.error?.msg;
          alert(err?.error?.msg);
          //this.openModal();
        }
      })
    }
    else {
      console.log("Send Mobile OTP invalid", this.mobileAuthForm.value);
      this.iSsubmittedMobileOTP = false;
    }
  }

  redirect() {
    this.regObj = this.commonService.getUserSignUpFromLocalStorage();
    let Obj = {
      user_id: this.regObj?.user_id
    }
    this.customerDataService.postVerifySignupUser(Obj).subscribe((data) => {
      this.commonService.storeInLocalStorage('registerData', data?.user);
      this.commonService.removeObjecLocal('signup');
      this.rt.navigate(['/country']);
    }, (err) => {
      console.log(err)
    })

  }
}