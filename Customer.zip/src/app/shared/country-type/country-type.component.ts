import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { CustomerDataService } from 'src/app/services/customer-data.service';
import { CommonService } from 'src/app/services/common.service';

@Component({
  selector: 'app-country-type',
  templateUrl: './country-type.component.html',
  styleUrls: ['./country-type.component.css']
})
export class CountryTypeComponent implements OnInit {
  regObj: any;
  countryTypeForm: any;
  countryData: any;
  accntTyData: any
  isSubmitted: boolean = false;
  isUpdate:boolean=false
  constructor(private fb: FormBuilder, private rt: Router, private customerDataService: CustomerDataService, private commonService: CommonService) { }

  ngOnInit(): void {
    this.regObj = this.commonService.getUserFromLocalStorage();

    if ((this.regObj.isSubmitted!=undefined && this.regObj.isSubmitted!=0)  || (this.regObj.leadReviewStatus!=undefined && this.regObj.leadReviewStatus != "customer_process")) {
      // this.rt.navigate(["/individual-account", "ending"]);
    }


    let Obj = {
      user_id: this.regObj.user_id,
      process_id: 1,
      applicant_id: this.regObj?.applicant_id
    }

    this.customerDataService.fetchCountry(Obj).subscribe((value) => {
      console.log("This is country type", value);
      if (value?.data?.length > 0) {
        this.isUpdate=true
        if (String(value?.data?.[0]?.is_trading_facility_opt) === "1") {
          this.isSubmitted = true
        } else {
          this.isSubmitted = false
        }

        this.countryTypeForm = this.fb.group({
          countryType: [value?.data?.[0]?.country_id, [Validators.required]],
          cntryAccType: [value?.data?.[0]?.account_type_id, [Validators.required]],
          tradingFacility: [String(value?.data?.[0]?.is_trading_facility_opt), [Validators.required]]
        })
      }
      console.log("sdhfgdfgdhgfdhgfhdgf",this.countryTypeForm.get("tradingFacility"))
    })

    this.countryTypeForm = this.fb.group({
      countryType: ['', [Validators.required]],
      cntryAccType: ['', [Validators.required]],
      tradingFacility: ['', [Validators.required]]
    })

    this.customerDataService.getCountry().subscribe((data: any) => {
      this.countryData = data;
    })

    this.customerDataService.getAccountType().subscribe((data) => {
      this.accntTyData = data;
    })
  }
  get countryType() { return this.countryTypeForm.get("countryType") }
  get cntryAccType() { return this.countryTypeForm.get("cntryAccType") }
  get tradingFacility() { return this.countryTypeForm.get("tradingFacility") }

  onChangetradingFacility(event: any) {
    // if(event.target.value==="1")
    // {
    //   this.isSubmitted=true
    // }else
    // {
    //   this.isSubmitted=false
    // }
  }

  sendCountryType() {
    this.commonService.storeInLocalStorage('registerData',  { 'country_id': this.countryTypeForm.value.countryType})
    if (this.countryTypeForm.valid) {
      //console.log("This is valid form value", this.countryTypeForm.value)
      this.regObj = this.commonService.getUserFromLocalStorage();
      //user_id:any,country_id:any,account_type_id:any,is_trading:any,process_id:any
      let user_id = this.regObj.user_id;
      let country_id = Number(this.countryTypeForm.get("countryType").value);
      let account_type_id = Number(this.countryTypeForm.get("cntryAccType").value);
      let is_trading = Number(this.countryTypeForm.get("tradingFacility").value);
      let process_id = Number(1);
      let applicant_id = this.regObj?.applicant_id

      this.customerDataService.postCountryType(applicant_id, user_id, country_id, account_type_id, is_trading, process_id).subscribe((data) => {
        //console.log("data accepete", data?.applicant_id);
        //registerData 
        this.commonService.storeInLocalStorage('registerData', { "applicant_id": data?.applicant_id, "account_type_id": data?.account_type_id })
        //this.storeInLocalStorage('registerData',{"applicant_id": data?.applicant_id})
        //data?.data?.applicant_id;

        /*
        console.log("This is trading facility",this.countryTypeForm.get("tradingFacility").value)
        console.log("Account type data",this.countryTypeForm.get("cntryAccType").value)
        */
        // if(Number(this.countryTypeForm.get("tradingFacility").value)===1)
        // {
        //   this.rt.navigate(["/account"])
        // }else
        // {

        // if(Number(this.countryTypeForm.get("cntryAccType").value)===1)
        // {
        //   this.rt.navigate(["/individual-account","personal-dtls1"]); 
        // }

        // if(Number(this.countryTypeForm.get("cntryAccType").value)===2)
        // {
        //   this.rt.navigate(["/joint-account","applicant-form"]);
        // }

        //   //this.rt.navigate(["/account"])
        // }
        this.rt.navigate(["/account"])
      })
    } 
    else {
      console.log("This is invalid form");
    }
  }
}
