import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { CommonService } from '../../services/common.service';
import { CustomerDataService } from '../../services/customer-data.service'
import { Router } from '@angular/router';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {
  regObj: any;
  registerFrom: any;
  checkedAutherized: Boolean = false;
  formSubmitted: any;
  contentUrlClss: string = '';
  display: string = "none";
  loginFailedErr: string = ""
  countCodeList: Array<any> = [];
  loginFailed: boolean = false;
  constructor(private fb: FormBuilder, private commonService: CommonService, private rt: Router, private customerDataService: CustomerDataService) { }

  ngOnInit(): void {

    this.countCodeList = ['1', '1-242', '1-246', '1-264', '1-268', '1-284', '1-340', '1-345', '1-441',
      '1-473', '1-649', '1-664', '1-670', '1-671', '1-684', '1-721', '1-758', '1-767', '1-784', '1-787', '1-809', '1-829', '1-849', '1-868', '1-869', '1-876', '1-939', '20', '211', '212', '212', '213', '216', '218', '220', '221', '222', '223', '224', '225', '226', '227', '228', '229', '230', '231', '232', '233', '234', '235', '236', '237', '238', '239', '240', '241', '242', '243', '244', '245', '246', '248', '249', '250', '251', '252', '253', '254', '255', '256', '257', '258', '260', '261', '262', '262', '263', '264', '265', '266', '267', '268', '269', '27', '290', '291', '297', '298', '299', '30', '31', '32', '33', '34', '350', '351', '352', '353', '354', '355', '356', '357', '358', '359', '36', '370', '371', '372', '373', '374', '375', '376', '377', '378', '379', '380', '381', '382', '383', '385', '386', '387', '389', '39', '40', '41', '420', '421', '423', '43', '44', '44-1481', '44-1534', '44-1624', '45', '46', '47', '47', '48', '49', '500', '501', '502', '503', '504', '505', '506', '507', '508', '509', '51', '52', '53', '54', '55', '56', '57', '58', '590', '590', '591', '592', '593', '595', '597', '598', '599', '599', '60', '61', '61', '61', '62', '63', '64', '64', '65', '66', '670', '672', '673', '674', '675', '676', '677', '678', '679', '680', '681', '682', '683', '685', '686', '687', '688', '689', '690', '691', '692', '7', '7', '81', '82', '84', '850', '852', '853', '855', '856', '86', '880', '886', '90', '91', '92', '93', '94', '95', '960', '961', '962', '963', '964', '965', '966', '967', '968', '970', '971', '972', '973', '974', '975', '976', '977', '98', '992', '993', '994', '995', '996', '998',
    ];

    if (this.customerDataService.checkCustomerLoginAuth()) {
      this.regObj = this.commonService.getUserFromLocalStorage();
      if (this.regObj.isSubmitted != undefined && this.regObj.isSubmitted == 1) {
        this.rt.navigate(["/individual-account", "ending"]);
      } else {

        if (this.regObj.current_process_id == undefined) {
          this.rt.navigate(["/country"]);
        } else {
          var current_process_id = this.regObj.current_process_id;
          switch (current_process_id) {
            case 2:
              this.rt.navigate(["/account"])
              break;
            case 3:
            case 4:
              this.rt.navigate(['/individual-account', 'personal-dtls1'])
              break;
            case 5:
              this.rt.navigate(['/individual-account', 'personal-dtls2'])
              break;
            case 6:
              this.rt.navigate(['/individual-account', 'fatca'])
              break;
            case 7:
              this.rt.navigate(['/individual-account', 'kyc-dtls1'])
              break;
            case 8:
              this.rt.navigate(['/individual-account', 'kyc-dtls2'])
              break;
            case 9:
              this.rt.navigate(['/individual-account', 'kyc-dtls3'])
              break;
            case 10:
              this.rt.navigate(['/individual-account', 'kyc-dtls4'])
              break;
            case 11:
              this.rt.navigate(['/individual-account', 'contact-details'])
              break;
            case 12:
              this.rt.navigate(['/individual-account', 'addrs-dtls1'])
              break;
            case 13:
              this.rt.navigate(['/individual-account', 'addrs-dtls2'])
              break;
            case 14:
              this.rt.navigate(['/individual-account', 'customer-profile'])
              break;
            case 15:
              this.rt.navigate(['/individual-account', 'internet-banking'])
              break;
            case 16:
              this.rt.navigate(['/individual-account', 'internet-banking2'])
              break;
            case 25:
              this.rt.navigate(['/individual-account', 'nomination1'])
              break;
            case 26:
              this.rt.navigate(['/individual-account', 'nomination2'])
              break;
            case 27:
              this.rt.navigate(['/individual-account', 'nomination3'])
              break;
            case 28:
              this.rt.navigate(['/individual-account', 'declaration1'])
              break;
            case 29:
              this.rt.navigate(['/individual-account', 'declaration2'])
              break;
            case 30:
              this.rt.navigate(['/individual-account', 'thanks'])
              break;
            case 31:
              this.rt.navigate(['/individual-account', 'ending'])
              break;

            default:
              this.rt.navigate(["/country"]);
              break;
          }
        }
      }
    }

    this.registerFrom = this.fb.group({
      firstname: ['', [Validators.required, Validators.minLength(3)]],
      lastname: ['', [Validators.required, Validators.minLength(3)]],
      isd: ['', Validators.required],
      mobile: ['', [Validators.required]],
      emailID: ['', [Validators.required, Validators.pattern(/^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z]{2,4})+$/)]],
      autherizeCheck: ['', Validators.required],

    })
    this.contentUrlClss = `content page_home`;
  }

  get firstname() { return this.registerFrom.get("firstname") }
  get lastname() { return this.registerFrom.get("lastname") }
  get mobile() { return this.registerFrom.get("mobile") }
  get emailID() { return this.registerFrom.get("emailID") }
  get autherizeCheck() { return this.registerFrom.get("autherizeCheck") }
  get isd() { return this.registerFrom.get("isd") }


  openModal() {
    this.display = "block";
  }
  onCloseHandled() {
    this.display = "none";
  }

  //Filter Only Numbers  
  kypressNumber(event: any) {
    return this.commonService.enterOnlyNumber(event);
  }

  //Filter Only Alphabets to input feild 
  keypressLetters(event: any) {
    return this.commonService.enterOnlyAlphabetsNoSpace(event);
  }

  validateISD(event: any) {
    return this.commonService.validateISD(event);
  }

  //if submitted 
  //true

  check(val:any){
    console.log(val.value);
  }

  submitRegisteration() {
    if (this.registerFrom.valid && this.registerFrom.get("autherizeCheck").value === true){
      this.checkedAutherized = true;
      this.formSubmitted = true;
      this.customerDataService.registerCustomer(this.registerFrom.value).subscribe((data) => {
        this.commonService.storeInLocalStorage('signup', data);
        this.rt.navigate(["/signup-authentication"]);
      }, (err) => {
        if (err?.status === 409) {
          console.log(err)
          this.loginFailedErr = err?.error?.msg;
          this.openModal();
          this.loginFailed = true;
        }
      });
    }
    else {
      this.checkedAutherized = false;
      this.formSubmitted = false;
    }
  }
}