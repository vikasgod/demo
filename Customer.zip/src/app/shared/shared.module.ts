import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router'; 

import { HeaderComponent } from './header/header.component';
import { StepperComponent } from './stepper/stepper.component';
import { RegistrationComponent } from './registration/registration.component';
import { LoginComponent } from './login/login.component';
import { ReactiveFormsModule } from '@angular/forms';
import { SignupAuthComponent } from './signup-auth/signup-auth.component';
import { CountryTypeComponent } from './country-type/country-type.component';
import { AccountTypeComponent } from './account-type/account-type.component';
import { BreadcrumUrlComponent } from './breadcrum-url/breadcrum-url.component';
import { CarouselComponent } from './carousel/carousel.component'; 

import { HttpClientModule, HTTP_INTERCEPTORS} from '@angular/common/http';
import { ErrPopupComponent } from './err-popup/err-popup.component';
import { ThankPageComponent } from './thank-page/thank-page.component';
import { ThankPersonComponent } from './thank-person/thank-person.component';
import { TermsOfUseComponent } from './terms-of-use/terms-of-use.component';
import { RejectedPageComponent } from './rejected-page/rejected-page.component';



@NgModule({
  declarations: [
    HeaderComponent,
    StepperComponent,
    RegistrationComponent,
    LoginComponent,
    SignupAuthComponent,
    CountryTypeComponent,
    AccountTypeComponent,
    BreadcrumUrlComponent,
    CarouselComponent,
    ErrPopupComponent,
    ThankPageComponent,
    ThankPersonComponent,
    TermsOfUseComponent,
    RejectedPageComponent,
    
  ],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    RouterModule,
    HttpClientModule
  ],
  exports:[
    HeaderComponent,
    StepperComponent,
    RegistrationComponent,
    LoginComponent,
    CountryTypeComponent,
    AccountTypeComponent,
    SignupAuthComponent,
    BreadcrumUrlComponent,
    CarouselComponent,
    ErrPopupComponent,
    ThankPageComponent,
    ThankPersonComponent,
  ]
})
export class SharedModule { }
