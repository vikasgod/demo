import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-breadcrum-url',
  templateUrl: './breadcrum-url.component.html',
  styleUrls: ['./breadcrum-url.component.css']
})
export class BreadcrumUrlComponent implements OnInit {

  pageUrl:string='';
  constructor(private router:Router) { }

  ngOnInit(): void {

    this.pageUrl=String(this.router.url).replace(/[\/]/,'');
    console.log("This is page URL",this.pageUrl);
  }

}
