import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BreadcrumUrlComponent } from './breadcrum-url.component';

describe('BreadcrumUrlComponent', () => {
  let component: BreadcrumUrlComponent;
  let fixture: ComponentFixture<BreadcrumUrlComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BreadcrumUrlComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(BreadcrumUrlComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
