import { Component, OnInit } from '@angular/core';

import { Router } from '@angular/router';
import { CommonService } from 'src/app/services/common.service';

@Component({
  selector: 'app-stepper',
  templateUrl: './stepper.component.html',
  styleUrls: ['./stepper.component.css']
})
export class StepperComponent implements OnInit {

  urlObj: any;
  stepper: string = '0%';
  isDisplay: boolean = false;
  stepperBStatus: string = '';
  stepperCStatus: string = '';
  stepperDStatus: string = '';
  regObj: any;

  constructor(private rt: Router, private commonService: CommonService) {

    rt.events.subscribe(() => {
      const regex1: any = new RegExp('individual-account');
      const regex2: any = new RegExp('joint-account');
      const regex3: any = new RegExp('minor-accnt');

      if (regex1.test(this.rt.url) || regex2.test(this.rt.url) || regex3.test(this.rt.url)) {
        this.stepperBStatus = 'active';
      } else {
        this.stepperBStatus = 'completed';
      }
      switch (this.rt.url) {
        case '/individual-account/personal-dtls1':
          this.stepper = '11.11%';
          break;
        case '/individual-account/personal-dtls2':
          this.stepper = '11.11%';
          break;
        case '/individual-account/fatca':
          this.stepper = '22.222222%';
          break;
        case '/individual-account/kyc-dtls1':
          this.stepper = '33.333333%';
          break;
        case '/individual-account/kyc-dtls2':
          this.stepper = '33.333333%';
          break;
        case '/individual-account/kyc-dtls3':
          this.stepper = '33.333333%';
          break;
        case '/individual-account/kyc-dtls4':
          this.stepper = '33.333333%';
          break;
        case '/individual-account/contact-details':
          this.stepper = '40.444444%';
          break;
        case '/individual-account/addrs-dtls1':
          this.stepper = '50.555555%';
          break;
        case '/individual-account/addrs-dtls2':
          this.stepper = '55.555555%';
          break;
        case '/individual-account/customer-profile':
          this.stepper = '66.666666%';
          break;
        case '/individual-account/internet-banking':
          this.stepper = '77.7777777%';
          break;
        case '/individual-account/internet-banking2':
          this.stepper = '77.7777777%';
          break;
        case '/individual-account/doc-upload1':
          this.stepper = '80.7777777%';
          break;
        case '/individual-account/doc-identity-proof':
          this.stepper = '80.7777777%';
          break;
        case '/individual-account/doc-address-proof1':
          this.stepper = '80.7777777%';
          break;
        case '/individual-account/doc-address-proof2':
          this.stepper = '80.7777777%';
          break;
        case '/individual-account/doc-address-proof3':
          this.stepper = '80.7777777%';
          break;
        case '/individual-account/doc-fomr60':
          this.stepper = '80.7777777%';
          break;
        case '/individual-account/doc-visa':
          this.stepper = '80.7777777%';
          break;
        case '/individual-account/doc-oci':
          this.stepper = '80.7777777%';
          break;
        case '/individual-account/doc-pio':
          this.stepper = '80.7777777%';
          break;
        case '/individual-account/other-docs-proof':
          this.stepper = '80.7777777%';
          break;
        case '/individual-account/nomination1':
          this.stepper = '88.8888888%';
          break;
        case '/individual-account/nomination2':
          this.stepper = '88.8888888%';
          break;
        case '/individual-account/nomination3':
          this.stepper = '88.8888888%';
          break;
        case '/individual-account/declaration1':
          this.stepper = '99.9999999%';
          break;
        case '/individual-account/declaration2':
          this.stepper = '99.9999999%';
          break;
        case '/individual-account/thanks':
          this.stepper = '99.9999999%';
          break;
        case '/individual-account/ending':
          this.stepper = '99.9999999%';
          break;
        default:
          break;
      }
      switch (this.rt.url) {
        case '/joint-account/applicant-form':
          this.stepper = '11.11%';
          break;
        case '/joint-account/personal-dtls1':
          this.stepper = '11.11%';
          break;
        case '/joint-account/fatca':
          this.stepper = '22.222222%';
          break;
        case '/joint-account/kyc-dtls1':
          this.stepper = '33.333333%';
          break;
        case '/joint-account/kyc-dtls2':
          this.stepper = '33.333333%';
          break;
        case '/joint-account/kyc-dtls3':
          this.stepper = '33.333333%';
          break;
        case '/joint-account/kyc-dtls4':
          this.stepper = '33.333333%';
          break;
        case '/joint-account/contact-details':
          this.stepper = '44.444444%';
          break;
        case '/joint-account/addrs-dtls1':
          this.stepper = '55.555555%';
          break;
        case '/joint-account/addrs-dtls2':
          this.stepper = '55.555555%';
          break;
        case '/joint-account/customer-profile':
          this.stepper = '66.666666%';
          break;
        case '/joint-account/internet-banking':
          this.stepper = '77.7777777%';
          break;
        case '/joint-account/internet-banking2':
          this.stepper = '77.7777777%';
          break;
        case '/joint-account/doc-upload1':
          this.stepper = '80.7777777%';
          break;
        case '/joint-account/doc-identity-proof':
          this.stepper = '80.7777777%';
          break;
        case '/joint-account/doc-address-proof1':
          this.stepper = '80.7777777%';
          break;
        case '/joint-account/doc-address-proof2':
          this.stepper = '80.7777777%';
          break;
        case '/joint-account/doc-address-proof3':
          this.stepper = '80.7777777%';
          break;
        case '/joint-account/doc-fomr60':
          this.stepper = '80.7777777%';
          break;
        case '/joint-account/doc-visa':
          this.stepper = '80.7777777%';
          break;
        case '/joint-account/doc-oci':
          this.stepper = '80.7777777%';
          break;
        case '/joint-account/doc-pio':
          this.stepper = '80.7777777%';
          break;
        case '/joint-account/other-docs-proof':
          this.stepper = '80.7777777%';
          break;
        case '/joint-account/nomination1':
          this.stepper = '88.8888888%';
          break;
        case '/joint-account/nomination2':
          this.stepper = '88.8888888%';
          break;
        case '/joint-account/nomination3':
          this.stepper = '88.8888888%';
          break;
        case '/joint-account/declaration1':
          this.stepper = '99.9999999%';
          break;
        case '/joint-account/declaration2':
          this.stepper = '99.9999999%';
          break;
        case '/joint-account/thanks':
          this.stepper = '99.9999999%';
          break;
        case '/joint-account/ending':
          this.stepper = '99.9999999%';
          break;
        default:
          break;
      }

      switch (this.rt.url) {
        case '/minor-accnt/personal-dtls1-minor':
          this.stepper = '8.11%';
          break;
        case '/minor-accnt/personal-dtls2-minor':
          this.stepper = '12.11%';
          break;
        case '/minor-accnt/kyc-dtls1-minor':
          this.stepper = '16.222222%';
          break;
        case '/minor-accnt/kyc-dtls4-minor':
          this.stepper = '20.222222%';
          break;
        case '/minor-accnt/document-upload1-minor':
          this.stepper = '24.333333%';
          break;
        case '/minor-accnt/guardian-dtls':
          this.stepper = '28.444444%';
          break;
        case '/minor-accnt/personal-dtls1-guardian':
          this.stepper = '32.555555%';
          break;
        case '/minor-accnt/personal-dtls2-guardian':
          this.stepper = '36.555555%';
          break;
        case '/minor-accnt/fatca-guardian':
          this.stepper = '40.666666%';
          break;
        case '/minor-accnt/kyc-dtls1-guardian':
          this.stepper = '44.7777777%';
          break;
        case '/minor-accnt/kyc-dtls4-guardian':
          this.stepper = '48.7777777%';
          break;
        case '/minor-accnt/contact-details-guardian':
          this.stepper = '52.7777777%';
          break;
        case '/minor-accnt/addrs-dtls1-guardian':
          this.stepper = '56.7777777%';
          break;
        case '/minor-accnt/addrs-dtls2-guardian':
          this.stepper = '60.7777777%';
          break;
        case '/minor-accnt/customer-profile-guardian':
          this.stepper = '64.7777777%';
          break;
        case '/minor-accnt/internet-banking1-guardian':
          this.stepper = '68.7777777%';
          break;
        case '/minor-accnt/internet-banking2-guardian':
          this.stepper = '72.7777777%';
          break;
        case '/minor-accnt/nomination1-guardian':
          this.stepper = '74.7777777%';
          break;
        case '/minor-accnt/nomination2-guardian':
          this.stepper = '78.7777777%';
          break;
        case '/minor-accnt/declaration1-guardian':
          this.stepper = '82.7777777%';
          break;
        case '/minor-accnt/document-upload1-guardian':
          this.stepper = '86.7777777%';
          break;
        case '/minor-accnt/doc-address-proof2-guardian':
          this.stepper = '86.7777777%';
          break;
        case '/minor-accnt/declaration2-guardian':
          this.stepper = '95.8888888%';
          break;
        case '/minor-accnt/thanks':
          this.stepper = '99.9999999%';
          break;
        case '/minor-accnt/ending':
          this.stepper = '99.9999999%';
          break;
        default:
          break;
      }

      this.isDisplay = regex1.test(this.rt.url) || regex2.test(this.rt.url) || regex3.test(this.rt.url);

      const feedbackRegex = new RegExp('feedback');

      if (feedbackRegex.test(this.rt.url)) {
        this.stepperCStatus = 'active';
      } else {
        if(window.location.href.split('/')?.includes('rejected-page')){
          this.stepperCStatus = 'completed';
          this.stepper ='100%';
        }  else {
          this.stepperCStatus = '';
        }
      }

      let strip = this.rt.url
      switch (strip) {
        case "/feedback/feedback-summary":
          this.isDisplay = true;
          break;
        default:
          break;
      }

      this.isDisplay = regex1.test(this.rt.url) || regex2.test(this.rt.url) || regex3.test(this.rt.url);
      const approvedRegex = new RegExp('rejected-page');
      
      if (approvedRegex.test(this.rt.url)) {
        this.stepperDStatus = 'active';
      } else {
        this.stepperDStatus = '';
      }

      let approved = this.rt.url
      switch (approved) {
        case "/rejected-page":
          this.isDisplay = true;
          break;
        default:
          break;
      }


      // if (this.rt.url === '/individual-account/personal-dtls1') {
      //   this.stepper = '11.11%';
      // }
    })
  }

  ngOnInit(): void {
    // this.regObj = this.commonService.getUserFromLocalStorage().leadReviewStatus
    // if(this.regObj == 'agent_review'){
    //   this.stepper = '88.8888888%';
    //   console.log("check",this.regObj);
    // }
  }
}