import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { CommonService } from '../../services/common.service';
import { CustomerDataService } from 'src/app/services/customer-data.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  loginVerifyEmail: any;
  emailVerifyOTP: any;
  iSsubmitEmail: Boolean = false;
  regObj: any;
  contentUrlClss: string = '';
  display: string = "none";
  loginFailedErr: String = '';
  isErrorEmail: boolean = false;
  constructor(private fb: FormBuilder, private commonService: CommonService, private rt: Router, private customerDataService: CustomerDataService) {

  }

  ngOnInit(): void {


    if (this.customerDataService.checkCustomerLoginAuth() === true) {
      this.rt.navigate(['/country'])
    }

    this.loginVerifyEmail = this.fb.group({
      email: ['', [Validators.required, Validators.pattern(/^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z]{2,4})+$/)]]
    });


    this.emailVerifyOTP = this.fb.group({
      verifyCode: ['', [Validators.required, Validators.maxLength(6), Validators.pattern(/[0-9]{6}/)]]
    })

    this.contentUrlClss = `content page_${String(this.rt.url).replace(/[\/]/, '')}`;
    console.log("This ispage name", this.contentUrlClss)
  }


  get email() { return this.loginVerifyEmail.get("email") }

  get verifyCode() { return this.emailVerifyOTP.get("verifyCode") }

  validateOTP(event: any) {
    return this.commonService.enterOnlyNumber(event);
  }

  sendEmailVerifyCode() {
    if (this.loginVerifyEmail.valid) {


      this.customerDataService.generateEmailOTP('', 'customer' + this.rt.url, this.loginVerifyEmail.get("email").value).subscribe((data: any) => {
        console.log("This is generate email OTP", data);

        this.iSsubmitEmail = true;

        this.loginFailedErr = data?.msg;
        //this.openModal();
        // alert(data?.msg)

      }, (err) => {

        if (err?.status === 401 && err?.error?.msg === "User not found for this email") {
          this.loginFailedErr = "User not found";
          alert("This email address does not exists");
          //this.openModal();
          this.iSsubmitEmail = false;
          //User not found for this email
        } else if (err?.status === 401 && err?.error?.msg === "Otp already send please try again 2 minutes") {
          this.iSsubmitEmail = true;
        }

      })
    } else {
      this.iSsubmitEmail = false;
    }
  }

  sendEmailOTP() {
    this.customerDataService.emailVerifyOTP(this.loginVerifyEmail.get("email").value, Number(this.emailVerifyOTP.get("verifyCode").value), 'customer' + this.rt.url).subscribe((data) => {
      console.log("THis verified", data);

      this.commonService.storeInLocalStorage('registerData', data?.user);
      console.log('THis is lead status-----------------------------------', data?.lead_status);
      this.commonService.storeInLocalStorage('registerData', { 'applicant_id': data?.applicant_id, 'current_process_id': data?.current_process_id, 'account_type': data?.account_type, isFormCompleted: data?.is_completed, leadReviewStatus: data?.lead_status,nomination_id:data.nomination_id });

      this.regObj = this.commonService.getUserFromLocalStorageLogin();
      if (data?.user_email_verify == null || data?.user_mobile_verify == null) {
        this.rt.navigate(["/"]);
      }
      if (data?.lead_status == "agent_process") {
        // alert(data?.lead_status);
        this.rt.navigate(['/individual-account', 'ending']);
      } else if (data?.lead_status == "agent_review") {
        alert(data?.lead_status);
        this.rt.navigate(['/feedback', 'feedback-summary'])
      } else if (data?.lead_status == "approved") {
        alert(data?.lead_status);
        this.rt.navigate(['/rejected-page']);
      } else {
        switch (data?.current_process_id) {
          case 2:
            this.rt.navigate(["/account"])
            break;
          case 3:
            this.rt.navigate(['/individual-account', 'personal-dtls1'])
            break;
          case 4:
            this.rt.navigate(['/individual-account', 'personal-dtls1'])
            break;
          case 5:
            this.rt.navigate(['/individual-account', 'personal-dtls2'])
            break;
          case 6:
            this.rt.navigate(['/individual-account', 'fatca'])
            break;
          case 7:
            this.rt.navigate(['/individual-account', 'kyc-dtls1'])
            break;
          case 8:
            this.rt.navigate(['/individual-account', 'kyc-dtls2'])
            break;
          case 9:
            this.rt.navigate(['/individual-account', 'kyc-dtls3'])
            break;
          case 10:
            this.rt.navigate(['/individual-account', 'kyc-dtls4'])
            break;
          case 11:
            this.rt.navigate(['/individual-account', 'contact-details'])
            break;
          case 12:
            this.rt.navigate(['/individual-account', 'addrs-dtls1'])
            break;
          case 13:
            this.rt.navigate(['/individual-account', 'addrs-dtls2'])
            break;
          case 14:
            this.rt.navigate(['/individual-account', 'customer-profile'])
            break;
          case 15:
            this.rt.navigate(['/individual-account', 'internet-banking'])
            break;
          case 16:
            this.rt.navigate(['/individual-account', 'internet-banking2'])
            break;
          case 25:
            this.rt.navigate(['/individual-account', 'nomination1'])
            break;
          case 26:
            this.rt.navigate(['/individual-account', 'nomination2'])
            break;
          case 27:
            this.rt.navigate(['/individual-account', 'nomination3'])
            break;
          case 28:
            this.rt.navigate(['/individual-account', 'declaration1'])
            break;
          case 29:
            this.rt.navigate(['/individual-account', 'declaration2'])
            break;
          case 30:
            this.rt.navigate(['/individual-account', 'thanks'])
            break;
          case 31:
            this.rt.navigate(['/individual-account', 'ending'])
            break;

          default:
            this.rt.navigate(["/country"]);
            break;
        }
      }
      // console.log('Login all data',data);

      // if () {

      // }

      // if (data?.current_process_id === 1) {
      //   this.rt.navigate(["/country"])
      // }

      /*
      
       {
        "process_id": 28,
        "form_number": "9.2",
        "form_name": "Declaration Final Submit(1)"
    },
    {
        "process_id": 29,
        "form_number": "9.2.1",
        "form_name": "Declaration Final Submit(2)"
    },
    {
        "process_id": 30,
        "form_number": "10",
        "form_name": "Form Submit"
      */

    }, (err) => {
      if (err?.status === 401) {
        alert(err?.error?.msg)
        this.loginFailedErr = err?.error?.msg;
        //this.openModal();
      }
    })
  }

  verifyEmail() {

    //this.openModal()
    console.log("This is loging")
    this.regObj = this.commonService.getUserFromLocalStorageLogin();
    console.log("This Obj", this.regObj?.user_id);

    this.customerDataService.generateEmailOTP(this.regObj?.user_id, "email", this.loginVerifyEmail.get("email").value).subscribe((data) => {
      console.log("THis verified", data);

    }, (err) => {
      alert(err?.error?.msg);
      this.loginFailedErr = err?.error?.msg;
      //this.openModal();
    })
  }

  //For state management set Customer data in localstorage
  setUserInLocalStorage(customerState: any) {
    console.log("??????????", customerState)
    localStorage.setItem('registerData', JSON.stringify(customerState));
  }

  openModal() {
    this.display = "block";
  }
  onCloseHandled() {
    this.display = "none";
  }
}