import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ThankPersonComponent } from './thank-person.component';

describe('ThankPersonComponent', () => {
  let component: ThankPersonComponent;
  let fixture: ComponentFixture<ThankPersonComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ThankPersonComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ThankPersonComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
