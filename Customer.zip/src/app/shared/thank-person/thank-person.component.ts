import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CommonService } from 'src/app/services/common.service';
import { CustomerDataService } from 'src/app/services/customer-data.service';

@Component({
  selector: 'app-thank-person',
  templateUrl: './thank-person.component.html',
  styleUrls: ['./thank-person.component.css']
})
export class ThankPersonComponent implements OnInit {
  regObj: any;
  isSubmitted: boolean = true;
  is_loading: boolean = false;

  constructor(private rt: Router, private commonService: CommonService, private customerDataService: CustomerDataService) { }

  userName: string = '';


  ngOnInit(): void {

    this.regObj = this.commonService.getUserFromLocalStorage();

    if ((this.regObj.isSubmitted != undefined && this.regObj.isSubmitted != 0) || (this.regObj.leadReviewStatus != undefined && this.regObj.leadReviewStatus != "customer_process")) {
      this.rt.navigate(["/individual-account", "ending"]);
    }

    // if(this.regObj.isSubmitted!=undefined)
    // {
    //   this.rt.navigate(["/individual-account","ending"]);
    // }

    let Obj = {
      user_id: this.regObj.user_id,
    }

    this.customerDataService.fetchFirstApplicantName(Obj).subscribe((res) => {
      // console.log("Applicant name", res.result[0].applicant_name);
      this.userName = res.result[0].applicant_name
    })


  }

  redirectEnding() {
    this.is_loading = true;
    let Obj = {
      user_id: this.commonService.getUserFromLocalStorage()?.user_id
    }
    
    this.customerDataService.postLeadSubmit(Obj).subscribe((value) => {
      this.commonService.storeInLocalStorage('registerData', { isSubmitted: true })
      this.is_loading = false;
      this.rt.navigate(['/individual-account', 'ending']);
      // this.rt.navigate(['/minor-accnt','ending']);
    })
    // if (this.commonService.getUserFromLocalStorage()?.user_id){
    //   this.rt.navigate(['/minor-accnt','ending']);
    // }
  }
}