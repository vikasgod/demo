import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Nomination2GuardianComponent } from './nomination2-guardian.component';

describe('Nomination2GuardianComponent', () => {
  let component: Nomination2GuardianComponent;
  let fixture: ComponentFixture<Nomination2GuardianComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ Nomination2GuardianComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(Nomination2GuardianComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
