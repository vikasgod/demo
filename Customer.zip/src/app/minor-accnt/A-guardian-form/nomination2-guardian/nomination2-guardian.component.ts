import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { CommonService } from 'src/app/services/common.service';
import { CustomerDataService } from 'src/app/services/customer-data.service';

@Component({
  selector: 'app-nomination2-guardian',
  templateUrl: './nomination2-guardian.component.html',
  styleUrls: ['./nomination2-guardian.component.css']
})
export class Nomination2GuardianComponent implements OnInit {
  countryData: any;
  nominationBFrom: any;
  currentDate: any;
  startDate = new Date(1990, 0, 1);
  regObj: any;
  titleArrData: any;
  ageInYears: string = '';
  ageInMonths: string = '';
  ageInDays: string = '';
  isDisplayAge: boolean = false;
  current_address: any;
  age: any;
  isDisplayUpdateBtn: boolean = false;
  relation = [
    { value: 'father', name: 'Father' },
    { value: 'mother', name: 'mother' },
    { value: 'brother', name: 'Brother' },
    { value: 'sister', name: 'Sister' },
    { value: 'spouse', name: 'Spouse' },
    { value: 'son', name: 'Son' },
    { value: 'daughter', name: 'Daughter' }
  ]

  constructor(private fb: FormBuilder, private commonService: CommonService, private customerDataService: CustomerDataService, private rt: Router) { }

  ngOnInit(): void {
    this.regObj = this.commonService.getUserFromLocalStorage();
    // if ((this.regObj.isSubmitted != undefined && this.regObj.isSubmitted != 0)
    //   || ((this.regObj.leadReviewStatus != undefined && this.regObj.leadReviewStatus != "customer_process")
    //     && (this.regObj.leadReviewStatus != undefined && this.regObj.leadReviewStatus != "agent_review"))
    // ) {
    //   this.rt.navigate(["/minor-accnt", "ending"]);
    // }
    // else if (this.regObj.isNominationSelected != undefined && this.regObj.isNominationSelected == 0) {
    //   this.rt.navigate(["/minor-accnt", "doc-upload1"]);
    // }
    // if (this.commonService.getUserFromLocalStorage()?.leadReviewStatus === undefined) {
    //   this.isDisplayUpdateBtn = false;
    // } 
    // else {
    //   this.isDisplayUpdateBtn = true;
    // }

    let Obj = {
      applicant_id: this.regObj.guardianApplicantID,
      process_id: 53
    }

    
    this.customerDataService.fetchAddressDtls1(Obj).subscribe((value) => {
      if (value?.data?.length > 0) {
        this.current_address = value.data[0];
        this.patchData();
      }});

    this.nominationBFrom = this.fb.group({
      nominationBtitle: ['', [Validators.required]],
      nominationBFirstName: ['', [Validators.required, Validators.minLength(2)]],
      nominationBMiddleName: [''],
      nominationBLastName: [''],
      sameascurrentaddress: [],
      nominationBAaddrsHuseNo: ['', [Validators.required, Validators.minLength(2)]],
      nominationBAaddrsBuldNm: ['', [Validators.required, Validators.minLength(2)]],
      nominationBAaddrsRdNm: ['', [Validators.required, Validators.minLength(2)]],
      nominationBAaddrsLndMrk: ['', [Validators.required, Validators.minLength(2)]],
      nominationBAaddrsCntry: ['', [Validators.required]],
      nominationBAaddrsState: ['', [Validators.required, Validators.minLength(2)]],
      nominationBAaddrsCity: ['', [Validators.required, Validators.minLength(2)]],
      nominationBAaddrsPnCd: ['', [Validators.required, Validators.pattern(/^[A-Za-z0-9\s]*$/)]],
      nominationBReltnDepositor: ['', [Validators.required]],
      nominationDOB: ['', [Validators.required]],
    })

    this.currentDate = this.commonService.getCurrentDate();
    this.customerDataService.getCountry().subscribe((data) => {
      this.countryData = data;
    })

    this.customerDataService.getTitle().subscribe((data) => {
      this.titleArrData = data
    })

    // this.sameasAddress()
  }

  patchData(){

    

    let Obj1 = {
      applicant_id: this.regObj.guardianApplicantID,
      process_id: 68,
      nomination_id: this?.regObj?.nomination_id,
    }

    this.customerDataService.fetchNomination2(Obj1).subscribe((value) => {
      // console.log("This i nomination 3", value);
      if (value?.data?.length > 0) {
        this.isDisplayUpdateBtn = true;
        this.nominationBFrom = this.fb.group({
          nominationBtitle: [value?.data?.[0]?.nominee_title, [Validators.required]],
          nominationBFirstName: [value?.data?.[0]?.nominee_first_name, [Validators.required]],
          nominationBMiddleName: [value?.data?.[0]?.nominee_middle_name],
          nominationBLastName: [value?.data?.[0]?.nominee_last_name],
          sameascurrentaddress: [],
          nominationBAaddrsHuseNo: [value?.data?.[0]?.nominee_house_number, [Validators.required]],
          nominationBAaddrsBuldNm: [value?.data?.[0]?.nominee_house_or_building_name, [Validators.required]],
          nominationBAaddrsRdNm: [value?.data?.[0]?.nominee_road_or_street_name, [Validators.required]],
          nominationBAaddrsLndMrk: [value?.data?.[0]?.nominee_landkmark, [Validators.required]],
          nominationBAaddrsCntry: [value?.data?.[0]?.nominee_country_id==0?"":value?.data?.[0]?.nominee_country_id, [Validators.required]],
          nominationBAaddrsState: [value?.data?.[0]?.nominee_state, [Validators.required]],
          nominationBAaddrsCity: [value?.data?.[0]?.nominee_city, [Validators.required]],
          nominationBAaddrsPnCd: [value?.data?.[0]?.nominee_pincode, [Validators.required, Validators.pattern(/^[A-Za-z0-9\s]*$/)]],
          nominationBReltnDepositor: [value?.data?.[0]?.relationship, [Validators.required]],
          nominationDOB: [value?.data?.[0]?.nominee_date_of_birth, [Validators.required]],
        })
        this.nominationBFrom.controls['sameascurrentaddress'].setValue(this.sameasAddress())
        //On Page load get Age on basis of Birth Date  
        this.getNominationAge(value?.data?.[0]?.nominee_date_of_birth);
      }
    })


  }

  get nominationBtitle() { return this.nominationBFrom.get("nominationBtitle") }
  get nominationBFirstName() { return this.nominationBFrom.get("nominationBFirstName") }
  get nominationBMiddleName() { return this.nominationBFrom.get("nominationBMiddleName") }
  get nominationBLastName() { return this.nominationBFrom.get("nominationBLastName") }
  get nominationBAaddrsType() { return this.nominationBFrom.get("nominationBAaddrsType") }
  get nominationBAaddrsHuseNo() { return this.nominationBFrom.get("nominationBAaddrsHuseNo") }
  get nominationBAaddrsBuldNm() { return this.nominationBFrom.get("nominationBAaddrsBuldNm") }
  get nominationBAaddrsRdNm() { return this.nominationBFrom.get("nominationBAaddrsRdNm") }
  get nominationBAaddrsLndMrk() { return this.nominationBFrom.get("nominationBAaddrsLndMrk") }
  get nominationBAaddrsCntry() { return this.nominationBFrom.get("nominationBAaddrsCntry") }
  get nominationBAaddrsState() { return this.nominationBFrom.get("nominationBAaddrsState") }
  get nominationBAaddrsCity() { return this.nominationBFrom.get("nominationBAaddrsCity") }
  get nominationBAaddrsPnCd() { return this.nominationBFrom.get("nominationBAaddrsPnCd") }
  get nominationBReltnDepositor() { return this.nominationBFrom.get("nominationBReltnDepositor") }
  get nominationDOB() { return this.nominationBFrom.get("nominationDOB") }

  keypressAlphabetNoSpce(event: any) {
    return this.commonService.enterOnlyAlphabetsNoSpace(event)
  }

  keypressAlphabets(event: any) {
    return this.commonService.enterOnlyAlphabetsSpaceNBcktck(event);
    //return this.commonService.enterOnlyAlphabets(event);
  }

  keypressNumber(event: any) {
    return this.commonService.enterOnlyNumber(event);
  }

  checkSpecialChar(event: any) {
    return this.commonService.keypressSpecialChar(event)
  }

  onChangeDate(event: any) {
    this.getNominationAge(event.target.value);
  }

  getNominationAge(age: any) {
    //Get Age in Obj years,months and days
    this.age = this.commonService.getAge(age)
    this.ageInYears = this.age.years;
    this.ageInMonths = this.age.months;
    this.ageInDays = this.age.days;
    //Get Store Age in Obj years,months and days
    this.commonService.storeInLocalStorage('registerData', { nomineeAgeYears: this.ageInYears, nomineeAgeMonths: this.ageInMonths })
  }

  submitNomination() {
    if (this.nominationBFrom.valid) {
      this.regObj = this.commonService.getUserFromLocalStorage();
      //console.log("This Obj", this.regObj.guardianApplicantID);
      let Obj = {
        applicant_id: Number(this.regObj.guardianApplicantID),
        process_id: 68,
        nomination_id: Number(this.regObj.nomination_id),
        nominee_title: this.nominationBFrom.get("nominationBtitle").value,
        nominee_first_name: this.nominationBFrom.get("nominationBFirstName").value,
        nominee_middle_name: this.nominationBFrom.get("nominationBMiddleName").value,
        nominee_last_name: this.nominationBFrom.get("nominationBLastName").value,
        nominee_house_number: this.nominationBFrom.get("nominationBAaddrsHuseNo").value,
        nominee_house_or_building_name: this.nominationBFrom.get("nominationBAaddrsBuldNm").value,
        nominee_road_or_street_name: this.nominationBFrom.get("nominationBAaddrsRdNm").value,
        nominee_state: this.nominationBFrom.get("nominationBAaddrsState").value,
        nominee_city: this.nominationBFrom.get("nominationBAaddrsCity").value,
        nominee_landkmark: this.nominationBFrom.get("nominationBAaddrsLndMrk").value,
        nominee_country_id: Number(this.nominationBFrom.get("nominationBAaddrsCntry").value),
        nominee_pincode: this.nominationBFrom.get("nominationBAaddrsPnCd").value,
        relationship: this.nominationBFrom.get("nominationBReltnDepositor").value,
        nominee_date_of_birth: this.customerDataService.formatDob(this.nominationBFrom.get("nominationDOB").value)
      }

      this.customerDataService.postNomination2(Obj).subscribe((data) => {
        // console.log("This is nomination id", data)
        if (this.commonService.getUserFromLocalStorage()?.leadReviewStatus == 'customer_process') {
          // this.rt.navigate(["/feedback", "feedback-summary"]);
          this.rt.navigate(['/minor-accnt', 'document-upload1-guardian']);
        }
        else if (this.commonService.getUserFromLocalStorage()?.leadReviewStatus == 'agent_review') {
          this.rt.navigate(["/feedback", "feedback-summary"]);
        }
        if (Number(this.ageInYears) < 18) {
          this.rt.navigate(['/minor-accnt', 'nomination3-guardian']);
        }
        var is_feedback_show = 0;
        // if (this.commonService.getUserFromLocalStorage()?.leadReviewStatus != undefined) {
        //   if (this.commonService.getUserFromLocalStorage()?.leadReviewStatus != 'customer_process') {
        //     is_feedback_show += 1;
        //   }
        // }

        // if (is_feedback_show != 0) {
        //   this.rt.navigate(["/feedback", "feedback-summary"]);
        // } 
        // else {
        //   if (Number(this.ageInYears) < 18) {
        //     this.rt.navigate(['/minor-accnt', 'nomination3-guardian']);
        //   } 
        // else {
        //   this.rt.navigate(['/minor-accnt', 'declaration1-guardian']);
        // }
        // }
        // if(Number(this.ageInYears)<18)
        // {
        // else{
        //   this.rt.navigate(['/minor-accnt', 'nomination3-guardian']);  
        // }  
        // }else
        // {
        //   this.rt.navigate(['/minor-accnt','declaration1-guardian']);
        // }

        //this.rt.navigate(['/minor-accnt', 'nomination3-guardian']);
      })
    }
    else {
      console.log("This is invalid value");
    }
  }

  setOverseaData() {
    if (this.nominationBFrom.value.sameascurrentaddress == true) {
      this.nominationBFrom.controls['nominationBAaddrsHuseNo'].setValue( this.current_address?.current_house_number)
      this.nominationBFrom.controls['nominationBAaddrsBuldNm'].setValue(this.current_address?.current_house_or_building_name)
      this.nominationBFrom.controls['nominationBAaddrsRdNm'].setValue(this.current_address?.current_road_or_street_name)
      this.nominationBFrom.controls['nominationBAaddrsLndMrk'].setValue(this.current_address?.current_landmark)
      this.nominationBFrom.controls['nominationBAaddrsCntry'].setValue(this.current_address?.current_country_id)
      this.nominationBFrom.controls['nominationBAaddrsState'].setValue(this.current_address?.current_state)
      this.nominationBFrom.controls['nominationBAaddrsCity'].setValue(this.current_address?.current_city)
      this.nominationBFrom.controls['nominationBAaddrsPnCd'].setValue(this.current_address?.current_pincode)

      this.nominationBFrom.controls['nominationBAaddrsHuseNo'].disable()
      this.nominationBFrom.controls['nominationBAaddrsBuldNm'].disable()
      this.nominationBFrom.controls['nominationBAaddrsRdNm'].disable()
      this.nominationBFrom.controls['nominationBAaddrsLndMrk'].disable()
      this.nominationBFrom.controls['nominationBAaddrsCntry'].disable()
      this.nominationBFrom.controls['nominationBAaddrsState'].disable()
      this.nominationBFrom.controls['nominationBAaddrsCity'].disable()
      this.nominationBFrom.controls['nominationBAaddrsPnCd'].disable()

    }
    else {
      this.nominationBFrom.controls['nominationBAaddrsHuseNo'].setValue('')
      this.nominationBFrom.controls['nominationBAaddrsBuldNm'].setValue('')
      this.nominationBFrom.controls['nominationBAaddrsRdNm'].setValue('')
      this.nominationBFrom.controls['nominationBAaddrsLndMrk'].setValue('')
      this.nominationBFrom.controls['nominationBAaddrsCntry'].setValue('')
      this.nominationBFrom.controls['nominationBAaddrsState'].setValue('')
      this.nominationBFrom.controls['nominationBAaddrsCity'].setValue('')
      this.nominationBFrom.controls['nominationBAaddrsPnCd'].setValue('')

      this.nominationBFrom.controls['nominationBAaddrsHuseNo'].enable()
      this.nominationBFrom.controls['nominationBAaddrsBuldNm'].enable()
      this.nominationBFrom.controls['nominationBAaddrsRdNm'].enable()
      this.nominationBFrom.controls['nominationBAaddrsLndMrk'].enable()
      this.nominationBFrom.controls['nominationBAaddrsCntry'].enable()
      this.nominationBFrom.controls['nominationBAaddrsState'].enable()
      this.nominationBFrom.controls['nominationBAaddrsCity'].enable()
      this.nominationBFrom.controls['nominationBAaddrsPnCd'].enable()
    }
  }

  sameasAddress(){
    if(this.nominationBFrom.controls['nominationBAaddrsHuseNo'].value ==  this.current_address?.current_house_number && 
    this.nominationBFrom.controls['nominationBAaddrsBuldNm'].value == this.current_address?.current_house_or_building_name &&
    this.nominationBFrom.controls['nominationBAaddrsRdNm'].value == this.current_address?.current_road_or_street_name &&
    this.nominationBFrom.controls['nominationBAaddrsLndMrk'].value == this.current_address?.current_landmark &&
    this.nominationBFrom.controls['nominationBAaddrsCntry'].value == this.current_address?.current_country_id &&
    this.nominationBFrom.controls['nominationBAaddrsState'].value == this.current_address?.current_state &&
    this.nominationBFrom.controls['nominationBAaddrsCity'].value == this.current_address?.current_city &&
    this.nominationBFrom.controls['nominationBAaddrsPnCd'].value == this.current_address?.current_pincode){
      return true
    }
    else{
      return false
    }
  }
}