import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Nomination1GuardianComponent } from './nomination1-guardian.component';

describe('Nomination1GuardianComponent', () => {
  let component: Nomination1GuardianComponent;
  let fixture: ComponentFixture<Nomination1GuardianComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ Nomination1GuardianComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(Nomination1GuardianComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
