import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { CommonService } from 'src/app/services/common.service';
import { CustomerDataService } from 'src/app/services/customer-data.service';

@Component({
  selector: 'app-nomination1-guardian',
  templateUrl: './nomination1-guardian.component.html',
  styleUrls: ['./nomination1-guardian.component.css']
})
export class Nomination1GuardianComponent implements OnInit {

  nominationGuardianAFrom: any;
  regObj: any;
  nomination_id: any;
  isFacility: boolean = false;

  isDisplayUpdateBtn: boolean = false;
  constructor(private fb: FormBuilder, private commonService: CommonService, private customerDataService: CustomerDataService, private rt: Router) { }

  ngOnInit(): void {
    this.regObj = this.commonService.getUserFromLocalStorage();
    if (this.regObj.isSubmited || this.regObj.leadReviewStatus != "customer_process") {
      this.rt.navigate(["/minor-accnt", "ending"]);
    }


    // if (this.commonService.getUserFromLocalStorage()?.leadReviewStatus === undefined) {
    //   this.isDisplayUpdateBtn = false;
    // } 
    // else {
    //   this.isDisplayUpdateBtn = true;
    // }

    this.nominationGuardianAFrom = this.fb.group({
      nominationAFacility: ['', [Validators.required]]
    })

    let Obj = {
      applicant_id: this.commonService.getUserFromLocalStorage()?.guardianApplicantID,
      process_id: 67,
      nomination_id: this?.regObj?.nomination_id,
    }

   

    this.customerDataService.fetchNomination1(Obj).subscribe((value) => {
      if(value.data.length > 0){
        this.isDisplayUpdateBtn = true;
      }

      this.nominationGuardianAFrom = this.fb.group({
        nominationAFacility: [String(value?.data?.[0]?.is_opted), [Validators.required]]
      })
      console.log(this.nominationGuardianAFrom.value, value?.data?.[0]?.is_opted);
    })
  }


  get nominationAFacility() { return this.nominationGuardianAFrom.get("nominationAFacility") }

  submitNomination1Guardian() {
    if (this.nominationGuardianAFrom.valid) {
      this.regObj = this.commonService.getUserFromLocalStorage();
      let Obj = {
        applicant_id: this.commonService.getUserFromLocalStorage()?.guardianApplicantID,
        applicant_personal_id: this.commonService.getUserFromLocalStorage()?.guardianApplicantID,
        applicant_serial_num: this.commonService.getUserFromLocalStorage()?.applicantSerialNum,
        user_id: this.regObj?.user_id,
        process_id: 67,
        nomination_id: this?.regObj?.nomination_id,
        is_opted: Number(this.nominationGuardianAFrom.get("nominationAFacility").value)
      }

      
      this.customerDataService.postNomination1(Obj).subscribe((data) => {
        this.commonService.storeInLocalStorage('registerData', { 'nomination_id': data?.nomination_id })
        var is_feedback_show = 0;
        if (this.commonService.getUserFromLocalStorage()?.leadReviewStatus != undefined) {
          if (this.commonService.getUserFromLocalStorage()?.leadReviewStatus != 'customer_process') {
            is_feedback_show += 1;
          }
          if (is_feedback_show != 0) {
            this.rt.navigate(["/feedback", "feedback-summary"]);
          } 
          // else {
          //   this.rt.navigate(["/minor-accnt", "nomination2"]);
          // }
  
          if (this.nominationGuardianAFrom.controls['nominationAFacility'].value == 1) {
            this.rt.navigate(['/minor-accnt','nomination2-guardian']);
            console.log("1");
          } 
          else if(this.nominationGuardianAFrom.controls['nominationAFacility'].value == 0) {
            this.rt.navigate(['/minor-accnt','document-upload1-guardian']);
          }
        }
      })
    } 
    else {
      console.log("This is invalid value");
    }
  }

}
