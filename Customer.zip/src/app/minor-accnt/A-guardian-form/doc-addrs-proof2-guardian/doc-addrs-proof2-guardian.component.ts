import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CommonService } from 'src/app/services/common.service';
import { CustomerDataService } from 'src/app/services/customer-data.service';

@Component({
  selector: 'app-doc-addrs-proof2-guardian',
  templateUrl: './doc-addrs-proof2-guardian.component.html',
  styleUrls: ['./doc-addrs-proof2-guardian.component.css']
})
export class DocAddrsProof2GuardianComponent implements OnInit {

  constructor(private rt: Router, private commonService: CommonService, private customerDataService: CustomerDataService) { }
  isRelativeForm=false;

  documentName: string = '';
  documentIndentificationNumber: string = '';

  ngOnInit(): void {

    let Obj = {
      applicant_id: this.commonService.getUserFromLocalStorage()?.guardianApplicantID,


      document: "address_proof"
    }

    this.customerDataService.fetchGetDoc(Obj).subscribe((value) => {
      console.log('This is value', value);

      this.documentName = value?.[0]?.address_proof_types_name;
      this.documentIndentificationNumber = value?.[0]?.document_identification_number;
      this.isRelativeForm = value?.[0]?.kyc_poi.is_family_indian_by_virtue || value?.[0]?.kyc_poi.is_spouse_held_indian_passport || value?.[0]?.kyc_poi.is_spouse_family_indian_by_virtue

    });

  }

  redirect() {
    if (this.isRelativeForm) {
      this.rt.navigate(['minor-accnt', 'doc-address-proof3-guardian'])

    } else {
      this.rt.navigate(['/minor-accnt', 'document-upload1-guardian']);
    }


  }

}
