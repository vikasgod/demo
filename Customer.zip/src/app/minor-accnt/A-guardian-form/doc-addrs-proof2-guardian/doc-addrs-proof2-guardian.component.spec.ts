import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DocAddrsProof2GuardianComponent } from './doc-addrs-proof2-guardian.component';

describe('DocAddrsProof2GuardianComponent', () => {
  let component: DocAddrsProof2GuardianComponent;
  let fixture: ComponentFixture<DocAddrsProof2GuardianComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DocAddrsProof2GuardianComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DocAddrsProof2GuardianComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
