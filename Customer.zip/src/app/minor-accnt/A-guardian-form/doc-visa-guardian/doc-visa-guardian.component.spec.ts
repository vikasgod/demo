import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DocVisaGuardianComponent } from './doc-visa-guardian.component';

describe('DocVisaGuardianComponent', () => {
  let component: DocVisaGuardianComponent;
  let fixture: ComponentFixture<DocVisaGuardianComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DocVisaGuardianComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DocVisaGuardianComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
