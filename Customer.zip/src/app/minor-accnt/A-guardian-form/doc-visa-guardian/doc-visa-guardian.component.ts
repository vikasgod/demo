import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { CommonService } from 'src/app/services/common.service';
import { CustomerDataService } from 'src/app/services/customer-data.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-doc-visa-guardian',
  templateUrl: './doc-visa-guardian.component.html',
  styleUrls: ['./doc-visa-guardian.component.css']
})
export class DocVisaGuardianComponent implements OnInit {
  requiredFileType: string = 'image/png,image/jpeg'
  docVisaFrom: any;
  iSfile1Change: boolean = false;
  errFileExtension: boolean = true;
  imgSrc: any = '';
  fileDataStr1: any = '';
  fileName1: string = '';
  regObj: any;
  imgSrc1: string = '';

  docVisaErr: string = '';

  display: string = "none";
  isUpdate: boolean = false

  constructor(private fb: FormBuilder, private commonService: CommonService, private customerDataService: CustomerDataService, private rt: Router) {
    this.getDoc()
  }

  ngOnInit(): void {
    this.regObj = this.commonService.getUserFromLocalStorage();
    if ((this.regObj.isSubmitted != undefined && this.regObj.isSubmitted != 0)
      || ((this.regObj.leadReviewStatus != undefined && this.regObj.leadReviewStatus != "customer_process")
        && (this.regObj.leadReviewStatus != undefined && this.regObj.leadReviewStatus != "agent_review"))
    ) {

      this.rt.navigate(["/individual-account", "ending"]);
    }

    this.docVisaFrom = this.fb.group({
      docVisaFile1: ['', [Validators.required]]
    })

    this.getDoc()

    /*
    {
    "applicant_id":5,
    "document":"old_indian_passport_front"
}
    */
    //console.log('This is image base64',this.img1);
  }

  getDoc() {
    let Obj = {
      applicant_id: this.commonService.getUserFromLocalStorage()?.guardianApplicantID,
      document: "visa"
    }

    this.customerDataService.fetchGetDoc(Obj).subscribe((value) => {
      if (value != undefined) {
        this.isUpdate = true
      }
      this.imgSrc1 = value?.file_path;
      this.fileName1 = value?.file_path.split('/').pop()
      this.customerDataService.getBase64ImageFromUrl(value.file_path).then(result => {
        this.fileDataStr1 = result
      })
        .catch(err => console.error(err));
      this.docVisaFrom.get('docVisaFile1').setValue(this.fileName1);
    })
  }

  get docVisaFile1() { return this.docVisaFrom.get("docVisaFile1") }

  //Working 1  
  onFilesSelected1(event: any) {

    this.iSfile1Change = true;
    let fileData = event.target.files[0];

    if (fileData != undefined) {
      this.fileName1 = fileData.name;
      let arr = String(fileData.name).split('.');
      let len = arr.length;

      if (fileData.size <= 5000000) {
        if (arr[len - 1] === "png" || arr[len - 1] === "jpeg" || arr[len - 1] === "jpg") {
          const reader = new FileReader();
          reader.onloadend = () => {
            this.imgSrc1 = String(reader.result)
            // Use a regex to remove data url part
            const base64String = String(reader.result)
              .replace('data:', '')
              .replace(/^.+,/, '');
            this.fileDataStr1 = base64String;
            //console.log("THis is file1 base64 string",base64String);
          };
          reader.readAsDataURL(fileData);
        }
        else {
          this.errFileExtension = false;
          console.log("Extension is not valid")
          //return
        }
      }
      else {
        this.fileName1 = '';
        this.docVisaFrom.get('docVisaFile1').setValue('');
        this.docVisaErr = 'File size exceeds 5mb'
        this.openModal();
      }
    }
    else{
      return
    }
    //return
  }

  openModal() {
    this.display = "block";
  }

  onCloseHandled() {
    this.display = "none";
  }

  submitVisa() {
    this.regObj = this.commonService.getUserFromLocalStorage();
    // if(this.regObj.isSubmitted!=undefined || this.regObj.leadReviewStatus != "customer_process")
    // {
    //   this.rt.navigate(["/minor-accnt","ending"]);
    // }

    let Obj = {
      applicant_id: this.regObj.guardianApplicantID,
      process_id: 64,
      file: this.fileDataStr1,
    }

    this.customerDataService.postCustomerVisaDoc(Obj).subscribe((data) => {
      this.rt.navigate(['/minor-accnt', 'document-upload1-guardian']).then(() => {
        window.location.reload();
      });
    })
    // window.location.reload();
  }
}