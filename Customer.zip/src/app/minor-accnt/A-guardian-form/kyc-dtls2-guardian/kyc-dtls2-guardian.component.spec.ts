import { ComponentFixture, TestBed } from '@angular/core/testing';

import { KycDtls2GuardianComponent } from './kyc-dtls2-guardian.component';

describe('KycDtls2GuardianComponent', () => {
  let component: KycDtls2GuardianComponent;
  let fixture: ComponentFixture<KycDtls2GuardianComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ KycDtls2GuardianComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(KycDtls2GuardianComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
