import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { CommonService } from 'src/app/services/common.service';
import { CustomerDataService } from 'src/app/services/customer-data.service';

@Component({
  selector: 'app-kyc-dtls2-guardian',
  templateUrl: './kyc-dtls2-guardian.component.html',
  styleUrls: ['./kyc-dtls2-guardian.component.css']
})
export class KycDtls2GuardianComponent implements OnInit {

  currentDate: any;
  kycDtlsGuardianBForm: any;
  regObj: any;
  kyc_details_id: any;

  isDisplayUpdateBtn: boolean = false;
  constructor(private rt: Router, private fb: FormBuilder, private commonService: CommonService, private customerDataService: CustomerDataService) { }

  ngOnInit(): void {
    this.regObj = this.commonService.getUserFromLocalStorage();

    if (this.regObj.isSubmited || this.regObj.leadReviewStatus != "customer_process") {
      this.rt.navigate(["/minor-accnt", "ending"]);
    }

    // if (this.commonService.getUserFromLocalStorage()?.leadReviewStatus === undefined) {
    //   this.isDisplayUpdateBtn = false;
    // }
    // else {
    //   this.isDisplayUpdateBtn = true;
    // }

    let Obj = {
      applicant_id: this.commonService.getUserFromLocalStorage()?.guardianApplicantID,
      process_id: 49,
      kyc_details_id: this.regObj?.kyc_details_id
    }

    this.customerDataService.fetchKycDtls2(Obj).subscribe((value) => {
      if (value.data.length > 0) {
        this.isDisplayUpdateBtn = true;
        this.kycDtlsGuardianBForm = this.fb.group({
          kycDtlsBSubmittedBank: [value?.data?.[0].is_temporary_visa_declaration==1?true:false, [Validators.required]],
          kycDtlsBIssueDate: [value?.data?.[0]?.temporary_visa_declare_issue_date, [Validators.required]],
          kycDtlsBExpiryDate: [value?.data?.[0]?.temporary_visa_declare_expiry_date, [Validators.required]],
          kycDtlsBAgreFurshBankCpy: [value?.data?.[0].is_temporary_visa_declaration==1?true:false, [Validators.required]],
        })
        this.kyc_details_id = value?.data?.[0]?.kyc_details_id;
      }

    })

    this.kycDtlsGuardianBForm = this.fb.group({
      kycDtlsBSubmittedBank: ['', Validators.required],
      kycDtlsBIssueDate: ['', Validators.required],
      kycDtlsBExpiryDate: ['', Validators.required],
      kycDtlsBAgreFurshBankCpy: ['', Validators.required]
    })
    this.currentDate = this.commonService.getCurrentDate();
  }

  get kycDtlsBSubmittedBank() { return this.kycDtlsGuardianBForm.get("kycDtlsBSubmittedBank") }
  get kycDtlsBIssueDate() { return this.kycDtlsGuardianBForm.get("kycDtlsBIssueDate") }
  get kycDtlsBExpiryDate() { return this.kycDtlsGuardianBForm.get("kycDtlsBExpiryDate") }
  get kycDtlsBAgreFurshBankCpy() { return this.kycDtlsGuardianBForm.get("kycDtlsBAgreFurshBankCpy") }

  //[routerLink]="['/']" routerLinkActive="router-link-active"

  check(val: any) {
    console.log("check", val.value);

  }

  submitKycDtls2Guardian() {
    // let kycDtlsID = '';
    if (this.kycDtlsGuardianBForm.valid) {
      this.regObj = this.commonService.getUserFromLocalStorage();
      /*
      this.kycDtlsGuardianBForm.get("kycDtlsBSubmittedBank").value
      this.kycDtlsGuardianBForm.get("kycDtlsBIssueDate").value
      this.kycDtlsGuardianBForm.get("kycDtlsBExpiryDate").value
      this.kycDtlsGuardianBForm.get("kycDtlsBAgreFurshBankCpy").value
      */

      // if (this.regObj.kyc_details_id === undefined || this.regObj.kyc_details_id === "undefined") {
      //   kycDtlsID = this.kyc_details_id;
      // }
      // else {
      //   kycDtlsID = this.regObj.kyc_details_id;

      // }

      let Obj = {
        applicant_serial_num: this.commonService.getUserFromLocalStorage()?.applicantSerialNum,
        applicant_personal_id: this.commonService.getUserFromLocalStorage()?.guardianApplicantID,
        applicant_id: this.commonService.getUserFromLocalStorage()?.guardianApplicantID,
        user_id: this.regObj?.user_id,
        process_id: 49,

        temporary_visa_declare_issue_date: this.customerDataService.formatDob(this.kycDtlsGuardianBForm.get("kycDtlsBIssueDate").value),
        temporary_visa_declare_expiry_date: this.customerDataService.formatDob(this.kycDtlsGuardianBForm.get("kycDtlsBExpiryDate").value),
        kyc_dtls_chk1: Number(this.kycDtlsGuardianBForm.get("kycDtlsBSubmittedBank").value),
        kyc_dtls_chk2: Number(this.kycDtlsGuardianBForm.get("kycDtlsBAgreFurshBankCpy").value),
        kyc_details_id: Number(this.regObj.kyc_details_id)
      }

      this.customerDataService.postKycDtls2(Obj).subscribe((data) => {
        
        // this.commonService.storeInLocalStorage('registerData', { "kyc_details_id": data?.kyc_details_id })
        //visaType
        if (this.commonService.getUserFromLocalStorage()?.leadReviewStatus == 'customer_process') {

            this.rt.navigate(["/minor-accnt", "kyc-dtls3-guardian"]);
        }
        else {
          this.rt.navigate(["/feedback", "feedback-summary"]);
        }
      })
    }
    else {
      console.log("This is ivalid");
    }
  }
}