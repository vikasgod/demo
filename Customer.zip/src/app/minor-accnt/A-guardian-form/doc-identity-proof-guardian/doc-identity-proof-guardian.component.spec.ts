import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DocIdentityProofGuardianComponent } from './doc-identity-proof-guardian.component';

describe('DocIdentityProofGuardianComponent', () => {
  let component: DocIdentityProofGuardianComponent;
  let fixture: ComponentFixture<DocIdentityProofGuardianComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DocIdentityProofGuardianComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DocIdentityProofGuardianComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
