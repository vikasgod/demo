import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { CommonService } from 'src/app/services/common.service';
import { CustomerDataService } from 'src/app/services/customer-data.service';

@Component({
  selector: 'app-addrs-dtls2-guardian',
  templateUrl: './addrs-dtls2-guardian.component.html',
  styleUrls: ['./addrs-dtls2-guardian.component.css']
})
export class AddrsDtls2GuardianComponent implements OnInit {

  countryData: any;
  addressTypeData: any;
  addrsDtlsBForm: any;
  regObj: any;
  isDisplayUpdateBtn: boolean = false;
  sameascurrentaddress: any = "Select";
  constructor(private rt: Router, private fb: FormBuilder, private commonService: CommonService, private customerDataService: CustomerDataService) { }

  ngOnInit(): void {
    this.regObj = this.commonService.getUserFromLocalStorage();
    if ((this.regObj.isSubmitted != undefined && this.regObj.isSubmitted != 0)
      || ((this.regObj.leadReviewStatus != undefined && this.regObj.leadReviewStatus != "customer_process")
        && (this.regObj.leadReviewStatus != undefined && this.regObj.leadReviewStatus != "agent_review"))
    ) {
      // this.rt.navigate(["/individual-account", "ending"]);
    }

    // if (this.commonService.getUserFromLocalStorage()?.leadReviewStatus === undefined) {
    //   this.isDisplayUpdateBtn = false;
    // } 
    // else {
    //   this.isDisplayUpdateBtn = true;
    // }
    let Obj = {
      applicant_id: this.regObj.guardianApplicantID,
      process_id: 54
    }

    this.customerDataService.fetchAddressDtls2(Obj).subscribe((value) => {
      // console.log("Adddress Dtls 2", value)
      if (value?.data?.length > 0) {
        this.isDisplayUpdateBtn = true;
        this.addrsDtlsBForm = this.fb.group({
          addrsDtlsBPermntAaddrsType: [value?.data?.[0]?.permenant_address_type, [Validators.required]],
          addrsDtlsBPermntAaddrsHuseNo: [value?.data?.[0]?.permenant_house_number, [Validators.required]],
          addrsDtlsBPermntAaddrsBuldNm: [value?.data?.[0]?.permenant_house_or_building_name, [Validators.required]],
          addrsDtlsBPermntAaddrsRdNm: [value?.data?.[0]?.permenant_road_or_street_name, [Validators.required]],
          addrsDtlsBPermntAaddrsLndMrk: [value?.data?.[0]?.permenant_landmark, [Validators.required]],
          addrsDtlsBPermntAaddrsCntry: [value?.data?.[0]?.permenant_country_id, [Validators.required]],
          addrsDtlsBPermntAaddrsState: [value?.data?.[0]?.permenant_state, [Validators.required]],
          addrsDtlsBPermntAaddrsCity: [value?.data?.[0]?.permenant_city, [Validators.required]],
          addrsDtlsBPermntAaddrsPnCd: [value?.data?.[0]?.permenant_pincode, [Validators.required, Validators.pattern(/^[A-Za-z0-9\s]*$/)]],
          addrsDtlsBPrefrdMailAddrss: [value?.data?.[0]?.preffered_mailing, []],
          addrsDtlsBJurisdictnAaddrsType: [value?.data?.[0]?.jurisdiction_address_type, [Validators.required]],
          addrsDtlsBJurisdictnAaddrsHuseNo: [value?.data?.[0]?.jurisdiction_house_number, [Validators.required]],
          addrsDtlsBJurisdictnAaddrsBuldNm: [value?.data?.[0]?.jurisdiction_house_or_building_name, [Validators.required]],
          addrsDtlsBJurisdictnAaddrsRdNm: [value?.data?.[0]?.jurisdiction_road_or_street_name, [Validators.required]],
          addrsDtlsBJurisdictnAaddrsLndMrk: [value?.data?.[0]?.jurisdiction_landmark, [Validators.required]],
          addrsDtlsBJurisdictnAaddrsCntry: [value?.data?.[0]?.jurisdiction_country_id, [Validators.required]],
          addrsDtlsBJurisdictnAaddrsState: [value?.data?.[0]?.jurisdiction_state, [Validators.required]],
          addrsDtlsBJurisdictnAaddrsCity: [value?.data?.[0]?.jurisdiction_city, [Validators.required]],
          addrsDtlsBJurisdictnAaddrsPnCd: [value?.data?.[0]?.jurisdiction_pincode, [Validators.required, Validators.pattern(/^[A-Za-z0-9\s]*$/)]]
        })
      }
    })

    this.addrsDtlsBForm = this.fb.group({
      addrsDtlsBPermntAaddrsType: ['', [Validators.required]],
      addrsDtlsBPermntAaddrsHuseNo: ['', [Validators.required, Validators.minLength(2)]],
      addrsDtlsBPermntAaddrsBuldNm: ['', [Validators.required, Validators.minLength(2)]],
      addrsDtlsBPermntAaddrsRdNm: ['', [Validators.required]],
      addrsDtlsBPermntAaddrsLndMrk: ['', [Validators.required]],
      addrsDtlsBPermntAaddrsCntry: ['', [Validators.required]],
      addrsDtlsBPermntAaddrsState: ['', [Validators.required]],
      addrsDtlsBPermntAaddrsCity: ['', [Validators.required]],
      addrsDtlsBPermntAaddrsPnCd: ['', [Validators.required, Validators.pattern(/^[A-Za-z0-9\s]*$/)]],
      addrsDtlsBPrefrdMailAddrss: ['', []],
      addrsDtlsBJurisdictnAaddrsType: ['', [Validators.required]],
      addrsDtlsBJurisdictnAaddrsHuseNo: ['', [Validators.required, Validators.minLength(2)]],
      addrsDtlsBJurisdictnAaddrsBuldNm: ['', [Validators.required, Validators.minLength(2)]],
      addrsDtlsBJurisdictnAaddrsRdNm: ['', [Validators.required]],
      addrsDtlsBJurisdictnAaddrsLndMrk: ['', [Validators.required]],
      addrsDtlsBJurisdictnAaddrsCntry: ['', [Validators.required]],
      addrsDtlsBJurisdictnAaddrsState: ['', [Validators.required]],
      addrsDtlsBJurisdictnAaddrsCity: ['', [Validators.required]],
      addrsDtlsBJurisdictnAaddrsPnCd: ['', [Validators.required, Validators.pattern(/^[A-Za-z0-9\s]*$/)]]
    })

    this.customerDataService.getCountry().subscribe((data) => {
      // console.log("Country", data)
      this.countryData = data;
    })

    this.customerDataService.getAddressType().subscribe((data) => {
      // console.log("Address Type", data);
      this.addressTypeData = data;
    })
  }

  get addrsDtlsBPermntAaddrsType() { return this.addrsDtlsBForm.get("addrsDtlsBPermntAaddrsType") }
  get addrsDtlsBPermntAaddrsHuseNo() { return this.addrsDtlsBForm.get("addrsDtlsBPermntAaddrsHuseNo") }
  get addrsDtlsBPermntAaddrsBuldNm() { return this.addrsDtlsBForm.get("addrsDtlsBPermntAaddrsBuldNm") }
  get addrsDtlsBPermntAaddrsRdNm() { return this.addrsDtlsBForm.get("addrsDtlsBPermntAaddrsRdNm") }
  get addrsDtlsBPermntAaddrsLndMrk() { return this.addrsDtlsBForm.get("addrsDtlsBPermntAaddrsLndMrk") }
  get addrsDtlsBPermntAaddrsCntry() { return this.addrsDtlsBForm.get("addrsDtlsBPermntAaddrsCntry") }
  get addrsDtlsBPermntAaddrsState() { return this.addrsDtlsBForm.get("addrsDtlsBPermntAaddrsState") }
  get addrsDtlsBPermntAaddrsCity() { return this.addrsDtlsBForm.get("addrsDtlsBPermntAaddrsCity") }
  get addrsDtlsBPermntAaddrsPnCd() { return this.addrsDtlsBForm.get("addrsDtlsBPermntAaddrsPnCd") }
  get addrsDtlsBPrefrdMailAddrss() { return this.addrsDtlsBForm.get("addrsDtlsBPrefrdMailAddrss") }
  get addrsDtlsBJurisdictnAaddrsType() { return this.addrsDtlsBForm.get("addrsDtlsBJurisdictnAaddrsType") }
  get addrsDtlsBJurisdictnAaddrsHuseNo() { return this.addrsDtlsBForm.get("addrsDtlsBJurisdictnAaddrsHuseNo") }
  get addrsDtlsBJurisdictnAaddrsBuldNm() { return this.addrsDtlsBForm.get("addrsDtlsBJurisdictnAaddrsBuldNm") }
  get addrsDtlsBJurisdictnAaddrsRdNm() { return this.addrsDtlsBForm.get("addrsDtlsBJurisdictnAaddrsRdNm") }
  get addrsDtlsBJurisdictnAaddrsLndMrk() { return this.addrsDtlsBForm.get("addrsDtlsBJurisdictnAaddrsLndMrk") }
  get addrsDtlsBJurisdictnAaddrsCntry() { return this.addrsDtlsBForm.get("addrsDtlsBJurisdictnAaddrsCntry") }
  get addrsDtlsBJurisdictnAaddrsState() { return this.addrsDtlsBForm.get("addrsDtlsBJurisdictnAaddrsState") }
  get addrsDtlsBJurisdictnAaddrsCity() { return this.addrsDtlsBForm.get("addrsDtlsBJurisdictnAaddrsCity") }
  get addrsDtlsBJurisdictnAaddrsPnCd() { return this.addrsDtlsBForm.get("addrsDtlsBJurisdictnAaddrsPnCd") }

  keypressNumber(event: any) {
    return this.commonService.enterOnlyNumber(event);
  }

  keypressAlphabets(event: any) {
    //return this.commonService.enterOnlyAlphabets(event);
    return this.commonService.enterOnlyAlphabetsSpaceNBcktck(event);
  }

  checkSpecialChar(event: any) {
    return this.commonService.keypressSpecialChar(event)
  }

  selectPerferMailingAddress(event: any) {
    let selectedVal = event.target.value;
    let Obj = this.commonService.getUserFromLocalStorage();
    switch (selectedVal) {
      case 'current':
        this.addrsDtlsBForm.get("addrsDtlsBJurisdictnAaddrsType").setValue(Obj?.address_Dtls1?.addrsDtlsAaddrsType)
        this.addrsDtlsBForm.get("addrsDtlsBJurisdictnAaddrsHuseNo").setValue(Obj?.address_Dtls1?.addrsDtlsAaddrsHuseNo)
        this.addrsDtlsBForm.get("addrsDtlsBJurisdictnAaddrsBuldNm").setValue(Obj?.address_Dtls1?.addrsDtlsAaddrsBuldNm)
        this.addrsDtlsBForm.get("addrsDtlsBJurisdictnAaddrsRdNm").setValue(Obj?.address_Dtls1?.addrsDtlsAaddrsRdNm)
        this.addrsDtlsBForm.get("addrsDtlsBJurisdictnAaddrsLndMrk").setValue(Obj?.address_Dtls1?.addrsDtlsAaddrsLndMrk)
        this.addrsDtlsBForm.get("addrsDtlsBJurisdictnAaddrsCntry").setValue(Obj?.address_Dtls1?.addrsDtlsAaddrsCntry)
        this.addrsDtlsBForm.get("addrsDtlsBJurisdictnAaddrsState").setValue(Obj?.address_Dtls1?.addrsDtlsAaddrsState)
        this.addrsDtlsBForm.get("addrsDtlsBJurisdictnAaddrsCity").setValue(Obj?.address_Dtls1?.addrsDtlsAaddrsCity)
        this.addrsDtlsBForm.get("addrsDtlsBJurisdictnAaddrsPnCd").setValue(Obj?.address_Dtls1?.addrsDtlsAaddrsPnCd)

        this.addrsDtlsBForm.controls['addrsDtlsBJurisdictnAaddrsType'].disable()
        this.addrsDtlsBForm.controls['addrsDtlsBJurisdictnAaddrsHuseNo'].disable()
        this.addrsDtlsBForm.controls['addrsDtlsBJurisdictnAaddrsBuldNm'].disable()
        this.addrsDtlsBForm.controls['addrsDtlsBJurisdictnAaddrsRdNm'].disable()
        this.addrsDtlsBForm.controls['addrsDtlsBJurisdictnAaddrsCntry'].disable()
        this.addrsDtlsBForm.controls['addrsDtlsBJurisdictnAaddrsCntry'].disable()
        this.addrsDtlsBForm.controls['addrsDtlsBJurisdictnAaddrsState'].disable()
        this.addrsDtlsBForm.controls['addrsDtlsBJurisdictnAaddrsCity'].disable()
        this.addrsDtlsBForm.controls['addrsDtlsBJurisdictnAaddrsPnCd'].disable()
        break;
      case 'overseas':
        this.addrsDtlsBForm.get("addrsDtlsBJurisdictnAaddrsType").setValue(Obj?.address_Dtls1?.addrsDtlsOverseasAaddrsType)
        this.addrsDtlsBForm.get("addrsDtlsBJurisdictnAaddrsHuseNo").setValue(Obj?.address_Dtls1?.addrsDtlsOverseasAaddrsHuseNo)
        this.addrsDtlsBForm.get("addrsDtlsBJurisdictnAaddrsBuldNm").setValue(Obj?.address_Dtls1?.addrsDtlsOverseasAaddrsBuldNm)
        this.addrsDtlsBForm.get("addrsDtlsBJurisdictnAaddrsRdNm").setValue(Obj?.address_Dtls1?.addrsDtlsOverseasAaddrsRdNm)
        this.addrsDtlsBForm.get("addrsDtlsBJurisdictnAaddrsLndMrk").setValue(Obj?.address_Dtls1?.addrsDtlsOverseasAaddrsLndMrk)
        this.addrsDtlsBForm.get("addrsDtlsBJurisdictnAaddrsCntry").setValue(Obj?.address_Dtls1?.addrsDtlsOverseasAaddrsCntry)
        this.addrsDtlsBForm.get("addrsDtlsBJurisdictnAaddrsState").setValue(Obj?.address_Dtls1?.addrsDtlsOverseasAaddrsState)
        this.addrsDtlsBForm.get("addrsDtlsBJurisdictnAaddrsCity").setValue(Obj?.address_Dtls1?.addrsDtlsOverseasAaddrsCity)
        this.addrsDtlsBForm.get("addrsDtlsBJurisdictnAaddrsPnCd").setValue(Obj?.address_Dtls1?.addrsDtlsOverseasAaddrsPnCd)
        
        this.addrsDtlsBForm.controls['addrsDtlsBJurisdictnAaddrsType'].disable()
        this.addrsDtlsBForm.controls['addrsDtlsBJurisdictnAaddrsHuseNo'].disable()
        this.addrsDtlsBForm.controls['addrsDtlsBJurisdictnAaddrsBuldNm'].disable()
        this.addrsDtlsBForm.controls['addrsDtlsBJurisdictnAaddrsRdNm'].disable()
        this.addrsDtlsBForm.controls['addrsDtlsBJurisdictnAaddrsCntry'].disable()
        this.addrsDtlsBForm.controls['addrsDtlsBJurisdictnAaddrsCntry'].disable()
        this.addrsDtlsBForm.controls['addrsDtlsBJurisdictnAaddrsState'].disable()
        this.addrsDtlsBForm.controls['addrsDtlsBJurisdictnAaddrsCity'].disable()
        this.addrsDtlsBForm.controls['addrsDtlsBJurisdictnAaddrsPnCd'].disable()
        break;
      case 'permenant':
        this.addrsDtlsBForm.get("addrsDtlsBJurisdictnAaddrsType").setValue(this.addrsDtlsBForm.get("addrsDtlsBPermntAaddrsType").value)
        this.addrsDtlsBForm.get("addrsDtlsBJurisdictnAaddrsHuseNo").setValue(this.addrsDtlsBForm.get("addrsDtlsBPermntAaddrsHuseNo").value)
        this.addrsDtlsBForm.get("addrsDtlsBJurisdictnAaddrsBuldNm").setValue(this.addrsDtlsBForm.get("addrsDtlsBPermntAaddrsBuldNm").value)
        this.addrsDtlsBForm.get("addrsDtlsBJurisdictnAaddrsRdNm").setValue(this.addrsDtlsBForm.get("addrsDtlsBPermntAaddrsRdNm").value)
        this.addrsDtlsBForm.get("addrsDtlsBJurisdictnAaddrsLndMrk").setValue(this.addrsDtlsBForm.get("addrsDtlsBPermntAaddrsLndMrk").value)
        this.addrsDtlsBForm.get("addrsDtlsBJurisdictnAaddrsCntry").setValue(this.addrsDtlsBForm.get("addrsDtlsBPermntAaddrsCntry").value)
        this.addrsDtlsBForm.get("addrsDtlsBJurisdictnAaddrsState").setValue(this.addrsDtlsBForm.get("addrsDtlsBPermntAaddrsState").value)
        this.addrsDtlsBForm.get("addrsDtlsBJurisdictnAaddrsCity").setValue(this.addrsDtlsBForm.get("addrsDtlsBPermntAaddrsCity").value)
        this.addrsDtlsBForm.get("addrsDtlsBJurisdictnAaddrsPnCd").setValue(this.addrsDtlsBForm.get("addrsDtlsBPermntAaddrsPnCd").value)
        
        this.addrsDtlsBForm.controls['addrsDtlsBJurisdictnAaddrsType'].disable()
        this.addrsDtlsBForm.controls['addrsDtlsBJurisdictnAaddrsHuseNo'].disable()
        this.addrsDtlsBForm.controls['addrsDtlsBJurisdictnAaddrsBuldNm'].disable()
        this.addrsDtlsBForm.controls['addrsDtlsBJurisdictnAaddrsRdNm'].disable()
        this.addrsDtlsBForm.controls['addrsDtlsBJurisdictnAaddrsCntry'].disable()
        this.addrsDtlsBForm.controls['addrsDtlsBJurisdictnAaddrsCntry'].disable()
        this.addrsDtlsBForm.controls['addrsDtlsBJurisdictnAaddrsState'].disable()
        this.addrsDtlsBForm.controls['addrsDtlsBJurisdictnAaddrsCity'].disable()
        this.addrsDtlsBForm.controls['addrsDtlsBJurisdictnAaddrsPnCd'].disable()
        break;
    }

  }

  submitAddrsDtls() {
    if (this.addrsDtlsBForm.valid) {
      this.regObj = this.commonService.getUserFromLocalStorage();
      let Obj = {
        applicant_id: Number(this.regObj.guardianApplicantID),
        process_id: 54,
        permenant_address_type: Number(this.addrsDtlsBForm.get("addrsDtlsBPermntAaddrsType").value),
        permenant_house_number: this.addrsDtlsBForm.get("addrsDtlsBPermntAaddrsHuseNo").value,
        permenant_house_or_building_name: this.addrsDtlsBForm.get("addrsDtlsBPermntAaddrsBuldNm").value,
        permenant_road_or_street_name: this.addrsDtlsBForm.get("addrsDtlsBPermntAaddrsRdNm").value,
        permenant_state: this.addrsDtlsBForm.get("addrsDtlsBPermntAaddrsState").value,
        permenant_city: this.addrsDtlsBForm.get("addrsDtlsBPermntAaddrsCity").value,
        permenant_country_id: Number(this.addrsDtlsBForm.get("addrsDtlsBPermntAaddrsCntry").value),
        permenant_pincode: this.addrsDtlsBForm.get("addrsDtlsBPermntAaddrsPnCd").value,
        jurisdiction_address_type: Number(this.addrsDtlsBForm.get("addrsDtlsBJurisdictnAaddrsType").value),
        jurisdiction_house_number: this.addrsDtlsBForm.get("addrsDtlsBJurisdictnAaddrsHuseNo").value,
        jurisdiction_house_or_building_name: this.addrsDtlsBForm.get("addrsDtlsBJurisdictnAaddrsBuldNm").value,
        jurisdiction_road_or_street_name: this.addrsDtlsBForm.get("addrsDtlsBJurisdictnAaddrsRdNm").value,
        jurisdiction_state: this.addrsDtlsBForm.get("addrsDtlsBJurisdictnAaddrsState").value,
        jurisdiction_city: this.addrsDtlsBForm.get("addrsDtlsBJurisdictnAaddrsCity").value,
        jurisdiction_country_id: Number(this.addrsDtlsBForm.get("addrsDtlsBJurisdictnAaddrsCntry").value),
        jurisdiction_pincode: this.addrsDtlsBForm.get("addrsDtlsBJurisdictnAaddrsPnCd").value,
        preffered_mailing: this.addrsDtlsBForm.get("addrsDtlsBPrefrdMailAddrss").value?.length ? this.addrsDtlsBForm.get("addrsDtlsBPrefrdMailAddrss").value :null,
        permenant_landmark: this.addrsDtlsBForm.get("addrsDtlsBPermntAaddrsLndMrk").value,
        jurisdiction_landmark: this.addrsDtlsBForm.get("addrsDtlsBJurisdictnAaddrsLndMrk").value,

        address_id: Number(this.regObj.address_id),
      }

      this.customerDataService.postAddressDtls2(Obj).subscribe((data) => {
        var is_feedback_show = 0;
        if (this.commonService.getUserFromLocalStorage()?.leadReviewStatus != undefined) {
          if (this.commonService.getUserFromLocalStorage()?.leadReviewStatus != 'customer_process') {
            is_feedback_show += 1;
          }
        }
        if (is_feedback_show != 0) {
          this.rt.navigate(["/feedback", "feedback-summary"]);
        }
        else {
          this.rt.navigate(["/minor-accnt", "customer-profile-guardian"]);
        }
        // this.rt.navigate(["/individual-account", "customer-profile"])
      })
    }
    else {
      console.log("This is invalid form");
    }
  }

  setSameAddress() {

    if (this.sameascurrentaddress == "current") {
      console.log("check");
      this.addrsDtlsBForm.controls['addrsDtlsBPermntAaddrsType'].setValue(this.regObj?.address_Dtls1.addrsDtlsAaddrsType)
      this.addrsDtlsBForm.controls['addrsDtlsBPermntAaddrsHuseNo'].setValue(this.regObj?.address_Dtls1.addrsDtlsAaddrsHuseNo)
      this.addrsDtlsBForm.controls['addrsDtlsBPermntAaddrsBuldNm'].setValue(this.regObj?.address_Dtls1.addrsDtlsAaddrsBuldNm)
      this.addrsDtlsBForm.controls['addrsDtlsBPermntAaddrsRdNm'].setValue(this.regObj?.address_Dtls1.addrsDtlsAaddrsRdNm)
      this.addrsDtlsBForm.controls['addrsDtlsBPermntAaddrsLndMrk'].setValue(this.regObj?.address_Dtls1.addrsDtlsAaddrsLndMrk)
      this.addrsDtlsBForm.controls['addrsDtlsBPermntAaddrsCntry'].setValue(this.regObj?.address_Dtls1.addrsDtlsAaddrsCntry)
      this.addrsDtlsBForm.controls['addrsDtlsBPermntAaddrsState'].setValue(this.regObj?.address_Dtls1.addrsDtlsAaddrsState)
      this.addrsDtlsBForm.controls['addrsDtlsBPermntAaddrsCity'].setValue(this.regObj?.address_Dtls1.addrsDtlsAaddrsCity)
      this.addrsDtlsBForm.controls['addrsDtlsBPermntAaddrsPnCd'].setValue(this.regObj?.address_Dtls1.addrsDtlsAaddrsPnCd)

      this.addrsDtlsBForm.controls['addrsDtlsBPermntAaddrsType'].disable()
      this.addrsDtlsBForm.controls['addrsDtlsBPermntAaddrsHuseNo'].disable()
      this.addrsDtlsBForm.controls['addrsDtlsBPermntAaddrsBuldNm'].disable()
      this.addrsDtlsBForm.controls['addrsDtlsBPermntAaddrsRdNm'].disable()
      this.addrsDtlsBForm.controls['addrsDtlsBPermntAaddrsLndMrk'].disable()
      this.addrsDtlsBForm.controls['addrsDtlsBPermntAaddrsCntry'].disable()
      this.addrsDtlsBForm.controls['addrsDtlsBPermntAaddrsState'].disable()
      this.addrsDtlsBForm.controls['addrsDtlsBPermntAaddrsCity'].disable()
      this.addrsDtlsBForm.controls['addrsDtlsBPermntAaddrsPnCd'].disable()
    }
    else if (this.sameascurrentaddress == "overseas") {
      this.addrsDtlsBForm.controls['addrsDtlsBPermntAaddrsType'].setValue(this.regObj?.address_Dtls1.addrsDtlsOverseasAaddrsType)
      this.addrsDtlsBForm.controls['addrsDtlsBPermntAaddrsHuseNo'].setValue(this.regObj?.address_Dtls1.addrsDtlsOverseasAaddrsHuseNo)
      this.addrsDtlsBForm.controls['addrsDtlsBPermntAaddrsBuldNm'].setValue(this.regObj?.address_Dtls1.addrsDtlsOverseasAaddrsBuldNm)
      this.addrsDtlsBForm.controls['addrsDtlsBPermntAaddrsRdNm'].setValue(this.regObj?.address_Dtls1.addrsDtlsOverseasAaddrsRdNm)
      this.addrsDtlsBForm.controls['addrsDtlsBPermntAaddrsLndMrk'].setValue(this.regObj?.address_Dtls1.addrsDtlsOverseasAaddrsLndMrk)
      this.addrsDtlsBForm.controls['addrsDtlsBPermntAaddrsCntry'].setValue(this.regObj?.address_Dtls1.addrsDtlsOverseasAaddrsCntry)
      this.addrsDtlsBForm.controls['addrsDtlsBPermntAaddrsState'].setValue(this.regObj?.address_Dtls1.addrsDtlsOverseasAaddrsState)
      this.addrsDtlsBForm.controls['addrsDtlsBPermntAaddrsCity'].setValue(this.regObj?.address_Dtls1.addrsDtlsOverseasAaddrsCity)
      this.addrsDtlsBForm.controls['addrsDtlsBPermntAaddrsPnCd'].setValue(this.regObj?.address_Dtls1.addrsDtlsOverseasAaddrsPnCd)

      this.addrsDtlsBForm.controls['addrsDtlsBPermntAaddrsType'].disable()
      this.addrsDtlsBForm.controls['addrsDtlsBPermntAaddrsHuseNo'].disable()
      this.addrsDtlsBForm.controls['addrsDtlsBPermntAaddrsBuldNm'].disable()
      this.addrsDtlsBForm.controls['addrsDtlsBPermntAaddrsRdNm'].disable()
      this.addrsDtlsBForm.controls['addrsDtlsBPermntAaddrsLndMrk'].disable()
      this.addrsDtlsBForm.controls['addrsDtlsBPermntAaddrsCntry'].disable()
      this.addrsDtlsBForm.controls['addrsDtlsBPermntAaddrsState'].disable()
      this.addrsDtlsBForm.controls['addrsDtlsBPermntAaddrsCity'].disable()
      this.addrsDtlsBForm.controls['addrsDtlsBPermntAaddrsPnCd'].disable()

    }
  }
}