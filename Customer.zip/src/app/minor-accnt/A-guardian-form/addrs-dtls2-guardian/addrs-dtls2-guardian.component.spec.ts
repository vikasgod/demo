import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddrsDtls2GuardianComponent } from './addrs-dtls2-guardian.component';

describe('AddrsDtls2GuardianComponent', () => {
  let component: AddrsDtls2GuardianComponent;
  let fixture: ComponentFixture<AddrsDtls2GuardianComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddrsDtls2GuardianComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AddrsDtls2GuardianComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
