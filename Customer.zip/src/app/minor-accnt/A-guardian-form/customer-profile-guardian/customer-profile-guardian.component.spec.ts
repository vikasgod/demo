import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomerProfileGuardianComponent } from './customer-profile-guardian.component';

describe('CustomerProfileGuardianComponent', () => {
  let component: CustomerProfileGuardianComponent;
  let fixture: ComponentFixture<CustomerProfileGuardianComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CustomerProfileGuardianComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CustomerProfileGuardianComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
