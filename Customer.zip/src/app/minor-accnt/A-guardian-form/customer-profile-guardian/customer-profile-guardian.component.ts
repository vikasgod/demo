import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { CommonService } from 'src/app/services/common.service';
import { CustomerDataService } from 'src/app/services/customer-data.service';

@Component({
  selector: 'app-customer-profile-guardian',
  templateUrl: './customer-profile-guardian.component.html',
  styleUrls: ['./customer-profile-guardian.component.css']
})
export class CustomerProfileGuardianComponent implements OnInit {

  occupationTypeData: any;
  employmentTypeData: any;
  customerProfileGuardianFrom: any;
  isIndustryTypeVisible:boolean = true;
  regObj: any;
  anualIncomeTypeData: any;
  industryTypeData: any;
  isDisplayUpdateBtn: boolean = false;
  customer_profiler:any;

  constructor(private rt: Router, private fb: FormBuilder, private commonService: CommonService, private customerDataService: CustomerDataService) { }

  ngOnInit(): void {
    this.regObj = this.commonService.getUserFromLocalStorage();

    if ((this.regObj.isSubmited || this.regObj.leadReviewStatus != "customer_process" ) && this.regObj.leadReviewStatus != "agent_review") {
      this.rt.navigate(["/minor-accnt", "ending"]);
    }

    // if (this.commonService.getUserFromLocalStorage()?.leadReviewStatus === undefined) {
    //   this.isDisplayUpdateBtn = false;
    // }
    // else {
    //   this.isDisplayUpdateBtn = true;
    // }

    let Obj = {
      applicant_id: this.commonService.getUserFromLocalStorage()?.guardianApplicantID,
      process_id: 55
    }

    this.customerDataService.fetchCustomerProfiler(Obj).subscribe((value) => {
      console.log("Customer Profiler", value);
      if (value?.data?.length > 0) {
        this.isDisplayUpdateBtn = true;
        this.customer_profiler = value?.data?.[0]?.customer_profile_id
        this.customerProfileGuardianFrom = this.fb.group({
          customerProfileEdctnQufictn: [value?.data?.[0]?.qualification, [Validators.required]],
          customerProfileEmptynType: [value?.data?.[0]?.employment_type_id, [Validators.required]],
          customerProfileOccptn: [value?.data?.[0]?.occupation_id, [Validators.required]],
          customerProfileSrcIncome: [value?.data?.[0]?.source_income, [Validators.required]],
          customerProfileGrossIcome: [value?.data?.[0]?.gross_annual_income, [Validators.required]],
          customerProfileIdustType: [value?.data?.[0]?.industry_type_id]
        })
        this.updateIndustryTypeVisible(value?.data?.[0]?.employment_type_id)
      }
    })


    this.customerProfileGuardianFrom = this.fb.group({
      customerProfileEdctnQufictn: ['', [Validators.required]],
      customerProfileEmptynType: ['', [Validators.required]],
      customerProfileOccptn: ['', [Validators.required]],
      customerProfileSrcIncome: ['', [Validators.required]],
      customerProfileGrossIcome: ['', [Validators.required]],
      customerProfileIdustType: ['']
    })

    this.customerProfileGuardianFrom.get('customerProfileEmptynType')?.valueChanges.subscribe((value:any)=>{
      this.updateIndustryTypeVisible(value)
    })

    this.customerDataService.getEmploymentType().subscribe((data) => {
      console.log("This is employemnt type", data);
      this.employmentTypeData = data
    })

    this.customerDataService.getOccupationType().subscribe((data) => {
      console.log("This occupation", data);
      this.occupationTypeData = data;
    })

    this.customerDataService.getGrossAnualIncomeType().subscribe((data) => {
      console.log("This occupation", data);
      this.anualIncomeTypeData = data;
    })

    this.customerDataService.getIndustryType().subscribe((data) => {
      console.log("This occupation", data);
      this.industryTypeData = data;
    })
  }


  get customerProfileEdctnQufictn() { return this.customerProfileGuardianFrom.get("customerProfileEdctnQufictn") }
  get customerProfileEmptynType() { return this.customerProfileGuardianFrom.get("customerProfileEmptynType") }
  get customerProfileOccptn() { return this.customerProfileGuardianFrom.get("customerProfileOccptn") }
  get customerProfileSrcIncome() { return this.customerProfileGuardianFrom.get("customerProfileSrcIncome") }
  get customerProfileGrossIcome() { return this.customerProfileGuardianFrom.get("customerProfileGrossIcome") }
  get customerProfileIdustType() { return this.customerProfileGuardianFrom.get("customerProfileIdustType") }
  updateIndustryTypeVisible(employTypeId:Number){
    this.isIndustryTypeVisible = employTypeId == 1 || employTypeId == 2;
  }
  submitCustomerProfileGuardian() {
    
    if (this.customerProfileGuardianFrom.valid) {

      this.regObj = this.commonService.getUserFromLocalStorage();
      console.log("This Obj", this.customerProfileGuardianFrom.value);

      let Obj = {

        applicant_id: this.commonService.getUserFromLocalStorage()?.guardianApplicantID,
        applicant_personal_id: this.commonService.getUserFromLocalStorage()?.guardianApplicantID,
        applicant_serial_num: this.commonService.getUserFromLocalStorage()?.applicantSerialNum,
        user_id: this.regObj?.user_id,

        process_id: 55,
        qualification: this.customerProfileGuardianFrom.get("customerProfileEdctnQufictn").value,
        employment_type_id: Number(this.customerProfileGuardianFrom.get("customerProfileEmptynType").value),
        occupation_id: Number(this.customerProfileGuardianFrom.get("customerProfileOccptn").value),
        source_income: this.customerProfileGuardianFrom.get("customerProfileSrcIncome").value,
        gross_annual_income: this.customerProfileGuardianFrom.get("customerProfileGrossIcome").value,
        industry_type_id: Number(this.customerProfileGuardianFrom.get("customerProfileIdustType").value),
        customer_profiler: this.customer_profiler

      }

      /*
      applicant_id: req.body.applicant_id, qualification: req.body.qualification, employment_type_id: req.body.employment_type_id, occupation_id: req.body.occupation_id, source_income: req.body.source_income, gross_annual_income: req.body.gross_annual_income,
                industry_type_id: req.body.industry_type_id
                */

      this.customerDataService.postCustomerProfiler(Obj).subscribe((data) => {
        console.log("This is profile dtl", data);

        if(this.regObj.leadReviewStatus == "agent_review"){
          this.rt.navigate(["/feedback", "feedback-summary"]);
          return;

        }
        if (this.commonService.getUserFromLocalStorage()?.leadStatus !== undefined || this.commonService.getUserFromLocalStorage()?.leadStatus !== 'undefined' || this.commonService.getUserFromLocalStorage()?.leadStatus !== null) {
          this.rt.navigate(["/minor-accnt", "internet-banking1-guardian"])
        }
        else {
        }
        // this.rt.navigate(["/individual-account", "internet-banking"])
      })
      this.rt.navigate(["/minor-accnt", "internet-banking1-guardian"])
    }
    else {
      console.log("This is invalid form");
    }
  }
}