import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PersonalDtls1GuardianComponent } from './personal-dtls1-guardian.component';

describe('PersonalDtls1GuardianComponent', () => {
  let component: PersonalDtls1GuardianComponent;
  let fixture: ComponentFixture<PersonalDtls1GuardianComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PersonalDtls1GuardianComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PersonalDtls1GuardianComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
