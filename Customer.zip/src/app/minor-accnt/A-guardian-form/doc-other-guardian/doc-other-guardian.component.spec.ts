import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DocOtherGuardianComponent } from './doc-other-guardian.component';

describe('DocOtherGuardianComponent', () => {
  let component: DocOtherGuardianComponent;
  let fixture: ComponentFixture<DocOtherGuardianComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DocOtherGuardianComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DocOtherGuardianComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
