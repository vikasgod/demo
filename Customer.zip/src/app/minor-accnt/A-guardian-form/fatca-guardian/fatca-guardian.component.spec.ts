import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FatcaGuardianComponent } from './fatca-guardian.component';

describe('FatcaGuardianComponent', () => {
  let component: FatcaGuardianComponent;
  let fixture: ComponentFixture<FatcaGuardianComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ FatcaGuardianComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(FatcaGuardianComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
