import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { CommonService } from 'src/app/services/common.service';
import { Router } from '@angular/router';
import { CustomerDataService } from 'src/app/services/customer-data.service';

@Component({
  selector: 'app-fatca-guardian',
  templateUrl: './fatca-guardian.component.html',
  styleUrls: ['./fatca-guardian.component.css']
})
export class FatcaGuardianComponent implements OnInit {
  regObj: any;
  fatcaForm: any;
  tinDisplay: Boolean = true;
  countryData: any;
  fatcaID: number = 0;

  isDisplayUpdateBtn: boolean = false;
  constructor(private fb: FormBuilder, private commonService: CommonService, private rt: Router, private customerDataService: CustomerDataService) { }

  ngOnInit(): void {
    this.regObj = this.commonService.getUserFromLocalStorage();
    if ((this.regObj.isSubmitted != undefined && this.regObj.isSubmitted != 0)
    || ((this.regObj.leadReviewStatus != undefined && this.regObj.leadReviewStatus != "customer_process")
    && (this.regObj.leadReviewStatus != undefined && this.regObj.leadReviewStatus != "agent_review"))
    ) {
      // this.rt.navigate(["/individual-account", "ending"]);
    }

    if (this.commonService.getUserFromLocalStorage()?.leadStatus !== undefined || this.commonService.getUserFromLocalStorage()?.leadStatus !== 'undefined' || this.commonService.getUserFromLocalStorage()?.leadStatus !== null) {
      this.isDisplayUpdateBtn = false;
    } 
    else {
      this.isDisplayUpdateBtn = true;
    }

    this.fatcaForm = this.fb.group({
      fatcatxjursdtnOutIndRdBtn: ['1', Validators.required],
      fatcatxTin: ['', [Validators.maxLength(9), Validators.required]],
      fatcatxTinDesc: ['', Validators.required],
      fatcatxCntrytxJursdtn: [null, Validators.required],
      fatcaTinIssCntry: [null, Validators.required],
      fatcaCtyOfBrth: ['',[Validators.required,Validators.pattern('^[a-zA-Z ]*$')]],
      fatcaCntryOfBrth: [null, Validators.required],
    })

    let Obj = {
      applicant_id: this.regObj.guardianApplicantID,
      process_id: 47
    }

    this.customerDataService.fetchFatca(Obj).subscribe((value) => {
      console.log("This is value", value);
      if (value?.data?.length > 0) {
        this.isDisplayUpdateBtn=true
        this.fatcaForm = this.fb.group({
          fatcatxjursdtnOutIndRdBtn: [String(value?.data?.[0]?.is_residence_for_tax), [Validators.required]],
          fatcatxTin: [value?.data?.[0]?.tax_identification_number, Validators.required],
          fatcatxTinDesc: [value?.data?.[0]?.tin_description, Validators.required],
          fatcatxCntrytxJursdtn: [value?.data?.[0]?.tin_country_id==0?null:value?.data?.[0]?.tin_country_id, Validators.required],
          fatcaTinIssCntry: [value?.data?.[0]?.tin_issue_county_id==0?null:value?.data?.[0]?.tin_issue_county_id, Validators.required],
          fatcaCtyOfBrth: [value?.data?.[0]?.city_of_birth, Validators.required],
          fatcaCntryOfBrth: [value?.data?.[0]?.birth_county_id==0?null:value?.data?.[0]?.birth_county_id, Validators.required],
        })
        this.fatcaID = value?.data?.[0]?.fatca_id

      }
      this.displayTin();
    })

    this.customerDataService.getCountry().subscribe((data) => {
      console.log("Country", data)
      this.countryData = data
    })
  }

  get fatcatxjursdtnOutIndRdBtn() { return this.fatcaForm.get("fatcatxjursdtnOutIndRdBtn") }
  get fatcatxTin() { return this.fatcaForm.get("fatcatxTin") }
  get fatcatxTinDesc() { return this.fatcaForm.get("fatcatxTinDesc") }
  get fatcatxCntrytxJursdtn() { return this.fatcaForm.get("fatcatxCntrytxJursdtn") }
  get fatcaTinIssCntry() { return this.fatcaForm.get("fatcaTinIssCntry") }
  get fatcaCtyOfBrth() { return this.fatcaForm.get("fatcaCtyOfBrth") }
  get fatcaCntryOfBrth() { return this.fatcaForm.get("fatcaCntryOfBrth") }

  keypressLetters(event: any) {
    return this.commonService.enterOnlyAlphabetsSpaceNBcktck(event);
  }

  keypressAlphabetNoSpce(event: any) {
    return this.commonService.enterOnlyAlphabetsNoSpace(event)
  }

  keypressNumbers(event: any) {
    return this.commonService.enterOnlyNumber(event);
  }

  keypressAlphaNumbers(event: any) {
    return this.commonService.allowAlphaNumericSpace(event);
  }

  displayTin() {
    if (this.fatcatxjursdtnOutIndRdBtn.value === "1") {
      //Dispaly Tiny Value
      
      //Add Tiny Validators
      this.fatcaForm.controls['fatcatxTin'].setValidators([Validators.required])
      this.fatcaForm.controls['fatcatxTinDesc'].setValidators([Validators.required])
      this.fatcaForm.controls['fatcatxCntrytxJursdtn'].setValidators([Validators.required])
      this.fatcaForm.controls['fatcaTinIssCntry'].setValidators([Validators.required])
      this.fatcaForm.controls['fatcaCtyOfBrth'].setValidators([Validators.required])
      this.fatcaForm.controls['fatcaCntryOfBrth'].setValidators([Validators.required])
      this.tinDisplay = true;
    }

    else if (this.fatcatxjursdtnOutIndRdBtn.value === "0") {

      this.fatcaForm.controls['fatcatxTin'].clearValidators();
      this.fatcaForm.controls['fatcatxTinDesc'].clearValidators();
      this.fatcaForm.controls['fatcatxCntrytxJursdtn'].clearValidators();
      this.fatcaForm.controls['fatcaTinIssCntry'].clearValidators();
      this.fatcaForm.controls['fatcaCtyOfBrth'].clearValidators();
      this.fatcaForm.controls['fatcaCntryOfBrth'].clearValidators();
      this.tinDisplay = false;
    }
    //Update Controls according to condition
    this.fatcaForm.controls['fatcatxTin'].updateValueAndValidity();
    this.fatcaForm.controls['fatcatxTinDesc'].updateValueAndValidity();
    this.fatcaForm.controls['fatcatxCntrytxJursdtn'].updateValueAndValidity();
    this.fatcaForm.controls['fatcaTinIssCntry'].updateValueAndValidity();
    this.fatcaForm.controls['fatcaCtyOfBrth'].updateValueAndValidity();
    this.fatcaForm.controls['fatcaCntryOfBrth'].updateValueAndValidity();
  }


  submitFatcaForm() {
    if (this.fatcaForm.valid) {
      this.regObj = this.commonService.getUserFromLocalStorage();
      this.fatcaForm.get("fatcatxjursdtnOutIndRdBtn").value
      this.fatcaForm.get("fatcatxTin").value
      this.fatcaForm.get("fatcatxTinDesc").value
      this.fatcaForm.get("fatcatxCntrytxJursdtn").value
      this.fatcaForm.get("fatcaTinIssCntry").value
      this.fatcaForm.get("fatcaCtyOfBrth").value
      this.fatcaForm.get("fatcaCntryOfBrth").value
      console.log("This is fatca ID", this.fatcaID)
      let Obj = {
        fatca_id: String(this.fatcaID),
        applicant_id: this.regObj.guardianApplicantID,
        is_residence_for_tax: Number(this.fatcaForm.get("fatcatxjursdtnOutIndRdBtn").value),
        tax_identification_number: this.fatcaForm.get("fatcatxTin").value,
        tin_description: this.fatcaForm.get("fatcatxTinDesc").value,
        tin_country_id: this.fatcaForm.get("fatcaTinIssCntry").value,

        tin_issue_county_id: this.fatcaForm.get("fatcatxCntrytxJursdtn").value,
        city_of_birth: this.fatcaForm.get("fatcaCtyOfBrth").value,
        birth_county_id: this.fatcaForm.get("fatcaCntryOfBrth").value,
        process_id: 47
      }
      this.customerDataService.postFatca(Obj).subscribe((data) => {
        var is_feedback_show = 0;
        if (this.commonService.getUserFromLocalStorage()?.leadReviewStatus != undefined) {
          if (this.commonService.getUserFromLocalStorage()?.leadReviewStatus != 'customer_process') {
            is_feedback_show += 1;
          }
        }
        // console.log('this is feedback',is_feedback_show)
        // return false

        if (is_feedback_show != 0) {
          this.rt.navigate(["/feedback", "feedback-summary"]);
        } else {
          this.rt.navigate(["/minor-accnt", "kyc-dtls1-guardian"]);
        }

        // if (this.commonService.getUserFromLocalStorage()?.leadReviewStatus === undefined) {
        //   this.rt.navigate(["/individual-account", "kyc-dtls1"]);
        // } else {

        //   this.rt.navigate(["/feedback", "feedback-summary"]);
        // }
        // // this.rt.navigate(["/individual-account", "kyc-dtls1"]);

        // console.log("personal details 2",data)
      })

    } 
    else {
      console.log("This is invalid fatca form");
    }
  }
}