import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DocForm60GuardianComponent } from './doc-form60-guardian.component';

describe('DocForm60GuardianComponent', () => {
  let component: DocForm60GuardianComponent;
  let fixture: ComponentFixture<DocForm60GuardianComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DocForm60GuardianComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DocForm60GuardianComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
