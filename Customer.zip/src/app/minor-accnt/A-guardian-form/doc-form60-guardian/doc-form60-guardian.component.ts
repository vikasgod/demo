import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { CommonService } from 'src/app/services/common.service';
import { CustomerDataService } from 'src/app/services/customer-data.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-doc-form60-guardian',
  templateUrl: './doc-form60-guardian.component.html',
  styleUrls: ['./doc-form60-guardian.component.css']
})
export class DocForm60GuardianComponent implements OnInit {
  requiredFileType: string = 'image/png,image/jpeg'
  docIndentityFrom: any;
  iSfile1Change: boolean = false;
  errFileExtension: boolean = true;
  imgSrc: any = '';
  fileDataStr1: any = '';
  fileDataStr2: string = '';
  fileName1: string = '';
  fileName2: string = '';
  regObj: any;
  imgSrc1: string = '';
  imgSrc2: string = '';
  display: string = "none";
  docAddressProofFailedErr: string = '';
  isUpdate:boolean=false
  constructor(private fb: FormBuilder, private commonService: CommonService, private customerDataService: CustomerDataService, private rt: Router) { 
    this. getDoc()
  }

  ngOnInit(): void {
    this.regObj=this.commonService.getUserFromLocalStorage();
    if ((this.regObj.isSubmitted != undefined && this.regObj.isSubmitted != 0 && this.regObj.leadReviewStatus != "agent_review")
    || ((this.regObj.leadReviewStatus != undefined && this.regObj.leadReviewStatus != "customer_process")
    && (this.regObj.leadReviewStatus != undefined && this.regObj.leadReviewStatus != "agent_review"))
    ) {
      this.rt.navigate(["/minor-accnt", "ending"]);
    }

    this.docIndentityFrom = this.fb.group({
      docForm60File1: ['', [Validators.required]]
    })

    this. getDoc()

    //console.log('This is image base64',this.img1);
  }

  getDoc(){
    let Obj = {
      applicant_id: this.commonService.getUserFromLocalStorage()?.guardianApplicantID,
      document: "form_sixty"
    }

    this.customerDataService.fetchGetDoc(Obj).subscribe((value) => {
      if (value != undefined) {
        this.isUpdate = true
      }
      this.docIndentityFrom = this.fb.group({
        docForm60File1: [value.file_path, [Validators.required]]
      })
      this.imgSrc1 = value.file_path;
      this.customerDataService.getBase64ImageFromUrl(value?.file_path).then(result => {
        console.log(value.file_path, result)
        this.fileDataStr1 = result
        this.fileName1 = value.file_path.split('/').pop()
      })
        .catch(err => console.error(err));
      this.docIndentityFrom.get('docVisaFile1').setValue(this.fileName1);
    })
  }

  get docForm60File1() { return this.docIndentityFrom.get("docForm60File1") }

  //Working 1  
  onFilesSelected1(event: any) {
    this.iSfile1Change = true;
    let fileData = event.target.files[0];
    if(fileData != undefined){

    this.fileName1 = fileData.name;
    this.docIndentityFrom.get('docForm60File1').setValue(this.fileName1);
    let arr = String(fileData.name).split('.');
    let len = arr.length;

    if (fileData.size <= 5000000) {
      if (arr[len - 1] === "png" || arr[len - 1] === "jpeg" || arr[len - 1] === "jpg") {
        const reader = new FileReader();
        reader.onloadend = () => {
          this.imgSrc1 = String(reader.result)
          // Use a regex to remove data url part
          const base64String = String(reader.result)
            .replace('data:', '')
            .replace(/^.+,/, '');
          this.fileDataStr1 = base64String;
          //console.log("THis is file1 base64 string",base64String);
        };
        reader.readAsDataURL(fileData);
      } 
      else {
        this.errFileExtension = false;
        console.log("Extension is not valid")
        //return
      }
    } 
    else {
      console.log("Extension is not valid ex")
      this.fileName1 = '';
      this.docIndentityFrom.get('docForm60File1').setValue('');
      this.docAddressProofFailedErr = 'File size exceeds 5mb'
      this.openModal();
    }
    }
    else{
      return
    }
    //return
  }

  openModal() {
    this.display = "block";
  }

  onCloseHandled() {
    this.display = "none";
  }

  submitForm60() {
    this.regObj = this.commonService.getUserFromLocalStorage();
    // if(this.regObj.isSubmitted!=undefined)
    // {
    //   this.rt.navigate(["/minor-accnt","ending"]);
    // }
    let Obj = {
      applicant_id: this.regObj.guardianApplicantID,
      process_id: 63,
      file: this.fileDataStr1,
    }

    this.customerDataService.postCustomerForm60Doc(Obj).subscribe((data) => {

      if(this.regObj.leadReviewStatus == "agent_review"){
        this.rt.navigate(['/feedback', 'feedback-summary']);
        return;
      }
      this.rt.navigate(['/minor-accnt', 'document-upload1-guardian']);
      //console.log("THis is document upload successfull",data?.banking_doc_id);
      //this.commonService.storeInLocalStorage('registerData',{'banking_doc_id':data?.banking_doc_id})
    })
  }
}