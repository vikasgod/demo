import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GuardianDtlsComponent } from './guardian-dtls.component';

describe('GuardianDtlsComponent', () => {
  let component: GuardianDtlsComponent;
  let fixture: ComponentFixture<GuardianDtlsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ GuardianDtlsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(GuardianDtlsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
