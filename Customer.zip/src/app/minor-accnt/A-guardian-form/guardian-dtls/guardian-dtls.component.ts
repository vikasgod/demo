import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { CommonService } from 'src/app/services/common.service';
import { Router } from '@angular/router';
import { CustomerDataService } from 'src/app/services/customer-data.service';
import { Observable, of } from 'rxjs';

@Component({
  selector: 'app-guardian-dtls',
  templateUrl: './guardian-dtls.component.html',
  styleUrls: ['./guardian-dtls.component.css']
})
export class GuardianDtlsComponent implements OnInit {

  startDate = new Date(2004, 0, 1);
  currentDate: any | string | boolean | undefined;
  persnDltsForm: any;
  picker: any = '';
  regObj: any;
  isSubmitted: boolean = false;
  titleArrData: any;
  formData: any;
  applicant_personal_id: any;
  frirstName: string = '';
  lastName: string = '';

  religionObs$: Observable<any> = of();

  isDisplayUpdateBtn: boolean = false;

  relation = [
    { value: 'father', name: 'Father' },
    { value: 'mother', name: 'mother' },
    { value: 'brother', name: 'Brother' },
    { value: 'sister', name: 'Sister' }
    // { value: 'spouse', name: 'Spouse' },
    // { value: 'son', name: 'Son' },
    // { value: 'daughter', name: 'Daughter' }
  ]

  constructor(private fb: FormBuilder, private commonService: CommonService, private rt: Router, private customerDataService: CustomerDataService) { }

  ngOnInit(): void {

    this.regObj = this.commonService.getUserFromLocalStorage();

    if (this.regObj.isSubmited || this.regObj.leadReviewStatus != "customer_process") {
      this.rt.navigate(["/minor-accnt", "ending"]);
    }

    let Obj = {
      applicant_id: this?.regObj?.guardianApplicantID,
      process_id: 44,
      account_type_id: this?.regObj?.account_type_id,
      user_id: this?.regObj?.user_id
    }

    this.customerDataService.fetchGuardianDtls(Obj).subscribe((value) => {
      // this.dob = value.minor_dob
      console.log('check dob', value.minor_dob);
      if (value?.data?.length > 0) {
        this.isDisplayUpdateBtn = true;
        this.commonService.storeInLocalStorage('registerData', { applicantTitle: value?.data?.[0]?.applicant_title })
        this.persnDltsForm = this.fb.group({
          prnltitle: [value?.data?.[0]?.applicant_title, Validators.required],
          prnlFirstName: [value?.data?.[0]?.applicant_first_name, Validators.required],
          prnlMiddleName: [value?.data?.[0]?.applicant_middle_name],
          prnlLastName: [value?.data?.[0]?.applicant_last_name],
          prnlaadhaarNo1: [this.getAadhaarNumber(value?.data?.[0]?.aadhaar_number)],
          prnlDOb: [value?.data?.[0]?.date_of_birth, Validators.required],
          relminor: [value?.data?.[0]?.guardian_relation, Validators.required],
          acceptterms: [value?.data?.[0]?.acceptterms==1?true:false, Validators.required],
          acceptwithdrawl: [value?.data?.[0]?.acceptwithdrawl==1?true:false, Validators.required],
        })
      }
      else {
        this.persnDltsForm.get('prnlDOb').setValue(value.minor_dob)
      }
      this.applicant_personal_id = value?.data?.[0]?.applicant_personal_id;
    })


    this.persnDltsForm = this.fb.group({
      prnltitle: ['', Validators.required],
      prnlFirstName: ['', Validators.required],
      prnlMiddleName: [''],
      prnlLastName: [''],
      prnlaadhaarNo1: ['', Validators.pattern(/[0-9\s]{14}/)],
      prnlDOb: ['', Validators.required],
      relminor: ['', Validators.required],
      acceptterms: ['', Validators.required],
      acceptwithdrawl: ['', Validators.required],
    })

    this.currentDate = this.commonService.getCurrentDate()
    this.customerDataService.getTitle().subscribe((data) => {
      this.titleArrData = data;
    })
  }

  get prnltitle() { return this.persnDltsForm.get("prnltitle") }
  get prnlFirstName() { return this.persnDltsForm.get("prnlFirstName") }
  get prnlMiddleName() { return this.persnDltsForm.get("prnlMiddleName") }
  get prnlLastName() { return this.persnDltsForm.get("prnlLastName") }
  get prnlaadhaarNo1() { return this.persnDltsForm.get("prnlaadhaarNo1") }
  // get prnlaadhaarNo2() { return this.persnDltsForm.get("prnlaadhaarNo2") }
  // get prnlaadhaarNo3() { return this.persnDltsForm.get("prnlaadhaarNo3") }
  get prnlDOb() { return this.persnDltsForm.get("prnlDOb") }
  get prnlGender() { return this.persnDltsForm.get("prnlGender") }
  get relminor() { return this.persnDltsForm.get("relminor") }

  get acceptterms() { return this.persnDltsForm.get("acceptterms") }
  get acceptwithdrawl() { return this.persnDltsForm.get("acceptwithdrawl") }


  changeExposed(event: any) {
    // if(event.target.value==='0')
    // {
    //   this.isSubmitted=true

    // }else if(event.target.value==='1')
    // {
    //   this.isSubmitted=false
    // }
  }

  keypressLetters(event: any) {
    //return this.commonService.enterOnlyAlphabets(event);

    return this.commonService.enterOnlyAlphabetsNoSpace(event);
  }

  validateAadhar(event: any) {
    if (event.target.value != "") {
      this.persnDltsForm.controls['prnlaadhaarNo1'].setValidators(Validators.pattern(/[0-9\s]{14}/))
    }
    else {
      this.persnDltsForm.controls['prnlaadhaarNo1'].clearValidators();
    }
    this.persnDltsForm.controls['prnlaadhaarNo1'].updateValueAndValidity();
    return this.commonService.validateAadhar(event);

  }

  selectTitle(event: any) {
    let applicantTitle = event.target.value;
    this.commonService.storeInLocalStorage('registerData', { applicantTitle: applicantTitle })
  }


  getAadhaarNumber(value: any) {
    if(value != undefined){
      let str1 = String(value).slice(0, 4);
      let str2 = String(value).slice(4, 8);
      let str3 = String(value).slice(8, 12)
      return `${str1} ${str2} ${str3}`
    }
    else{
      return ''
    }
  }

  submitPersnalDtls() {

    let addharNumberArr = String(this.persnDltsForm.get("prnlaadhaarNo1").value).split(' ');
    let addhaarNumber = addharNumberArr.join('');

    let Obj = {
      applicant_personal_id: this?.regObj?.guardianApplicantID,
      applicant_id: this?.regObj?.guardianApplicantID,
      account_type_id: this?.regObj?.account_type_id,

      process_id: 44,
      applicant_title: this.persnDltsForm.get('prnltitle')?.value,
      applicant_first_name: this.persnDltsForm.get('prnlFirstName')?.value,
      applicant_middle_name: this.persnDltsForm.get('prnlMiddleName')?.value,
      applicant_last_name: this.persnDltsForm.get('prnlLastName')?.value,
      aadhaar_number: Number(addhaarNumber),
      guardian_relation: this.persnDltsForm.get('relminor')?.value,
      date_of_birth: this.customerDataService.formatDob(this.persnDltsForm.get('prnlDOb')?.value),
      acceptterms: this.persnDltsForm.get('acceptterms')?.value,
      acceptwithdrawl: this.persnDltsForm.get('acceptwithdrawl')?.value,
      guardian_customer_id: this?.regObj?.mobile_no,
      user_id: this?.regObj?.user_id
    }

    this.customerDataService.postGuardianDtls(Obj).subscribe((data) => {
      console.log("aplicant data", data);
      
      this.commonService.storeInLocalStorage('registerData', { guardianApplicantID: data?.applicant_id, applicantSerialNum: data?.applicant_serial_num })
      if (this.commonService.getUserFromLocalStorage()?.leadStatus !== undefined || this.commonService.getUserFromLocalStorage()?.leadStatus !== 'undefined' || this.commonService.getUserFromLocalStorage()?.leadStatus !== null) {

        this.rt.navigate(["/minor-accnt", "personal-dtls1-guardian"]);
      } else {

        this.rt.navigate(["/feedback", "feedback-summary"]);
      }
    })

    //this.rt.navigate(["/individual-account", "personal-dtls2"]);
    /*}else{
      
    }*/
  }
}