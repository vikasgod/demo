import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DocAddrsProof1GuardianComponent } from './doc-addrs-proof1-guardian.component';

describe('DocAddrsProof1GuardianComponent', () => {
  let component: DocAddrsProof1GuardianComponent;
  let fixture: ComponentFixture<DocAddrsProof1GuardianComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DocAddrsProof1GuardianComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DocAddrsProof1GuardianComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
