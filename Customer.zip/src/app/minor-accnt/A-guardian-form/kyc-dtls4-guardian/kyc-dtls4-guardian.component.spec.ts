import { ComponentFixture, TestBed } from '@angular/core/testing';

import { KycDtls4GuardianComponent } from './kyc-dtls4-guardian.component';

describe('KycDtls4GuardianComponent', () => {
  let component: KycDtls4GuardianComponent;
  let fixture: ComponentFixture<KycDtls4GuardianComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ KycDtls4GuardianComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(KycDtls4GuardianComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
