import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DocAddrsProof3GuardianComponent } from './doc-addrs-proof3-guardian.component';

describe('DocAddrsProof3GuardianComponent', () => {
  let component: DocAddrsProof3GuardianComponent;
  let fixture: ComponentFixture<DocAddrsProof3GuardianComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DocAddrsProof3GuardianComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DocAddrsProof3GuardianComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
