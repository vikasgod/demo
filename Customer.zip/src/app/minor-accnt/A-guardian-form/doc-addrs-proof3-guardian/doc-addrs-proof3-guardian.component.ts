import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { CommonService } from 'src/app/services/common.service';
import { CustomerDataService } from 'src/app/services/customer-data.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-doc-addrs-proof3-guardian',
  templateUrl: './doc-addrs-proof3-guardian.component.html',
  styleUrls: ['./doc-addrs-proof3-guardian.component.css']
})
export class DocAddrsProof3GuardianComponent implements OnInit {

  docAddressGuardianCFrom: any;
  titleArrData: any;
  countryData: any;
  regObj: any;
  constructor(private fb: FormBuilder, private commonService: CommonService, private customerDataService: CustomerDataService, private rt: Router) { }
  ngOnInit(): void {



    let Obj = {
      applicant_id:this.commonService.getUserFromLocalStorage()?.guardianApplicantID,
      process_id: 62
    }

    this.customerDataService.fetchAddressProofDocRelative(Obj).subscribe((value) => {

      
     if(value?.data?.length>0)
     {
      this.docAddressGuardianCFrom = this.fb.group({
        docAddressProofCTitle: [value?.data?.[0].declarant_title, [Validators.required]],
        docAddressProofCFirstName: [value?.data?.[0].declarant_first_name, [Validators.required]],
        docAddressProofCMiddleName: [value?.data?.[0].declarant_middle_name, [Validators.required]],
        docAddressProofCLastName: [value?.data?.[0].declarant_last_name, [Validators.required]],

        // docAddressProofCAaddrsType: [value?.data?.[0].countrie_name, [Validators.required]],
        docAddressProofCAaddrsHuseNo: [value?.data?.[0].declarant_house_number, [Validators.required]],
        docAddressProofCAaddrsBuldNm: [value?.data?.[0].declarant_house_and_building_name, [Validators.required]],
        docAddressProofCAaddrsRdNm: [value?.data?.[0].countrie_name, [Validators.required]],
        docAddressProofCAaddrsLndMrk: [value?.data?.[0].declarant_road_or_street_name, [Validators.required]],
        docAddressProofCAaddrsCntry: [value?.data?.[0].declarant_country_id, [Validators.required]],
        docAddressProofCAaddrsState: [value?.data?.[0].declarant_state, [Validators.required]],
        docAddressProofCAaddrsCity: [value?.data?.[0].declarant_city, [Validators.required]],
        docAddressProofCAaddrsPnCd: [value?.data?.[0].declarant_pincode, [Validators.required, Validators.pattern(/[0-9]{6}/)]],

        docAddressProofCRelApplicnt: [value?.data?.[0].declarant_relation, [Validators.required]]
      });

     }

      

    })


    this.docAddressGuardianCFrom = this.fb.group({
      docAddressProofCTitle: ['', [Validators.required]],
      docAddressProofCFirstName: ['', [Validators.required]],
      docAddressProofCMiddleName: ['', [Validators.required]],
      docAddressProofCLastName: ['', [Validators.required]],

      // docAddressProofCAaddrsType: ['', [Validators.required]],
      docAddressProofCAaddrsHuseNo: ['', [Validators.required]],
      docAddressProofCAaddrsBuldNm: ['', [Validators.required]],
      docAddressProofCAaddrsRdNm: ['', [Validators.required]],
      docAddressProofCAaddrsLndMrk: ['', [Validators.required]],
      docAddressProofCAaddrsCntry: ['', [Validators.required]],
      docAddressProofCAaddrsState: ['', [Validators.required]],
      docAddressProofCAaddrsCity: ['', [Validators.required]],
      docAddressProofCAaddrsPnCd: ['', [Validators.required, Validators.pattern(/[0-9]{6}/)]],

      docAddressProofCRelApplicnt: ['', [Validators.required]]
    });


    this.customerDataService.getTitle().subscribe((value) => {
      this.titleArrData = value
    })


    this.customerDataService.getCountry().subscribe((value) => {
      this.countryData = value
    })



  }




  get docAddressProofCTitle() { return this.docAddressGuardianCFrom.get("docAddressProofCTitle") }
  get docAddressProofCFirstName() { return this.docAddressGuardianCFrom.get("docAddressProofCFirstName") }
  get docAddressProofCMiddleName() { return this.docAddressGuardianCFrom.get("docAddressProofCMiddleName") }
  get docAddressProofCLastName() { return this.docAddressGuardianCFrom.get("docAddressProofCLastName") }

  // get docAddressProofCAaddrsType() { return this.docAddressGuardianCFrom.get("docAddressProofCAaddrsType") }
  get docAddressProofCAaddrsHuseNo() { return this.docAddressGuardianCFrom.get("docAddressProofCAaddrsHuseNo") }
  get docAddressProofCAaddrsBuldNm() { return this.docAddressGuardianCFrom.get("docAddressProofCAaddrsBuldNm") }
  get docAddressProofCAaddrsRdNm() { return this.docAddressGuardianCFrom.get("docAddressProofCAaddrsRdNm") }
  get docAddressProofCAaddrsLndMrk() { return this.docAddressGuardianCFrom.get("docAddressProofCAaddrsLndMrk") }
  get docAddressProofCAaddrsCntry() { return this.docAddressGuardianCFrom.get("docAddressProofCAaddrsCntry") }
  get docAddressProofCAaddrsState() { return this.docAddressGuardianCFrom.get("docAddressProofCAaddrsState") }
  get docAddressProofCAaddrsCity() { return this.docAddressGuardianCFrom.get("docAddressProofCAaddrsCity") }
  get docAddressProofCAaddrsPnCd() { return this.docAddressGuardianCFrom.get("docAddressProofCAaddrsPnCd") }
  get docAddressProofCRelApplicnt() { return this.docAddressGuardianCFrom.get("docAddressProofCRelApplicnt") }






  keypressNumber(event: any) {
    return this.commonService.enterOnlyNumber(event);
  }

  keypressAlphabets(event: any) {
    return this.commonService.enterOnlyAlphabets(event);
  }


  submitAddressProof3Guardian() {

    if (this.docAddressGuardianCFrom.valid) {
      console.log("This is valid address proof", this.docAddressGuardianCFrom.value);
      this.regObj = this.commonService.getUserFromLocalStorage();


     // if(this.regObj.isSubmited || this.regObj.leadReviewStatus != "customer_process")
    // {
    // this.rt.navigate(["/minor-accnt","ending"]);
    // }



      let Obj = {

        /*
        this.docAddressGuardianCFrom.get("docAddressProofCTitle")
        this.docAddressGuardianCFrom.get("docAddressProofCFirstName")
        this.docAddressGuardianCFrom.get("docAddressProofCMiddleName")
        this.docAddressGuardianCFrom.get("docAddressProofCLastName")
        this.docAddressGuardianCFrom.get("docAddressProofCAaddrsType")
        this.docAddressGuardianCFrom.get("docAddressProofCAaddrsHuseNo")
        this.docAddressGuardianCFrom.get("docAddressProofCAaddrsBuldNm")
        this.docAddressGuardianCFrom.get("docAddressProofCAaddrsRdNm")
        this.docAddressGuardianCFrom.get("docAddressProofCAaddrsLndMrk")
        this.docAddressGuardianCFrom.get("docAddressProofCAaddrsCntry")
        this.docAddressGuardianCFrom.get("docAddressProofCAaddrsState")
        this.docAddressGuardianCFrom.get("docAddressProofCAaddrsCity")
        this.docAddressGuardianCFrom.get("docAddressProofCAaddrsPnCd")
        this.docAddressGuardianCFrom.get("docAddressProofCRelApplicnt")
         */


        // Address Type and landmark is missing

        applicant_personal_id: this.commonService.getUserFromLocalStorage()?.guardianApplicantID,      
        applicant_serial_num:this.commonService.getUserFromLocalStorage()?.applicantSerialNum,
        user_id: this.regObj?.user_id,
        applicant_id: this.commonService.getUserFromLocalStorage()?.guardianApplicantID,
        
        process_id: 62,
        declarant_title: this.docAddressGuardianCFrom.get("docAddressProofCTitle").value,
        declarant_first_name: this.docAddressGuardianCFrom.get("docAddressProofCFirstName").value,
        declarant_middle_name: this.docAddressGuardianCFrom.get("docAddressProofCMiddleName").value,
        declarant_last_name: this.docAddressGuardianCFrom.get("docAddressProofCLastName").value,
        declarant_house_number: this.docAddressGuardianCFrom.get("docAddressProofCAaddrsHuseNo").value,
        declarant_house_and_building_name: this.docAddressGuardianCFrom.get("docAddressProofCAaddrsBuldNm").value,
        declarant_landmark: this.docAddressGuardianCFrom.get("docAddressProofCAaddrsLndMrk").value,
        declarant_road_or_street_name: this.docAddressGuardianCFrom.get("docAddressProofCAaddrsRdNm").value,
        declarant_state: this.docAddressGuardianCFrom.get("docAddressProofCAaddrsState").value,
        declarant_city: this.docAddressGuardianCFrom.get("docAddressProofCAaddrsCity").value,
        declarant_country_id: this.docAddressGuardianCFrom.get("docAddressProofCAaddrsCntry").value,
        declarant_pincode: this.docAddressGuardianCFrom.get("docAddressProofCAaddrsPnCd").value,
        declarant_relation: this.docAddressGuardianCFrom.get("docAddressProofCRelApplicnt").value,

      }


      this.customerDataService.postCustomerAddressProofRelative(Obj).subscribe((value) => {
        //this.rt.navigate(['/individual-account','doc-address-proof2']);
        this.rt.navigate(['/minor-accnt', 'document-upload1-guardian']);
        //
      })

    } else {
      console.log("This is invalid address proof");
    }

  }


}