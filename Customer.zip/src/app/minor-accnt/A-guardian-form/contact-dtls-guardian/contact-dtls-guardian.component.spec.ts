import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ContactDtlsGuardianComponent } from './contact-dtls-guardian.component';

describe('ContactDtlsGuardianComponent', () => {
  let component: ContactDtlsGuardianComponent;
  let fixture: ComponentFixture<ContactDtlsGuardianComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ContactDtlsGuardianComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ContactDtlsGuardianComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
