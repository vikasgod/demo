import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { CommonService } from 'src/app/services/common.service';
import { CustomerDataService } from 'src/app/services/customer-data.service';

@Component({
  selector: 'app-contact-dtls-guardian',
  templateUrl: './contact-dtls-guardian.component.html',
  styleUrls: ['./contact-dtls-guardian.component.css']
})
export class ContactDtlsGuardianComponent implements OnInit {

  contactDtlsGuardianForm: any;
  regObj: any;
  contact_details_id: any;
  mobileNo: any;
  isdCode: any;
  emailID: string = '';
  isDisplayUpdateBtn: boolean = false;
  constructor(private rt: Router, private fb: FormBuilder, private commonService: CommonService, private customerDataService: CustomerDataService) { }


  ngOnInit(): void {
    this.regObj = this.commonService.getUserFromLocalStorage();

    if (this.regObj.isSubmited || (this.regObj.leadReviewStatus != "customer_process" && this.regObj.leadReviewStatus != "agent_review" )) {
      this.rt.navigate(["/minor-accnt", "ending"]);
    }


    // if (this.commonService.getUserFromLocalStorage()?.leadReviewStatus === undefined) {
    //   this.isDisplayUpdateBtn = false;
    // } else {
    //   this.isDisplayUpdateBtn = true;
    // }


    let Obj = {
      applicant_id: this.commonService.getUserFromLocalStorage()?.guardianApplicantID,
      process_id: 52
    }

    this.customerDataService.fetchContactDtls(Obj).subscribe((value) => {
      if(value.data.length > 0){
        this.isDisplayUpdateBtn = true;
      }
      this.regObj = this.commonService.getUserFromLocalStorage();

      if (this.regObj.mobile_no === undefined || this.regObj.mobile_no === "undefined" || this.regObj.mobile_no === "") {
        this.mobileNo = value?.data?.[0]?.mobile_number
      }
       else {
        this.mobileNo = this.regObj?.mobile_no;
      }

      if (this.regObj.isd_code === undefined || this.regObj.isd_code === "undefined" || this.regObj.isd_code === "") {
        this.isdCode = value?.data?.[0]?.country_code;
      } 
      else {
        this.isdCode = this.regObj.isd_code;
      }

      if (this.regObj.email_address === undefined || this.regObj.email_address === "undefined" || this.regObj.email_address === "") {
        this.emailID = value?.data?.[0]?.email_address;
      } 
      else {
        this.emailID = this.regObj.email_address;
      }

      this.contactDtlsGuardianForm = this.fb.group({
        contactDtlsOfficeCntryCd: [value?.data?.[0]?.office_country_code],
        contactDtlsOfficeStdCd: [value?.data?.[0]?.office_std_code],
        contactDtlsOfficeTelNo: [value?.data?.[0]?.office_tel_number],
        contactDtlsResidenceCntryCd: [value?.data?.[0]?.residence_country_code],
        contactDtlsResidenceStdCd: [value?.data?.[0]?.residence_std_code],
        contactDtlsResidenceTelNo: [value?.data?.[0]?.residence_tel_number],
        contactDtlsMobileISDCd: [this.isdCode, [Validators.required]],
        contactDtlsMobileTelNo: [this.mobileNo, [Validators.required]],
        contactDtlsFaxCntryCd: [value?.data?.[0]?.fax_country_code],
        contactDtlsFaxStdCd: [value?.data?.[0]?.fax_std_code],
        contactDtlsFaxTelNo: [value?.data?.[0]?.fax_number],
        contactDtlsEmailID: [this.emailID, [Validators.email]],
      })


      if (value?.data?.[0]?.contact_details_id === 'undefined' || value?.data?.[0]?.contact_details_id === undefined) {
        this.contact_details_id = "undefined"
      } else {
        this.contact_details_id = value?.data?.[0]?.contact_details_id
      }


    })


    this.contactDtlsGuardianForm = this.fb.group({
      contactDtlsOfficeCntryCd: [],
      contactDtlsOfficeStdCd: [],
      contactDtlsOfficeTelNo: [],
      contactDtlsResidenceCntryCd: [],
      contactDtlsResidenceStdCd: [],
      contactDtlsResidenceTelNo: [],
      contactDtlsMobileISDCd: ['', [Validators.required]],
      contactDtlsMobileTelNo: ['', [Validators.required]],
      contactDtlsFaxCntryCd: [''],
      contactDtlsFaxStdCd: [''],
      contactDtlsFaxTelNo: [''],
      contactDtlsEmailID: ['', [Validators.email]],
    })
  }

  get contactDtlsOfficeCntryCd() { return this.contactDtlsGuardianForm.get("contactDtlsOfficeCntryCd") }
  get contactDtlsOfficeStdCd() { return this.contactDtlsGuardianForm.get("contactDtlsOfficeStdCd") }
  get contactDtlsOfficeTelNo() { return this.contactDtlsGuardianForm.get("contactDtlsOfficeTelNo") }
  get contactDtlsResidenceCntryCd() { return this.contactDtlsGuardianForm.get("contactDtlsResidenceCntryCd") }
  get contactDtlsResidenceStdCd() { return this.contactDtlsGuardianForm.get("contactDtlsResidenceStdCd") }
  get contactDtlsResidenceTelNo() { return this.contactDtlsGuardianForm.get("contactDtlsResidenceTelNo") }
  get contactDtlsMobileISDCd() { return this.contactDtlsGuardianForm.get("contactDtlsMobileISDCd") }
  get contactDtlsMobileTelNo() { return this.contactDtlsGuardianForm.get("contactDtlsMobileTelNo") }
  get contactDtlsFaxCntryCd() { return this.contactDtlsGuardianForm.get("contactDtlsFaxCntryCd") }
  get contactDtlsFaxStdCd() { return this.contactDtlsGuardianForm.get("contactDtlsFaxStdCd") }
  get contactDtlsFaxTelNo() { return this.contactDtlsGuardianForm.get("contactDtlsFaxTelNo") }
  get contactDtlsEmailID() { return this.contactDtlsGuardianForm.get("contactDtlsEmailID") }



  keypressHyphenNumber(event: any) {
    return this.commonService.enterOnlyNumber(event);
  }

  validateISD(event: any) {
    return this.commonService.validateISD(event);
  }

  keyPressMobile(event: any) {
    return this.commonService.enterOnlyNumber(event)
  }

  submitContactDtlsGuardian() {
    if (this.contactDtlsGuardianForm.valid) {

      this.regObj = this.commonService.getUserFromLocalStorage();
      console.log("This Obj", this.regObj.guardianApplicantID);
      /*
        this.contactDtlsGuardianForm.get("contactDtlsOfficeCntryCd").value
        this.contactDtlsGuardianForm.get("contactDtlsOfficeStdCd").value
        this.contactDtlsGuardianForm.get("contactDtlsOfficeTelNo").value
        this.contactDtlsGuardianForm.get("contactDtlsResidenceCntryCd").value
        this.contactDtlsGuardianForm.get("contactDtlsResidenceStdCd").value
        this.contactDtlsGuardianForm.get("contactDtlsResidenceTelNo").value
        this.contactDtlsGuardianForm.get("contactDtlsMobileISDCd").value
        this.contactDtlsGuardianForm.get("contactDtlsMobileTelNo").value
        this.contactDtlsGuardianForm.get("contactDtlsFaxCntryCd").value
        this.contactDtlsGuardianForm.get("contactDtlsFaxStdCd").value
        this.contactDtlsGuardianForm.get("contactDtlsFaxTelNo").value
        this.contactDtlsGuardianForm.get("contactDtlsEmailID").value
        */

      let Obj = {
        applicant_personal_id: this.commonService.getUserFromLocalStorage()?.guardianApplicantID,
        applicant_id: this.commonService.getUserFromLocalStorage()?.guardianApplicantID,
        applicant_serial_num: this.commonService.getUserFromLocalStorage()?.applicantSerialNum,
        user_id: this.regObj?.user_id,

        process_id: 52,
        contact_details_id: this.contact_details_id,
        office_country_code: this.contactDtlsGuardianForm.get("contactDtlsOfficeCntryCd").value,
        office_std_code: this.contactDtlsGuardianForm.get("contactDtlsOfficeStdCd").value,
        office_tel_number: Number(this.contactDtlsGuardianForm.get("contactDtlsOfficeTelNo").value),
        country_code: this.contactDtlsGuardianForm.get("contactDtlsMobileISDCd").value,
        mobile_number: Number(this.contactDtlsGuardianForm.get("contactDtlsMobileTelNo").value),
        fax_country_code: this.contactDtlsGuardianForm.get("contactDtlsFaxCntryCd").value,
        fax_std_code: this.contactDtlsGuardianForm.get("contactDtlsFaxStdCd").value,
        fax_number: Number(this.contactDtlsGuardianForm.get("contactDtlsFaxTelNo").value),
        email_address: this.contactDtlsGuardianForm.get("contactDtlsEmailID").value,
        residence_std_code: this.contactDtlsGuardianForm.get("contactDtlsResidenceStdCd").value,
        residence_country_code: this.contactDtlsGuardianForm.get("contactDtlsResidenceCntryCd").value,
        residence_tel_number: Number(this.contactDtlsGuardianForm.get("contactDtlsResidenceTelNo").value)
      }


      this.customerDataService.postContactDtls(Obj).subscribe((data) => {
        if (this.commonService.getUserFromLocalStorage()?.leadReviewStatus !='agent_review') {
          this.rt.navigate(["/minor-accnt", "addrs-dtls1-guardian"])
        } 
        else {
          this.rt.navigate(["/feedback", "feedback-summary"]);
        }
      })
    }
    else {
      console.log("This is invalid form");
    }
  }

}