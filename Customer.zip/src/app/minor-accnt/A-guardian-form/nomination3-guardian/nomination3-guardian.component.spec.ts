import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Nomination3GuardianComponent } from './nomination3-guardian.component';

describe('Nomination3GuardianComponent', () => {
  let component: Nomination3GuardianComponent;
  let fixture: ComponentFixture<Nomination3GuardianComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ Nomination3GuardianComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(Nomination3GuardianComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
