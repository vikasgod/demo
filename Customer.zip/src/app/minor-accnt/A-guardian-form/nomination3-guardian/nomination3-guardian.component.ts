import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { CommonService } from 'src/app/services/common.service';
import { CustomerDataService } from 'src/app/services/customer-data.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-nomination3-guardian',
  templateUrl: './nomination3-guardian.component.html',
  styleUrls: ['./nomination3-guardian.component.css']
})
export class Nomination3GuardianComponent implements OnInit {

  nominationGuardianCFrom: any;
  regObj: any;
  titleArrData: any;
  isDisplayUpdateBtn: boolean = false;
  constructor(private fb: FormBuilder, private commonService: CommonService, private customerDataService: CustomerDataService, private rt: Router) { }

  ngOnInit(): void {
    this.regObj = this.commonService.getUserFromLocalStorage();
    if (this.regObj.isSubmited || this.regObj.leadReviewStatus != "customer_process") {
      this.rt.navigate(["minor-accnt", "ending"]);
    }

    // if (this.commonService.getUserFromLocalStorage()?.leadReviewStatus === undefined) {
    //   this.isDisplayUpdateBtn = false;
    // } else {
    //   this.isDisplayUpdateBtn = true;
    // }

    let Obj = {
      applicant_id: this.commonService.getUserFromLocalStorage()?.guardianApplicantID,
      process_id: 69,
      nomination_id: this?.regObj?.nomination_id
    }

    this.customerDataService.fetchNomination3(Obj).subscribe((value) => {

      if (value?.data?.length > 0) {
        this.isDisplayUpdateBtn = true;
        this.nominationGuardianCFrom = this.fb.group({
          nominationAgeYrs: [this.regObj?.nomineeAgeYears === undefined || this.regObj?.nomineeAgeYears === 'undefined' ? '' : this.regObj?.nomineeAgeYears, [Validators.required]],
          nominationAgeMonths: [this.regObj?.nomineeAgeYears === undefined || this.regObj?.nomineeAgeMonths === 'undefined' ? '' : this.regObj?.nomineeAgeMonths, [Validators.required]],
          nominationCtitle: [value.data?.[0]?.gaurdian_title, [Validators.required]],
          nominationCFirstName: [value.data?.[0]?.gaurdian_first_name, [Validators.required]],
          nominationCMiddleName: [value.data?.[0]?.gaurdian_middle_name, [Validators.required]],
          nominationCLastName: [value.data?.[0]?.gaurdian_last_name, [Validators.required]],
        })
      }
    })

    this.nominationGuardianCFrom = this.fb.group({
      nominationAgeYrs: [this.regObj?.nomineeAgeYears, [Validators.required]],
      nominationAgeMonths: [this.regObj?.nomineeAgeMonths, [Validators.required]],
      nominationCtitle: ['', [Validators.required]],
      nominationCFirstName: ['', [Validators.required]],
      nominationCMiddleName: ['', [Validators.required]],
      nominationCLastName: ['', [Validators.required]],
    })

    this.customerDataService.getTitle().subscribe((data) => {
      this.titleArrData = data
    })
  }

  get nominationAgeYrs() { return this.nominationGuardianCFrom.get("nominationAgeYrs") }
  get nominationAgeMonths() { return this.nominationGuardianCFrom.get("nominationAgeMonths") }
  get nominationCtitle() { return this.nominationGuardianCFrom.get("nominationCtitle") }
  get nominationCFirstName() { return this.nominationGuardianCFrom.get("nominationCFirstName") }
  get nominationCMiddleName() { return this.nominationGuardianCFrom.get("nominationCMiddleName") }
  get nominationCLastName() { return this.nominationGuardianCFrom.get("nominationCLastName") }

  keypressAlphabets(event: any) {
    return this.commonService.enterOnlyAlphabetsNoSpace(event);
    //return this.commonService.enterOnlyAlphabets(event);
  }

  keypressNumbers(event: any) {
    return this.commonService.enterOnlyNumber(event);
  }

  submitNomination3Guardian() {
    if (this.nominationGuardianCFrom.valid) {
      this.regObj = this.commonService.getUserFromLocalStorage();
      let Obj = {
        applicant_id: this.commonService.getUserFromLocalStorage()?.guardianApplicantID,
        applicant_serial_num: this.commonService.getUserFromLocalStorage()?.applicantSerialNum,
        user_id: this.regObj?.user_id,
        applicant_personal_id: this.commonService.getUserFromLocalStorage()?.guardianApplicantID,
        nomination_id: Number(this.regObj.nomination_id),
        process_id: 69,
        nominee_age_in_month: Number(this.nominationGuardianCFrom.get("nominationAgeMonths").value),
        nominee_age_in_year: Number(this.nominationGuardianCFrom.get("nominationAgeYrs").value),
        gaurdian_title: this.nominationGuardianCFrom.get("nominationCtitle").value,
        gaurdian_first_name: this.nominationGuardianCFrom.get("nominationCFirstName").value,
        gaurdian_middle_name: this.nominationGuardianCFrom.get("nominationCMiddleName").value,
        gaurdian_last_name: this.nominationGuardianCFrom.get("nominationCLastName").value
      }

      this.customerDataService.postNomination3(Obj).subscribe((data) => {

        if (this.commonService.getUserFromLocalStorage()?.leadReviewStatus === 'customer_process') {
          this.rt.navigate(['/minor-accnt', 'declaration1-guardian']);
        } 
        else {
          this.rt.navigate(["/feedback", "feedback-summary"]);
        }
        //  this.rt.navigate(['/individual-account','declaration1']);
      })
    } 
    else {
      console.log("This is invalid form");
    }
  }

}
