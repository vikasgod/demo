import { ComponentFixture, TestBed } from '@angular/core/testing';

import { InterBank1GuardianComponent } from './inter-bank1-guardian.component';

describe('InterBank1GuardianComponent', () => {
  let component: InterBank1GuardianComponent;
  let fixture: ComponentFixture<InterBank1GuardianComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ InterBank1GuardianComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(InterBank1GuardianComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
