import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { Router } from '@angular/router';
import { Observable, of } from 'rxjs';
import { CommonService } from 'src/app/services/common.service';
import { CustomerDataService } from 'src/app/services/customer-data.service';

@Component({
  selector: 'app-document-upload1-guardian',
  templateUrl: './document-upload1-guardian.component.html',
  styleUrls: ['./document-upload1-guardian.component.css']
})
export class DocumentUpload1GuardianComponent implements OnInit {
  isDisplayForm60: boolean = true;
  isTypeOfPassportDoc: boolean = true;
  isDisplayPIO: boolean = true;
  isDisplayVisa: boolean = true;
  isResidencePermitDoc: boolean = true
  imgSrcVisaOrOci: string = '';

  isOtherThanIndianPassport:string ='';

  showInfoDetail:string = '';

  addressProofDoc: any;
  regObj: any;
  imgSrcPsportFront: string = '';
  imgSrcPsportBack: string = '';
  imgSrcAddressProof: string = '';
  imgSrcFrom60: string = '';
  imgSrcOci: string = '';
  imgSrcPio1: string = '';
  imgSrcPio2: string = '';
  imgSrcOtherDoc: string = '';
  passportFront$: Observable<any> = of();
  passportBack$: Observable<any> = of();
  display: string = "none";
  docValidPassportErr: string = '';
  isDisplayAddressProofUpload: boolean = true;
  @ViewChild('addressProofddl')
  addressProofddl!: ElementRef;
  renderer: any;
  validpassport: boolean = false;
  docupload: any = '';
  isDisabled: boolean = true;
  addressProofSelect: boolean = true;
  isDisplayUpdateBtn: boolean = false;

  constructor(private rt: Router, private commonService: CommonService, private customerDataService: CustomerDataService) {
  }

  ngOnInit(): void {
    this.regObj = this.commonService.getUserFromLocalStorage();

    this.customerDataService.getAddressProofDoc().subscribe((value) => {
      if (value.length < 0) {
        this.isDisplayUpdateBtn = true;
      }
      else {
        this.isDisplayUpdateBtn = false;
      }
      if (this.validpassport == true) {
        let index = value.address_proof_types.findIndex((res: any) => res.name == "Valid Passport")
        value.address_proof_types.splice(index, 1)
      }
      this.addressProofDoc = value.address_proof_types;
    })
    this.addAdressProof()

    let Obj1 = {
      applicant_id: this.regObj.guardianApplicantID,
      document: "passport_front"
    }

    this.customerDataService.postCustomerGetDoc(Obj1).subscribe((value) => {
      this.imgSrcPsportFront = value?.file_path;
    });

    let Obj2 = {
      applicant_id: this.regObj.guardianApplicantID,
      document: "passport_back"
    }
    this.customerDataService.postCustomerGetDoc(Obj2).subscribe((value) => {
      this.imgSrcPsportBack = value?.file_path;
    });

    let Obj3 = {
      applicant_id: this.regObj.guardianApplicantID,
      document: "address_proof"
    }
    this.customerDataService.postCustomerGetDoc(Obj3).subscribe((value) => {
      this.imgSrcAddressProof = value?.[0]?.file_path;
    });

    let Obj4 = {
      applicant_id: this.regObj.guardianApplicantID,
      document: "form_sixty"
    }
    this.customerDataService.postCustomerGetDoc(Obj4).subscribe((value) => {
      this.imgSrcFrom60 = value?.file_path;
    });

    let Obj5 = {
      applicant_id: this.regObj.guardianApplicantID,
      document: "oci"
    }
    this.customerDataService.postCustomerGetDoc(Obj5).subscribe((value) => {

      this.imgSrcOci = value?.file_path;
    }, (err) => {

    });

    let Obj6 = {
      applicant_id: this.regObj.guardianApplicantID,
      document: "visa"
    }
    this.customerDataService.postCustomerGetDoc(Obj6).subscribe((value) => {
      this.imgSrcVisaOrOci = value?.file_path;
    }, (err) => {

    });

    let Obj7 = {
      applicant_id: this.regObj.guardianApplicantID,
      document: "old_indian_passport_front"
    }
    this.customerDataService.postCustomerGetDoc(Obj7).subscribe((value) => {
      this.imgSrcPio1 = value?.file_path;
    }, (err) => {

    });

    let Obj8 = {
      applicant_id: this.regObj.guardianApplicantID,
      document: "old_indian_passport_back"
    }
    this.customerDataService.postCustomerGetDoc(Obj8).subscribe((value) => {
      this.imgSrcPio2 = value?.file_path;
    }, (err) => {

    });

    let Obj9 = {
      applicant_id: this.regObj.guardianApplicantID,
      document: "other"
    }
    this.customerDataService.postCustomerGetDoc(Obj9).subscribe((value) => {
      this.imgSrcOtherDoc = value[0]?.file_path;
    }, (err) => {

    });

    let Obj = {
      applicant_id: this.regObj.guardianApplicantID
    }
    this.customerDataService.postCustomerDocumentCondition(Obj).subscribe((value) => {
      console.log(value.data[0]);

      if(value.data[0].address_proof_id == 0 || value.data[0].address_proof_id == '' || value.data[0].address_proof_id== null){
        this.docupload = ''
        this.addressProofSelect = true
      } 
      else{
        this.docupload = value.data[0].address_proof_id
        this.addressProofSelect = false;
      }

      if (value.data[0].is_form_60 == 0 || value.data[0].is_form_60 == undefined || value.data[0].is_form_60 == '' || value.data[0].is_form_60 == false) {
        this.isDisplayForm60 = false;
      }

      if (value.data[0].visa_type == 1 || value.data[0].visa_type == undefined || value.data[0].visa_type == "" || value.data[0].visa_type == 0) {
        this.isTypeOfPassportDoc = false;
        this.isDisplayVisa = false
      }

      if (value.data[0].is_pio == undefined || value.data[0].is_pio == "" || value.data[0].is_pio == 0) {
        this.isDisplayPIO = false;
      }

    }, (err) => {

    });


    // changing text Indian to foreign for other than passport
    let Obj0 = {
      applicant_id: this.regObj.guardianApplicantID,
      process_id: 48
    }

    this.customerDataService.fetchKycDtls1(Obj0).subscribe((data)=>{
     this.isOtherThanIndianPassport = data?.data?.map((data:any)=>{
       return data?.is_other_than_indian_passport_name === "yes"? "Foreign":"Indian";
      })      
    })

  }

  ngAfterViewInit(): void {
    //this.addressProofddl.nativeElement.setValue('1')
  }

  addAdressProof() {
    if (this.docupload === '') {
      this.docValidPassportErr = 'Already uploaded passport';
      this.isDisplayAddressProofUpload = true;
    }
    if(this.docupload == 0 || this.docupload == '' || this.docupload == null){
      this.addressProofSelect = true
    } 
    else{
      this.addressProofSelect = false;
    }
  }

  redirectUploadPage(path1: string, path2: string) {
    this.rt.navigate([`${path1}`, `${path2}`])

  } 

  redirectDeclaration() {
    this.rt.navigate([`minor-accnt`, `declaration1-guardian`])
  }

  openModal() {
    this.display = "block";
  }
  onCloseHandled() {
    this.display = "none";
  }

  ///disable proceed 
  isProceedDisableBtn() {
    if (this.isDisplayForm60 && (this.imgSrcPsportFront == '' || this.imgSrcPsportBack == '' || this.imgSrcAddressProof == '' || this.imgSrcFrom60 == '')) {
      return true
    } else if (!this.isDisplayForm60 && (this.imgSrcPsportFront == '' || this.imgSrcPsportBack == '' || this.imgSrcAddressProof == '')) {
      return true
    } else {
      return false
    }
  }

  //  show info click on i-info button
  showInfoDetails(label: any) {
    this.showInfoDetail = label;
  }
}