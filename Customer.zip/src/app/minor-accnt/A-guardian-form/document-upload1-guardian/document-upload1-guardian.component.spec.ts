import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DocumentUpload1GuardianComponent } from './document-upload1-guardian.component';

describe('DocumentUpload1GuardianComponent', () => {
  let component: DocumentUpload1GuardianComponent;
  let fixture: ComponentFixture<DocumentUpload1GuardianComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DocumentUpload1GuardianComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DocumentUpload1GuardianComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
