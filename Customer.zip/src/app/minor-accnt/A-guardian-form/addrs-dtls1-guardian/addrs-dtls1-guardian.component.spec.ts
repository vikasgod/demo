import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddrsDtls1GuardianComponent } from './addrs-dtls1-guardian.component';

describe('AddrsDtls1GuardianComponent', () => {
  let component: AddrsDtls1GuardianComponent;
  let fixture: ComponentFixture<AddrsDtls1GuardianComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddrsDtls1GuardianComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AddrsDtls1GuardianComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
