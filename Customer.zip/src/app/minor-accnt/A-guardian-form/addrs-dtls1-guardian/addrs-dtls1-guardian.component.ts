import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { CommonService } from 'src/app/services/common.service';
import { CustomerDataService } from 'src/app/services/customer-data.service';

@Component({
  selector: 'app-addrs-dtls1-guardian',
  templateUrl: './addrs-dtls1-guardian.component.html',
  styleUrls: ['./addrs-dtls1-guardian.component.css']
})
export class AddrsDtls1GuardianComponent implements OnInit {
  countryData: any;
  addressTypeData: any;
  addrsDtlsAForm: any;
  regObj: any;
  isDisplayUpdateBtn: boolean = false;
  constructor(private rt: Router, private fb: FormBuilder, private commonService: CommonService, private customerDataService: CustomerDataService) { }

  ngOnInit(): void {

    this.regObj = this.commonService.getUserFromLocalStorage();
    if ((this.regObj.isSubmitted != undefined && this.regObj.isSubmitted != 0)
      || ((this.regObj.leadReviewStatus != undefined && this.regObj.leadReviewStatus != "customer_process")
        && (this.regObj.leadReviewStatus != undefined && this.regObj.leadReviewStatus != "agent_review"))
    ) {
      // this.rt.navigate(["/individual-account", "ending"]);
    }

    // if (this.commonService.getUserFromLocalStorage()?.leadReviewStatus === undefined) {
    //   this.isDisplayUpdateBtn = false;
    // }
    // else {
    //   this.isDisplayUpdateBtn = true;
    // }

    let Obj = {
      applicant_id: this.regObj.guardianApplicantID,
      process_id: 53
    }

    
    this.customerDataService.fetchAddressDtls1(Obj).subscribe((value) => {
      if (value?.data?.length > 0) {
        this.isDisplayUpdateBtn = true;
        this.addrsDtlsAForm = this.fb.group({
          addrsDtlsAaddrsType: [value?.data?.[0]?.current_address_type, [Validators.required]],
          addrsDtlsAaddrsHuseNo: [value?.data?.[0]?.current_house_number, [Validators.required]],
          addrsDtlsAaddrsBuldNm: [value?.data?.[0]?.current_house_or_building_name, [Validators.required]],
          addrsDtlsAaddrsRdNm: [value?.data?.[0]?.current_road_or_street_name, [Validators.required]],
          addrsDtlsAaddrsLndMrk: [value?.data?.[0]?.current_landmark, [Validators.required]],
          addrsDtlsAaddrsCntry: [value?.data?.[0]?.current_country_id, [Validators.required]],
          addrsDtlsAaddrsState: [value?.data?.[0]?.current_state, [Validators.required]],
          addrsDtlsAaddrsCity: [value?.data?.[0]?.current_city, [Validators.required]],
          addrsDtlsAaddrsPnCd: [value?.data?.[0]?.current_pincode, [Validators.required, Validators.pattern(/^[A-Za-z0-9\s]*$/)]],
          sameascurrentaddress: [],
          addrsDtlsOverseasAaddrsType: [value?.data?.[0]?.overseas_address_type==0?"":value?.data?.[0]?.overseas_address_type, [Validators.required]],
          addrsDtlsOverseasAaddrsHuseNo: [value?.data?.[0]?.overseas_house_number, [Validators.required]],
          addrsDtlsOverseasAaddrsBuldNm: [value?.data?.[0]?.overseas_house_or_building_name, [Validators.required]],
          addrsDtlsOverseasAaddrsRdNm: [value?.data?.[0]?.overseas_road_or_street_name, [Validators.required]],
          addrsDtlsOverseasAaddrsLndMrk: [value?.data?.[0]?.overseas_landmark, [Validators.required]],
          addrsDtlsOverseasAaddrsCntry: [value?.data?.[0]?.overseas_country_id==0?"":value?.data?.[0]?.overseas_country_id, [Validators.required]],
          addrsDtlsOverseasAaddrsState: [value?.data?.[0]?.overseas_state, [Validators.required]],
          addrsDtlsOverseasAaddrsCity: [value?.data?.[0]?.overseas_city, [Validators.required]],
          addrsDtlsOverseasAaddrsPnCd: [value?.data?.[0]?.overseas_pincode, [Validators.required, Validators.pattern(/^[A-Za-z0-9\s]*$/)]]
        })
        this.addrsDtlsAForm.controls['sameascurrentaddress'].setValue(this.isAddressSame())
      }
    })

    this.addrsDtlsAForm = this.fb.group({
      addrsDtlsAaddrsType: ['', [Validators.required]],
      addrsDtlsAaddrsHuseNo: ['', [Validators.required, Validators.minLength(2)]],
      addrsDtlsAaddrsBuldNm: ['', [Validators.required, Validators.minLength(2)]],
      addrsDtlsAaddrsRdNm: ['', [Validators.required]],
      addrsDtlsAaddrsLndMrk: ['', [Validators.required]],
      addrsDtlsAaddrsCntry: ['', [Validators.required]],
      addrsDtlsAaddrsState: ['', [Validators.required]],
      addrsDtlsAaddrsCity: ['', [Validators.required]],
      addrsDtlsAaddrsPnCd: ['', [Validators.required, Validators.pattern(/^[A-Za-z0-9\s]*$/)]],
      sameascurrentaddress: [''],
      addrsDtlsOverseasAaddrsType: ['', [Validators.required]],
      addrsDtlsOverseasAaddrsHuseNo: ['', [Validators.required, Validators.minLength(2)]],
      addrsDtlsOverseasAaddrsBuldNm: ['', [Validators.required, Validators.minLength(2)]],
      addrsDtlsOverseasAaddrsRdNm: ['', [Validators.required]],
      addrsDtlsOverseasAaddrsLndMrk: ['', [Validators.required]],
      addrsDtlsOverseasAaddrsCntry: ['', [Validators.required]],
      addrsDtlsOverseasAaddrsState: ['', [Validators.required]],
      addrsDtlsOverseasAaddrsCity: ['', [Validators.required]],
      addrsDtlsOverseasAaddrsPnCd: ['', [Validators.required, Validators.pattern(/^[A-Za-z0-9\s]*$/)]]
    })

    this.customerDataService.getAddressType().subscribe((data) => {
      this.addressTypeData = data;
    })

    this.customerDataService.getCountry().subscribe((data) => {
      this.countryData = data;
    })
  }

  get addrsDtlsAaddrsType() { return this.addrsDtlsAForm.get("addrsDtlsAaddrsType") }
  get addrsDtlsAaddrsHuseNo() { return this.addrsDtlsAForm.get("addrsDtlsAaddrsHuseNo") }
  get addrsDtlsAaddrsBuldNm() { return this.addrsDtlsAForm.get("addrsDtlsAaddrsBuldNm") }
  get addrsDtlsAaddrsRdNm() { return this.addrsDtlsAForm.get("addrsDtlsAaddrsRdNm") }
  get addrsDtlsAaddrsLndMrk() { return this.addrsDtlsAForm.get("addrsDtlsAaddrsLndMrk") }
  get addrsDtlsAaddrsCntry() { return this.addrsDtlsAForm.get("addrsDtlsAaddrsCntry") }
  get addrsDtlsAaddrsState() { return this.addrsDtlsAForm.get("addrsDtlsAaddrsState") }
  get addrsDtlsAaddrsCity() { return this.addrsDtlsAForm.get("addrsDtlsAaddrsCity") }
  get addrsDtlsAaddrsPnCd() { return this.addrsDtlsAForm.get("addrsDtlsAaddrsPnCd") }
  get addrsDtlsOverseasAaddrsType() { return this.addrsDtlsAForm.get("addrsDtlsOverseasAaddrsType") }
  get addrsDtlsOverseasAaddrsHuseNo() { return this.addrsDtlsAForm.get("addrsDtlsOverseasAaddrsHuseNo") }
  get addrsDtlsOverseasAaddrsBuldNm() { return this.addrsDtlsAForm.get("addrsDtlsOverseasAaddrsBuldNm") }
  get addrsDtlsOverseasAaddrsRdNm() { return this.addrsDtlsAForm.get("addrsDtlsOverseasAaddrsRdNm") }
  get addrsDtlsOverseasAaddrsLndMrk() { return this.addrsDtlsAForm.get("addrsDtlsOverseasAaddrsLndMrk") }
  get addrsDtlsOverseasAaddrsCntry() { return this.addrsDtlsAForm.get("addrsDtlsOverseasAaddrsCntry") }
  get addrsDtlsOverseasAaddrsState() { return this.addrsDtlsAForm.get("addrsDtlsOverseasAaddrsState") }
  get addrsDtlsOverseasAaddrsCity() { return this.addrsDtlsAForm.get("addrsDtlsOverseasAaddrsCity") }
  get addrsDtlsOverseasAaddrsPnCd() { return this.addrsDtlsAForm.get("addrsDtlsOverseasAaddrsPnCd") }

  keypressNumber(event: any) {
    return this.commonService.enterOnlyNumber(event);
  }

  keypressAlphabets(event: any) {
    //return this.commonService.enterOnlyAlphabets(event);
    return this.commonService.enterOnlyAlphabetsSpaceNBcktck(event)
  }

  checkSpecialChar(event: any) {
    return this.commonService.keypressSpecialChar(event)
  }

  isAddressSame() {

    if ((this.addrsDtlsAForm.get("addrsDtlsAaddrsType").value === this.addrsDtlsAForm.get("addrsDtlsOverseasAaddrsType").value) &&
      (this.addrsDtlsAForm.get("addrsDtlsAaddrsHuseNo").value === this.addrsDtlsAForm.get("addrsDtlsOverseasAaddrsHuseNo").value) &&
      (this.addrsDtlsAForm.get("addrsDtlsAaddrsBuldNm").value === this.addrsDtlsAForm.get("addrsDtlsOverseasAaddrsBuldNm").value) &&
      (this.addrsDtlsAForm.get("addrsDtlsAaddrsRdNm").value === this.addrsDtlsAForm.get("addrsDtlsOverseasAaddrsRdNm").value) &&
      (this.addrsDtlsAForm.get("addrsDtlsAaddrsLndMrk").value === this.addrsDtlsAForm.get("addrsDtlsOverseasAaddrsLndMrk").value) &&
      (this.addrsDtlsAForm.get("addrsDtlsAaddrsCntry").value === this.addrsDtlsAForm.get("addrsDtlsOverseasAaddrsCntry").value) &&
      (this.addrsDtlsAForm.get("addrsDtlsAaddrsState").value === this.addrsDtlsAForm.get("addrsDtlsOverseasAaddrsState").value) &&
      (this.addrsDtlsAForm.get("addrsDtlsAaddrsCity").value === this.addrsDtlsAForm.get("addrsDtlsOverseasAaddrsCity").value) &&
      (this.addrsDtlsAForm.get("addrsDtlsOverseasAaddrsPnCd").value === this.addrsDtlsAForm.get("addrsDtlsOverseasAaddrsPnCd").value)
    ) {
      return true
    } else {
      return false
    }
  }

  submitAddrsDtls() {
    if (this.addrsDtlsAForm.controls['sameascurrentaddress'].value == true) {
      let addrsDtlsAaddrsType= this.addrsDtlsAForm.controls['addrsDtlsAaddrsType'].value;
      let addrsDtlsAaddrsHuseNo= this.addrsDtlsAForm.controls['addrsDtlsAaddrsHuseNo'].value
      let addrsDtlsAaddrsBuldNm= this.addrsDtlsAForm.controls['addrsDtlsAaddrsBuldNm'].value
      let addrsDtlsAaddrsRdNm= this.addrsDtlsAForm.controls['addrsDtlsAaddrsRdNm'].value
      let addrsDtlsAaddrsLndMrk= this.addrsDtlsAForm.controls['addrsDtlsAaddrsLndMrk'].value
      let addrsDtlsAaddrsCntry= this.addrsDtlsAForm.controls['addrsDtlsAaddrsCntry'].value
      let addrsDtlsAaddrsState= this.addrsDtlsAForm.controls['addrsDtlsAaddrsState'].value
      let addrsDtlsAaddrsCity= this.addrsDtlsAForm.controls['addrsDtlsAaddrsCity'].value
      let addrsDtlsAaddrsPnCd= this.addrsDtlsAForm.controls['addrsDtlsAaddrsPnCd'].value
      this.addrsDtlsAForm = this.fb.group({
        addrsDtlsAaddrsType: [addrsDtlsAaddrsType, [Validators.required]],
        addrsDtlsAaddrsHuseNo: [addrsDtlsAaddrsHuseNo, [Validators.required]],
        addrsDtlsAaddrsBuldNm: [addrsDtlsAaddrsBuldNm, [Validators.required]],
        addrsDtlsAaddrsRdNm: [addrsDtlsAaddrsRdNm, [Validators.required]],
        addrsDtlsAaddrsLndMrk: [addrsDtlsAaddrsLndMrk, [Validators.required]],
        addrsDtlsAaddrsCntry: [addrsDtlsAaddrsCntry, [Validators.required]],
        addrsDtlsAaddrsState: [addrsDtlsAaddrsState, [Validators.required]],
        addrsDtlsAaddrsCity: [addrsDtlsAaddrsCity, [Validators.required]],
        addrsDtlsAaddrsPnCd: [addrsDtlsAaddrsPnCd, [Validators.required, Validators.pattern(/^[A-Za-z0-9\s]*$/)]],
        sameascurrentaddress: [true],
        addrsDtlsOverseasAaddrsType: [addrsDtlsAaddrsType, [Validators.required]],
        addrsDtlsOverseasAaddrsHuseNo: [addrsDtlsAaddrsHuseNo, [Validators.required]],
        addrsDtlsOverseasAaddrsBuldNm: [addrsDtlsAaddrsBuldNm, [Validators.required]],
        addrsDtlsOverseasAaddrsRdNm: [addrsDtlsAaddrsRdNm, [Validators.required]],
        addrsDtlsOverseasAaddrsLndMrk: [addrsDtlsAaddrsLndMrk, [Validators.required]],
        addrsDtlsOverseasAaddrsCntry: [addrsDtlsAaddrsCntry, [Validators.required]],
        addrsDtlsOverseasAaddrsState: [addrsDtlsAaddrsState, [Validators.required]],
        addrsDtlsOverseasAaddrsCity: [addrsDtlsAaddrsCity, [Validators.required]],
        addrsDtlsOverseasAaddrsPnCd: [addrsDtlsAaddrsPnCd, [Validators.required, Validators.pattern(/^[A-Za-z0-9\s]*$/)]]
      })
    }
    console.log("???>>>>>>>>>>", this.addrsDtlsAForm.value)

    if (this.addrsDtlsAForm.valid) {
      this.regObj = this.commonService.getUserFromLocalStorage();
      // console.log("This Obj", this.regObj.guardianApplicantID);
      // this.addrsDtlsAForm.get("addrsDtlsAaddrsType").value
      // this.addrsDtlsAForm.get("addrsDtlsAaddrsHuseNo").value
      // this.addrsDtlsAForm.get("addrsDtlsAaddrsBuldNm").value
      // this.addrsDtlsAForm.get("addrsDtlsAaddrsRdNm").value
      // this.addrsDtlsAForm.get("addrsDtlsAaddrsLndMrk").value
      // this.addrsDtlsAForm.get("addrsDtlsAaddrsCntry").value
      // this.addrsDtlsAForm.get("addrsDtlsAaddrsState").value
      // this.addrsDtlsAForm.get("addrsDtlsAaddrsCity").value
      // this.addrsDtlsAForm.get("addrsDtlsAaddrsPnCd").value
      // this.addrsDtlsAForm.get("addrsDtlsOverseasAaddrsType").value
      // this.addrsDtlsAForm.get("addrsDtlsOverseasAaddrsHuseNo").value
      // this.addrsDtlsAForm.get("addrsDtlsOverseasAaddrsBuldNm").value
      // this.addrsDtlsAForm.get("addrsDtlsOverseasAaddrsRdNm").value
      // this.addrsDtlsAForm.get("addrsDtlsOverseasAaddrsLndMrk").value
      // this.addrsDtlsAForm.get("addrsDtlsOverseasAaddrsCntry").value
      // this.addrsDtlsAForm.get("addrsDtlsOverseasAaddrsState").value
      // this.addrsDtlsAForm.get("addrsDtlsOverseasAaddrsCity").value
      // this.addrsDtlsAForm.get("addrsDtlsOverseasAaddrsPnCd").value
      console.log("This is banking doc_id", this.regObj.banking_doc_id)

      let Obj = {
        applicant_id: Number(this.regObj.guardianApplicantID),
        process_id: 53,
        address_id: this.regObj.address_id,
        current_address_type: Number(this.addrsDtlsAForm.get("addrsDtlsAaddrsType").value),
        current_house_number: this.addrsDtlsAForm.get("addrsDtlsAaddrsHuseNo").value,
        current_house_or_building_name: this.addrsDtlsAForm.get("addrsDtlsAaddrsBuldNm").value,
        current_road_or_street_name: this.addrsDtlsAForm.get("addrsDtlsAaddrsRdNm").value,
        current_state: this.addrsDtlsAForm.get("addrsDtlsAaddrsState").value,
        current_city: this.addrsDtlsAForm.get("addrsDtlsAaddrsCity").value,
        current_country_id: Number(this.addrsDtlsAForm.get("addrsDtlsAaddrsCntry").value),
        current_pincode: this.addrsDtlsAForm.get("addrsDtlsAaddrsPnCd").value,
        overseas_address_type: Number(this.addrsDtlsAForm.get("addrsDtlsOverseasAaddrsType").value),
        overseas_house_number: this.addrsDtlsAForm.get("addrsDtlsOverseasAaddrsHuseNo").value,
        overseas_house_or_building_name: this.addrsDtlsAForm.get("addrsDtlsOverseasAaddrsBuldNm").value,
        overseas_road_or_street_name: this.addrsDtlsAForm.get("addrsDtlsOverseasAaddrsRdNm").value,
        overseas_state: this.addrsDtlsAForm.get("addrsDtlsOverseasAaddrsState").value,
        overseas_city: this.addrsDtlsAForm.get("addrsDtlsOverseasAaddrsCity").value,
        overseas_country_id: Number(this.addrsDtlsAForm.get("addrsDtlsOverseasAaddrsCntry").value),
        overseas_pincode: this.addrsDtlsAForm.get("addrsDtlsOverseasAaddrsPnCd").value,
        current_landmark: this.addrsDtlsAForm.get("addrsDtlsAaddrsLndMrk").value,
        overseas_landmark: this.addrsDtlsAForm.get("addrsDtlsOverseasAaddrsLndMrk").value,
        permenant_landmark: this.addrsDtlsAForm.get("addrsDtlsAaddrsLndMrk").value,
        jurisdiction_landmar: this.addrsDtlsAForm.get("addrsDtlsOverseasAaddrsLndMrk").value
      }
      this.commonService.storeInLocalStorage('registerData', { 'address_Dtls1': this.addrsDtlsAForm.value })
      this.customerDataService.postAddressDtls1(Obj).subscribe((data) => {
        console.log("Address Details", data);
        this.commonService.storeInLocalStorage('registerData', { 'address_id': data?.address_id })
        var is_feedback_show = 0;
        if (this.commonService.getUserFromLocalStorage()?.leadReviewStatus != undefined) {
          if (this.commonService.getUserFromLocalStorage()?.leadReviewStatus != 'customer_process') {
            is_feedback_show += 1;
          }
        }
        if (is_feedback_show != 0) {
          this.rt.navigate(["/feedback", "feedback-summary"]);
        }
        else {
          this.rt.navigate(["/minor-accnt", "addrs-dtls2-guardian"]);
        }

        // if (this.commonService.getUserFromLocalStorage()?.leadReviewStatus === undefined) {

        //   this.rt.navigate(["/individual-account", "addrs-dtls2"])
        // } else {

        //   this.rt.navigate(["/feedback", "feedback-summary"]);
        // }

      })
    }
    else {
      console.log('This is invalid form')
    }
  }

  setOverseaData() {
    console.log('set same as', this.addrsDtlsAForm.value.sameascurrentaddress);
    if (this.addrsDtlsAForm.controls['sameascurrentaddress'].value == true) {
      console.log("/////////////", this.addrsDtlsAForm.controls['addrsDtlsAaddrsType'].value);

      this.addrsDtlsAForm.controls['addrsDtlsOverseasAaddrsType'].setValue(this.addrsDtlsAForm.controls['addrsDtlsAaddrsType'].value)
      this.addrsDtlsAForm.controls['addrsDtlsOverseasAaddrsHuseNo'].setValue(this.addrsDtlsAForm.controls['addrsDtlsAaddrsHuseNo'].value)
      this.addrsDtlsAForm.controls['addrsDtlsOverseasAaddrsBuldNm'].setValue(this.addrsDtlsAForm.controls['addrsDtlsAaddrsBuldNm'].value)
      this.addrsDtlsAForm.controls['addrsDtlsOverseasAaddrsRdNm'].setValue(this.addrsDtlsAForm.controls['addrsDtlsAaddrsRdNm'].value)
      this.addrsDtlsAForm.controls['addrsDtlsOverseasAaddrsLndMrk'].setValue(this.addrsDtlsAForm.controls['addrsDtlsAaddrsLndMrk'].value)
      this.addrsDtlsAForm.controls['addrsDtlsOverseasAaddrsCntry'].setValue(this.addrsDtlsAForm.controls['addrsDtlsAaddrsCntry'].value)
      this.addrsDtlsAForm.controls['addrsDtlsOverseasAaddrsState'].setValue(this.addrsDtlsAForm.controls['addrsDtlsAaddrsState'].value)
      this.addrsDtlsAForm.controls['addrsDtlsOverseasAaddrsCity'].setValue(this.addrsDtlsAForm.controls['addrsDtlsAaddrsCity'].value)
      this.addrsDtlsAForm.controls['addrsDtlsOverseasAaddrsPnCd'].setValue(this.addrsDtlsAForm.controls['addrsDtlsAaddrsPnCd'].value)
      this.addrsDtlsOverseasAaddrsType.setValue(this.addrsDtlsAForm.controls['addrsDtlsAaddrsType'].value)

      console.log("???", this.addrsDtlsAForm.value)

      this.addrsDtlsAForm.controls['addrsDtlsOverseasAaddrsType'].disable()
      this.addrsDtlsAForm.controls['addrsDtlsOverseasAaddrsHuseNo'].disable()
      this.addrsDtlsAForm.controls['addrsDtlsOverseasAaddrsBuldNm'].disable()
      this.addrsDtlsAForm.controls['addrsDtlsOverseasAaddrsRdNm'].disable()
      this.addrsDtlsAForm.controls['addrsDtlsOverseasAaddrsLndMrk'].disable()
      this.addrsDtlsAForm.controls['addrsDtlsOverseasAaddrsCntry'].disable()
      this.addrsDtlsAForm.controls['addrsDtlsOverseasAaddrsState'].disable()
      this.addrsDtlsAForm.controls['addrsDtlsOverseasAaddrsCity'].disable()
      this.addrsDtlsAForm.controls['addrsDtlsOverseasAaddrsPnCd'].disable()

    }
    else {
      this.addrsDtlsAForm.controls['addrsDtlsOverseasAaddrsType'].setValue('')
      this.addrsDtlsAForm.controls['addrsDtlsOverseasAaddrsHuseNo'].setValue('')
      this.addrsDtlsAForm.controls['addrsDtlsOverseasAaddrsBuldNm'].setValue('')
      this.addrsDtlsAForm.controls['addrsDtlsOverseasAaddrsRdNm'].setValue('')
      this.addrsDtlsAForm.controls['addrsDtlsOverseasAaddrsLndMrk'].setValue('')
      this.addrsDtlsAForm.controls['addrsDtlsOverseasAaddrsCntry'].setValue('')
      this.addrsDtlsAForm.controls['addrsDtlsOverseasAaddrsState'].setValue('')
      this.addrsDtlsAForm.controls['addrsDtlsOverseasAaddrsCity'].setValue('')
      this.addrsDtlsAForm.controls['addrsDtlsOverseasAaddrsPnCd'].setValue('')


      this.addrsDtlsAForm.controls['addrsDtlsOverseasAaddrsType'].enable()
      this.addrsDtlsAForm.controls['addrsDtlsOverseasAaddrsHuseNo'].enable()
      this.addrsDtlsAForm.controls['addrsDtlsOverseasAaddrsBuldNm'].enable()
      this.addrsDtlsAForm.controls['addrsDtlsOverseasAaddrsRdNm'].enable()
      this.addrsDtlsAForm.controls['addrsDtlsOverseasAaddrsLndMrk'].enable()
      this.addrsDtlsAForm.controls['addrsDtlsOverseasAaddrsCntry'].enable()
      this.addrsDtlsAForm.controls['addrsDtlsOverseasAaddrsState'].enable()
      this.addrsDtlsAForm.controls['addrsDtlsOverseasAaddrsCity'].enable()
      this.addrsDtlsAForm.controls['addrsDtlsOverseasAaddrsPnCd'].enable()
    }
  }
}