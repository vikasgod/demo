import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DocPioGuardianComponent } from './doc-pio-guardian.component';

describe('DocPioGuardianComponent', () => {
  let component: DocPioGuardianComponent;
  let fixture: ComponentFixture<DocPioGuardianComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DocPioGuardianComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DocPioGuardianComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
