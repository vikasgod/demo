import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { CommonService } from 'src/app/services/common.service';
import { CustomerDataService } from 'src/app/services/customer-data.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-doc-pio-guardian',
  templateUrl: './doc-pio-guardian.component.html',
  styleUrls: ['./doc-pio-guardian.component.css']
})
export class DocPioGuardianComponent implements OnInit {
  requiredFileType: string = 'image/png,image/jpeg'
  docPoi: any;
  iSfile1Change: boolean = false;
  errFileExtension: boolean = true;
  imgSrc: any = '';
  fileDataStr1: any = '';
  fileName1: string = '';
  regObj: any;
  imgSrc1: string = '';
  fileDataStr2: any = '';
  fileName2: string = '';
  imgSrc2: string = '';
  isUpdate: boolean = false

  docPioErr: string = '';

  display: string = "none";
  constructor(private fb: FormBuilder, private commonService: CommonService, private customerDataService: CustomerDataService, private rt: Router) {
    this.getDoc()
  }

  ngOnInit(): void {

    this.docPoi = this.fb.group({
      docPoiFile1: [this.imgSrc1, [Validators.required]],
      docPoiFile2: [this.imgSrc2, [Validators.required]]
    })
    this.regObj = this.commonService.getUserFromLocalStorage();
    if ((this.regObj.isSubmitted != undefined && this.regObj.isSubmitted != 0)
      || ((this.regObj.leadReviewStatus != undefined && this.regObj.leadReviewStatus != "customer_process")
        && (this.regObj.leadReviewStatus != undefined && this.regObj.leadReviewStatus != "agent_review"))
    ) {
      this.rt.navigate(["/individual-account", "ending"]);
    }
    this.getDoc()
  }


  getDoc(){
    let Obj1 = {
      applicant_id: this.commonService.getUserFromLocalStorage()?.guardianApplicantID,
      document: "old_indian_passport_front"
    }

    this.customerDataService.fetchGetDoc(Obj1).subscribe((value) => {
      this.imgSrc1 = value?.file_path
      this.customerDataService.getBase64ImageFromUrl(value.file_path).then(result => {
        this.fileDataStr1 = result
      })
        .catch(err => console.error(err));
      this.docPoi = this.fb.group({
        docPoiFile1: [this.imgSrc1, [Validators.required]],
        docPoiFile2: [this.imgSrc2, [Validators.required]]
      })
    });

    let Obj2 = {
      applicant_id: this.commonService.getUserFromLocalStorage()?.guardianApplicantID,
      document: "old_indian_passport_back"
    }

    this.customerDataService.fetchGetDoc(Obj2).subscribe((value) => {
      if (value != undefined) {
        this.isUpdate = true
      }
      this.imgSrc2 = value?.file_path
      //this.docPoi.get('docPoiFile2')
      this.customerDataService.getBase64ImageFromUrl(value.file_path).then(result => {
        this.fileDataStr2 = result
      })
        .catch(err => console.error(err));
      this.docPoi = this.fb.group({
        docPoiFile1: [this.imgSrc1, [Validators.required]],
        docPoiFile2: [this.imgSrc2, [Validators.required]]
      })
      console.log(this.docPoi)
    });
  }
  get docPoiFile1() { return this.docPoi.get("docPoiFile1") }
  get docPoiFile2() { return this.docPoi.get("docPoiFile2") }

  //Working 1  
  onFilesSelected1(event: any) {
    this.iSfile1Change = true;
    let fileData = event.target.files[0];
    this.fileName1 = fileData.name;
    let arr = String(fileData.name).split('.');
    let len = arr.length;
    if (fileData.size <= 5000000) {
      if (arr[len - 1] === "png" || arr[len - 1] === "jpeg" || arr[len - 1] === "jpg") {
        const reader = new FileReader();
        reader.onloadend = () => {
          this.imgSrc1 = String(reader.result)
          // Use a regex to remove data url part
          const base64String = String(reader.result)
            .replace('data:', '')
            .replace(/^.+,/, '');
          this.fileDataStr1 = base64String;
          //console.log("THis is file1 base64 string",base64String);
        };
        reader.readAsDataURL(fileData);
      } 
      else {
        this.errFileExtension = false;
        console.log("Extension is not valid")
        //return
      }
    } 
    else {
      this.fileName1 = '';
      this.docPoi.get('docPoiFile1').setValue('');
      this.docPioErr = 'File size exceeds 5mb'
      this.openModal();
    }
    //return
  }

  onFilesSelected2(event: any) {
    this.iSfile1Change = true;
    let fileData = event.target.files[0];
    this.fileName2 = fileData.name;
    let arr = String(fileData.name).split('.');
    let len = arr.length;
    if (fileData.size <= 5000000) {
      if (arr[len - 1] === "png" || arr[len - 1] === "jpeg" || arr[len - 1] === "jpg") {

        const reader = new FileReader();
        reader.onloadend = () => {
          this.imgSrc2 = String(reader.result)
          // Use a regex to remove data url part
          const base64String = String(reader.result)
            .replace('data:', '')
            .replace(/^.+,/, '');
          this.fileDataStr2 = base64String;
          //console.log("THis is file1 base64 string",base64String);
        };
        reader.readAsDataURL(fileData);
      } 
      else {
        this.errFileExtension = false;
        console.log("Extension is not valid")
        //return
      }
    } 
    else {
      this.fileName2 = '';
      this.docPoi.get('docPoiFile2').setValue('');
      this.docPioErr = 'File size exceeds 5mb'
      this.openModal();
    }
    //return
  }

  openModal() {
    this.display = "block";
  }

  onCloseHandled() {
    this.display = "none";
  }

  submitPio() {
    this.regObj = this.commonService.getUserFromLocalStorage();
    //     if(this.regObj.isSubmitted!=undefined || this.regObj.leadReviewStatus != "customer_process")
    // {
    //   this.rt.navigate(["/individual-account","ending"]);
    // }
    let Obj = {
      applicant_id: this.regObj.guardianApplicantID,
      process_id: 65,
      passport_front: this.fileDataStr1,
      passport_back: this.fileDataStr2
    }

    this.customerDataService.postCustomerPioDoc(Obj).subscribe((data) => {
      this.rt.navigate(['/minor-accnt', 'document-upload1-guardian']);
    })
  }
}