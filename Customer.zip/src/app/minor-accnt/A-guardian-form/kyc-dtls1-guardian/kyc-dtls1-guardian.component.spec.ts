import { ComponentFixture, TestBed } from '@angular/core/testing';

import { KycDtls1GuardianComponent } from './kyc-dtls1-guardian.component';

describe('KycDtls1GuardianComponent', () => {
  let component: KycDtls1GuardianComponent;
  let fixture: ComponentFixture<KycDtls1GuardianComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ KycDtls1GuardianComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(KycDtls1GuardianComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
