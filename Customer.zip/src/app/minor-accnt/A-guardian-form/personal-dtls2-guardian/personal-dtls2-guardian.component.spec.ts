import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PersonalDtls2GuardianComponent } from './personal-dtls2-guardian.component';

describe('PersonalDtls2GuardianComponent', () => {
  let component: PersonalDtls2GuardianComponent;
  let fixture: ComponentFixture<PersonalDtls2GuardianComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PersonalDtls2GuardianComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PersonalDtls2GuardianComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
