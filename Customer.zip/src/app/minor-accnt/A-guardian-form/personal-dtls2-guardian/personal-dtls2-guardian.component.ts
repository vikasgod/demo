import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { CommonService } from 'src/app/services/common.service';
import { Router } from '@angular/router';
import { CustomerDataService } from 'src/app/services/customer-data.service';

@Component({
  selector: 'app-personal-dtls2-guardian',
  templateUrl: './personal-dtls2-guardian.component.html',
  styleUrls: ['./personal-dtls2-guardian.component.css']
})
export class PersonalDtls2GuardianComponent implements OnInit {

  regObj: any;
  currentDate: string = '';
  countryData: any;
  persnDltsGuardianForm: any;
  titleData: any;
  titleDataArr: any;
  dateNri: any;
  applicant_personal_id: any;
  isDisplayMaidenName: boolean = false;

  isDisplayUpdateBtn: boolean = false;
  fatherTitle: boolean = false

  constructor(private fb: FormBuilder, private commonService: CommonService, private rt: Router, private customerDataService: CustomerDataService) { }

  ngOnInit(): void {
    this.regObj = this.commonService.getUserFromLocalStorage();
    if (this.regObj.isSubmited || (this.regObj.leadReviewStatus != "customer_process" && this.regObj.leadReviewStatus != "agent_review" )) {
      this.rt.navigate(["/minor-accnt", "ending"]);
    }
    // if (this.commonService.getUserFromLocalStorage()?.leadStatus !== undefined || this.commonService.getUserFromLocalStorage()?.leadStatus !== 'undefined' || this.commonService.getUserFromLocalStorage()?.leadStatus !== null) {
    //   this.isDisplayUpdateBtn = false;
    // } else {
    //   this.isDisplayUpdateBtn = true;
    // }

    this.currentDate = this.commonService.getCurrentDate();

    let Obj = {
      applicant_id: this.commonService.getUserFromLocalStorage()?.guardianApplicantID,
      process_id: 46
    }

    this.customerDataService.fetchPersonalDtls2(Obj).subscribe((value) => {
      if (value?.data?.length > 0) {
        this.isDisplayUpdateBtn = true;
        this.dateNri = new Date(value?.data?.[0]?.date_of_becoming_nri);
        this.persnDltsGuardianForm = this.fb.group({
          prsnlDtlsMaidenTitle: [value?.data?.[0]?.maiden_title, []],
          prsnlDtlsMaidenFirstName: [value?.data?.[0]?.maiden_first_name, []],
          prsnlDtlsMaidenMiddleName: [value?.data?.[0]?.maiden_middle_name, []],
          prsnlDtlsMaidenLastName: [value?.data?.[0]?.maiden_last_name, []],

          prsnlDtlsMothersTitle: ['mrs', [Validators.required]],
          prsnlDtlsMothersFirstName: [value?.data?.[0]?.mother_first_name, [Validators.required]],
          prsnlDtlsMothersMiddleName: [value?.data?.[0]?.mother_middle_name],
          prsnlDtlsMothersLastName: [this.regObj?.last_name],

          prsnlDtlsFathersNameValid: [value?.data?.[0]?.in_relation_type, [Validators.required]],

          prsnlDtlsFathersTitle: [value?.data?.[0]?.in_relation_title],
          prsnlDtlsFathersFirstName: [value?.data?.[0]?.in_relation_first_name, [Validators.required]],
          prsnlDtlsFathersMiddleName: [value?.data?.[0]?.in_relation_middle_name],
          prsnlDtlsFathersLastName: [value?.data?.[0]?.in_relation_last_name],
          prsnlDtlsCountry: [value?.data?.[0]?.nationality, [Validators.required]],
          prsnlDtlsDtNri: [this.dateNri, [Validators.required]],
        })
        this.applicant_personal_id = value?.data?.[0]?.applicant_personal_id;
      }
    })

    this.persnDltsGuardianForm = this.fb.group({
      prsnlDtlsMaidenTitle: [null],
      prsnlDtlsMaidenFirstName: [''],
      prsnlDtlsMaidenMiddleName: [''],
      prsnlDtlsMaidenLastName: [''],
      prsnlDtlsMothersTitle: ['mrs', Validators.required],
      prsnlDtlsMothersFirstName: ['', Validators.required],
      prsnlDtlsMothersMiddleName: [''],
      prsnlDtlsMothersLastName: [''],
      prsnlDtlsFathersNameValid: ['father', [Validators.required]],
      prsnlDtlsFathersTitle: [null],
      prsnlDtlsFathersFirstName: ['', Validators.required],
      prsnlDtlsFathersMiddleName: [''],
      prsnlDtlsFathersLastName: [''],
      prsnlDtlsCountry: ['', Validators.required],
      prsnlDtlsDtNri: ['', Validators.required],
    })

    this.currentDate = this.commonService.getCurrentDate();
    this.customerDataService.getCountry().subscribe((data) => {
      this.countryData = data;
    })

    this.customerDataService.getTitle().subscribe((data) => {
      this.titleData = data
    })

    if (this.regObj?.applicantTitle === 'mrs' && this.regObj?.genderSelected === 'female') {
      this.isDisplayMaidenName = true;
      this.persnDltsGuardianForm.controls['prsnlDtlsMaidenTitle'].setValidators([Validators.required]);
      this.persnDltsGuardianForm.controls['prsnlDtlsMaidenFirstName'].setValidators([Validators.required]);
      this.persnDltsGuardianForm.controls['prsnlDtlsMaidenMiddleName'].setValidators([Validators.required]);
      this.persnDltsGuardianForm.controls['prsnlDtlsMaidenLastName'].setValidators([Validators.required]);
      this.persnDltsGuardianForm.controls['prsnlDtlsMaidenTitle'].updateValueAndValidity();
      this.persnDltsGuardianForm.controls['prsnlDtlsMaidenFirstName'].updateValueAndValidity();
      this.persnDltsGuardianForm.controls['prsnlDtlsMaidenMiddleName'].updateValueAndValidity();
      this.persnDltsGuardianForm.controls['prsnlDtlsMaidenLastName'].updateValueAndValidity();

    } 
    else {
      this.isDisplayMaidenName = false;
      this.persnDltsGuardianForm.controls['prsnlDtlsMaidenTitle'].clearValidators();
      this.persnDltsGuardianForm.controls['prsnlDtlsMaidenFirstName'].clearValidators();
      this.persnDltsGuardianForm.controls['prsnlDtlsMaidenMiddleName'].clearValidators();
      this.persnDltsGuardianForm.controls['prsnlDtlsMaidenLastName'].clearValidators();
      this.persnDltsGuardianForm.controls['prsnlDtlsMaidenTitle'].updateValueAndValidity();
      this.persnDltsGuardianForm.controls['prsnlDtlsMaidenFirstName'].updateValueAndValidity();
      this.persnDltsGuardianForm.controls['prsnlDtlsMaidenMiddleName'].updateValueAndValidity();
      this.persnDltsGuardianForm.controls['prsnlDtlsMaidenLastName'].updateValueAndValidity();
    }
    this.persnDltsGuardianForm.controls['prsnlDtlsMothersLastName'].setValue(this.regObj?.last_name);
  }

  get prsnlDtlsMaidenTitle() { return this.persnDltsGuardianForm.get("prsnlDtlsMaidenTitle") }
  get prsnlDtlsMaidenFirstName() { return this.persnDltsGuardianForm.get("prsnlDtlsMaidenFirstName") }
  get prsnlDtlsMaidenMiddleName() { return this.persnDltsGuardianForm.get("prsnlDtlsMaidenMiddleName") }
  get prsnlDtlsMaidenLastName() { return this.persnDltsGuardianForm.get("prsnlDtlsMaidenLastName") }

  get prsnlDtlsMothersTitle() { return this.persnDltsGuardianForm.get("prsnlDtlsMothersTitle") }
  get prsnlDtlsMothersFirstName() { return this.persnDltsGuardianForm.get("prsnlDtlsMothersFirstName") }
  get prsnlDtlsMothersMiddleName() { return this.persnDltsGuardianForm.get("prsnlDtlsMothersMiddleName") }
  get prsnlDtlsMothersLastName() { return this.persnDltsGuardianForm.get("prsnlDtlsMothersLastName") }

  get prsnlDtlsFathersNameValid() { return this.persnDltsGuardianForm.get("prsnlDtlsFathersNameValid") }

  get prsnlDtlsFathersTitle() { return this.persnDltsGuardianForm.get("prsnlDtlsFathersTitle") }
  get prsnlDtlsFathersFirstName() { return this.persnDltsGuardianForm.get("prsnlDtlsFathersFirstName") }
  get prsnlDtlsFathersMiddleName() { return this.persnDltsGuardianForm.get("prsnlDtlsFathersMiddleName") }
  get prsnlDtlsFathersLastName() { return this.persnDltsGuardianForm.get("prsnlDtlsFathersLastName") }

  get prsnlDtlsCountry() { return this.persnDltsGuardianForm.get("prsnlDtlsCountry") }
  get prsnlDtlsDtNri() { return this.persnDltsGuardianForm.get("prsnlDtlsDtNri") }

  keypressLetters(event: any) {
    //return this.commonService.enterOnlyAlphabetsNoSpace(event);

    return this.commonService.enterOnlyAlphabetsNoSpace(event)
  }

  submitPersnalDtls() {

    if (this.persnDltsGuardianForm.valid) {
      this.regObj = this.commonService.getUserFromLocalStorage();
      this.persnDltsGuardianForm.get("prsnlDtlsMaidenTitle").value
      this.persnDltsGuardianForm.get("prsnlDtlsMaidenFirstName").value
      this.persnDltsGuardianForm.get("prsnlDtlsMaidenMiddleName").value
      this.persnDltsGuardianForm.get("prsnlDtlsMaidenLastName").value

      this.persnDltsGuardianForm.get("prsnlDtlsMothersTitle").value
      this.persnDltsGuardianForm.get("prsnlDtlsMothersFirstName").value
      this.persnDltsGuardianForm.get("prsnlDtlsMothersMiddleName").value
      this.persnDltsGuardianForm.get("prsnlDtlsMothersLastName").value

      this.persnDltsGuardianForm.get("prsnlDtlsFathersNameValid").value

      this.persnDltsGuardianForm.get("prsnlDtlsFathersTitle").value
      this.persnDltsGuardianForm.get("prsnlDtlsFathersFirstName").value
      this.persnDltsGuardianForm.get("prsnlDtlsFathersMiddleName").value
      this.persnDltsGuardianForm.get("prsnlDtlsFathersLastName").value

      this.persnDltsGuardianForm.get("prsnlDtlsCountry").value
      this.persnDltsGuardianForm.get("prsnlDtlsDtNri").value

      let Obj = {
        applicant_personal_id: this.commonService.getUserFromLocalStorage()?.guardianApplicantID,
        applicant_serial_num: this.commonService.getUserFromLocalStorage()?.applicantSerialNum,

        user_id: this.regObj?.user_id,
        maiden_title: this.persnDltsGuardianForm.get("prsnlDtlsMaidenTitle").value,
        maiden_first_name: this.persnDltsGuardianForm.get("prsnlDtlsMaidenFirstName").value,
        maiden_middle_name: this.persnDltsGuardianForm.get("prsnlDtlsMaidenMiddleName").value,
        maiden_last_name: this.persnDltsGuardianForm.get("prsnlDtlsMaidenLastName").value,
        mother_first_name: this.persnDltsGuardianForm.get("prsnlDtlsMothersFirstName").value,
        mother_middle_name: this.persnDltsGuardianForm.get("prsnlDtlsMothersMiddleName").value,
        mother_last_name: this.persnDltsGuardianForm.get("prsnlDtlsMothersLastName").value,

        in_relation_type: this.persnDltsGuardianForm.get("prsnlDtlsFathersNameValid").value,
        in_relation_title: this.persnDltsGuardianForm.get("prsnlDtlsFathersTitle").value,
        in_relation_first_name: this.persnDltsGuardianForm.get("prsnlDtlsFathersFirstName").value,
        in_relation_middle_name: this.persnDltsGuardianForm.get("prsnlDtlsFathersMiddleName").value,
        in_relation_last_name: this.persnDltsGuardianForm.get("prsnlDtlsFathersLastName").value,
        nationality: this.persnDltsGuardianForm.get("prsnlDtlsCountry").value,
        date_of_becoming_nri: this.customerDataService.formatDob(this.persnDltsGuardianForm.get("prsnlDtlsDtNri").value),
        is_consent_declared: 0,
        is_submited: 1,
        process_id: 46,
        applicant_id: this.commonService.getUserFromLocalStorage()?.guardianApplicantID,
      }

      this.customerDataService.postPersonalDtls2(Obj).subscribe((data) => {
        
        if (this.regObj.leadReviewStatus == 'agent_review') {
          this.rt.navigate(['/feedback', 'feedback-summary']);
          return;
        }

        if (this.commonService.getUserFromLocalStorage()?.leadStatus !== undefined || this.commonService.getUserFromLocalStorage()?.leadStatus !== 'undefined' || this.commonService.getUserFromLocalStorage()?.leadStatus !== null) {
          this.rt.navigate(["/minor-accnt", "fatca-guardian"]);
        } 
        else {
          this.rt.navigate(["/feedback", "feedback-summary"]);
        }
      })
    } 
  }

  titleShow(val: any) {
    if (val.target.value == 'father') {
      this.fatherTitle = false;
      this.persnDltsGuardianForm.controls['prsnlDtlsFathersTitle'].clearValidators();
    }
    else {
      this.fatherTitle = true;
      this.persnDltsGuardianForm.controls['prsnlDtlsFathersTitle'].setValue(null);
      this.persnDltsGuardianForm.controls['prsnlDtlsFathersTitle'].setValidators([Validators.required]);
    }
    this.persnDltsGuardianForm.controls['prsnlDtlsFathersTitle'].updateValueAndValidity();
  }

}
