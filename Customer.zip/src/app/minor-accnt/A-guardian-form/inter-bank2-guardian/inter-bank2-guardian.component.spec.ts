import { ComponentFixture, TestBed } from '@angular/core/testing';

import { InterBank2GuardianComponent } from './inter-bank2-guardian.component';

describe('InterBank2GuardianComponent', () => {
  let component: InterBank2GuardianComponent;
  let fixture: ComponentFixture<InterBank2GuardianComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ InterBank2GuardianComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(InterBank2GuardianComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
