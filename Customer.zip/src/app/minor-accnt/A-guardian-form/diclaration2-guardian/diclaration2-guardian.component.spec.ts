import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Diclaration2GuardianComponent } from './diclaration2-guardian.component';

describe('Diclaration2GuardianComponent', () => {
  let component: Diclaration2GuardianComponent;
  let fixture: ComponentFixture<Diclaration2GuardianComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ Diclaration2GuardianComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(Diclaration2GuardianComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
