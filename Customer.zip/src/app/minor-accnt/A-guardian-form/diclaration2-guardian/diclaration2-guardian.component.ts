import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CustomerDataService } from 'src/app/services/customer-data.service';
import { CommonService } from 'src/app/services/common.service';

@Component({
  selector: 'app-diclaration2-guardian',
  templateUrl: './diclaration2-guardian.component.html',
  styleUrls: ['./diclaration2-guardian.component.css']
})
export class Diclaration2GuardianComponent implements OnInit {

  regObj: any;

  constructor(private rt: Router, private customerDataService: CustomerDataService, private commonService: CommonService) { }

  ngOnInit(): void {
  }

  submitDec2() {
    this.regObj = this.commonService.getUserFromLocalStorage();


    if (this.regObj.isSubmited || this.regObj.leadReviewStatus != "customer_process") {
      this.rt.navigate(["/minor-accnt", "ending"]);
    }


    if (this.regObj?.account_type_id === 3 || this.regObj?.account_type === 3) {
      this.rt.navigate(['/minor-accnt', 'thanks'])
    } else if (this.regObj?.account_type_id === 2 || this.regObj?.account_type === 2) {

      let Obj = {
        user_id: this.regObj?.user_id,
        applicant_serial_num: this.commonService.getUserFromLocalStorage()?.applicantSerialNum,
        applicant_personal_id: this.commonService.getUserFromLocalStorage()?.guardianApplicantID,

        process_id: 71,
        applicant_id: this.commonService.getUserFromLocalStorage()?.guardianApplicantID,
        account_type_id: this.regObj?.account_type_id,
      }
      this.customerDataService.postJointAccntTermsCndnt(Obj).subscribe((data) => {
        console.log("Terms and condition", data);

        // applicant_per_id: 8
        // applicant_serial_number: 2
        // is_completed: false
        //this.commonService.storeInLocalStorage('registerData',{guardianApplicantID:data?.applicant_per_id,applicantSerialNo:data?.applicant_serial_number});

        this.commonService.storeInLocalStorage('registerData', { guardianApplicantID: data?.guardianApplicantID, applicantSerialNo: data?.applicant_serial_number, isFormCompleted: data?.is_completed });
        if (data?.is_completed === false || data?.is_completed === 0) {

          if (data?.applicant_serial_number !== 1) {
            this.rt.navigate(['/minor-accnt', 'personal-dtls1-minor'])
          }

        } else {
          this.rt.navigate(['/joint-account', 'thanks'])
        }

      })
      //this.rt.navigate(['/joint-account', 'thanks'])

    }

    //this.rt.navigate(['/individual-account','thanks']);
  }

}
