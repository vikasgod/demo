import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Diclaration1GuardianComponent } from './diclaration1-guardian.component';

describe('Diclaration1GuardianComponent', () => {
  let component: Diclaration1GuardianComponent;
  let fixture: ComponentFixture<Diclaration1GuardianComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ Diclaration1GuardianComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(Diclaration1GuardianComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
