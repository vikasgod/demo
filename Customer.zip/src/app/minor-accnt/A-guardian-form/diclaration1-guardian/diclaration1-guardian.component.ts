import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { CommonService } from 'src/app/services/common.service';
import { Router } from '@angular/router';
import { CustomerDataService } from 'src/app/services/customer-data.service';

@Component({
  selector: 'app-diclaration1-guardian',
  templateUrl: './diclaration1-guardian.component.html',
  styleUrls: ['./diclaration1-guardian.component.css']
})
export class Diclaration1GuardianComponent implements OnInit {

  declarationAGuardianFrom: any;
  regObj: any;
  isDisplayUpdateBtn: boolean = false;
  constructor(private fb: FormBuilder, private commonService: CommonService, private rt: Router, private customerDataService: CustomerDataService) { }

  ngOnInit(): void {
    this.regObj = this.commonService.getUserFromLocalStorage();

    if (this.regObj.isSubmited || this.regObj.leadReviewStatus != "customer_process") {
      this.rt.navigate(["/minor-accnt", "ending"]);
    }

    let Obj ={
      applicant_id: this.regObj.guardianApplicantID,
      process_id: 70,
      user_id: this.regObj.user_id
    }

    this.customerDataService.fetchConcentDeclared(Obj).subscribe((value) => {
      console.log(value);
      
     if(value.data.length > 0){
      this.isDisplayUpdateBtn = true;
      this.declarationAGuardianFrom = this.fb.group({
        declarationAConcent: [String(value?.data?.[0]?.is_consent_declared), []],
        declarationBConcent: [String(value.data[0]?.is_info_consent_declared), []]
      })
     }

    })

    this.declarationAGuardianFrom = this.fb.group({
      declarationAConcent: ['', Validators.required],
      declarationBConcent: ['', Validators.required]
    })
  }

  get declarationAConcent() { return this.declarationAGuardianFrom.get("declarationAConcent") }
  get declarationBConcent() { return this.declarationAGuardianFrom.get("declarationBConcent") }

  submitDeclaration1Guardian() {
    if (this.declarationAGuardianFrom.valid) {
      //console.log("This is valid form",this.declarationAGuardianFrom.value);
      this.regObj = this.commonService.getUserFromLocalStorage();
      console.log("This Obj", this.regObj.guardianApplicantID);

      let Obj = {
        applicant_id: this.commonService.getUserFromLocalStorage()?.guardianApplicantID,
        applicant_personal_id: this.commonService.getUserFromLocalStorage()?.guardianApplicantID,
        applicant_serial_num: this.commonService.getUserFromLocalStorage()?.applicantSerialNum,
        user_id: this.regObj?.user_id,

        process_id: 70,
        is_consent_declared: Number(this.declarationAGuardianFrom.get("declarationAConcent").value),
        is_info_consent_declared: Number(this.declarationAGuardianFrom.get("declarationBConcent").value)
      }

      this.customerDataService.postConsentDeclared(Obj).subscribe((data) => {

        this.rt.navigate(['/minor-accnt', 'declaration2-guardian']);
      })


    } else {
      console.log("This is invalid form")
    }
  }


}
