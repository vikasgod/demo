import { ComponentFixture, TestBed } from '@angular/core/testing';

import { KycDtls3GuardianComponent } from './kyc-dtls3-guardian.component';

describe('KycDtls3GuardianComponent', () => {
  let component: KycDtls3GuardianComponent;
  let fixture: ComponentFixture<KycDtls3GuardianComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ KycDtls3GuardianComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(KycDtls3GuardianComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
