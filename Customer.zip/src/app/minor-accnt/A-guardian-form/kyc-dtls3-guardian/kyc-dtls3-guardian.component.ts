import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-kyc-dtls3-guardian',
  templateUrl: './kyc-dtls3-guardian.component.html',
  styleUrls: ['./kyc-dtls3-guardian.component.css']
})
export class KycDtls3GuardianComponent implements OnInit {

  kycDtlsGuardianCForm: any;
  constructor(private rt: Router, private fb: FormBuilder) { }

  ngOnInit(): void {
    this.kycDtlsGuardianCForm = this.fb.group({
    })
  }

  submitKycDtls3Guardian() {
    if (this.kycDtlsGuardianCForm.valid) {
      this.rt.navigate(["/minor-accnt/kyc-dtls4-guardian"])
    } else {
      console.log("This form is invalid")
    }
  }
}