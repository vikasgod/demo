import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';

import { HttpClientModule } from '@angular/common/http';
import { FormsModule,ReactiveFormsModule} from '@angular/forms';
import { MatInputModule} from '@angular/material/input';
import {MatFormFieldModule} from '@angular/material/form-field'
import {MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';

import { PersonalDtls1MinorComponent } from './personal-dtls1-minor/personal-dtls1-minor.component';
import { PersonalDtls2MinorComponent } from './personal-dtls2-minor/personal-dtls2-minor.component';
import { KycDtls1MinorComponent } from './kyc-dtls1-minor/kyc-dtls1-minor.component';
import { KycDtls2MinorComponent } from './kyc-dtls2-minor/kyc-dtls2-minor.component';
import { KycDtls3MinorComponent } from './kyc-dtls3-minor/kyc-dtls3-minor.component';
import { KycDtls4MinorComponent } from './kyc-dtls4-minor/kyc-dtls4-minor.component';
import { DocIdentityProofMinorComponent } from './doc-identity-proof-minor/doc-identity-proof-minor.component';
import { DocVisaMinorComponent } from './doc-visa-minor/doc-visa-minor.component';
import { DocPioMinorComponent } from './doc-pio-minor/doc-pio-minor.component';
import { DocOtherProofMinorComponent } from './doc-other-proof-minor/doc-other-proof-minor.component';
import { DocumentUpload1MinorComponent } from './document-upload1-minor/document-upload1-minor.component';
import { GuardianDtlsComponent } from './A-guardian-form/guardian-dtls/guardian-dtls.component';
import { PersonalDtls1GuardianComponent } from './A-guardian-form/personal-dtls1-guardian/personal-dtls1-guardian.component';
import { PersonalDtls2GuardianComponent } from './A-guardian-form/personal-dtls2-guardian/personal-dtls2-guardian.component';
import { FatcaGuardianComponent } from './A-guardian-form/fatca-guardian/fatca-guardian.component';
import { KycDtls1GuardianComponent } from './A-guardian-form/kyc-dtls1-guardian/kyc-dtls1-guardian.component';
import { KycDtls2GuardianComponent } from './A-guardian-form/kyc-dtls2-guardian/kyc-dtls2-guardian.component';
import { KycDtls3GuardianComponent } from './A-guardian-form/kyc-dtls3-guardian/kyc-dtls3-guardian.component';
import { KycDtls4GuardianComponent } from './A-guardian-form/kyc-dtls4-guardian/kyc-dtls4-guardian.component';
import { ContactDtlsGuardianComponent } from './A-guardian-form/contact-dtls-guardian/contact-dtls-guardian.component';
import { AddrsDtls1GuardianComponent } from './A-guardian-form/addrs-dtls1-guardian/addrs-dtls1-guardian.component';
import { AddrsDtls2GuardianComponent } from './A-guardian-form/addrs-dtls2-guardian/addrs-dtls2-guardian.component';
import { CustomerProfileGuardianComponent } from './A-guardian-form/customer-profile-guardian/customer-profile-guardian.component';
import { InterBank1GuardianComponent } from './A-guardian-form/inter-bank1-guardian/inter-bank1-guardian.component';
import { InterBank2GuardianComponent } from './A-guardian-form/inter-bank2-guardian/inter-bank2-guardian.component';
import { DocumentUpload1GuardianComponent } from './A-guardian-form/document-upload1-guardian/document-upload1-guardian.component';
import { DocAddrsProof1GuardianComponent } from './A-guardian-form/doc-addrs-proof1-guardian/doc-addrs-proof1-guardian.component';
import { DocAddrsProof2GuardianComponent } from './A-guardian-form/doc-addrs-proof2-guardian/doc-addrs-proof2-guardian.component';
import { DocAddrsProof3GuardianComponent } from './A-guardian-form/doc-addrs-proof3-guardian/doc-addrs-proof3-guardian.component';
import { DocForm60GuardianComponent } from './A-guardian-form/doc-form60-guardian/doc-form60-guardian.component';
import { DocIdentityProofGuardianComponent } from './A-guardian-form/doc-identity-proof-guardian/doc-identity-proof-guardian.component';
import { DocOtherGuardianComponent } from './A-guardian-form/doc-other-guardian/doc-other-guardian.component';
import { DocPioGuardianComponent } from './A-guardian-form/doc-pio-guardian/doc-pio-guardian.component';
import { DocVisaGuardianComponent } from './A-guardian-form/doc-visa-guardian/doc-visa-guardian.component';
import { Nomination1GuardianComponent } from './A-guardian-form/nomination1-guardian/nomination1-guardian.component';
import { Nomination2GuardianComponent } from './A-guardian-form/nomination2-guardian/nomination2-guardian.component';
import { Nomination3GuardianComponent } from './A-guardian-form/nomination3-guardian/nomination3-guardian.component';
import { Diclaration1GuardianComponent } from './A-guardian-form/diclaration1-guardian/diclaration1-guardian.component';
import { Diclaration2GuardianComponent } from './A-guardian-form/diclaration2-guardian/diclaration2-guardian.component';





@NgModule({
  declarations: [
    PersonalDtls1MinorComponent,
    PersonalDtls2MinorComponent,
    KycDtls1MinorComponent,
    KycDtls2MinorComponent,
    KycDtls3MinorComponent,
    KycDtls4MinorComponent,
    DocIdentityProofMinorComponent,
    DocVisaMinorComponent,
    DocPioMinorComponent,
    DocOtherProofMinorComponent,
    DocumentUpload1MinorComponent,
    GuardianDtlsComponent,
    PersonalDtls1GuardianComponent,
    PersonalDtls2GuardianComponent,
    FatcaGuardianComponent,
    KycDtls1GuardianComponent,
    KycDtls2GuardianComponent,
    KycDtls3GuardianComponent,
    KycDtls4GuardianComponent,
    ContactDtlsGuardianComponent,
    AddrsDtls1GuardianComponent,
    AddrsDtls2GuardianComponent,
    CustomerProfileGuardianComponent,
    InterBank1GuardianComponent,
    InterBank2GuardianComponent,
    DocumentUpload1GuardianComponent,
    DocAddrsProof1GuardianComponent,
    DocAddrsProof2GuardianComponent,
    DocAddrsProof3GuardianComponent,
    DocForm60GuardianComponent,
    DocIdentityProofGuardianComponent,
    DocOtherGuardianComponent,
    DocPioGuardianComponent,
    DocVisaGuardianComponent,
    Nomination1GuardianComponent,
    Nomination2GuardianComponent,
    Nomination3GuardianComponent,
    Diclaration1GuardianComponent,
    Diclaration2GuardianComponent,

  ],
  imports: [
    CommonModule,
    HttpClientModule,
    RouterModule,
    ReactiveFormsModule,
    FormsModule,
    MatInputModule,
    MatFormFieldModule,
    MatDatepickerModule,
    MatNativeDateModule,
  ]
})
export class MinorAccntModule { }
