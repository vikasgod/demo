import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PersonalDtls2MinorComponent } from './personal-dtls2-minor.component';

describe('PersonalDtls2MinorComponent', () => {
  let component: PersonalDtls2MinorComponent;
  let fixture: ComponentFixture<PersonalDtls2MinorComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PersonalDtls2MinorComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PersonalDtls2MinorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
