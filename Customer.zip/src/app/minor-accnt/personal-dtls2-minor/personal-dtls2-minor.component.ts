import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { CommonService } from 'src/app/services/common.service';
import { Router } from '@angular/router';
import { CustomerDataService } from 'src/app/services/customer-data.service';

@Component({
  selector: 'app-personal-dtls2-minor',
  templateUrl: './personal-dtls2-minor.component.html',
  styleUrls: ['./personal-dtls2-minor.component.css']
})
export class PersonalDtls2MinorComponent implements OnInit {

  regObj: any;
  currentDate: string = '';
  countryData: any;
  prsnlDtlsForm: any;
  titleData: any;
  titleDataArr: any;
  dateNri: any;
  applicant_personal_id: any;
  isDisplayMaidenName: boolean = false;

  isDisplayUpdateBtn: boolean = false;

  constructor(private fb: FormBuilder, private commonService: CommonService, private rt: Router, private customerDataService: CustomerDataService) { }

  ngOnInit(): void {

    this.regObj = this.commonService.getUserFromLocalStorage();

    if (this.regObj.isSubmited || (this.regObj.leadReviewStatus != "customer_process" && this.regObj.leadReviewStatus != "agent_review")) {
      this.rt.navigate(["/minor-accnt", "ending"]);
    }


    


    this.currentDate = this.commonService.getCurrentDate();

    let Obj = {
      applicant_id: this.regObj?.applicant_id,
      process_id: 34
    }



    this.customerDataService.fetchPersonalDtls2(Obj).subscribe((value) => {

      if (value?.data?.length > 0) {
        this.isDisplayUpdateBtn = true;
        this.dateNri = new Date(value?.data?.[0]?.date_of_becoming_nri);
        this.prsnlDtlsForm = this.fb.group({
          prsnlDtlsMothersFirstName: [value?.data?.[0]?.mother_first_name, [Validators.required]],
          prsnlDtlsMothersMiddleName: [value?.data?.[0]?.mother_middle_name],
          prsnlDtlsMothersLastName: [this.regObj?.last_name],
          // prsnlDtlsFathersNameValid: [value?.data?.[0]?.in_relation_type, [Validators.required]],
          // prsnlDtlsFathersTitle: [value?.data?.[0]?.in_relation_title, [Validators.required]],
          prsnlDtlsFathersFirstName: [value?.data?.[0]?.in_relation_first_name, [Validators.required]],
          prsnlDtlsFathersMiddleName: [value?.data?.[0]?.in_relation_middle_name],
          prsnlDtlsFathersLastName: [value?.data?.[0]?.in_relation_last_name],

          prsnlDtlsCountry: [value?.data?.[0]?.nationality, [Validators.required]],
          prsnlDtlsDtNri: [this.dateNri, [Validators.required]],
        })
        this.applicant_personal_id = value?.data?.[0]?.applicant_personal_id;
      }
      else {
        this.isDisplayUpdateBtn = false;
      }
    })

    this.prsnlDtlsForm = this.fb.group({
      prsnlDtlsMothersFirstName: ['', [Validators.required]],
      prsnlDtlsMothersMiddleName: [''],
      prsnlDtlsMothersLastName: [''],
      // prsnlDtlsFathersNameValid: ['', [Validators.required]],
      // prsnlDtlsFathersTitle: ['', [Validators.required]],
      prsnlDtlsFathersFirstName: ['', [Validators.required]],
      prsnlDtlsFathersMiddleName: [''],
      prsnlDtlsFathersLastName: [''],

      prsnlDtlsCountry: ['', [Validators.required]],
      prsnlDtlsDtNri: ['', [Validators.required]],
    })

    this.currentDate = this.commonService.getCurrentDate();

    this.customerDataService.getCountry().subscribe((data) => {
      this.countryData = data;
    })


    this.customerDataService.getTitle().subscribe((data) => {
      this.titleData = data
    })

    this.prsnlDtlsForm.controls['prsnlDtlsMothersLastName'].setValue(this.regObj?.last_name);
    this.prsnlDtlsForm.controls['prsnlDtlsCountry'].setValue(this.regObj?.country_id);
  }

  get prsnlDtlsMothersFirstName() { return this.prsnlDtlsForm.get("prsnlDtlsMothersFirstName") }
  get prsnlDtlsMothersMiddleName() { return this.prsnlDtlsForm.get("prsnlDtlsMothersMiddleName") }
  get prsnlDtlsMothersLastName() { return this.prsnlDtlsForm.get("prsnlDtlsMothersLastName") }

  // get prsnlDtlsFathersNameValid() { return this.prsnlDtlsForm.get("prsnlDtlsFathersNameValid") }

  get prsnlDtlsFathersTitle() { return this.prsnlDtlsForm.get("prsnlDtlsFathersTitle") }
  get prsnlDtlsFathersFirstName() { return this.prsnlDtlsForm.get("prsnlDtlsFathersFirstName") }
  get prsnlDtlsFathersMiddleName() { return this.prsnlDtlsForm.get("prsnlDtlsFathersMiddleName") }
  get prsnlDtlsFathersLastName() { return this.prsnlDtlsForm.get("prsnlDtlsFathersLastName") }

  get prsnlDtlsCountry() { return this.prsnlDtlsForm.get("prsnlDtlsCountry") }
  get prsnlDtlsDtNri() { return this.prsnlDtlsForm.get("prsnlDtlsDtNri") }

  keypressLetters(event: any) {
    //return this.commonService.enterOnlyAlphabetsNoSpace(event);
    return this.commonService.enterOnlyAlphabetsNoSpace(event)
  }

  submitPersnalDtlsMinor() {
    console.log('This is personal Details 2', this.prsnlDtlsForm.value)
    console.log('This is personal 2 form', this.prsnlDtlsForm);
    //if (this.prsnlDtlsForm.valid) {
    this.regObj = this.commonService.getUserFromLocalStorage();

    // this.prsnlDtlsForm.get("prsnlDtlsMothersFirstName").value
    // this.prsnlDtlsForm.get("prsnlDtlsMothersMiddleName").value
    // this.prsnlDtlsForm.get("prsnlDtlsMothersLastName").value

    // this.prsnlDtlsForm.get("prsnlDtlsFathersNameValid").value

    // this.prsnlDtlsForm.get("prsnlDtlsFathersTitle").value
    // this.prsnlDtlsForm.get("prsnlDtlsFathersFirstName").value
    // this.prsnlDtlsForm.get("prsnlDtlsFathersMiddleName").value
    // this.prsnlDtlsForm.get("prsnlDtlsFathersLastName").value

    // this.prsnlDtlsForm.get("prsnlDtlsCountry").value
    // this.prsnlDtlsForm.get("prsnlDtlsDtNri").value

    let Obj = {
      applicant_id: this.regObj.applicant_id,
      process_id: 34,
      mother_first_name: this.prsnlDtlsForm.get('prsnlDtlsMothersFirstName')?.value,
      mother_middle_name: this.prsnlDtlsForm.get('prsnlDtlsMothersMiddleName')?.value,
      mother_last_name: this.prsnlDtlsForm.get('prsnlDtlsMothersLastName')?.value,
      in_relation_first_name: this.prsnlDtlsForm.get('prsnlDtlsFathersFirstName')?.value,
      in_relation_middle_name: this.prsnlDtlsForm.get('prsnlDtlsFathersMiddleName')?.value,
      in_relation_last_name: this.prsnlDtlsForm.get('prsnlDtlsFathersLastName')?.value,
      nationality: this.prsnlDtlsForm.get('prsnlDtlsCountry')?.value,
      date_of_becoming_nri: this.customerDataService.formatDob(this.prsnlDtlsForm.get('prsnlDtlsDtNri')?.value),
    }
    this.customerDataService.postPersonalDtls2Minor(Obj).subscribe((data) => {
      if (this.commonService.getUserFromLocalStorage()?.leadReviewStatus !='agent_review') {
        this.rt.navigate(["/minor-accnt", "kyc-dtls1-minor"]);
      } 
      else {
        this.rt.navigate(["/feedback", "feedback-summary"]);
      }
    })

    // } else {
    // }

  }
}