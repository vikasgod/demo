import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DocIdentityProofMinorComponent } from './doc-identity-proof-minor.component';

describe('DocIdentityProofMinorComponent', () => {
  let component: DocIdentityProofMinorComponent;
  let fixture: ComponentFixture<DocIdentityProofMinorComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DocIdentityProofMinorComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DocIdentityProofMinorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
