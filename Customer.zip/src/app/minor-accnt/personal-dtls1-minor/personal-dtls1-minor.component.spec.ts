import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PersonalDtls1MinorComponent } from './personal-dtls1-minor.component';

describe('PersonalDtls1MinorComponent', () => {
  let component: PersonalDtls1MinorComponent;
  let fixture: ComponentFixture<PersonalDtls1MinorComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PersonalDtls1MinorComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PersonalDtls1MinorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
