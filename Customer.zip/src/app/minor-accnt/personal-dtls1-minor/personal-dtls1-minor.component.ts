import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { CommonService } from 'src/app/services/common.service';
import { Router } from '@angular/router';
import { CustomerDataService } from 'src/app/services/customer-data.service';
import { Observable, of } from 'rxjs';

@Component({
  selector: 'app-personal-dtls1-minor',
  templateUrl: './personal-dtls1-minor.component.html',
  styleUrls: ['./personal-dtls1-minor.component.css']
})
export class PersonalDtls1MinorComponent implements OnInit {


  startDate = new Date(1990, 0, 1);
  currentDate: any | string | boolean | undefined;
  persnDltsForm: any;
  picker: any = '';
  religionData: any = '';
  categoryData: any;
  regObj: any;
  titleArrData: any;
  formData: any;
  applicant_personal_id: any;
  frirstName: string = '';
  lastName: string = '';
  religionObs$: Observable<any> = of();
  isDisplayUpdateBtn: boolean = false;
  isUpdate=false
  constructor(private fb: FormBuilder, private commonService: CommonService, private rt: Router, private customerDataService: CustomerDataService) { }

  ngOnInit(): void {
    this.regObj = this.commonService.getUserFromLocalStorage();
    if ((this.regObj.isSubmitted != undefined && this.regObj.isSubmitted != 0)
      || ((this.regObj.leadReviewStatus != undefined && this.regObj.leadReviewStatus != "customer_process")
        && (this.regObj.leadReviewStatus != undefined && this.regObj.leadReviewStatus != "agent_review"))
    ) {
      // this.rt.navigate(["/individual-account", "ending"]);
    }

    if (this.commonService.getUserFromLocalStorage()?.leadStatus) {
      this.isDisplayUpdateBtn = false;
    } else {
      this.isDisplayUpdateBtn = true;
    }
    let Obj = {
      applicant_id: this.regObj.applicant_id,
      process_id: 33,
      account_type_id: this?.regObj?.account_type_id,
    }

    this.customerDataService.fetchPersonalDtls1(Obj).subscribe((value) => {
      if (value?.data?.length > 0) {
        if(value?.data?.length > 2){
          this.isUpdate = true
        }
        this.persnDltsForm = this.fb.group({
          prnltitle: [value?.data?.[0]?.applicant_title==null?'':value?.data?.[0]?.applicant_title, [Validators.required]],
          prnlFirstName: [value?.data?.[0]?.applicant_first_name, [Validators.required]],
          prnlMiddleName: [value?.data?.[0]?.applicant_middle_name],
          prnlLastName: [value?.data?.[0]?.applicant_last_name],
          prnlaadhaarNo1: [this.getAadhaarNumber(value?.data?.[0]?.aadhaar_number)],
          prnlReligion: [value?.data?.[0]?.religion_id==undefined?'':value?.data?.[0]?.religion_id, [Validators.required]],
          prnlCategory: [value?.data?.[0]?.religion_category_id==undefined?'':value?.data?.[0]?.religion_category_id, [Validators.required]],
          prnlPolticalExpsd: [String(value?.data?.[0]?.is_politically_exposed == undefined ? '': value?.data?.[0]?.is_politically_exposed), [Validators.required]],
          prnlDOb: [value?.data?.[0]?.date_of_birth, [Validators.required]],
          prnlGender: [value?.data?.[0]?.gender==undefined?'':value?.data?.[0]?.gender, [Validators.required]],
        })
      }
      //value?.data?.[0]?.aadhaar_number
      this.applicant_personal_id = value?.data?.[0]?.applicant_personal_id;
    })

    this.persnDltsForm = this.fb.group({
      prnltitle: ['', [Validators.required]],
      prnlFirstName: ['', [Validators.required]],
      prnlMiddleName: [''],
      prnlLastName: [''],
      prnlaadhaarNo1: [''],
      prnlReligion: ['', [Validators.required]],
      prnlCategory: ['', [Validators.required]],
      prnlPolticalExpsd: ['', [Validators.required]],
      prnlDOb: ['', [Validators.required]],
      prnlGender: ['', [Validators.required]],
    })

    this.currentDate = this.commonService.getCurrentDate();
    this.customerDataService.getTitle().subscribe((data) => {
      this.titleArrData = data;
    })

    this.customerDataService.getReligion().subscribe((data) => {
      this.religionData = data;
    })

    this.customerDataService.getCategory().subscribe((data) => {
      this.categoryData = data;
    })
  }

  get prnltitle() { return this.persnDltsForm.get("prnltitle") }
  get prnlFirstName() { return this.persnDltsForm.get("prnlFirstName") }
  get prnlMiddleName() { return this.persnDltsForm.get("prnlMiddleName") }
  get prnlLastName() { return this.persnDltsForm.get("prnlLastName") }
  get prnlaadhaarNo1() { return this.persnDltsForm.get("prnlaadhaarNo1") }
  get prnlaadhaarNo2() { return this.persnDltsForm.get("prnlaadhaarNo2") }
  get prnlaadhaarNo3() { return this.persnDltsForm.get("prnlaadhaarNo3") }
  get prnlReligion() { return this.persnDltsForm.get("prnlReligion") }
  get prnlCategory() { return this.persnDltsForm.get("prnlCategory") }
  get prnlPolticalExpsd() { return this.persnDltsForm.get("prnlPolticalExpsd") }
  get prnlDOb() { return this.persnDltsForm.get("prnlDOb") }
  get prnlGender() { return this.persnDltsForm.get("prnlGender") }

  changeExposed(event: any) {
    // if(event.target.value==='0')
    // {
    //   this.isSubmitted=true
    // }else if(event.target.value==='1')
    // {
    //   this.isSubmitted=false
    // }
  }

  keypressLetters(event: any) {
    //return this.commonService.enterOnlyAlphabets(event);
    return this.commonService.enterOnlyAlphabetsNoSpace(event);
  }

  validateAadhar(event: any) {
    if(event.target.value!=""){
      this.persnDltsForm.controls['prnlaadhaarNo1'].setValidators(Validators.pattern(/[0-9\s]{14}/))
    }
    else{
      this.persnDltsForm.controls['prnlaadhaarNo1'].clearValidators();
    }
    this.persnDltsForm.controls['prnlaadhaarNo1'].updateValueAndValidity();
    return this.commonService.validateAadhar(event);
    
  }

  selectTitle(event: any) {
    console.log("title");
    let applicantTitle = event.target.value;
    
    if(event.target.value == 'mr'){
      this.persnDltsForm.controls['prnlGender'].setValue('male')
    }
    else if(event.target.value == 'mrs'){
      this.persnDltsForm.controls['prnlGender'].setValue('female')
    }
    else if(event.target.value == 'ms'){
      this.persnDltsForm.controls['prnlGender'].setValue('female')
    }

    // this.commonService.storeInLocalStorage('registerData', { applicantTitle: applicantTitle })
  }

  getAadhaarNumber(value: any) {
    if(value != undefined){
      let str1 = String(value).slice(0, 4);
      let str2 = String(value).slice(4, 8);
      let str3 = String(value).slice(8, 12)
      return `${str1} ${str2} ${str3}`
    }
    else{
      return ''
    }
  }

  submitPersnalDtls() {
    this.regObj = this.commonService.getUserFromLocalStorage();
    let addharNumberArr = String(this.persnDltsForm.get("prnlaadhaarNo1").value).split(' ');
    let addhaarNumber = addharNumberArr.join('');
    this.commonService.storeInLocalStorage('registerData',  { 'middle_name': this.persnDltsForm.value.prnlMiddleName })
    let Obj = {
      applicant_personal_id: String(this.applicant_personal_id),
      user_id: this.regObj?.user_id,
      account_type_id: this?.regObj?.account_type_id,
      applicant_title: this.persnDltsForm.get("prnltitle").value,
      applicant_first_name: this.persnDltsForm.get("prnlFirstName").value,
      applicant_middle_name: this.persnDltsForm.get("prnlMiddleName").value,
      applicant_last_name: this.persnDltsForm.get("prnlLastName").value,

      aadhaar_number: Number(addhaarNumber),
      religion_id: Number(this.persnDltsForm.get("prnlReligion").value),
      religion_category_id: Number(this.persnDltsForm.get("prnlCategory").value),
      is_politically_exposed: Number(this.persnDltsForm.get("prnlPolticalExpsd").value),
      date_of_birth: this.customerDataService.formatDob(this.persnDltsForm.get("prnlDOb").value),
      gender: this.persnDltsForm.get("prnlGender").value,
      
      is_consent_declared: 2,
      is_Submitted: 1,
      process_id: 33,
      applicant_id: Number(this.regObj?.applicant_id)
    }

    this.customerDataService.postPersonalDtls1(Obj).subscribe((data) => {
    })

    // this.commonService.storeInLocalStorage('registerData', { isSubmitted: this.isSubmitted })
    // if (this.isSubmitted === undefined) {
    //   if (this.isSubmitted == true) {
    //     this.rt.navigate(["/individual-account", "ending"]);
    //   }
    // }

    // if (this.commonService.getUserFromLocalStorage()?.isSubmitted !== undefined || this.commonService.getUserFromLocalStorage()?.isSubmitted !== 'undefined' || this.commonService.getUserFromLocalStorage()?.isSubmitted !== null) {
    //   if (this.commonService.getUserFromLocalStorage()?.isSubmitted == true) {
    //     this.rt.navigate(["/individual-account", "ending"]);
    //   }
    // }
    // if (this.commonService.getUserFromLocalStorage()?.leadStatus !== undefined || this.commonService.getUserFromLocalStorage()?.leadStatus !== 'undefined' || this.commonService.getUserFromLocalStorage()?.leadStatus !== null) {
    //   this.rt.navigate(["/individual-account", "personal-dtls2"]);
    // }

    if (this.commonService.getUserFromLocalStorage()?.leadReviewStatus == 'customer_process') {
      // this.rt.navigate(["/feedback", "feedback-summary"]);
      this.rt.navigate(["/minor-accnt", "personal-dtls2-minor"]);
    }
    else if (this.commonService.getUserFromLocalStorage()?.leadReviewStatus == 'agent_review') {
      this.rt.navigate(["/feedback", "feedback-summary"]);
    }
    // else {
    //   this.rt.navigate(["/feedback", "feedback-summary"]);
    // }
    //this.rt.navigate(["/individual-account", "personal-dtls2"]);
    /*}else{
    }*/
  }
}
