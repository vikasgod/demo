import { Component, OnInit, ElementRef, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { Observable, of } from 'rxjs';
import { CommonService } from 'src/app/services/common.service';
import { CustomerDataService } from 'src/app/services/customer-data.service';

@Component({
  selector: 'app-document-upload1-minor',
  templateUrl: './document-upload1-minor.component.html',
  styleUrls: ['./document-upload1-minor.component.css']
})
export class DocumentUpload1MinorComponent implements OnInit {

  isDisplayForm60: boolean = false;
  isDisplayVisa: boolean = true;
  isDisplayPIO: boolean = true;
  addressProofDoc: any;

  regObj: any;
  isOtherThanIndianPassport:string='';

  imgSrcPsportFront: string = '';
  imgSrcPsportBack: string = '';
  imgSrcPio1: string = '';
  imgSrcPio2: string = '';
  imgSrcOtherDoc: string = '';
  imgVisaDoc:string = ''

  showInfoDetail:string = '';

  passportFront$: Observable<any> = of();
  passportBack$: Observable<any> = of();


  display: string = "none";

  docValidPassportErr: string = '';
  isDisplayAddressProofUpload: boolean = true;

  @ViewChild('addressProofddl')
  addressProofddl!: ElementRef;
  renderer: any;


  constructor(private rt: Router, private commonService: CommonService, private customerDataService: CustomerDataService) {
    this.getDoc()
  }

  ngOnInit(): void {

    this.regObj = this.commonService.getUserFromLocalStorage();
    if (this.regObj.isSubmited || this.regObj.leadReviewStatus != "customer_process") {
      this.rt.navigate(["/minor-accnt", "ending"]);
    }

    let Obj = {
      applicant_id: this.commonService.getUserFromLocalStorage().applicant_id
    }
    this.customerDataService.postCustomerDocumentCondition(Obj).subscribe((value) => {
      console.log(value.data[0]);

      if (value.data[0].visa_type == 1 || value.data[0].visa_type == undefined || value.data[0].visa_type == "" || value.data[0].visa_type == 0) {
        this.isDisplayVisa = false
      }

      if (value.data[0].is_pio == undefined || value.data[0].is_pio == "" || value.data[0].is_pio == 0) {
        this.isDisplayPIO = false;
      }

    }, (err) => {

    });

    this.customerDataService.getAddressProofDoc().subscribe((value) => {
      this.addressProofDoc = value;
    })

    this.getDoc() 


    // changing text Indian to foreign for other than passport
    let Obj0 = {
      applicant_id: this.regObj.applicant_id,
      process_id: 35
    }

    this.customerDataService.fetchKycDtls1(Obj0).subscribe((data)=>{
     this.isOtherThanIndianPassport = data?.data?.map((data:any)=>{
       return data?.is_other_than_indian_passport_name === "yes"? "Foreign":"Indian";
      })      
    })
  }

  getDoc() {
    let Obj1 = {
      applicant_id: this.commonService.getUserFromLocalStorage().applicant_id,
      document: "passport_front"
    }
    this.customerDataService.postCustomerGetDoc(Obj1).subscribe((value) => {
      this.imgSrcPsportFront = value?.file_path;
    });

    let Obj2 = {
      applicant_id: this.commonService.getUserFromLocalStorage().applicant_id,
      document: "passport_back"
    }
    this.customerDataService.postCustomerGetDoc(Obj2).subscribe((value) => {
      this.imgSrcPsportBack = value?.file_path;
    });

    let Obj6 = {
      applicant_id: this.commonService.getUserFromLocalStorage().applicant_id,
      document: "visa"
    }
    this.customerDataService.postCustomerGetDoc(Obj6).subscribe((value) => {
      this.imgVisaDoc = value?.file_path;
    }, (err) => {

    });

    let Obj7 = {
      applicant_id: this.commonService.getUserFromLocalStorage().applicant_id,
      document: "old_indian_passport_front"
    }
    this.customerDataService.postCustomerGetDoc(Obj7).subscribe((value) => {
      this.imgSrcPio1 = value?.file_path;
    }, (err) => {

    });

    let Obj8 = {
      applicant_id: this.commonService.getUserFromLocalStorage().applicant_id,
      document: "old_indian_passport_back"
    }
    this.customerDataService.postCustomerGetDoc(Obj8).subscribe((value) => {
      this.imgSrcPio2 = value?.file_path;
    }, (err) => {

    });

    let Obj9 = {
      applicant_id: this.commonService.getUserFromLocalStorage().applicant_id,
      document: "other"
    }
    this.customerDataService.postCustomerGetDoc(Obj9).subscribe((value) => {
      console.log('check other', value[0].file_path);
      
      this.imgSrcOtherDoc = value[0].file_path;
    }, (err) => {

    });

  }

  ngAfterViewInit(): void {
    //this.addressProofddl.nativeElement.setValue('1')
  }

  viewDoc(link: string) {
    console.log('This is link', link);
    window.open(link);
  }

  addAdressProof(event: any) {
    // alert(event.target.value);
    let docAddressType = event.target.value;
    console.log('This is event', event.target);
    if (docAddressType === '1') {
      this.docValidPassportErr = 'Already uploaded passport';
      this.isDisplayAddressProofUpload = false;
    }
    this.commonService.storeInLocalStorage('registerData', { docAddressType: docAddressType });
  }

  redirectUploadPage(path1: string, path2: string) {
    this.rt.navigate([`${path1}`, `${path2}`])
  }

  redirectGuardianDtls() {
    this.rt.navigate([`minor-accnt`, `guardian-dtls`])
    
  }

  openModal() {
    this.display = "block";
  }

  onCloseHandled() {
    this.display = "none";
  }

  //  show info click on i-info button
  showInfoDetails(label: any) {
    this.showInfoDetail = label;
  }
}