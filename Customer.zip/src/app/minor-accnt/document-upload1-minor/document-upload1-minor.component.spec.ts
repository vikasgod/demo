import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DocumentUpload1MinorComponent } from './document-upload1-minor.component';

describe('DocumentUpload1MinorComponent', () => {
  let component: DocumentUpload1MinorComponent;
  let fixture: ComponentFixture<DocumentUpload1MinorComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DocumentUpload1MinorComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DocumentUpload1MinorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
