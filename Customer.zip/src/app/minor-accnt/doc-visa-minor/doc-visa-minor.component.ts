import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { CommonService } from 'src/app/services/common.service';
import { CustomerDataService } from 'src/app/services/customer-data.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-doc-visa-minor',
  templateUrl: './doc-visa-minor.component.html',
  styleUrls: ['./doc-visa-minor.component.css']
})
export class DocVisaMinorComponent implements OnInit {

  requiredFileType: string = 'image/png,image/jpeg'
  docVisaMinorForm: any;
  iSfile1Change: boolean = false;
  errFileExtension: boolean = true;
  imgSrc: any = '';
  fileDataStr1: any = '';
  fileName1: string = '';
  regObj: any;
  imgSrc1: string = '';
  docVisaErr: string = '';
  display: string = "none";
  constructor(private fb: FormBuilder, private commonService: CommonService, private customerDataService: CustomerDataService, private rt: Router) {
    this.getDoc()
   }

  ngOnInit(): void {
    this.docVisaMinorForm = this.fb.group({
      docVisaFile1: ['', Validators.required]
    })

    this.getDoc()
  }

  getDoc(){
    let Obj = {
      applicant_id: this.commonService.getUserFromLocalStorage()?.applicant_id,
      document: "visa"
    }

    this.customerDataService.fetchGetDoc(Obj).subscribe((value) => {
      
      this.imgSrc1 = value?.file_path;
      let name = value.file_path.split("/").pop()
      this.customerDataService.getBase64ImageFromUrl(value.file_path).then(result => {
        this.fileDataStr1 = result
      })
        .catch(err => console.error(err));
      this.fileName1 = name;
    })
  }

  get docVisaFile1() { return this.docVisaMinorForm.get("docVisaFile1") }


  //Working 1  
  onFilesSelected1(event: any) {
    this.iSfile1Change = true;
    let fileData = event.target.files[0];
    this.fileName1 = fileData.name;
    let arr = String(fileData.name).split('.');
    let len = arr.length;

    if (fileData.size <= 5000000) {
      if (arr[len - 1] === "png" || arr[len - 1] === "jpeg" || arr[len - 1] === "jpg") {

        const reader = new FileReader();
        reader.onloadend = () => {
          this.imgSrc1 = String(reader.result)
          // Use a regex to remove data url part
          const base64String = String(reader.result)
            .replace('data:', '')
            .replace(/^.+,/, '');
          this.fileDataStr1 = base64String;
          //console.log("THis is file1 base64 string",base64String);

        };
        reader.readAsDataURL(fileData);
      } else {
        this.errFileExtension = false;
      }
    } else {
      this.fileName1 = '';
      this.docVisaMinorForm.get('docVisaFile1').setValue('');
      this.docVisaErr = 'File size exceeds 5mb'
      this.openModal();
    }
    //return
  }


  openModal() {
    this.display = "block";
  }

  onCloseHandled() {
    this.display = "none";
  }

  submitVisaMinor() {
    this.regObj = this.commonService.getUserFromLocalStorage();
    if (this.regObj.isSubmited) {
      this.rt.navigate(["/minor-accnt", "ending"]);
    }

    let Obj = {
      applicant_id: this.regObj.applicant_id,
      process_id: 41,
      file: this.fileDataStr1,
    }
    this.customerDataService.postCustomerVisaDoc(Obj).subscribe((data) => {
      this.rt.navigate(['/minor-accnt', 'document-upload1-minor']);
    })
  }
}