import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DocVisaMinorComponent } from './doc-visa-minor.component';

describe('DocVisaMinorComponent', () => {
  let component: DocVisaMinorComponent;
  let fixture: ComponentFixture<DocVisaMinorComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DocVisaMinorComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DocVisaMinorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
