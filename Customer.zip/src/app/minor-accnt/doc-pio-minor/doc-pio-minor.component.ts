import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { CommonService } from 'src/app/services/common.service';
import { CustomerDataService } from 'src/app/services/customer-data.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-doc-pio-minor',
  templateUrl: './doc-pio-minor.component.html',
  styleUrls: ['./doc-pio-minor.component.css']
})
export class DocPioMinorComponent implements OnInit {

  requiredFileType: string = 'image/png,image/jpeg'
  docPioMinor: any;
  iSfile1Change: boolean = false;
  errFileExtension: boolean = true;
  imgSrc: any = '';
  fileDataStr1: any = '';
  fileName1: string = '';
  regObj: any;
  imgSrc1: string = '';
  fileDataStr2: any = '';
  fileName2: string = '';
  imgSrc2: string = '';


  docPioErr: string = '';

  display: string = "none";
  constructor(private fb: FormBuilder, private commonService: CommonService, private customerDataService: CustomerDataService, private rt: Router) {
    this.getDoc()
  }

  ngOnInit(): void {
    this.docPioMinor = this.fb.group({
      docPioMinorFile1: ['', [Validators.required]],
      docPioMinorFile2: ['', [Validators.required]]
    })


    this.getDoc()

    //console.log('This is image base64',this.img1);
  }

  getDoc() {
    let Obj1 = {
      applicant_id: this.commonService.getUserFromLocalStorage()?.applicant_id,
      document: "old_indian_passport_front"
    }

    this.customerDataService.fetchGetDoc(Obj1).subscribe((value) => {
      console.log(this.docPioMinor.get('docPioMinorFile1'));
      this.imgSrc1 = value.file_path;
      let name = value.file_path.split("/").pop()
      this.customerDataService.getBase64ImageFromUrl(value.file_path).then(result => {
        this.fileDataStr1 = result
      })
        .catch(err => console.error(err));
      this.fileName1 = name;
    });


    let Obj2 = {
      applicant_id: this.commonService.getUserFromLocalStorage()?.applicant_id,
      document: "old_indian_passport_back"
    }

    this.customerDataService.fetchGetDoc(Obj2).subscribe((value) => {
      this.imgSrc2 = value?.file_path
      let name = value.file_path.split("/").pop()
      this.customerDataService.getBase64ImageFromUrl(value.file_path).then(result => {
        this.fileDataStr2 = result
      })
        .catch(err => console.error(err));
      this.fileName2 = name;
      console.log(this.docPioMinor.get("docPioMinorFile2"));
    });
  }


  get docPioMinorFile1() { return this.docPioMinor.get("docPioMinorFile1") }

  get docPioMinorFile2() { return this.docPioMinor.get("docPioMinorFile2") }




  //Working 1  
  onFilesSelected1(event: any) {

    this.iSfile1Change = true;

    let fileData = event.target.files[0];


    this.fileName1 = fileData.name;

    let arr = String(fileData.name).split('.');
    let len = arr.length;

    if (fileData.size <= 5000000) {
      if (arr[len - 1] === "png" || arr[len - 1] === "jpeg" || arr[len - 1] === "jpg") {

        const reader = new FileReader();
        reader.onloadend = () => {
          this.imgSrc1 = String(reader.result)
          // Use a regex to remove data url part
          const base64String = String(reader.result)
            .replace('data:', '')
            .replace(/^.+,/, '');

          this.fileDataStr1 = base64String;

          //console.log("THis is file1 base64 string",base64String);

        };
        reader.readAsDataURL(fileData);
      } else {
        this.errFileExtension = false;

        console.log("Extension is not valid")

        //return
      }
    } else {


      this.fileName1 = '';
      this.docPioMinor.get('docPioMinorFile1').setValue('');
      this.docPioErr = 'File size exceeds 5mb'
      this.openModal();
    }

    //return
  }


  onFilesSelected2(event: any) {

    this.iSfile1Change = true;

    let fileData = event.target.files[0];


    this.fileName2 = fileData.name;

    let arr = String(fileData.name).split('.');
    let len = arr.length;
    if (fileData.size <= 5000000) {
      if (arr[len - 1] === "png" || arr[len - 1] === "jpeg" || arr[len - 1] === "jpg") {

        const reader = new FileReader();
        reader.onloadend = () => {
          this.imgSrc2 = String(reader.result)
          // Use a regex to remove data url part
          const base64String = String(reader.result)
            .replace('data:', '')
            .replace(/^.+,/, '');

          this.fileDataStr2 = base64String;

          //console.log("THis is file1 base64 string",base64String);

        };
        reader.readAsDataURL(fileData);
      } else {
        this.errFileExtension = false;

        console.log("Extension is not valid")

        //return
      }
    } else {
      this.fileName2 = '';
      this.docPioMinor.get('docPioMinorFile2').setValue('');
      this.docPioErr = 'File size exceeds 5mb'
      this.openModal();

    }

    //return
  }



  openModal() {
    this.display = "block";
  }

  onCloseHandled() {
    this.display = "none";
  }





  submitPioMinor() {
    this.regObj = this.commonService.getUserFromLocalStorage();


    if (this.regObj.isSubmited) {
      this.rt.navigate(["/minor-accnt", "ending"]);
    }


    let Obj = {


      applicant_id: this.regObj.applicant_id,
      process_id: 42,
      passport_front: this.fileDataStr1,
      passport_back: this.fileDataStr2
    }

    this.customerDataService.postCustomerPioDoc(Obj).subscribe((data) => {

      this.rt.navigate(['/minor-accnt', 'document-upload1-minor']);


    })



  }


}