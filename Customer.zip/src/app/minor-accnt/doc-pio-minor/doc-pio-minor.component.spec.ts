import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DocPioMinorComponent } from './doc-pio-minor.component';

describe('DocPioMinorComponent', () => {
  let component: DocPioMinorComponent;
  let fixture: ComponentFixture<DocPioMinorComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DocPioMinorComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DocPioMinorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
