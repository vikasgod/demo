import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-kyc-dtls3-minor',
  templateUrl: './kyc-dtls3-minor.component.html',
  styleUrls: ['./kyc-dtls3-minor.component.css']
})
export class KycDtls3MinorComponent implements OnInit {

  kycDtlsMinorCFrom: any;
  constructor(private rt: Router, private fb: FormBuilder) { }

  ngOnInit(): void {
    this.kycDtlsMinorCFrom = this.fb.group({
    })
  }

  submitKycDtlsMinor() {
    if (this.kycDtlsMinorCFrom.valid) {
      this.rt.navigate(["/minor-accnt/kyc-dtls2-minor"])
    } else {
      console.log("This form is invalid")
    }
  }
}