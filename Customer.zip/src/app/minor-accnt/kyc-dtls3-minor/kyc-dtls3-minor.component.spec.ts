import { ComponentFixture, TestBed } from '@angular/core/testing';

import { KycDtls3MinorComponent } from './kyc-dtls3-minor.component';

describe('KycDtls3MinorComponent', () => {
  let component: KycDtls3MinorComponent;
  let fixture: ComponentFixture<KycDtls3MinorComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ KycDtls3MinorComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(KycDtls3MinorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
