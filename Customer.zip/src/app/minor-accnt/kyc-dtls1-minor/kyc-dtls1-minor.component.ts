import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { CommonService } from 'src/app/services/common.service';
import { CustomerDataService } from 'src/app/services/customer-data.service';

@Component({
  selector: 'app-kyc-dtls1-minor',
  templateUrl: './kyc-dtls1-minor.component.html',
  styleUrls: ['./kyc-dtls1-minor.component.css']
})
export class KycDtls1MinorComponent implements OnInit {
  isDisablePancard: boolean = false
  isDisableForm60: boolean = false
  isDisablePassportType: any;
  isDisplayForm60: boolean = true;
  kycDtlsFromA: any;
  currentDate: any;
  typeVisaData: any;
  regObj: any;
  kyc_details_id: any;
  panLength: number = 0;
  isDisabledDate: any = true;
  panNo: any;
  isDisplayUpdateBtn: boolean = false;
  isPanDisable: boolean = false;
  foreignerPassword: boolean = true
  indianPassword: boolean = false;
  typeOfVisa: boolean = true;
  pan: boolean = true;
  formsixty: boolean = true;
  checkValidPan: any
  visatype: any;
  expiryDate: any;
  constructor(private rt: Router, private fb: FormBuilder, private commonService: CommonService, private customerDataService: CustomerDataService) { }

  ngOnInit(): void {
    this.regObj = this.commonService.getUserFromLocalStorage();
    if (this.regObj.Form60Doc != undefined) {
      this.isPanDisable = this.regObj.Form60Doc;
    }
    this.kycDtlsFromA = this.fb.group({
      kycDtlsOtherPssprt: ['', [Validators.required]],
      kycDtlsPassprtNo: ['', [Validators.required]],
      kycDtlsPassprtIssueDate: [''],
      kycDtlsPassprtExpiryDate: ['',[Validators.required]],
      kycDtlsPassprtIssAthrity: [''],
      kycDtlsPassprtPlcIssue: [''],
      kycDtlsPassprtTempVisaType: [null],
      kycDtlsVisaTypeExpiryDt: [''],
      kycDtlsResiPermit: [''],
      // kycDtlsPanNo: ['', [Validators.pattern(/^([A-Za-z]){5}([0-9]){4}([A-Za-z]){1}$/), Validators.required, Validators.maxLength(10)]],
      // kycDtlsForm60: [false, Validators.required],
    });

    this.selectTypeOfPassport()

    let Obj = {
      applicant_id: this.regObj.applicant_id,
      process_id: 35
    }

    this.customerDataService.fetchKycDtls1(Obj).subscribe((value) => {
      if (value?.data?.length > 0) {
        this.isDisplayUpdateBtn = true
        //If set form60 on load
        this.addForm60FileUpload(value?.data?.[0]?.is_form_60);
        //if other than Indian Passport is selected
        this.addTypeOfPassport(value?.data?.[0]?.is_other_than_indian_passport)
        this.addTypeOfResident(value?.data?.[0]?.is_resident_permit)
        this.kycDtlsFromA = this.fb.group({
          kycDtlsOtherPssprt: [String(value?.data?.[0]?.is_other_than_indian_passport), [Validators.required]],
          kycDtlsPassprtNo: [value?.data?.[0]?.passport_number],
          kycDtlsPassprtIssueDate: [value?.data?.[0]?.issue_date],
          kycDtlsPassprtExpiryDate: [value?.data?.[0]?.expiry_date,[Validators.required]],
          kycDtlsPassprtIssAthrity: [value?.data?.[0]?.issueing_authority],
          kycDtlsPassprtPlcIssue: [value?.data?.[0]?.place_of_issue],
          kycDtlsPassprtTempVisaType: [value?.data?.[0]?.visa_type],
          kycDtlsResiPermit: [String(value?.data?.[0]?.is_resident_permit)],
          kycDtlsVisaTypeExpiryDt: [value?.data?.[0]?.visa_permit_expiry_date],
          // kycDtlsPanNo: [value?.data?.[0]?.pan_number, [Validators.pattern(/^([A-Za-z]){5}([0-9]){4}([A-Za-z]){1}$/)]],
          // kycDtlsForm60: [value?.data?.[0]?.is_form_60],
        });

        // this.selectedForm60()

        this.panLength = value?.data?.[0]?.pan_number;
        this.panNo = String(value?.data?.[0]?.pan_number);
        this.kyc_details_id = value?.data?.[0]?.kyc_details_id;
        this.isDisablePassportType = value?.data?.[0]?.is_other_than_indian_passport;
      }
      
      else {
        this.formsixty = true
      }
      this.selectTypeOfPassport()
    })
    this.currentDate = this.commonService.getCurrentDate();
    this.customerDataService.getVisaType().subscribe((data) => {
      this.typeVisaData = data
      this.visatype = this.typeVisaData.data[0].visa_type_name
    })
    // this.onSelectPanCard()
  }

  get kycDtlsOtherPssprt() { return this.kycDtlsFromA.get("kycDtlsOtherPssprt") }
  get kycDtlsPassprtNo() { return this.kycDtlsFromA.get("kycDtlsPassprtNo") }
  get kycDtlsPassprtIssueDate() { return this.kycDtlsFromA.get("kycDtlsPassprtIssueDate") }
  get kycDtlsPassprtExpiryDate() { return this.kycDtlsFromA.get("kycDtlsPassprtExpiryDate") }
  get kycDtlsPassprtIssAthrity() { return this.kycDtlsFromA.get("kycDtlsPassprtIssAthrity") }
  get kycDtlsPassprtPlcIssue() { return this.kycDtlsFromA.get("kycDtlsPassprtPlcIssue") }
  get kycDtlsPassprtTempVisaType() { return this.kycDtlsFromA.get("kycDtlsPassprtTempVisaType") }
  get kycDtlsResiPermit() { return this.kycDtlsFromA.get("kycDtlsResiPermit") }
  get kycDtlsVisaTypeExpiryDt() { return this.kycDtlsFromA.get("kycDtlsVisaTypeExpiryDt") }
  // get kycDtlsPanNo() { return this.kycDtlsFromA.get("kycDtlsPanNo") }
  // get kycDtlsForm60() { return this.kycDtlsFromA.get("kycDtlsForm60") }

  keypressNumber(event: any) {
    return this.commonService.enterOnlyNumber(event);
  }

  keypressAlphabets(event: any) {
    return this.commonService.enterOnlyAlphabetsSpaceNBcktck(event);
  }

  keypressAplhaNumberic(event: any) {
    return this.commonService.allowAlphaNumericSpace(event)
  }

  checkSpecialChar(event: any) {
    return this.commonService.keypressSpecialChar(event)
  }

  // onSelectPanCard() {
  //   if (this.kycDtlsFromA.controls['kycDtlsPanNo'].valid) {
  //     this.formsixty = false;
  //     this.commonService.storeInLocalStorage('registerData', { Form60Doc: 0 })

  //   }
  //   else {
  //     this.formsixty = true;
  //     this.commonService.storeInLocalStorage('registerData', { Form60Doc: 1 })
  //   }
  // }


  // Passport Issue and expiry validation
  passportValidation(val: any) {
    if (val == 'kycDtlsPassprtIssueDate') {
      this.expiryDate = new Date(this.kycDtlsFromA.controls['kycDtlsPassprtIssueDate'].value);
      this.expiryDate.setDate(this.expiryDate.getDate() + 1)
    }
    if (val == 'kycDtlsPassprtExpiryDate') {
      // this.currentDate = new Date(this.kycDtlsFromA.controls['kycDtlsPassprtExpiryDate'].value);
      // this.currentDate.setDate(this.currentDate.getDate() - 1)
      const startDate = new Date();
      const endDate = new Date(this.kycDtlsFromA.controls['kycDtlsPassprtExpiryDate'].value);
      const diffTime = endDate.getTime() - startDate.getTime();
      const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
      if(diffDays <30){
        this.kycDtlsFromA.controls['kycDtlsPassprtExpiryDate'].setErrors({'dateError': true});
      } else {
        this.kycDtlsFromA.controls['kycDtlsPassprtExpiryDate'].setErrors(null);

      }

        
    }
  }

  //On change selected other Form60
  // selectedForm60() {

  //   if (this.kycDtlsFromA.get("kycDtlsForm60").value === true || this.kycDtlsFromA.get("kycDtlsForm60").value === 1) {
  //     this.pan = false;
  //     this.formsixty = true;
  //     this.kycDtlsFromA.controls['kycDtlsPanNo'].clearValidators(Validators.required)
  //   }
  //   else if (this.kycDtlsFromA.get("kycDtlsForm60").value === false || this.kycDtlsFromA.get("kycDtlsForm60").value === 0) {
  //     this.pan = true;
  //     this.formsixty = true;
  //     this.kycDtlsFromA.controls['kycDtlsPanNo'].setValidators([Validators.required, Validators.pattern(/^([A-Za-z]){5}([0-9]){4}([A-Za-z]){1}$/), Validators.maxLength(10)])
  //   }
  //   this.kycDtlsFromA.controls['kycDtlsPanNo'].updateValueAndValidity();
  // }

  //Add selected form60 to localstorage
  addForm60FileUpload(value: boolean) {
    this.commonService.storeInLocalStorage('registerData', { Form60Doc: value })
  }

  //On change selected other than Indian Passport
  selectTypeOfPassport() {
    console.log('This is type of passport', this.kycDtlsFromA.value.kycDtlsOtherPssprt)

    if (this.kycDtlsFromA.value.kycDtlsOtherPssprt == "0") {
      this.foreignerPassword = false;
      this.indianPassword = true;
      this.typeOfVisa = true;
      this.kycDtlsFromA.controls['kycDtlsPassprtTempVisaType'].setValidators([Validators.required]);
    }
    else {
      this.indianPassword = false;
      this.foreignerPassword = true;
      this.typeOfVisa = false;
      this.kycDtlsFromA.controls['kycDtlsPassprtTempVisaType'].setValue(null)
      this.kycDtlsFromA.controls['kycDtlsPassprtTempVisaType'].clearValidators();
    }
    this.kycDtlsFromA.controls['kycDtlsPassprtTempVisaType'].updateValueAndValidity();
  }

  selectTypeOfResident(event: any) {
    let typeOfResident = event.target.value;
    this.addTypeOfPassport(Number(typeOfResident));
  }

  //Add selected other than Indian Passport to localstorage
  addTypeOfPassport(value: number) {
    this.commonService.storeInLocalStorage('registerData', { TypeOfPassportDoc: value })
  }

  addTypeOfResident(value: number) {
    this.commonService.storeInLocalStorage('registerData', { TypeOfResidentDoc: value })
  }

  submitKycDtls() {

    if (this.kycDtlsFromA.valid) {
      this.regObj = this.commonService.getUserFromLocalStorage();
      let Obj = {
        kyc_details_id: String(this.kyc_details_id),
        process_id: 35,
        applicant_id: this.regObj?.applicant_id,
        is_other_than_indian_passport: Number(this.kycDtlsFromA.get("kycDtlsOtherPssprt").value),
        passport_number: this.kycDtlsFromA.get("kycDtlsPassprtNo").value,
        issue_date: this.customerDataService.formatDob(this.kycDtlsFromA.get("kycDtlsPassprtIssueDate").value),
        expiry_date: this.customerDataService.formatDob(this.kycDtlsFromA.get("kycDtlsPassprtExpiryDate").value),
        issueing_authority: this.kycDtlsFromA.get("kycDtlsPassprtIssAthrity").value,
        place_of_issue: this.kycDtlsFromA.get("kycDtlsPassprtPlcIssue").value,
        visa_type: this.kycDtlsFromA.get("kycDtlsPassprtTempVisaType").value,
        visa_permit_expiry_date: this.customerDataService.formatDob(this.kycDtlsFromA.get("kycDtlsVisaTypeExpiryDt").value),
        // pan_number: this.kycDtlsFromA.get("kycDtlsPanNo").value,
        // is_form_60: Number(this.kycDtlsFromA.get("kycDtlsForm60").value),
        is_resident_permit: Number(this.kycDtlsFromA.get("kycDtlsResiPermit").value)
      }

      this.customerDataService.postKycDtls1(Obj).subscribe((data) => {
        this.commonService.storeInLocalStorage('registerData', { "kyc_details_id": data?.kyc_details_id })
        this.commonService.storeInLocalStorage('registerData', { "visaType": this.kycDtlsFromA.get("kycDtlsPassprtTempVisaType").value })
        if (this.commonService.getUserFromLocalStorage()?.leadReviewStatus != undefined) {
          // if (this.commonService.getUserFromLocalStorage()?.TypeOfPassportDoc != 'customer_process') {
          //   this.rt.navigate(["/feedback", "feedback-summary"]);
          // }
          if (this.commonService.getUserFromLocalStorage()?.leadReviewStatus == 'agent_review') {
            this.rt.navigate(["/feedback", "feedback-summary"]);
          }
          else if (this.kycDtlsFromA.get("kycDtlsPassprtTempVisaType").value == 1) {
            this.rt.navigate(["/minor-accnt", "kyc-dtls2-minor"]);
            console.log('check', this.visatype);
          }
          else {
            // this.rt.navigate(["/minor-accnt", "kyc-dtls3"]);
            this.rt.navigate(["/minor-accnt", "kyc-dtls4-minor"]);
          }
        }
        else {
          this.rt.navigate(["/minor-accnt", "kyc-dtls4-minor"]);
        }
      });
    }
    else {
      console.log("This is invalid form");
    }
  }

  changeVisa(val: any) {
    console.log("check", val.value);
    this.commonService.storeInLocalStorage('registerData', { visaType: val.value })
  }
}