import { ComponentFixture, TestBed } from '@angular/core/testing';

import { KycDtls1MinorComponent } from './kyc-dtls1-minor.component';

describe('KycDtls1MinorComponent', () => {
  let component: KycDtls1MinorComponent;
  let fixture: ComponentFixture<KycDtls1MinorComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ KycDtls1MinorComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(KycDtls1MinorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
