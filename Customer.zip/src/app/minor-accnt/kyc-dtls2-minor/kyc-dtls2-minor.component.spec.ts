import { ComponentFixture, TestBed } from '@angular/core/testing';

import { KycDtls2MinorComponent } from './kyc-dtls2-minor.component';

describe('KycDtls2MinorComponent', () => {
  let component: KycDtls2MinorComponent;
  let fixture: ComponentFixture<KycDtls2MinorComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ KycDtls2MinorComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(KycDtls2MinorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
