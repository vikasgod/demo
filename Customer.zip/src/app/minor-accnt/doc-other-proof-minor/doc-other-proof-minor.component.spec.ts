import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DocOtherProofMinorComponent } from './doc-other-proof-minor.component';

describe('DocOtherProofMinorComponent', () => {
  let component: DocOtherProofMinorComponent;
  let fixture: ComponentFixture<DocOtherProofMinorComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DocOtherProofMinorComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DocOtherProofMinorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
