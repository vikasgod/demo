import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { CommonService } from 'src/app/services/common.service';
import { CustomerDataService } from 'src/app/services/customer-data.service';

@Component({
  selector: 'app-kyc-dtls4-minor',
  templateUrl: './kyc-dtls4-minor.component.html',
  styleUrls: ['./kyc-dtls4-minor.component.css']
})
export class KycDtls4MinorComponent implements OnInit {
  kycDtlsDForm: any;
  regObj: any;
  kyc_pio_dec_id: any = '';
  isRelativeAddressProof: boolean = false;
  isDisplayUpdateBtn: boolean = false;
  ProceedClicked: boolean = true;
  isDisabled:any
  constructor(private rt: Router, private fb: FormBuilder, private commonService: CommonService, private customerDataService: CustomerDataService) { }
  
  ngOnInit(): void {
    //On Page initialize set isRelativeAddressProof false
    this.commonService.storeInLocalStorage('registerData', { isRelativeForm: this.isRelativeAddressProof });
    this.regObj = this.commonService.getUserFromLocalStorage();
    if ((this.regObj.isSubmitted != undefined && this.regObj.isSubmitted != 0)
      || ((this.regObj.leadReviewStatus != undefined && this.regObj.leadReviewStatus != "customer_process")
        && (this.regObj.leadReviewStatus != undefined && this.regObj.leadReviewStatus != "agent_review"))
    ) {
      // this.rt.navigate(["/individual-account", "ending"]);
    }

    

    // if (this.commonService.getUserFromLocalStorage()?.leadStatus !== undefined || this.commonService.getUserFromLocalStorage()?.leadStatus !== 'undefined' || this.commonService.getUserFromLocalStorage()?.leadStatus !== null) {
    //   this.isDisplayUpdateBtn = false;
    // } else {
    //   this.isDisplayUpdateBtn = true;
    // }
    let Obj = {
      applicant_id: this.regObj.applicant_id,
      process_id: 38,
      kyc_details_id: this.regObj.kyc_details_id
    }

    this.customerDataService.fetchKycDtls4(Obj).subscribe((value) => {
      console.log("value", value.data[0].pio_declaration);
      
      this.kyc_pio_dec_id = value.data[0].kyc_pio_dec_id
      if (value.data.length > 0) {
        this.isDisplayUpdateBtn = true;
        this.kycDtlsDForm = this.fb.group({
          kycDtlsCPioDecChk: [value.data[0]?.pio_declaration, [Validators.required]],
          indian_family_name: [value.data[0]?.indian_family_name, {value: "", disabled:true}],
          indian_spouse_name: [value.data[0]?.indian_spouse_name, {value: "", disabled:true}],
          indian_spouse_family_name: [value.data[0]?.indian_spouse_family_name, {value: "", disabled:true}],
        })
      } 
      else {
        this.isDisplayUpdateBtn = false;
      }

      // if (value?.data?.[0]?.is_held_indian_passport === 0 &&
      //   value?.data?.[0]?.is_citizen_of_india_by_virtue === 0 &&
      //   value?.data?.[0]?.is_belong_after_15_8_1947 === 0 &&
      //   value?.data?.[0]?.is_family_indian_by_virtue === 0 &&
      //   value?.data?.[0]?.is_spouse_family_indian_by_virtue === 0 &&
      //   value?.data?.[0]?.is_spouse_held_indian_passpor === 0) {
      //   this.commonService.storeInLocalStorage('registerData', { TypeOfPIODoc: 0 });
      // }
      // else {
      //   this.commonService.storeInLocalStorage('registerData', { TypeOfPIODoc: 1 })
      // }

    })

    this.kycDtlsDForm = this.fb.group({
      kycDtlsCPioDecChk: ['', [Validators.required]],
      indian_family_name: [{value: "", disabled:true}],
      indian_spouse_name: [{value: "", disabled:true}],
      indian_spouse_family_name: [{value: "", disabled:true}],
    })
  }

  checkedPIO(event: any) {
    if(event.target.value == "is_held_indian_passport"){
      this.kycDtlsDForm.controls['indian_family_name'].disable()
      this.kycDtlsDForm.controls['indian_family_name'].reset()
      this.kycDtlsDForm.controls['indian_spouse_name'].disable()
      this.kycDtlsDForm.controls['indian_spouse_name'].reset()
      this.kycDtlsDForm.controls['indian_spouse_family_name'].disable()
      this.kycDtlsDForm.controls['indian_spouse_family_name'].reset()
    }
    else if(event.target.value == "is_citizen_of_india_by_virtue"){
      this.kycDtlsDForm.controls['indian_family_name'].disable()
      this.kycDtlsDForm.controls['indian_family_name'].reset()
      this.kycDtlsDForm.controls['indian_spouse_name'].disable()
      this.kycDtlsDForm.controls['indian_spouse_name'].reset()
      this.kycDtlsDForm.controls['indian_spouse_family_name'].disable()
      this.kycDtlsDForm.controls['indian_spouse_family_name'].reset()
    }
    else if(event.target.value == "is_belong_after_15_8_1947"){
      this.kycDtlsDForm.controls['indian_family_name'].disable()
      this.kycDtlsDForm.controls['indian_family_name'].reset()
      this.kycDtlsDForm.controls['indian_spouse_name'].disable()
      this.kycDtlsDForm.controls['indian_spouse_name'].reset()
      this.kycDtlsDForm.controls['indian_spouse_family_name'].disable()
      this.kycDtlsDForm.controls['indian_spouse_family_name'].reset()
    }
    else if(event.target.value == "is_family_indian_by_virtue"){
      this.kycDtlsDForm.controls['indian_family_name'].enable()
      this.kycDtlsDForm.controls['indian_spouse_name'].disable()
      this.kycDtlsDForm.controls['indian_spouse_family_name'].disable()
      this.kycDtlsDForm.controls['indian_spouse_name'].reset()
      this.kycDtlsDForm.controls['indian_spouse_family_name'].reset()
    }
    else if(event.target.value == "is_spouse_held_indian_passport"){
      this.kycDtlsDForm.controls['indian_family_name'].disable()
      this.kycDtlsDForm.controls['indian_family_name'].reset()
      this.kycDtlsDForm.controls['indian_spouse_name'].enable()
      this.kycDtlsDForm.controls['indian_spouse_family_name'].disable()
      this.kycDtlsDForm.controls['indian_spouse_family_name'].reset()
    }
    else if(event.target.value == "is_spouse_family_indian_by_virtue"){
      this.kycDtlsDForm.controls['indian_family_name'].disable()
      this.kycDtlsDForm.controls['indian_family_name'].reset()
      this.kycDtlsDForm.controls['indian_spouse_name'].disable()
      this.kycDtlsDForm.controls['indian_spouse_name'].reset()
      this.kycDtlsDForm.controls['indian_spouse_family_name'].enable()
    }
  }

  submitKycDtls() {
    if (this.kycDtlsDForm.value) {
      this.regObj = this.commonService.getUserFromLocalStorage();
      let Obj = {
        applicant_id: this.regObj.applicant_id,
        process_id: 38,
        kyc_pio_dec_id: this.kyc_pio_dec_id,
        kyc_details_id: this.regObj.kyc_details_id,
        pio_declaration: this.kycDtlsDForm.controls['kycDtlsCPioDecChk'].value,
        indian_family_name: this.kycDtlsDForm.controls['indian_family_name'].value,
        indian_spouse_name: this.kycDtlsDForm.controls['indian_spouse_name'].value,
        indian_family_spouce_name: this.kycDtlsDForm.controls['indian_spouse_family_name'].value
      }

      this.customerDataService.postKycDtls4(Obj).subscribe((data) => {
        var is_feedback_show = 0;
        if (this.commonService.getUserFromLocalStorage()?.leadReviewStatus != undefined) {
          if (this.commonService.getUserFromLocalStorage()?.leadReviewStatus != 'customer_process') {
            is_feedback_show += 1;
          }
        }
        if (is_feedback_show != 0) {
          this.rt.navigate(["/feedback", "feedback-summary"]);
        } 
        else {
          this.rt.navigate(["/minor-accnt", "document-upload1-minor"]);
        }
      })
    } 
    else {
      console.log("This form is invalid");
    }
  }
}