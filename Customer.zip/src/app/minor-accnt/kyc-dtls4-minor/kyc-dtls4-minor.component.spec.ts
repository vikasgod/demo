import { ComponentFixture, TestBed } from '@angular/core/testing';

import { KycDtls4MinorComponent } from './kyc-dtls4-minor.component';

describe('KycDtls4MinorComponent', () => {
  let component: KycDtls4MinorComponent;
  let fixture: ComponentFixture<KycDtls4MinorComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ KycDtls4MinorComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(KycDtls4MinorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
