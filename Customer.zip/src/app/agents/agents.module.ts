import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LoginComponent } from './login/login.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { HomeComponent } from './home/home.component';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from '../app-routing.module';
import { AgentsLoginComponent } from './agents-login/agents-login.component';



@NgModule({
  declarations: [
    LoginComponent,
    DashboardComponent,
    HomeComponent,
    AgentsLoginComponent
  ],
  imports: [
    CommonModule,
    BrowserModule,
    AppRoutingModule
  ],
  exports:[
    LoginComponent,
    HomeComponent,
    AgentsLoginComponent
  ]
})
export class AgentsModule { }
