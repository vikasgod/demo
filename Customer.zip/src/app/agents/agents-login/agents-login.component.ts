import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-agents-login',
  templateUrl: './agents-login.component.html',
  styleUrls: ['./agents-login.component.css']
})
export class AgentsLoginComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
