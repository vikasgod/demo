import { ComponentFixture, TestBed } from '@angular/core/testing';

import { KycDtls4Component } from './kyc-dtls4.component';

describe('KycDtls4Component', () => {
  let component: KycDtls4Component;
  let fixture: ComponentFixture<KycDtls4Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ KycDtls4Component ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(KycDtls4Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
