import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { CommonService } from 'src/app/services/common.service';
import { Router } from '@angular/router';
import { CustomerDataService } from 'src/app/services/customer-data.service';

@Component({
  selector: 'app-declaration1',
  templateUrl: './declaration1.component.html',
  styleUrls: ['./declaration1.component.css']
})
export class Declaration1Component implements OnInit {

  isDisabled: boolean = true;
  isDisabledInfo: boolean = true;
  isDisplayUpdateBtn: boolean = false

  declarationAFrom: any;
  regObj: any;
  constructor(private fb: FormBuilder, private commonService: CommonService, private rt: Router, private customerDataService: CustomerDataService) { }

  ngOnInit(): void {
    this.declarationAFrom = this.fb.group({
      declarationAConcent: ['', Validators.required],
      declarationBConcent: ['', Validators.required]
    })

    this.regObj = this.commonService.getUserFromLocalStorage();

    if(this.regObj.leadReviewStatus =='agent_review'){
      this.rt.navigate(['/feedback/feedback-summary']);
    }
    if(this.regObj.leadReviewStatus =='approved'){
      this.rt.navigate(['/rejected-page']);
      return;
    }

    let Obj = {
      applicant_id: this.regObj.applicant_id,
      process_id: 16
    }

    this.customerDataService.fetchConcentDeclared(Obj).subscribe((value) => { 
      if(value.data.length > 0){
        this.isDisplayUpdateBtn == true
        if(value.data[0]?.is_consent_declared !== null && value.data[0]?.is_info_consent_declared !== null){
          this.declarationAFrom = this.fb.group({
            declarationAConcent: [String(value.data[0]?.is_consent_declared), Validators.required],
            declarationBConcent: [String(value.data[0]?.is_info_consent_declared), Validators.required],
          })
        }
      }

      let isConsent = "0"
      if (value?.data?.[0]?.is_consent_declared !== undefined || value?.data?.[0]?.is_consent_declared !== null) {
        isConsent = String(value?.data?.[0]?.is_consent_declared)
      }
      if (this.regObj.isConsentSelected !== undefined) {
        isConsent = String(this.regObj.isConsentSelected)
      }
    })

    if (this.regObj.isConsentSelected !== undefined) {
      this.isDisabled = false;
      this.declarationAFrom.get('declarationAConcent')?.setValue(String(this.regObj.isConsentSelected));
    }
    if (this.regObj.isConsentSelected !== undefined) {
      this.isDisabledInfo = false;
      this.declarationAFrom.get('declarationBConcent')?.setValue(String(this.regObj.isConsentSelected));
    }
  }

  get declarationAConcent() { return this.declarationAFrom.get("declarationAConcent") }
  get declarationBConcent() { return this.declarationAFrom.get("declarationBConcent") }

  onChangeConsent(event: any) {
    this.isDisabled = false;
  }
  
  onChangeConsentInfo(event: any) {
    this.isDisabledInfo = false;
  }

  submitDeclarationForm() {
    if (this.declarationAFrom.valid) {
      let Obj = {
        applicant_id: this.regObj.applicant_id,
        process_id: 28,
        is_consent_declared: Number(this.declarationAFrom.get("declarationAConcent").value),
        is_info_consent_declared:Number(this.declarationAFrom.get("declarationBConcent").value)
      }      
      this.customerDataService.postConsentDeclared(Obj).subscribe((data) => {
        this.rt.navigate(['/individual-account', 'declaration2']);
      })
    }
  }
}