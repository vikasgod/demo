import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Declaration1Component } from './declaration1.component';

describe('Declaration1Component', () => {
  let component: Declaration1Component;
  let fixture: ComponentFixture<Declaration1Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ Declaration1Component ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(Declaration1Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
