import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DocPioComponent } from './doc-pio.component';

describe('DocPioComponent', () => {
  let component: DocPioComponent;
  let fixture: ComponentFixture<DocPioComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DocPioComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DocPioComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
