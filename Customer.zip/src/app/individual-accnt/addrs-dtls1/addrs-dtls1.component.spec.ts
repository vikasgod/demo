import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddrsDtls1Component } from './addrs-dtls1.component';

describe('AddrsDtls1Component', () => {
  let component: AddrsDtls1Component;
  let fixture: ComponentFixture<AddrsDtls1Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddrsDtls1Component ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AddrsDtls1Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
