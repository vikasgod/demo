import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DocOciComponent } from './doc-oci.component';

describe('DocOciComponent', () => {
  let component: DocOciComponent;
  let fixture: ComponentFixture<DocOciComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DocOciComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DocOciComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
