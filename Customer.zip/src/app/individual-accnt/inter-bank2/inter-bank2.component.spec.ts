import { ComponentFixture, TestBed } from '@angular/core/testing';

import { InterBank2Component } from './inter-bank2.component';

describe('InterBank2Component', () => {
  let component: InterBank2Component;
  let fixture: ComponentFixture<InterBank2Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ InterBank2Component ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(InterBank2Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
