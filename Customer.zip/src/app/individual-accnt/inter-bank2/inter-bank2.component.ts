import { Component, OnInit } from '@angular/core';
import { FormArray, FormBuilder, FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { CommonService } from 'src/app/services/common.service';
import { CustomerDataService } from 'src/app/services/customer-data.service';

@Component({
  selector: 'app-inter-bank2',
  templateUrl: './inter-bank2.component.html',
  styleUrls: ['./inter-bank2.component.css']
})
export class InterBank2Component implements OnInit {
  internetBankBlncAlertArr: any;
  internetBankDbtAlertMdArr: any;
  internetBankBForm: any;
  balAlert: any = []
  dbAlert: any = [];
  showInfoDetail: string = '';
  internetBankBlncAlertData: Array<{}> = [{ value: 'SMS' }, { value: 'Email' }]
  internetBankDbtAlertMdData: Array<{}> = [{ value: 'SMS' }, { value: 'Email' }
    // { value: 'WHATS APP' }
  ];
  regObj: any;
  isDisplayUpdateBtn: boolean = false;
  banking_facilities_id: any
  constructor(private rt: Router, private fb: FormBuilder, private commonService: CommonService, private customerDataService: CustomerDataService) {
    this.internetBankBForm = this.fb.group({
      internetBankBPssBkRqst: ['1'],
      internetBankBlncAlert: ['1'],
      internetBankBlncAlertMd1: [false],
      internetBankBlncAlertMd2: [false],
      internetBankDbtAlert: ['1'],
      internetBankDbtAlertMd1: [false],
      internetBankDbtAlertMd2: [false]
    })
  }

  ngOnInit(): void {
    this.regObj = this.commonService.getUserFromLocalStorage();

    let Obj = {
      applicant_id: this.regObj.applicant_id,
      process_id: this.regObj.account_type_id == 3 && this.regObj.applicantSerialNum == 2 ? 57 : 16
    }

    this.customerDataService.fetchInternetBank2(Obj).subscribe((value) => {
      this.banking_facilities_id = value.data[0]?.banking_facilities_id
      this.balAlert = []
      if (value.data.length > 0) {
        this.isDisplayUpdateBtn = true;
        this.internetBankBForm = this.fb.group({
          internetBankBPssBkRqst: [String(value?.data?.[0]?.is_cheque_book_selected)],
          internetBankBlncAlert: [String(value?.data?.[0]?.is_daily_balance_alert_selected)],
          internetBankBlncAlertMd1: [false],
          internetBankBlncAlertMd2: [false],
          internetBankDbtAlert: [String(value?.data?.[0]?.is_card_alert_selected)],
          internetBankDbtAlertMd1: [false],
          internetBankDbtAlertMd2: [false],
        })
        if (String(value?.data?.[0]?.daily_balance_alert_mode).includes('SMS')) {
          this.balAlert.push('SMS')
          this.internetBankBForm.controls['internetBankBlncAlertMd1'].setValue(true)

        }
        if (String(value?.data?.[0]?.daily_balance_alert_mode).includes('Email')) {
          this.balAlert.push('Email')
          this.internetBankBForm.controls['internetBankBlncAlertMd2'].setValue(true)

        }
        if (String(value?.data?.[0]?.card_alert_mode).includes('SMS')) {
          this.dbAlert.push('SMS')
          this.internetBankBForm.controls['internetBankDbtAlertMd1'].setValue(true)

        }
        if (String(value?.data?.[0]?.card_alert_mode).includes('Email')) {
          this.dbAlert.push('Email')
          this.internetBankBForm.controls['internetBankDbtAlertMd2'].setValue(true)

        }
        setTimeout(() => {
          this.balanceAlert()
          this.selectCard()
        }, 100);
      }
    })
  }

  showInfoDetails(label: any) {
    this.showInfoDetail = label;
  }

  get internetBankBPssBkRqst() { return this.internetBankBForm.get("internetBankBPssBkRqst") }
  get internetBankBlncAlert() { return this.internetBankBForm.get("internetBankBlncAlert") }
  get internetBankBlncAlertMd() { return this.internetBankBForm.get("internetBankBlncAlertMd") as FormArray }
  get internetBankDbtAlert() { return this.internetBankBForm.get("internetBankDbtAlert") }
  get internetBankDbtAlertMd() { return this.internetBankBForm.get("internetBankDbtAlertMd") as FormArray }

  onInternetBankBlncAlertMd(e: any) {
    let website: FormArray = this.internetBankBForm.get('internetBankBlncAlertMd') as FormArray;
    if (e.target.checked) {
      website.push(new FormControl(e.target.value));
      // website.controls[i]=new FormControl(e.target.value);
    }
    else {
      let index = website.controls.findIndex(x => x.value === e.target.value);
      website.removeAt(index);
    }
  }

  onInternetBankDbtAlertMd(e: any) {
    let website: FormArray = this.internetBankBForm.get('internetBankDbtAlertMd') as FormArray;
    if (e.target.checked) {
      website.push(new FormControl(e.target.value));
    }
    else {
      let index = website.controls.findIndex(x => x.value === e.target.value);
      website.removeAt(index);
    }
  }

  selectCard() {
    if (this.internetBankBForm.controls['internetBankDbtAlert'].value == 0) {
      this.internetBankBForm.controls['internetBankDbtAlertMd1'].disable()
      this.internetBankBForm.controls['internetBankDbtAlertMd2'].disable()
      this.internetBankBForm.controls['internetBankDbtAlertMd1'].setValue(false)
      this.internetBankBForm.controls['internetBankDbtAlertMd2'].setValue(false)
    }

    if (this.internetBankBForm.controls['internetBankDbtAlert'].value == 1) {
      this.internetBankBForm.controls['internetBankDbtAlertMd1'].enable()
      this.internetBankBForm.controls['internetBankDbtAlertMd2'].enable()
    }
  }

  balanceAlert() {
    if (this.internetBankBForm.controls['internetBankBlncAlert'].value == 0) {
      this.internetBankBForm.controls['internetBankBlncAlertMd1'].disable()
      this.internetBankBForm.controls['internetBankBlncAlertMd2'].disable()
      this.internetBankBForm.controls['internetBankBlncAlertMd1'].setValue(false)
      this.internetBankBForm.controls['internetBankBlncAlertMd2'].setValue(false)
    }

    if (this.internetBankBForm.controls['internetBankBlncAlert'].value == 1) {
      this.internetBankBForm.controls['internetBankBlncAlertMd1'].enable()
      this.internetBankBForm.controls['internetBankBlncAlertMd2'].enable()
    }
  }

  submitInternetBank() {
    if (this.internetBankBForm.valid) {
      let Obj = {
        applicant_id: this.regObj.applicant_id,
        process_id: this.regObj.account_type_id == 3 && this.regObj.applicantSerialNum == 2 ? 57 : 16,
        banking_facilities_id: this.banking_facilities_id,
        is_cheque_book_selected: Number(this.internetBankBForm.get("internetBankBPssBkRqst").value),
        is_daily_balance_alert_selected: Number(this.internetBankBForm.get("internetBankBlncAlert").value),
        daily_balance_alert_mode: this.balAlert,
        is_card_alert_selected: Number(this.internetBankBForm.get("internetBankDbtAlert").value),
        card_alert_mode: this.dbAlert
      }

      this.customerDataService.postInternetBanking2(Obj).subscribe((data) => {
        var is_feedback_show = 0;
        if (this.commonService.getUserFromLocalStorage()?.leadReviewStatus != undefined) {
          if (this.commonService.getUserFromLocalStorage()?.leadReviewStatus != 'customer_process') {
            is_feedback_show += 1;
          }
        }
        if (is_feedback_show != 0) {
          this.rt.navigate(["/feedback", "feedback-summary"]);
        }
        else {
          this.rt.navigate(["/individual-account", "nomination1"]);
        }
      })
    }
  }

  changeCardAlertMd(e: any) {
    if (e.target.checked) {
      this.balAlert.push(e.target.value);
    }
    else {
      let index = this.balAlert.findIndex((x: any) => x === e.target.value);
      this.balAlert.splice(index, 1)
    }
  }

  changeDbAlert(e: any) {
    if (e.target.checked) {
      this.dbAlert.push(e.target.value);
    }
    else {
      let index = this.dbAlert.findIndex((x: any) => x === e.target.value);
      this.dbAlert.splice(index, 1)
    }
  }
}