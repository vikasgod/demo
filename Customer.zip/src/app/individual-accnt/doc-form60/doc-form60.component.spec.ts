import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DocForm60Component } from './doc-form60.component';

describe('DocForm60Component', () => {
  let component: DocForm60Component;
  let fixture: ComponentFixture<DocForm60Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DocForm60Component ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DocForm60Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
