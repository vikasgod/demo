import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { CommonService } from 'src/app/services/common.service';
import { CustomerDataService } from 'src/app/services/customer-data.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-doc-form60',
  templateUrl: './doc-form60.component.html',
  styleUrls: ['./doc-form60.component.css']
})
export class DocForm60Component implements OnInit {
  requiredFileType: string = 'image/png,image/jpeg'
  docIndentityFrom: any;
  iSfile1Change: boolean = false;
  errFileExtension: boolean = true;
  imgSrc: any = '';
  fileDataStr1: any = '';
  fileDataStr2: string = '';
  fileName1: string = '';
  fileName2: string = '';
  regObj: any;
  imgSrc1: string = '';
  imgSrc2: string = '';
  display: string = "none";
  docAddressProofFailedErr: string = '';
  isUpdate: boolean = false
  applicant:any
  constructor(private fb: FormBuilder, private commonService: CommonService, private customerDataService: CustomerDataService, private rt: Router) {
  }

  ngOnInit(): void {
    this.regObj = this.commonService.getUserFromLocalStorage();

    this.docIndentityFrom = this.fb.group({
      docForm60File1: ['', [Validators.required]]
    })

    let req = {
      user_id: this.regObj?.user_id
    }

    this.customerDataService.fetchAllID(req).subscribe((value) => {
      if (value?.data?.length > 0) {
        this.applicant = value.data[0].applicant_personal_id
      }
    })

    setTimeout(() => {
      this.getDoc()
    }, 500);

  }

  getDoc() {
    let Obj = {
      applicant_id: this.regObj?.applicant_id,
      document: "form_sixty"
    }

    this.customerDataService.fetchGetDoc(Obj).subscribe((value) => {
      if (value != undefined) {
        this.isUpdate = true
      }
      this.docIndentityFrom = this.fb.group({
        docForm60File1: [value.file_path, [Validators.required]]
      })
      this.imgSrc1 = value.file_path;
      this.customerDataService.getBase64ImageFromUrl(value?.file_path).then(result => {
        console.log(value.file_path, result)
        this.fileDataStr1 = result
        this.fileName1 = value.file_path.split('/').pop()
      })
        .catch(err => console.error(err));
      this.docIndentityFrom.get('docVisaFile1').setValue(this.fileName1);
    })
  }

  get docForm60File1() { return this.docIndentityFrom.get("docForm60File1") }

  // onFilesSelected1(event: any) {
  //   this.iSfile1Change = true;
  //   let fileData = event.target.files[0];
  //   if (fileData != undefined) {

  //     this.fileName1 = fileData.name;
  //     this.docIndentityFrom.get('docForm60File1').setValue(this.fileName1);
  //     let arr = String(fileData.name).split('.');
  //     let len = arr.length;

  //     if (fileData.size <= 5000000) {
  //       if (arr[len - 1] === "png" || arr[len - 1] === "jpeg" || arr[len - 1] === "jpg") {
  //         const reader = new FileReader();
  //         reader.onloadend = () => {
  //           this.imgSrc1 = String(reader.result)
  //           const base64String = String(reader.result)
  //             .replace('data:', '')
  //             .replace(/^.+,/, '');
  //         };
  //         reader.readAsDataURL(fileData);
  //       }
  //       else {
  //         this.errFileExtension = false;
  //       }
  //     }
  //     else {
  //       this.fileName1 = '';
  //       this.docIndentityFrom.get('docForm60File1').setValue('');
  //       this.docAddressProofFailedErr = 'File size exceeds 5mb'
  //       this.openModal();
  //     }
  //   }
  //   else {
  //     return
  //   }
  // }

    //Working 1  
    onFilesSelected1(event: any) {
      this.iSfile1Change = true;
      let fileData = event.target.files[0];
      if (fileData != undefined) {
  
        this.fileName1 = fileData.name;
        this.docIndentityFrom.get('docForm60File1').setValue(this.fileName1);
        let arr = String(fileData.name).split('.');
        let len = arr.length;
  
        if (fileData.size <= 5000000) {
          if (arr[len - 1] === "png" || arr[len - 1] === "jpeg" || arr[len - 1] === "jpg") {
            const reader = new FileReader();
            reader.onloadend = () => {
              this.imgSrc1 = String(reader.result)
              const base64String = String(reader.result)
                .replace('data:', '')
                .replace(/^.+,/, '');
              this.fileDataStr1 = base64String;
            };
            reader.readAsDataURL(fileData);
          }
          else {
            this.errFileExtension = false;
          }
        }
        else {
          console.log("Extension is not valid ex")
          this.fileName1 = '';
          this.docIndentityFrom.get('docForm60File1').setValue(this.fileName1);
          this.docAddressProofFailedErr = 'File size exceeds 5mb'
          this.openModal();
        }
      }
      else {
        return
      }
    }

  openModal() {
    this.display = "block";
  }

  onCloseHandled() {
    this.display = "none";
  }

  submitForm60() {
    let Obj = {
      applicant_id: this.regObj.applicant_id,
      process_id: 22,
      file: this.fileDataStr1,
    }

    this.customerDataService.postCustomerForm60Doc(Obj).subscribe((data) => {
      var is_feedback_show = 0;
      if (this.commonService.getUserFromLocalStorage()?.leadReviewStatus != undefined) {
        if (this.commonService.getUserFromLocalStorage()?.leadReviewStatus != 'customer_process') {
          is_feedback_show += 1;
        }
      }
      if (is_feedback_show != 0) {
        this.rt.navigate(["/feedback", "feedback-summary"]);
      }
      else {
        this.rt.navigate(['/individual-account', 'doc-upload1']);
      }
    })
  }
}