import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { CommonService } from 'src/app/services/common.service';
import { CustomerDataService } from 'src/app/services/customer-data.service';

@Component({
  selector: 'app-kyc-dtls4',
  templateUrl: './kyc-dtls4.component.html',
  styleUrls: ['./kyc-dtls4.component.css']
})
export class KycDtls4Component implements OnInit {
  kycDtlsDForm: any;
  regObj: any;
  kyc_pio_dec_id: any;
  // isTextkycDtlsCPioDectxt4: boolean = false;
  // isTextkycDtlsCPioDectxt5: boolean = false;
  // isTextkycDtlsCPioDectxt6: boolean = false;
  isRelativeAddressProof: boolean = false;
  isDisplayUpdateBtn: boolean = false;
  ProceedClicked: boolean = true;
  kycDtlsCPioDecChk:any
  constructor(private rt: Router, private fb: FormBuilder, private commonService: CommonService, private customerDataService: CustomerDataService) { }
  
  ngOnInit(): void {
    //On Page initialize set isRelativeAddressProof false
    this.commonService.storeInLocalStorage('registerData', { isRelativeForm: this.isRelativeAddressProof });
    this.regObj = this.commonService.getUserFromLocalStorage();
    if ((this.regObj.isSubmitted != undefined && this.regObj.isSubmitted != 0)
      || ((this.regObj.leadReviewStatus != undefined && this.regObj.leadReviewStatus != "customer_process")
        && (this.regObj.leadReviewStatus != undefined && this.regObj.leadReviewStatus != "agent_review"))
    ) {
      this.rt.navigate(["/individual-account", "ending"]);
    }

    if (this.commonService.getUserFromLocalStorage()?.leadReviewStatus === undefined) {
      this.isDisplayUpdateBtn = false;
    } else {
      this.isDisplayUpdateBtn = true;
    }
    let Obj = {
      applicant_id: this.regObj.applicant_id,
      process_id: 10,
      kyc_details_id: this.regObj.kyc_details_id
    }

    this.customerDataService.fetchKycDtls4(Obj).subscribe((value) => {
      if (value.data === undefined) {
        this.isDisplayUpdateBtn = false;
      } 
      else {
        this.isDisplayUpdateBtn = true;
        console.log('check value true',value.data);
      }
      if (value?.data?.[0]?.is_family_indian_by_virtue === 0) {
        this.kycDtlsDForm.controls['kycDtlsCPioDectxt4'].disable();
      }
      else {
        this.kycDtlsDForm.controls['kycDtlsCPioDectxt4'].enable();
      }
      if (value?.data?.[0]?.is_spouse_held_indian_passport === 0) {
        this.kycDtlsDForm.controls['kycDtlsCPioDectxt5'].disable();
      }
      else {
        this.kycDtlsDForm.controls['kycDtlsCPioDectxt5'].enable();
      }

      if (value?.data?.[0]?.is_spouse_family_indian_by_virtue === 0) {
        this.kycDtlsDForm.controls['kycDtlsCPioDectxt6'].disable();
      }
      else {
        this.kycDtlsDForm.controls['kycDtlsCPioDectxt6'].enable();
      }

      if (value?.data?.[0]?.is_held_indian_passport === 0 &&
        value?.data?.[0]?.is_citizen_of_india_by_virtue === 0 &&
        value?.data?.[0]?.is_belong_after_15_8_1947 === 0 &&
        value?.data?.[0]?.is_family_indian_by_virtue === 0 &&
        value?.data?.[0]?.is_spouse_family_indian_by_virtue === 0 &&
        value?.data?.[0]?.is_spouse_held_indian_passpor === 0) {
        this.commonService.storeInLocalStorage('registerData', { TypeOfPIODoc: 0 });
      }
      else {
        this.commonService.storeInLocalStorage('registerData', { TypeOfPIODoc: 1 })
      }

      this.kycDtlsDForm = this.fb.group({
        kycDtlsCPioDecChk: [value?.data?.[0]?.is_held_indian_passport],
        // kycDtlsCPioDecChk2: [value?.data?.[0]?.is_citizen_of_india_by_virtue],
        // kycDtlsCPioDecChk3: [value?.data?.[0]?.is_belong_after_15_8_1947],
        // kycDtlsCPioDecChk4: [value?.data?.[0]?.is_family_indian_by_virtue],
        // kycDtlsCPioDecChk5: [value?.data?.[0]?.is_spouse_held_indian_passport],
        // kycDtlsCPioDecChk6: [value?.data?.[0]?.is_spouse_family_indian_by_virtue],
        kycDtlsCPioDectxt4: [String(value?.data?.[0]?.indian_family_name) === 'undefined' || value?.data?.[0]?.indian_family_name === undefined || value?.data?.[0]?.indian_family_name === null ? '' : String(value?.data?.[0]?.indian_family_name)],
        kycDtlsCPioDectxt5: [String(value?.data?.[0]?.indian_spouse_name) === 'undefined' || value?.data?.[0]?.indian_spouse_name === undefined || value?.data?.[0]?.indian_spouse_name === null ? '' : String(value?.data?.[0]?.indian_spouse_name)],
        kycDtlsCPioDectxt6: [String(value?.data?.[0]?.indian_spouse_family_name) === 'undefined' || value?.data?.[0]?.indian_spouse_family_name === undefined || value?.data?.[0]?.indian_spouse_family_name === null ? '' : String(value?.data?.[0]?.indian_spouse_family_name)],
      })

      //Check PIO Relatives forms required in Address Proof
      this.checkRelativeAddressProofDoc();
      if (value?.data?.[0]?.kyc_pio_dec_id === undefined) {
        this.kyc_pio_dec_id = 'undefined';
      } else {
        this.kyc_pio_dec_id = value?.data?.[0]?.kyc_pio_dec_id;
      }
    })

    this.kycDtlsDForm = this.fb.group({
      kycDtlsCPioDecChk: ['I was citizen of India and held an Indian Passport in the past', [Validators.required]],
      // kycDtlsCPioDecChk2: [false,],
      // kycDtlsCPioDecChk3: [false,],
      // kycDtlsCPioDecChk4: [false,],
      // kycDtlsCPioDecChk5: [false,],
      // kycDtlsCPioDecChk6: [false,],
      // kycDtlsCPioDectxt4: [''],
      kycDtlsCPioDectxt5: [''],
      kycDtlsCPioDectxt6: [''],
    })
  }

  get kycDtlsCPioDecChk() { return this.kycDtlsDForm.get("kycDtlsCPioDecChk1") }
  // get kycDtlsCPioDecChk2() { return this.kycDtlsDForm.get("kycDtlsCPioDecChk2") }
  // get kycDtlsCPioDecChk3() { return this.kycDtlsDForm.get("kycDtlsCPioDecChk3") }
  // get kycDtlsCPioDecChk4() { return this.kycDtlsDForm.get("kycDtlsCPioDecChk4") }
  // get kycDtlsCPioDecChk5() { return this.kycDtlsDForm.get("kycDtlsCPioDecChk5") }
  // get kycDtlsCPioDecChk6() { return this.kycDtlsDForm.get("kycDtlsCPioDecChk6") }
  get kycDtlsCPioDectxt4() { return this.kycDtlsDForm.get("kycDtlsCPioDectxt4") }
  get kycDtlsCPioDectxt5() { return this.kycDtlsDForm.get("kycDtlsCPioDectxt5") }
  get kycDtlsCPioDectxt6() { return this.kycDtlsDForm.get("kycDtlsCPioDectxt6") }

  checkedPIO(event: any, value: number) {
    this.addedCheckedPIO();
    this.checkRelativeAddressProofDoc();
    console.log(this.kycDtlsDForm.controls['kycDtlsCPioDectxt4']);
    //According to case value make selected check box and textbox change respectively
    switch (value) {
      case 4: if (this.kycDtlsDForm.get("kycDtlsCPioDecChk4").value === false) {
        this.kycDtlsDForm.controls['kycDtlsCPioDectxt4'].disable();
        this.kycDtlsCPioDectxt4.setValue('');
      }
      else {
        this.kycDtlsDForm.controls['kycDtlsCPioDectxt4'].enable();
      }
        break;
      case 5: if (this.kycDtlsDForm.get("kycDtlsCPioDecChk5").value === false) {
        this.kycDtlsDForm.controls['kycDtlsCPioDectxt5'].disable();
        this.kycDtlsCPioDectxt5.setValue('');
      } 
      else {
        this.kycDtlsDForm.controls['kycDtlsCPioDectxt5'].enable();
      }
        break;
      case 6: if (this.kycDtlsDForm.get("kycDtlsCPioDecChk6").value === false) {
        this.kycDtlsDForm.controls['kycDtlsCPioDectxt6'].disable();
        this.kycDtlsCPioDectxt6.setValue('');
      } 
      else {
        this.kycDtlsDForm.controls['kycDtlsCPioDectxt6'].enable();
      }
        break;
    }
  }

  //if any of PIO declaration is not checked then PIO document will not be displayed in document upload
  //else PIO document will be displayed in document upload
  addedCheckedPIO() {
    if (
      Number(this.kycDtlsDForm.get("kycDtlsCPioDecChk").value) === 0 &&
      Number(this.kycDtlsDForm.get("kycDtlsCPioDecChk2").value) === 0 &&
      Number(this.kycDtlsDForm.get("kycDtlsCPioDecChk3").value) === 0 &&
      Number(this.kycDtlsDForm.get("kycDtlsCPioDecChk4").value) === 0 &&
      Number(this.kycDtlsDForm.get("kycDtlsCPioDecChk5").value) === 0 &&
      Number(this.kycDtlsDForm.get("kycDtlsCPioDecChk6").value) === 0) {
      this.commonService.storeInLocalStorage('registerData', { TypeOfPIODoc: 0 })
      this.ProceedClicked = true;
    } 
    else {
      this.commonService.storeInLocalStorage('registerData', { TypeOfPIODoc: 1 })
      this.ProceedClicked = false;
    }
  }

  //Any PIO Declaration relatives is checked then
  //Relative document will be displayed in address proof document upload
  checkRelativeAddressProofDoc() {
    if (Number(this.kycDtlsDForm.get("kycDtlsCPioDecChk3").value) === 1 ||
      Number(this.kycDtlsDForm.get("kycDtlsCPioDecChk4").value) === 1 ||
      Number(this.kycDtlsDForm.get("kycDtlsCPioDecChk5").value) === 1) {
      this.isRelativeAddressProof = true;
      this.commonService.storeInLocalStorage('registerData', { isRelativeForm: this.isRelativeAddressProof });
    } else {
      this.isRelativeAddressProof = false;
      this.commonService.storeInLocalStorage('registerData', { isRelativeForm: this.isRelativeAddressProof });
    }
  }

  submitKycDtls() {
    if (this.kycDtlsDForm.value) {
      console.log("This is kyc form", this.kycDtlsDForm.value);
      this.regObj = this.commonService.getUserFromLocalStorage();
      console.log("This Obj", this.regObj.applicant_id);
      console.log(`This is form PIO value`, this.kycDtlsDForm.value)
      let Obj =
      {
        applicant_id: this.regObj.applicant_id,
        process_id: 10,
        kyc_pio_dec_id: this.kyc_pio_dec_id,
        kyc_details_id: this.regObj.applicant_id,
        is_held_indian_passport: Number(this.kycDtlsDForm.get("kycDtlsCPioDecChk").value),
        is_citizen_of_india_by_virtue: Number(this.kycDtlsDForm.get("kycDtlsCPioDecChk2").value),
        is_belong_after_15_8_1947: Number(this.kycDtlsDForm.get("kycDtlsCPioDecChk3").value),
        is_family_indian_by_virtue: Number(this.kycDtlsDForm.get("kycDtlsCPioDecChk4").value),
        is_spouse_held_indian_passport: Number(this.kycDtlsDForm.get("kycDtlsCPioDecChk5").value),
        is_spouse_family_indian_by_virtue: Number(this.kycDtlsDForm.get("kycDtlsCPioDecChk6").value),
        indian_family_name: Number(this.kycDtlsDForm.get("kycDtlsCPioDecChk4").value) === 0 ? '' : this.kycDtlsDForm.get("kycDtlsCPioDectxt4").value,
        indian_spouse_name: Number(this.kycDtlsDForm.get("kycDtlsCPioDecChk5").value) === 0 ? '' : this.kycDtlsDForm.get("kycDtlsCPioDectxt5").value,
        indian_spouse_family_name: Number(this.kycDtlsDForm.get("kycDtlsCPioDecChk6").value) === 0 ? '' : this.kycDtlsDForm.get("kycDtlsCPioDectxt6").value
      }

      this.customerDataService.postKycDtls4(Obj).subscribe((data) => {
        var is_feedback_show = 0;
        if (this.commonService.getUserFromLocalStorage()?.leadReviewStatus != undefined) {
          if (this.commonService.getUserFromLocalStorage()?.leadReviewStatus != 'customer_process') {
            is_feedback_show += 1;
          }
        }
        if (is_feedback_show != 0) {
          this.rt.navigate(["/feedback", "feedback-summary"]);
        } 
        else {
          this.rt.navigate(["/individual-account", "contact-details"]);
        }
      })
    } 
    else {
      console.log("This form is invalid");
    }
  }
}