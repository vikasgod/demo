import { ComponentFixture, TestBed } from '@angular/core/testing';

import { KycDtls2Component } from './kyc-dtls2.component';

describe('KycDtls2Component', () => {
  let component: KycDtls2Component;
  let fixture: ComponentFixture<KycDtls2Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ KycDtls2Component ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(KycDtls2Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
