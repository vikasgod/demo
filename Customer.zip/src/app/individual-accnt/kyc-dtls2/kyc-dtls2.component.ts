import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { CommonService } from 'src/app/services/common.service';
import { CustomerDataService } from 'src/app/services/customer-data.service';

@Component({
  selector: 'app-kyc-dtls2',
  templateUrl: './kyc-dtls2.component.html',
  styleUrls: ['./kyc-dtls2.component.css']
})
export class KycDtls2Component implements OnInit {
  currentDate: any;
  kycDtlsBForm: any;
  regObj: any;
  kyc_details_id: any;
  isDisplayUpdateBtn: boolean = false;
  expiryDate: any;

  constructor(private rt: Router, private fb: FormBuilder, private commonService: CommonService, private customerDataService: CustomerDataService) { }

  ngOnInit(): void {
    this.regObj = this.commonService.getUserFromLocalStorage();

    let Obj = {
      applicant_id: this.regObj.applicant_id,
      process_id: 9,
      kyc_details_id: this.kyc_details_id
    }

    this.customerDataService.fetchKycDtls2(Obj).subscribe((value) => {
      if (value?.data?.length > 0) {
        this.isDisplayUpdateBtn = true;
        this.kycDtlsBForm = this.fb.group({
          kycDtlsBSubmittedBank: [value?.data?.[0].is_temporary_visa_declaration == 1 ? true : false, [Validators.required]],
          kycDtlsBIssueDate: [value?.data?.[0]?.temporary_visa_declare_issue_date, [Validators.required]],
          kycDtlsBExpiryDate: [value?.data?.[0]?.temporary_visa_declare_expiry_date, [Validators.required]],
          kycDtlsBAgreFurshBankCpy: [value?.data?.[0].is_temporary_visa_declaration == 1 ? true : false, [Validators.required]],
        })
      }
    })

    this.kycDtlsBForm = this.fb.group({
      kycDtlsBSubmittedBank: ['', [Validators.required]],
      kycDtlsBIssueDate: ['', [Validators.required]],
      kycDtlsBExpiryDate: ['', [Validators.required]],
      kycDtlsBAgreFurshBankCpy: ['', [Validators.required]],
    })
    this.currentDate = this.commonService.getCurrentDate();
  }

  get kycDtlsBSubmittedBank() { return this.kycDtlsBForm.get("kycDtlsBSubmittedBank") }
  get kycDtlsBIssueDate() { return this.kycDtlsBForm.get("kycDtlsBIssueDate") }
  get kycDtlsBExpiryDate() { return this.kycDtlsBForm.get("kycDtlsBExpiryDate") }
  get kycDtlsBAgreFurshBankCpy() { return this.kycDtlsBForm.get("kycDtlsBAgreFurshBankCpy") }


  submitKycDtls() {
    if (this.kycDtlsBForm.valid) {
      let Obj = {
        applicant_id: this.regObj.applicant_id,
        process_id: 9,
        temporary_visa_declare_issue_date: this.customerDataService.formatDob(this.kycDtlsBForm.get("kycDtlsBIssueDate").value),
        temporary_visa_declare_expiry_date: this.customerDataService.formatDob(this.kycDtlsBForm.get("kycDtlsBExpiryDate").value),
        kyc_dtls_chk1: Number(this.kycDtlsBForm.get("kycDtlsBSubmittedBank").value),
        kyc_dtls_chk2: Number(this.kycDtlsBForm.get("kycDtlsBAgreFurshBankCpy").value),
      }
      
      this.customerDataService.postKycDtls2(Obj).subscribe((data) => {
        this.commonService.storeInLocalStorage('registerData', { kyc_details_id: data?.kyc_details_id })
        //visaType
        var is_feedback_show = 0;
        if (this.commonService.getUserFromLocalStorage()?.leadReviewStatus != undefined) {
          if (this.commonService.getUserFromLocalStorage()?.leadReviewStatus != 'customer_process') {
            is_feedback_show += 1;
          }
        }

        if (is_feedback_show != 0) {
          this.rt.navigate(["/feedback", "feedback-summary"]);
        }
        else {
          if (this.regObj.visaType == 1) {
            this.rt.navigate(["/individual-account", "contact-details"]);
          }
          else {
            this.rt.navigate(["/individual-account", "contact-details"]);
          }
        }
      })
    }
  }

  visaValidation(val: any) {
    if (val == "kycDtlsBIssueDate") {
      this.expiryDate = new Date(this.kycDtlsBForm.controls['kycDtlsBIssueDate'].value);
      this.expiryDate.setDate(this.expiryDate.getDate() + 1)
    }
    if (val == "kycDtlsBExpiryDate") {
      this.currentDate = new Date(this.kycDtlsBForm.controls['kycDtlsBExpiryDate'].value);
      this.currentDate.setDate(this.currentDate.getDate() - 1)
    }
  }
}