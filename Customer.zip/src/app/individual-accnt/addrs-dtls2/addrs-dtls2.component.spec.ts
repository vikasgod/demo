import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddrsDtls2Component } from './addrs-dtls2.component';

describe('AddrsDtls2Component', () => {
  let component: AddrsDtls2Component;
  let fixture: ComponentFixture<AddrsDtls2Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddrsDtls2Component ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AddrsDtls2Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
