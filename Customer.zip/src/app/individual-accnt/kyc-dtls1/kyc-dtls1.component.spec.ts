import { ComponentFixture, TestBed } from '@angular/core/testing';

import { KycDtls1Component } from './kyc-dtls1.component';

describe('KycDtls1Component', () => {
  let component: KycDtls1Component;
  let fixture: ComponentFixture<KycDtls1Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ KycDtls1Component ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(KycDtls1Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
