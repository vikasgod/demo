import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CustomerDataService } from 'src/app/services/customer-data.service';
import { CommonService } from 'src/app/services/common.service';

@Component({
  selector: 'app-declaration2',
  templateUrl: './declaration2.component.html',
  styleUrls: ['./declaration2.component.css']
})
export class Declaration2Component implements OnInit {
  regObj: any;

  constructor(private rt: Router, private customerDataService: CustomerDataService, private commonService: CommonService) { }

  ngOnInit(): void {
    this.regObj = this.commonService.getUserFromLocalStorage();

    if ((this.regObj.isSubmitted != undefined && this.regObj.isSubmitted != 0)
      || ((this.regObj.leadReviewStatus != undefined && this.regObj.leadReviewStatus != "customer_process")
        && (this.regObj.leadReviewStatus != undefined && this.regObj.leadReviewStatus != "agent_review"))
    ) {
      this.rt.navigate(["/individual-account", "ending"]);
    }
  }

  submitDec2() {
    this.regObj = this.commonService.getUserFromLocalStorage();
    if (this.regObj?.account_type_id === 1 || this.regObj?.account_type === 1) {
    this.rt.navigate(['/individual-account', 'thanks'])
    } else if (this.regObj?.account_type_id === 2 || this.regObj?.account_type === 2) {

      let Obj = {
        user_id: this.regObj?.user_id,
        process_id: 29,
        applicant_id: this.regObj?.applicant_id,
        account_type_id: this.regObj?.account_type_id || this.regObj.account_type,
      }
      this.customerDataService.postJointAccntTermsCndnt(Obj).subscribe((data) => {
        this.commonService.storeInLocalStorage('registerData', { applicant_id: data?.applicant_id, applicantSerialNo: data?.applicant_serial_number, isFormCompleted: data?.is_completed });
        if (data?.is_completed === false || data?.is_completed === 0) {
          this.rt.navigate(['/individual-account', 'personal-dtls1'])
        } 
        else {
          this.rt.navigate(['/joint-account', 'thanks'])
        }
      })
    }
  }
}