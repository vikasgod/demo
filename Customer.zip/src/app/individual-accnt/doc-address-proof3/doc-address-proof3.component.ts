import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { CommonService } from 'src/app/services/common.service';
import { CustomerDataService } from 'src/app/services/customer-data.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-doc-address-proof3',
  templateUrl: './doc-address-proof3.component.html',
  styleUrls: ['./doc-address-proof3.component.css']
})
export class DocAddressProof3Component implements OnInit {

  docAddressProofCForm: any;
  titleArrData: any;
  countryData: any;
  regObj: any;
  constructor(private fb: FormBuilder, private commonService: CommonService, private customerDataService: CustomerDataService, private rt: Router) { 
    this.getDoc()
  }
  ngOnInit(): void {

    this.regObj = this.commonService.getUserFromLocalStorage();

    if ((this.regObj.isSubmitted != undefined && this.regObj.isSubmitted != 0 && this.regObj.leadReviewStatus != "agent_review")
      || ((this.regObj.leadReviewStatus != undefined && this.regObj.leadReviewStatus != "customer_process")
        && (this.regObj.leadReviewStatus != undefined && this.regObj.leadReviewStatus != "agent_review"))
    ) {

      this.rt.navigate(["/individual-account", "ending"]);
    }

    this.getDoc()

    this.docAddressProofCForm = this.fb.group({
      docAddressProofCTitle: ['', [Validators.required]],
      docAddressProofCFirstName: ['', [Validators.required]],
      docAddressProofCMiddleName: ['', [Validators.required]],
      docAddressProofCLastName: ['', [Validators.required]],

      // docAddressProofCAaddrsType: ['', [Validators.required]],
      docAddressProofCAaddrsHuseNo: ['', [Validators.required]],
      docAddressProofCAaddrsBuldNm: ['', [Validators.required]],
      docAddressProofCAaddrsRdNm: ['', [Validators.required]],
      docAddressProofCAaddrsLndMrk: ['', [Validators.required]],
      docAddressProofCAaddrsCntry: ['', [Validators.required]],
      docAddressProofCAaddrsState: ['', [Validators.required]],
      docAddressProofCAaddrsCity: ['', [Validators.required]],
      docAddressProofCAaddrsPnCd: ['', [Validators.required, Validators.pattern(/[0-9]{6}/)]],

      docAddressProofCRelApplicnt: ['', [Validators.required]]
    });

    this.customerDataService.getTitle().subscribe((value) => {
      this.titleArrData = value
    })

    this.customerDataService.getCountry().subscribe((value) => {
      this.countryData = value
    })
  }

  getDoc(){
    let Obj = {
      applicant_id: this.commonService.getUserFromLocalStorage()?.applicant_id,
      process_id: 21
    }

    this.customerDataService.fetchAddressProofDocRelative(Obj).subscribe((value) => {
      if (value?.data?.length > 0) {
        this.docAddressProofCForm = this.fb.group({
          docAddressProofCTitle: [value?.data?.[0].declarant_title, [Validators.required]],
          docAddressProofCFirstName: [value?.data?.[0].declarant_first_name, [Validators.required]],
          docAddressProofCMiddleName: [value?.data?.[0].declarant_middle_name, [Validators.required]],
          docAddressProofCLastName: [value?.data?.[0].declarant_last_name, [Validators.required]],

          // docAddressProofCAaddrsType: [value?.data?.[0].countrie_name, [Validators.required]],
          docAddressProofCAaddrsHuseNo: [value?.data?.[0].declarant_house_number, [Validators.required]],
          docAddressProofCAaddrsBuldNm: [value?.data?.[0].declarant_house_and_building_name, [Validators.required]],
          docAddressProofCAaddrsRdNm: [value?.data?.[0].countrie_name, [Validators.required]],
          docAddressProofCAaddrsLndMrk: [value?.data?.[0].declarant_road_or_street_name, [Validators.required]],
          docAddressProofCAaddrsCntry: [value?.data?.[0].declarant_country_id, [Validators.required]],
          docAddressProofCAaddrsState: [value?.data?.[0].declarant_state, [Validators.required]],
          docAddressProofCAaddrsCity: [value?.data?.[0].declarant_city, [Validators.required]],
          docAddressProofCAaddrsPnCd: [value?.data?.[0].declarant_pincode, [Validators.required, Validators.pattern(/[0-9]{6}/)]],

          docAddressProofCRelApplicnt: [value?.data?.[0].declarant_relation, [Validators.required]]
        });
      }

    })
  }

  get docAddressProofCTitle() { return this.docAddressProofCForm.get("docAddressProofCTitle") }
  get docAddressProofCFirstName() { return this.docAddressProofCForm.get("docAddressProofCFirstName") }
  get docAddressProofCMiddleName() { return this.docAddressProofCForm.get("docAddressProofCMiddleName") }
  get docAddressProofCLastName() { return this.docAddressProofCForm.get("docAddressProofCLastName") }

  // get docAddressProofCAaddrsType() { return this.docAddressProofCForm.get("docAddressProofCAaddrsType") }
  get docAddressProofCAaddrsHuseNo() { return this.docAddressProofCForm.get("docAddressProofCAaddrsHuseNo") }
  get docAddressProofCAaddrsBuldNm() { return this.docAddressProofCForm.get("docAddressProofCAaddrsBuldNm") }
  get docAddressProofCAaddrsRdNm() { return this.docAddressProofCForm.get("docAddressProofCAaddrsRdNm") }
  get docAddressProofCAaddrsLndMrk() { return this.docAddressProofCForm.get("docAddressProofCAaddrsLndMrk") }
  get docAddressProofCAaddrsCntry() { return this.docAddressProofCForm.get("docAddressProofCAaddrsCntry") }
  get docAddressProofCAaddrsState() { return this.docAddressProofCForm.get("docAddressProofCAaddrsState") }
  get docAddressProofCAaddrsCity() { return this.docAddressProofCForm.get("docAddressProofCAaddrsCity") }
  get docAddressProofCAaddrsPnCd() { return this.docAddressProofCForm.get("docAddressProofCAaddrsPnCd") }
  get docAddressProofCRelApplicnt() { return this.docAddressProofCForm.get("docAddressProofCRelApplicnt") }

  keypressNumber(event: any) {
    return this.commonService.enterOnlyNumber(event);
  }

  keypressAlphabets(event: any) {
    return this.commonService.enterOnlyAlphabets(event);
  }


  submitAddressProof() {

    if (this.docAddressProofCForm.valid) {
      console.log("This is valid address proof", this.docAddressProofCForm.value);
      this.regObj = this.commonService.getUserFromLocalStorage();


      //   if(this.regObj.isSubmitted || this.regObj.leadReviewStatus != "customer_process")
      // {
      //   this.rt.navigate(["/individual-account","ending"]);
      // }


      let Obj = {

        /*
        this.docAddressProofCForm.get("docAddressProofCTitle")
        this.docAddressProofCForm.get("docAddressProofCFirstName")
        this.docAddressProofCForm.get("docAddressProofCMiddleName")
        this.docAddressProofCForm.get("docAddressProofCLastName")
        this.docAddressProofCForm.get("docAddressProofCAaddrsType")
        this.docAddressProofCForm.get("docAddressProofCAaddrsHuseNo")
        this.docAddressProofCForm.get("docAddressProofCAaddrsBuldNm")
        this.docAddressProofCForm.get("docAddressProofCAaddrsRdNm")
        this.docAddressProofCForm.get("docAddressProofCAaddrsLndMrk")
        this.docAddressProofCForm.get("docAddressProofCAaddrsCntry")
        this.docAddressProofCForm.get("docAddressProofCAaddrsState")
        this.docAddressProofCForm.get("docAddressProofCAaddrsCity")
        this.docAddressProofCForm.get("docAddressProofCAaddrsPnCd")
        this.docAddressProofCForm.get("docAddressProofCRelApplicnt")
         */


        // Address Type and landmark is missing


        process_id: 21,
        applicant_id: this.regObj.applicant_id,
        declarant_title: this.docAddressProofCForm.get("docAddressProofCTitle").value,
        declarant_first_name: this.docAddressProofCForm.get("docAddressProofCFirstName").value,
        declarant_middle_name: this.docAddressProofCForm.get("docAddressProofCMiddleName").value,
        declarant_last_name: this.docAddressProofCForm.get("docAddressProofCLastName").value,
        declarant_house_number: this.docAddressProofCForm.get("docAddressProofCAaddrsHuseNo").value,
        declarant_house_and_building_name: this.docAddressProofCForm.get("docAddressProofCAaddrsBuldNm").value,
        declarant_landmark: this.docAddressProofCForm.get("docAddressProofCAaddrsLndMrk").value,
        declarant_road_or_street_name: this.docAddressProofCForm.get("docAddressProofCAaddrsRdNm").value,
        declarant_state: this.docAddressProofCForm.get("docAddressProofCAaddrsState").value,
        declarant_city: this.docAddressProofCForm.get("docAddressProofCAaddrsCity").value,
        declarant_country_id: this.docAddressProofCForm.get("docAddressProofCAaddrsCntry").value,
        declarant_pincode: this.docAddressProofCForm.get("docAddressProofCAaddrsPnCd").value,
        declarant_relation: this.docAddressProofCForm.get("docAddressProofCRelApplicnt").value,

      }


      this.customerDataService.postCustomerAddressProofRelative(Obj).subscribe((value) => {
        if(this.regObj.leadReviewStatus == "agent_review"){
          this.rt.navigate(['/feedback', 'feedback-summary']);
          return; 

        }
        this.rt.navigate(['/individual-account', 'doc-upload1']);
        //
      })

    } else {
      console.log("This is invalid address proof");
    }

  }


}
