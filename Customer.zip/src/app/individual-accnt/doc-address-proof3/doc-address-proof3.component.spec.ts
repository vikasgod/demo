import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DocAddressProof3Component } from './doc-address-proof3.component';

describe('DocAddressProof3Component', () => {
  let component: DocAddressProof3Component;
  let fixture: ComponentFixture<DocAddressProof3Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DocAddressProof3Component ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DocAddressProof3Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
