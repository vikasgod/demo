import { Component, OnInit } from '@angular/core';
import { FormArray, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { CommonService } from 'src/app/services/common.service';
import { CustomerDataService } from 'src/app/services/customer-data.service';

@Component({
  selector: 'app-inter-bank1',
  templateUrl: './inter-bank1.component.html',
  styleUrls: ['./inter-bank1.component.css']
})
export class InterBank1Component implements OnInit {

  cardVariantData: any;
  internetBankBnkTypeArr: any;
  internetBankForm: any;
  regObj: any;

  showInfoDetail: string = '';
  internetBankBnkTypedData: Array<{}> = [{ value: 'Internet Banking' }, { value: 'Mobile Banking' }];

  isDisplayUpdateBtn: boolean = false;
  banking_facilities_id: any
  constructor(private rt: Router, private fb: FormBuilder, private commonService: CommonService, private customerDataService: CustomerDataService) {

    this.internetBankForm = this.fb.group({
      internetBankType1: [''],
      internetBankType2: [''],
      internetBankDebitCrdType: ['international'],
      internetBankDebitCrdVariant: [0],
    }, { validators: this.atLeastOneCheckedValidator.bind(this) })

  }

  ngOnInit(): void {

    this.regObj = this.commonService.getUserFromLocalStorage();


    let Obj = {
      applicant_id: this.regObj.applicant_id,
      process_id: this.regObj.account_type_id == 3 && this.regObj.applicantSerialNum == 2 ? 56 : 15,
    }



    this.customerDataService.fetchInternetBank1(Obj).subscribe((value) => {
      this.banking_facilities_id = value.data[0]?.banking_facilities_id
      if (value.data.length > 0) {
        this.isDisplayUpdateBtn = true;
        this.internetBankForm = this.fb.group({
          internetBankType1: [value?.data?.[0]?.is_internet_banking_selected || null,],
          internetBankType2: [value?.data?.[0]?.is_mobile_banking_selected || null,],
          internetBankDebitCrdType: [value?.data?.[0]?.debit_card_type],
          internetBankDebitCrdVariant: [value?.data?.[0]?.card_variant],
        }, { validators: this.atLeastOneCheckedValidator.bind(this) })
      }
    })

    this.internetBankBnkTypeArr = this.internetBankBnkTypedData;
    this.customerDataService.fetchSelectedAccountType(Obj).subscribe((res) => {
      console.log("fjghjfdghfjg",res)
      this.customerDataService.getCardVariant().subscribe((data) => {
        if (res?.saving_account == 'Prime Edge NRE' || res?.saving_account == 'Prime Edge NRE + Prime Edge NRO' || res?.saving_account == 'Prime Edge NRO') {
          let index = data.data?.findIndex((obj: any) => obj.card_type.includes('Classic First'));
          if (index !== -1) {
            data.data.splice(index, 1);
          }
        }
        this.cardVariantData = data.data;
      })
    })


  }


  showInfoDetails(label: any) {
      this.showInfoDetail = label;

  }
  atLeastOneCheckedValidator(group: FormGroup) {
    const checkbox1 = this.internetBankForm?.controls?.internetBankType1?.value;
    const checkbox2 = this.internetBankForm?.controls?.internetBankType2?.value;
    return (checkbox1 || checkbox2) ? null : { atLeastOneChecked: true };
  }


  get internetBankType1() { return this.internetBankForm.get("internetBankType1") }
  get internetBankType2() { return this.internetBankForm.get("internetBankType2") }
  get internetBankDebitCrdType() { return this.internetBankForm.get("internetBankDebitCrdType") }
  get internetBankDebitCrdVariant() { return this.internetBankForm.get("internetBankDebitCrdVariant") }

  onInternetBankingMode(e: any) {
    let website: FormArray = this.internetBankForm.get('internetBankBnkType') as FormArray;
    if (e.target.checked) {
      website.push(new FormControl(e.target.value));
    }
    else {
      let index = website.controls.findIndex(x => x.value === e.target.value);
      website.removeAt(index);
    }
  }

  submitInternetBank() {
    if (this.internetBankForm.valid) {

      let Obj = {
        applicant_id: Number(this.regObj.applicant_id),//number
        process_id: this.regObj.account_type_id == 3 && this.regObj.applicantSerialNum == 2 ? 56 : 15,
        banking_facilities_id: this.banking_facilities_id || null,
        is_internet_banking_selected: Number(this.internetBankForm.get("internetBankType1").value),
        is_mobile_banking_selected: Number(this.internetBankForm.get("internetBankType2").value),
        debit_card_type: this.internetBankForm.get("internetBankDebitCrdType").value,
        card_variant: this.internetBankForm.get("internetBankDebitCrdVariant").value
      }

      this.customerDataService.postInternetBanking1(Obj).subscribe((data) => {
        this.commonService.storeInLocalStorage('registerData', { 'banking_facilities_id': data?.banking_facilities_id })
        var is_feedback_show = 0;
        if (this.commonService.getUserFromLocalStorage()?.leadReviewStatus != undefined) {
          if (this.commonService.getUserFromLocalStorage()?.leadReviewStatus != 'customer_process') {
            is_feedback_show += 1;
          }
        }
        if (is_feedback_show != 0) {
          this.rt.navigate(["/feedback", "feedback-summary"]);
        } else {
          this.rt.navigate(["/individual-account", "internet-banking2"]);
        }
      }, (err) => {
        console.log('This error', err)
      })

    }

  }
}