import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DocVisaComponent } from './doc-visa.component';

describe('DocVisaComponent', () => {
  let component: DocVisaComponent;
  let fixture: ComponentFixture<DocVisaComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DocVisaComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DocVisaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
