import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DocumentUpload1Component } from './document-upload1.component';

describe('DocumentUpload1Component', () => {
  let component: DocumentUpload1Component;
  let fixture: ComponentFixture<DocumentUpload1Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DocumentUpload1Component ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DocumentUpload1Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
