import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { Observable, of } from 'rxjs';
import { CommonService } from 'src/app/services/common.service';
import { CustomerDataService } from 'src/app/services/customer-data.service';

@Component({
  selector: 'app-document-upload1',
  templateUrl: './document-upload1.component.html',
  styleUrls: ['./document-upload1.component.css']
})

export class DocumentUpload1Component implements OnInit {
  isDisplayForm60: boolean = true;
  isTypeOfPassportDoc: boolean = true;
  isDisplayPIO: boolean = true;
  isDisplayVisa: boolean = true;
  isResidencePermitDoc: boolean = true
  imgSrcVisaOrOci: string = '';
  isOtherThanIndianPassport:string = ''
  showInfoDetail: string = '';

  addressProofDoc: any;
  regObj: any;
  imgSrcPsportFront: string = '';
  imgSrcPsportBack: string = '';
  imgSrcAddressProof: string = '';
  imgSrcFrom60: string = '';
  imgSrcOci: string = '';
  imgSrcPio1: string = '';
  imgSrcPio2: string = '';
  imgSrcOtherDoc: string = '';
  passportFront$: Observable<any> = of();
  passportBack$: Observable<any> = of();
  display: string = "none";
  docValidPassportErr: string = '';
  isDisplayAddressProofUpload: boolean = true;
  @ViewChild('addressProofddl')
  addressProofddl!: ElementRef;
  renderer: any;
  validpassport: boolean = false;
  docupload: any = '';
  isDisabled: boolean = true;
  addressProofSelect: boolean = true;
  isDisplayUpdateBtn: boolean = false;

  constructor(private rt: Router, private commonService: CommonService, private customerDataService: CustomerDataService) {
  }

  ngOnInit(): void {
    this.regObj = this.commonService.getUserFromLocalStorage();

    this.customerDataService.getAddressProofDoc().subscribe((value) => {
      if (value.length < 0) {
        this.isDisplayUpdateBtn = true;
      }
      else {
        this.isDisplayUpdateBtn = false;
      }
      if (this.validpassport == true) {
        let index = value.address_proof_types.findIndex((res: any) => res.name == "Valid Passport")
        value.address_proof_types.splice(index, 1)
      }
      this.addressProofDoc = value.address_proof_types;
    })
    this.addAdressProof()

    let Obj1 = {
      applicant_id: this.commonService.getUserFromLocalStorage().applicant_id,
      document: "passport_front"
    }

    this.customerDataService.postCustomerGetDoc(Obj1).subscribe((value) => {
      this.imgSrcPsportFront = value?.file_path;
    });

    let Obj2 = {
      applicant_id: this.commonService.getUserFromLocalStorage().applicant_id,
      document: "passport_back"
    }
    this.customerDataService.postCustomerGetDoc(Obj2).subscribe((value) => {
      this.imgSrcPsportBack = value?.file_path;
    });

    let Obj3 = {
      applicant_id: this.commonService.getUserFromLocalStorage().applicant_id,
      document: "address_proof"
    }
    this.customerDataService.postCustomerGetDoc(Obj3).subscribe((value) => {
      this.imgSrcAddressProof = value?.[0]?.file_path;
    });

    let Obj4 = {
      applicant_id: this.commonService.getUserFromLocalStorage().applicant_id,
      document: "form_sixty"
    }
    this.customerDataService.postCustomerGetDoc(Obj4).subscribe((value) => {
      this.imgSrcFrom60 = value?.file_path;
    });

    let Obj5 = {
      applicant_id: this.commonService.getUserFromLocalStorage().applicant_id,
      document: "oci"
    }
    this.customerDataService.postCustomerGetDoc(Obj5).subscribe((value) => {

      this.imgSrcOci = value?.file_path;
    }, (err) => {

    });

    let Obj6 = {
      applicant_id: this.commonService.getUserFromLocalStorage().applicant_id,
      document: "visa"
    }
    this.customerDataService.postCustomerGetDoc(Obj6).subscribe((value) => {
      this.imgSrcVisaOrOci = value?.file_path;
    }, (err) => {

    });

    let Obj7 = {
      applicant_id: this.commonService.getUserFromLocalStorage().applicant_id,
      document: "old_indian_passport_front"
    }
    this.customerDataService.postCustomerGetDoc(Obj7).subscribe((value) => {
      this.imgSrcPio1 = value?.file_path;
    }, (err) => {

    });

    let Obj8 = {
      applicant_id: this.commonService.getUserFromLocalStorage().applicant_id,
      document: "old_indian_passport_back"
    }
    this.customerDataService.postCustomerGetDoc(Obj8).subscribe((value) => {
      this.imgSrcPio2 = value?.file_path;
    }, (err) => {

    });

    let Obj9 = {
      applicant_id: this.commonService.getUserFromLocalStorage().applicant_id,
      document: "other"
    }
    this.customerDataService.postCustomerGetDoc(Obj9).subscribe((value) => {
      this.imgSrcOtherDoc = value[0]?.file_path;
    }, (err) => {

    });

    let Obj = {
      applicant_id: this.commonService.getUserFromLocalStorage().applicant_id
    }
    this.customerDataService.postCustomerDocumentCondition(Obj).subscribe((value) => {
      console.log(value.data[0]);

      if(value.data[0].address_proof_id == 0 || value.data[0].address_proof_id == '' || value.data[0].address_proof_id== null){
        this.docupload = ''
        this.addressProofSelect = true
      } 
      else{
        this.docupload = value.data[0].address_proof_id
        this.addressProofSelect = false;
      }

      if (value.data[0].is_form_60 == 0 || value.data[0].is_form_60 == undefined || value.data[0].is_form_60 == '' || value.data[0].is_form_60 == false) {
        this.isDisplayForm60 = false;
      }

      if (value.data[0].visa_type == undefined || value.data[0].visa_type == "" || value.data[0].visa_type == 0) {
        this.isTypeOfPassportDoc = false;
        this.isDisplayVisa = false
      }

      if (value.data[0].is_pio == undefined || value.data[0].is_pio == "" || value.data[0].is_pio == 0) {
        this.isDisplayPIO = false;
      }

      // else if(){

      // }

    }, (err) => {

    });



    //If in KYC form60 is selected then only display form 60 doc upload part  

    // if (this.commonService.getUserFromLocalStorage()?.Form60Doc === undefined || this.commonService.getUserFromLocalStorage()?.Form60Doc === '' || this.commonService.getUserFromLocalStorage()?.Form60Doc === false || this.commonService.getUserFromLocalStorage()?.Form60Doc === 0) {

    // } 
    // else {
    //   this.isDisplayForm60 = true;
    // }

    //If in KYC Other than Indian passport is selected then only display Visa document doc upload part  
    //else display OCI doc upload part  
    //else nothing is selected then show nothing
    // if (this.commonService.getUserFromLocalStorage()?.TypeOfPassportDoc == 1) {
    //   this.isTypeOfPassportDoc = false;
    // }
    // else {
    //   this.isTypeOfPassportDoc = true;
    // }

    // if (this.commonService.getUserFromLocalStorage().TypeOfPassportDoc === undefined) {
    //   this.isDisplayVisa = false;
    // }

    // if (this.commonService.getUserFromLocalStorage().TypeOfPassportDoc === "" || this.commonService.getUserFromLocalStorage().TypeOfPassportDoc === 0) {
    //   this.isDisplayVisa = false;
    // }
    // else {
    //   this.isDisplayVisa = true;
    // }

    ///If PIO in KYC Details is checked then div will displayed
    // if (this.commonService.getUserFromLocalStorage().TypeOfPIODoc === undefined || this.commonService.getUserFromLocalStorage().TypeOfPIODoc === "" || this.commonService.getUserFromLocalStorage().TypeOfPIODoc === 0) {
    //   this.isDisplayPIO = false;
    // }
    // else {
    //   this.isDisplayPIO = true;
    // }
    //TypeOfPIODoc
    if (this.commonService.getUserFromLocalStorage()?.docAddressType === undefined || this.commonService.getUserFromLocalStorage()?.docAddressType === '' || this.commonService.getUserFromLocalStorage()?.docAddressType === null) {
      // this.renderer.setStyle(this.input.nativeElement, 'background', '#d515a0');
      // this.addressProof.id 
    }


    // changing text Indian to foreign for other than passport
    let Obj0 = {
      applicant_id: this.regObj.applicant_id,
      process_id: 7
    }

    this.customerDataService.fetchKycDtls1(Obj0).subscribe((data)=>{
     this.isOtherThanIndianPassport = data?.data?.map((data:any)=>{
       return data?.is_other_than_indian_passport_name === "yes"? "Foreign":"Indian";
      })      
    })

  }

  ngAfterViewInit(): void {
    //this.addressProofddl.nativeElement.setValue('1')
  }

  addAdressProof(event?:any) {
    if (this.docupload === '') {
      this.docValidPassportErr = 'Already uploaded passport';
      this.isDisplayAddressProofUpload = true;
    }
    if(this.docupload == 0 || this.docupload == '' || this.docupload == null){
      this.addressProofSelect = true
    } 
    else{
      this.addressProofSelect = false;
    }
    if(event){
      this.commonService.storeInLocalStorage('registerData', { docAddressType: event?.target?.value });
    }
   
  }

  redirectUploadPage(path1: string, path2: string) {
    this.rt.navigate([`${path1}`, `${path2}`])

  }

  redirectNomination() {
    // this.rt.navigate([`individual-account`, `thanks`])
    this.rt.navigate([`individual-account`, `declaration1`])
  }

  openModal() {
    this.display = "block";
  }
  onCloseHandled() {
    this.display = "none";
  }

  ///disable proceed 
  isProceedDisableBtn() {
    if (this.isDisplayForm60 && (this.imgSrcPsportFront == '' || this.imgSrcPsportBack == '' || this.imgSrcAddressProof == '' || this.imgSrcFrom60 == '')) {
      return true
    } else if (!this.isDisplayForm60 && (this.imgSrcPsportFront == '' || this.imgSrcPsportBack == '' || this.imgSrcAddressProof == '')) {
      return true
    } else {
      return false
    }
  }

  //  show info click on i-info button
  showInfoDetails(label: any) {
    this.showInfoDetail = label;
  }

}