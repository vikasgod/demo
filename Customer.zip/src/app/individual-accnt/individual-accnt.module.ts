import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';

import { HttpClientModule } from '@angular/common/http';
import { FormsModule,ReactiveFormsModule} from '@angular/forms';
import { PersonalDtls1Component } from './personal-dtls1/personal-dtls1.component';
import { PersonalDtls2Component } from './personal-dtls2/personal-dtls2.component';
import { FatcaComponent } from './fatca/fatca.component';
import { KycDtls1Component } from './kyc-dtls1/kyc-dtls1.component';

import { MatInputModule} from '@angular/material/input';
import {MatFormFieldModule} from '@angular/material/form-field'
import {MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
import { KycDtls2Component } from './kyc-dtls2/kyc-dtls2.component';
import { KycDtls3Component } from './kyc-dtls3/kyc-dtls3.component';
import { KycDtls4Component } from './kyc-dtls4/kyc-dtls4.component';
import { ContactDtlsComponent } from './contact-dtls/contact-dtls.component';
import { CustomerProfileComponent } from './customer-profile/customer-profile.component';
import { InterBank1Component } from './inter-bank1/inter-bank1.component';
import { InterBank2Component } from './inter-bank2/inter-bank2.component';
import { AddrsDtls1Component } from './addrs-dtls1/addrs-dtls1.component';
import { AddrsDtls2Component } from './addrs-dtls2/addrs-dtls2.component';
import { DocumentUpload1Component } from './document-upload1/document-upload1.component';
import { DocIndentityProofComponent } from './doc-indentity-proof/doc-indentity-proof.component';
import { DocAddressProof1Component } from './doc-address-proof1/doc-address-proof1.component';
import { DocAddressProof2Component } from './doc-address-proof2/doc-address-proof2.component';
import { DocAddressProof3Component } from './doc-address-proof3/doc-address-proof3.component';
import { DocOtherProofComponent } from './doc-other-proof/doc-other-proof.component';
import { Nomination1Component } from './nomination1/nomination1.component';
import { Nomination2Component } from './nomination2/nomination2.component';
import { Nomination3Component } from './nomination3/nomination3.component';
import { Declaration1Component } from './declaration1/declaration1.component';
import { Declaration2Component } from './declaration2/declaration2.component';
import { DocForm60Component } from './doc-form60/doc-form60.component';
import { DocVisaComponent } from './doc-visa/doc-visa.component';
import { DocPioComponent } from './doc-pio/doc-pio.component';
import { DocOciComponent } from './doc-oci/doc-oci.component';




@NgModule({
  declarations: [
    PersonalDtls1Component,
    PersonalDtls2Component,
    FatcaComponent,
    KycDtls1Component,
    KycDtls2Component,
    KycDtls3Component,
    KycDtls4Component,
    ContactDtlsComponent,
    CustomerProfileComponent,
    InterBank1Component,
    InterBank2Component,
    AddrsDtls1Component,
    AddrsDtls2Component,
    DocumentUpload1Component,
    DocIndentityProofComponent,
    DocAddressProof1Component,
    DocAddressProof2Component,
    DocAddressProof3Component,
    DocOtherProofComponent,
    Nomination1Component,
    Nomination2Component,
    Nomination3Component,
    Declaration1Component,
    Declaration2Component,
    DocForm60Component,
    DocVisaComponent,
    DocPioComponent,
    DocOciComponent,
  ],
  imports: [
    HttpClientModule,
    CommonModule,
    RouterModule,
    ReactiveFormsModule,
    FormsModule,
    MatInputModule,
    MatFormFieldModule,
    MatDatepickerModule,
    MatNativeDateModule,
    
  ],
  exports:[
    PersonalDtls1Component,
    PersonalDtls2Component,
    FatcaComponent,
    KycDtls1Component,
    KycDtls2Component,
    KycDtls3Component,
    ContactDtlsComponent,
    CustomerProfileComponent,
    InterBank1Component,
    InterBank2Component,
    AddrsDtls1Component,
    AddrsDtls2Component,
    DocumentUpload1Component,
    DocIndentityProofComponent,
    DocAddressProof1Component,
    DocAddressProof2Component,
    DocAddressProof3Component,
    DocOtherProofComponent,
    Nomination1Component,
    Nomination2Component,
    Nomination3Component,
    Declaration1Component,
    Declaration2Component
  ]
})
export class IndividualAccntModule { }
