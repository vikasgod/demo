import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PersonalDtls1Component } from './personal-dtls1.component';

describe('PersonalDtls1Component', () => {
  let component: PersonalDtls1Component;
  let fixture: ComponentFixture<PersonalDtls1Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PersonalDtls1Component ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PersonalDtls1Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
