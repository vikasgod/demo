import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { CommonService } from 'src/app/services/common.service';
import { CustomerDataService } from 'src/app/services/customer-data.service';

@Component({
  selector: 'app-customer-profile',
  templateUrl: './customer-profile.component.html',
  styleUrls: ['./customer-profile.component.css']
})
export class CustomerProfileComponent implements OnInit {

  occupationTypeData: any;
  employmentTypeData: any;
  customerProfileFrom: any;
  isIndustryTypeVisible:boolean = true;
  regObj: any;
  anualIncomeTypeData: any;
  industryTypeData: any;
  isDisplayUpdateBtn: boolean = false;
  isSubmitted: boolean = false;
  customer_profiler: any
  constructor(private rt: Router, private fb: FormBuilder, private commonService: CommonService, private customerDataService: CustomerDataService) { }

  ngOnInit(): void {

    this.regObj = this.commonService.getUserFromLocalStorage();
     
    let Obj = {
      applicant_id: this.regObj.applicant_id,
      process_id: 14
    }

    this.customerDataService.fetchCustomerProfiler(Obj).subscribe((value) => {
      if (value?.data?.length > 0) {
        this.isDisplayUpdateBtn = true;
        this.customer_profiler = value?.data?.[0]?.customer_profile_id
        this.customerProfileFrom = this.fb.group({
          customerProfileEdctnQufictn: [value?.data?.[0]?.qualification, [Validators.required]],
          customerProfileEmptynType: [value?.data?.[0]?.employment_type_id, [Validators.required]],
          customerProfileOccptn: [value?.data?.[0]?.occupation_id, [Validators.required]],
          customerProfileSrcIncome: [value?.data?.[0]?.source_income, [Validators.required]],
          customerProfileGrossIcome: [value?.data?.[0]?.gross_annual_income, [Validators.required]],
          customerProfileIdustType: [value?.data?.[0]?.industry_type_id]
        })
        this.updateIndustryTypeVisible(value?.data?.[0]?.employment_type_id)
      }
    })

    this.customerProfileFrom = this.fb.group({
      customerProfileEdctnQufictn: ['', [Validators.required]],
      customerProfileEmptynType: ['', [Validators.required]],
      customerProfileOccptn: ['', [Validators.required]],
      customerProfileSrcIncome: ['', [Validators.required]],
      customerProfileGrossIcome: ['', [Validators.required]],
      customerProfileIdustType: ['']
    })

    this.customerProfileFrom.get('customerProfileEmptynType')?.valueChanges.subscribe((value:any)=>{
      this.updateIndustryTypeVisible(value)
    })
    this.customerDataService.getEmploymentType().subscribe((data) => {
      this.employmentTypeData = data
    })

    this.customerDataService.getOccupationType().subscribe((data) => {
      this.occupationTypeData = data;
    })

    this.customerDataService.getGrossAnualIncomeType().subscribe((data) => {
      this.anualIncomeTypeData = data;
    })

    this.customerDataService.getIndustryType().subscribe((data) => {
      this.industryTypeData = data;
    })
  }
  
  get customerProfileEdctnQufictn() { return this.customerProfileFrom.get("customerProfileEdctnQufictn") }
  get customerProfileEmptynType() { return this.customerProfileFrom.get("customerProfileEmptynType") }
  get customerProfileOccptn() { return this.customerProfileFrom.get("customerProfileOccptn") }
  get customerProfileSrcIncome() { return this.customerProfileFrom.get("customerProfileSrcIncome") }
  get customerProfileGrossIcome() { return this.customerProfileFrom.get("customerProfileGrossIcome") }
  get customerProfileIdustType() { return this.customerProfileFrom.get("customerProfileIdustType") }
  updateIndustryTypeVisible(employTypeId:Number){
    this.isIndustryTypeVisible = employTypeId == 1 || employTypeId == 2;
  }
  submitCustomerProfile() {
    if (this.customerProfileFrom.valid) {

      let Obj = {
        process_id: 14,
        applicant_id: this.regObj.applicant_id,
        qualification: this.customerProfileFrom.get("customerProfileEdctnQufictn").value,
        employment_type_id: Number(this.customerProfileFrom.get("customerProfileEmptynType").value),
        occupation_id: Number(this.customerProfileFrom.get("customerProfileOccptn").value),
        source_income: this.customerProfileFrom.get("customerProfileSrcIncome").value,
        gross_annual_income: this.customerProfileFrom.get("customerProfileGrossIcome").value,
        industry_type_id: Number(this.customerProfileFrom.get("customerProfileIdustType").value),
        customer_profiler: this.customer_profiler
      }

      this.customerDataService.postCustomerProfiler(Obj).subscribe((data) => {
        var is_feedback_show = 0;
        if (this.commonService.getUserFromLocalStorage()?.leadReviewStatus != undefined) {
          if (this.commonService.getUserFromLocalStorage()?.leadReviewStatus != 'customer_process') {
            is_feedback_show += 1;
          }
        }
        if (is_feedback_show != 0) {
          this.rt.navigate(["/feedback", "feedback-summary"]);
        } else {
          this.rt.navigate(["/individual-account", "internet-banking"]);
        }
      })
      this.rt.navigate(["/individual-account", "internet-banking"])
    }
  }
}