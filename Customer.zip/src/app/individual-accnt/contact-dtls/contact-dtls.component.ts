import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { CommonService } from 'src/app/services/common.service';
import { CustomerDataService } from 'src/app/services/customer-data.service';




@Component({
  selector: 'app-contact-dtls',
  templateUrl: './contact-dtls.component.html',
  styleUrls: ['./contact-dtls.component.css']
})
export class ContactDtlsComponent implements OnInit {

  contactDtlsForm: any;
  regObj: any;
  contact_details_id: any;
  mobileNo: any;
  isdCode: any;
  emailID: string = '';
  isDisplayUpdateBtn: boolean = false;
  isReadOnlyField:boolean = false;
  constructor(private rt: Router, private fb: FormBuilder, private commonService: CommonService, private customerDataService: CustomerDataService) { }


  ngOnInit(): void {

    this.regObj = this.commonService.getUserFromLocalStorage();
    let Obj = {
      applicant_id: this.regObj.applicant_id,
      process_id: 11
    }

    this.customerDataService.fetchContactDtls(Obj).subscribe((value) => {
      this.contactDtlsForm = this.fb.group({
        contactDtlsOfficeCntryCd: [value?.data?.[0]?.office_country_code],
        contactDtlsOfficeStdCd: [value?.data?.[0]?.office_std_code],
        contactDtlsOfficeTelNo: [value?.data?.[0]?.office_tel_number],
        contactDtlsResidenceCntryCd: [value?.data?.[0]?.residence_country_code],
        contactDtlsResidenceStdCd: [value?.data?.[0]?.residence_std_code],
        contactDtlsResidenceTelNo: [value?.data?.[0]?.residence_tel_number],
        contactDtlsMobileISDCd: [value.data[0].country_code],
        contactDtlsMobileTelNo: [value.data[0].mobile_number],
        contactDtlsFaxCntryCd: [value?.data?.[0]?.fax_country_code],
        contactDtlsFaxStdCd: [value?.data?.[0]?.fax_std_code],
        contactDtlsFaxTelNo: [value?.data?.[0]?.fax_number],
        contactDtlsEmailID: [value.data[0].email_address],
      })

      if (value?.data?.[0]?.contact_details_id === 'undefined' || value?.data?.[0]?.contact_details_id === undefined) {
        this.contact_details_id = "undefined"
      } else {
        this.contact_details_id = value?.data?.[0]?.contact_details_id
      }

      if( value?.data?.length > 0){
        this.isDisplayUpdateBtn = true;
      }

    })

      if(this.regObj?.account_type_id == 2){
        this.isReadOnlyField = false
      }else{
        this.isReadOnlyField = true
      }
      
    this.contactDtlsForm = this.fb.group({
      contactDtlsOfficeCntryCd: [],
      contactDtlsOfficeStdCd: [],
      contactDtlsOfficeTelNo: [],
      contactDtlsResidenceCntryCd: [],
      contactDtlsResidenceStdCd: [],
      contactDtlsResidenceTelNo: [],
      contactDtlsMobileISDCd: [''],
      contactDtlsMobileTelNo: ['',[Validators.required]],
      contactDtlsFaxCntryCd: [''],
      contactDtlsFaxStdCd: [''],
      contactDtlsFaxTelNo: [''],
      contactDtlsEmailID: ['', [Validators.email, Validators.required]],
    })
  }



  get contactDtlsOfficeCntryCd() { return this.contactDtlsForm.get("contactDtlsOfficeCntryCd") }
  get contactDtlsOfficeStdCd() { return this.contactDtlsForm.get("contactDtlsOfficeStdCd") }
  get contactDtlsOfficeTelNo() { return this.contactDtlsForm.get("contactDtlsOfficeTelNo") }
  get contactDtlsResidenceCntryCd() { return this.contactDtlsForm.get("contactDtlsResidenceCntryCd") }
  get contactDtlsResidenceStdCd() { return this.contactDtlsForm.get("contactDtlsResidenceStdCd") }
  get contactDtlsResidenceTelNo() { return this.contactDtlsForm.get("contactDtlsResidenceTelNo") }
  get contactDtlsMobileISDCd() { return this.contactDtlsForm.get("contactDtlsMobileISDCd") }
  get contactDtlsMobileTelNo() { return this.contactDtlsForm.get("contactDtlsMobileTelNo") }
  get contactDtlsFaxCntryCd() { return this.contactDtlsForm.get("contactDtlsFaxCntryCd") }
  get contactDtlsFaxStdCd() { return this.contactDtlsForm.get("contactDtlsFaxStdCd") }
  get contactDtlsFaxTelNo() { return this.contactDtlsForm.get("contactDtlsFaxTelNo") }
  get contactDtlsEmailID() { return this.contactDtlsForm.get("contactDtlsEmailID") }



  keypressHyphenNumber(event: any) {
    return this.commonService.enterOnlyNumberHypen(event);
  }





  validateISD(event: any) {
    return this.commonService.validateISD(event);
  }


  keyPressMobile(event: any) {
    return this.commonService.enterOnlyNumber(event)
  }



  submitContactDtls() {
    // if (this.contactDtlsForm.valid) {

      this.regObj = this.commonService.getUserFromLocalStorage();
      console.log("This Obj", this.regObj.applicant_id);


      /*
        this.contactDtlsForm.get("contactDtlsOfficeCntryCd").value
        this.contactDtlsForm.get("contactDtlsOfficeStdCd").value
        this.contactDtlsForm.get("contactDtlsOfficeTelNo").value
        this.contactDtlsForm.get("contactDtlsResidenceCntryCd").value
        this.contactDtlsForm.get("contactDtlsResidenceStdCd").value
        this.contactDtlsForm.get("contactDtlsResidenceTelNo").value
        this.contactDtlsForm.get("contactDtlsMobileISDCd").value
        this.contactDtlsForm.get("contactDtlsMobileTelNo").value
        this.contactDtlsForm.get("contactDtlsFaxCntryCd").value
        this.contactDtlsForm.get("contactDtlsFaxStdCd").value
        this.contactDtlsForm.get("contactDtlsFaxTelNo").value
        this.contactDtlsForm.get("contactDtlsEmailID").value
        */

      let Obj = {
        applicant_id: this.regObj.applicant_id,
        process_id: 11,
        contact_details_id: this.contact_details_id,
        office_country_code: this.contactDtlsForm.get("contactDtlsOfficeCntryCd").value,
        office_std_code: this.contactDtlsForm.get("contactDtlsOfficeStdCd").value,
        office_tel_number: Number(this.contactDtlsForm.get("contactDtlsOfficeTelNo").value),
        country_code: this.contactDtlsForm.get("contactDtlsMobileISDCd").value,
        mobile_number: Number(this.contactDtlsForm.get("contactDtlsMobileTelNo").value),
        fax_country_code: this.contactDtlsForm.get("contactDtlsFaxCntryCd").value,
        fax_std_code: this.contactDtlsForm.get("contactDtlsFaxStdCd").value,
        fax_number: Number(this.contactDtlsForm.get("contactDtlsFaxTelNo").value),
        email_address: this.contactDtlsForm.get("contactDtlsEmailID").value,
        residence_std_code: this.contactDtlsForm.get("contactDtlsResidenceStdCd").value,
        residence_country_code: this.contactDtlsForm.get("contactDtlsResidenceCntryCd").value,
        residence_tel_number: Number(this.contactDtlsForm.get("contactDtlsResidenceTelNo").value)

      }


      this.customerDataService.postContactDtls(Obj).subscribe((data) => {

        var is_feedback_show = 0;
        if (this.commonService.getUserFromLocalStorage()?.leadReviewStatus != undefined) {
          if (this.commonService.getUserFromLocalStorage()?.leadReviewStatus != 'customer_process') {
            is_feedback_show += 1;
          }
        }
        if (is_feedback_show != 0) {
          this.rt.navigate(["/feedback", "feedback-summary"]);
        } else {
          this.rt.navigate(["/individual-account", "addrs-dtls1"]);
        }


      })

    // } else {
    //   console.log("This is invalid form");
    // }



  }



}
