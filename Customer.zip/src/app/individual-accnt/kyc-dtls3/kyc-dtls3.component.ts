import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { CommonService } from 'src/app/services/common.service';

@Component({
  selector: 'app-kyc-dtls3',
  templateUrl: './kyc-dtls3.component.html',
  styleUrls: ['./kyc-dtls3.component.css']
})
export class KycDtls3Component implements OnInit {
  regObj: any;
  kycDtlsCForm: any;
  constructor(private rt: Router, private fb: FormBuilder, private commonService: CommonService) { }

  ngOnInit(): void {
    this.regObj = this.commonService.getUserFromLocalStorage();

    this.kycDtlsCForm = this.fb.group({
    })
  }

  submitKycDtls() {
    if (this.kycDtlsCForm.valid) {
      this.rt.navigate(["/individual-account/kyc-dtls2"])
    } else {
      console.log("This form is invalid")
    }
  }
}