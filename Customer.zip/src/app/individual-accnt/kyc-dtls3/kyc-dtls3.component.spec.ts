import { ComponentFixture, TestBed } from '@angular/core/testing';

import { KycDtls3Component } from './kyc-dtls3.component';

describe('KycDtls3Component', () => {
  let component: KycDtls3Component;
  let fixture: ComponentFixture<KycDtls3Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ KycDtls3Component ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(KycDtls3Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
