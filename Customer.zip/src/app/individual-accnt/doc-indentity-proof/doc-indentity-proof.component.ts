
import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { CommonService } from 'src/app/services/common.service';
import { CustomerDataService } from 'src/app/services/customer-data.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-doc-indentity-proof',
  templateUrl: './doc-indentity-proof.component.html',
  styleUrls: ['./doc-indentity-proof.component.css']
})
export class DocIndentityProofComponent implements OnInit {
  requiredFileType: string = 'image/png,image/jpeg,png,jpeg'
  docIndentityFrom: any;
  iSfile1Change: boolean = false;
  errFileExtension: boolean = true;
  imgSrc: any = '';
  fileDataStr1: any = '';
  fileDataStr2: any = '';
  fileName1: string = '';
  fileName2: string = '';
  regObj: any;
  imgSrc1: any = '';
  imgSrc2: any = '';
  isUpdate: boolean = false

  display: string = "none";
  docIdentiyFailedErr: string = '';
  applicant:any
  isOtherThanIndianPassport:string = '';

  constructor(private fb: FormBuilder, private commonService: CommonService, private customerDataService: CustomerDataService, private rt: Router) {
  }

  ngOnInit(): void {

    this.regObj = this.commonService.getUserFromLocalStorage();

    let req = {
      user_id: this.regObj?.user_id
    }

    // this.customerDataService.fetchAllID(req).subscribe((value) => {
    //   if (value?.data?.length > 0) {
    //     this.applicant = value.data[0].applicant_personal_id
    //   }
    // })

    this.docIndentityFrom = this.fb.group({
      docIndentityFile1: ['', [Validators.required]],
      docIndentityFile2: ['', [Validators.required]],
    })

    setTimeout(() => {
      this.getDoc()
    }, 500);

    // changing text Indian to foreign for other than passport
    let Obj0 = {
      applicant_id: this.regObj.applicant_id,
      process_id: 7
    }

    this.customerDataService.fetchKycDtls1(Obj0).subscribe((data)=>{
     this.isOtherThanIndianPassport = data?.data?.map((data:any)=>{
       return data?.is_other_than_indian_passport_name === "yes"? "Foreign":"Indian";
      })      
    })
  }

  getDoc() {
    let Obj1 = {
      applicant_id: this.regObj.applicant_id,
      document: "passport_front"
    }

    this.customerDataService.fetchGetDoc(Obj1).subscribe((value) => {
      console.log(">>>>>>>val", value)
      if (value != undefined) {
        this.isUpdate = true
      }
      this.imgSrc1 = value.file_path;
      let name = value.file_path.split("/").pop()
      this.fileName1 = name
      this.customerDataService.getBase64ImageFromUrl(value.file_path).then(result => {
        this.fileDataStr1 = result
      })
        .catch(err => console.error(err));

      this.docIndentityFrom.controls['docIndentityFile1'].setValue(name)
    })

    let Obj2 = {
      applicant_id: this.regObj.applicant_id,
      document: "passport_back"
    }

    this.customerDataService.fetchGetDoc(Obj2).subscribe((value) => {
      this.imgSrc2 = value.file_path;
      let name = value.file_path.split("/").pop()
      this.fileName2 = name
      this.customerDataService.getBase64ImageFromUrl(value.file_path).then(result => {
        this.fileDataStr2 = result
      })
        .catch(err => console.error(err));
      this.docIndentityFrom.controls['docIndentityFile2'].setValue(name)
    })
  }

  get docIndentityFile1() { return this.docIndentityFrom.get("docIndentityFile1") }
  get docIndentityFile2() { return this.docIndentityFrom.get("docIndentityFile2") }

  //Working 1  
  onFilesSelected1(event: any) {
    this.iSfile1Change = true;
    let fileData = event.target.files[0];
    this.fileName1 = fileData.name;
    this.docIndentityFrom.controls['docIndentityFile1'].setValue(fileData.name)
    //500000
    let arr = String(fileData.name).split('.');
    let len = arr.length;

    if (fileData.size <= 5000000) {
      if (arr[len - 1] === "png" || arr[len - 1] === "jpeg" || arr[len - 1] === "jpg") {
        const reader = new FileReader();
        reader.readAsDataURL(fileData);
        reader.onloadend = () => {
          this.imgSrc1 = reader.result
          // Use a regex to remove data url part
          const base64String = String(reader.result)
            .replace('data:', '')
            .replace(/^.+,/, '');
          this.fileDataStr1 = base64String;
        };
      } 
      else {
        this.errFileExtension = false;
      }
    } 
    else {
      this.fileName1 = '';
      this.docIndentityFrom.get('docIndentityFile1').setValue('');
      this.docIdentiyFailedErr = 'File size exceeds 5mb'
      this.openModal();
    }


    //return
  }
  //Working 2
  onFilesSelected2(event: any) {
    this.iSfile1Change = true;
    let fileData = event.target.files[0];
    this.fileName2 = fileData.name;
    this.docIndentityFrom.controls['docIndentityFile2'].setValue(fileData.name)
    let arr = String(fileData.name).split('.');
    let len = arr.length;
    if (fileData.size <= 5000000) {
      if (arr[len - 1] === "png" || arr[len - 1] === "jpeg" || arr[len - 1] === "jpg") {
        const reader = new FileReader();
        reader.onloadend = () => {
          // Use a regex to remove data url part
          this.imgSrc2 = String(reader.result);
          const base64String = String(reader.result)
            .replace('data:', '')
            .replace(/^.+,/, '');
          this.fileDataStr2 = base64String;
        };
        reader.readAsDataURL(fileData);
      } 
      else {
        this.errFileExtension = false;
      }
    } 
    else {
      //alert('File size exceed');
      this.fileName2 = '';
      this.docIndentityFrom.get('docIndentityFile2').setValue('');
      this.docIdentiyFailedErr = 'File size exceeds 5mb'
      this.openModal();
    }
  }

  openModal() {
    this.display = "block";
  }

  onCloseHandled() {
    this.display = "none";
  }

  submitIdentityProof() {
    let Obj = {
      passport_front: this.fileDataStr1,
      passport_back: this.fileDataStr2,
      passport_front_name: this.fileName1,
      passport_back_name: this.fileName2,
      applicant_id: this.regObj.applicant_id,
      process_id: 18
    }

    this.customerDataService.postCustomerBankingDoc(Obj).subscribe((data) => {
      this.commonService.storeInLocalStorage('registerData', { 'banking_doc_id': data?.banking_doc_id })

      var is_feedback_show = 0;
      if (this.commonService.getUserFromLocalStorage()?.leadReviewStatus != undefined) {
        if (this.commonService.getUserFromLocalStorage()?.leadReviewStatus != 'customer_process') {
          is_feedback_show += 1;
        }
      }
      if (is_feedback_show != 0) {
        this.rt.navigate(["/feedback", "feedback-summary"]);
      }
      else {
        this.rt.navigate(['/individual-account', 'doc-upload1']);
      }  
    })
  }
}