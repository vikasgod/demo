import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DocIndentityProofComponent } from './doc-indentity-proof.component';

describe('DocIndentityProofComponent', () => {
  let component: DocIndentityProofComponent;
  let fixture: ComponentFixture<DocIndentityProofComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DocIndentityProofComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DocIndentityProofComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
