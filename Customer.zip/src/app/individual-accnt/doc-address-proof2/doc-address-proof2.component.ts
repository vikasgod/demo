import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CommonService } from 'src/app/services/common.service';
import { CustomerDataService } from 'src/app/services/customer-data.service';


@Component({
  selector: 'app-doc-address-proof2',
  templateUrl: './doc-address-proof2.component.html',
  styleUrls: ['./doc-address-proof2.component.css']
})
export class DocAddressProof2Component implements OnInit {


  regObj: any;

  isRelativeForm=false;

  constructor(private rt: Router, private commonService: CommonService, private customerDataService: CustomerDataService) {
   }


  documentName: string = '';
  documentIndentificationNumber: string = '';

  ngOnInit(): void {
    this.regObj = this.commonService.getUserFromLocalStorage();

    if ((this.regObj.isSubmitted != undefined && this.regObj.isSubmitted != 0)
      || ((this.regObj.leadReviewStatus != undefined && this.regObj.leadReviewStatus != "customer_process")
        && (this.regObj.leadReviewStatus != undefined && this.regObj.leadReviewStatus != "agent_review"))
    ) {

      this.rt.navigate(["/individual-account", "ending"]);
    }

    this.getDoc()

  }

  getDoc(){
    let Obj = {
      applicant_id: this.commonService.getUserFromLocalStorage()?.applicant_id,
      document: "address_proof"
    }

    this.customerDataService.fetchGetDoc(Obj).subscribe((value) => {
      this.documentName = value?.[0]?.address_proof_types_name;
      this.documentIndentificationNumber = value?.[0]?.document_identification_number;
      this.isRelativeForm = value?.[0]?.kyc_poi.is_family_indian_by_virtue || value?.[0]?.kyc_poi.is_spouse_held_indian_passport || value?.[0]?.kyc_poi.is_spouse_family_indian_by_virtue
    });
  }

  redirect() {
    if (this.isRelativeForm) {
      this.rt.navigate(['individual-account', 'doc-address-proof3'])

    } else {
      this.rt.navigate(['/individual-account', 'doc-upload1']);
    }


  }

}
