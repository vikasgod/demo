import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Nomination1Component } from './nomination1.component';

describe('Nomination1Component', () => {
  let component: Nomination1Component;
  let fixture: ComponentFixture<Nomination1Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ Nomination1Component ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(Nomination1Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
