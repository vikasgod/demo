import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { CommonService } from 'src/app/services/common.service';
import { CustomerDataService } from 'src/app/services/customer-data.service';

@Component({
  selector: 'app-nomination1',
  templateUrl: './nomination1.component.html',
  styleUrls: ['./nomination1.component.css']
})
export class Nomination1Component implements OnInit {
  nominationAFrom: any;
  regObj: any;
  nomination_id: any;
  isFacility: boolean = true;
  isDisplayUpdateBtn: boolean = false;

  constructor(private fb: FormBuilder, private commonService: CommonService, private customerDataService: CustomerDataService, private rt: Router) { }
  
  ngOnInit(): void {
    this.regObj = this.commonService.getUserFromLocalStorage();
    
    let Obj = {
      applicant_id: this.regObj.applicant_id,
      process_id: 25,
      nomination_id: this.nomination_id,
    }
    
    this.customerDataService.fetchNomination1(Obj).subscribe((value) => {
      if(value.data?.length>0){
        this.nomination_id = value.data[0].nomination_id
        this.isDisplayUpdateBtn = true;
        this.nominationAFrom = this.fb.group({
        nominationAFacility: [String(value?.data?.[0]?.is_opted), [Validators.required]]
      })
      }
    })

    this.nominationAFrom = this.fb.group({
      nominationAFacility: ['', [Validators.required]]
    })
  }

  get nominationAFacility() { return this.nominationAFrom.get("nominationAFacility") }

  onChangeNominationFacility(event: any) {
    this.isFacility = false;
    this.commonService.storeInLocalStorage('registerData', { 'isNominationSelected': event.target.value })
  }

  submitNominations() {
    if (this.nominationAFrom.valid) {
      let Obj = {
        applicant_id: this.regObj.applicant_id,
        process_id: 25,
        nomination_id: this.nomination_id,
        is_opted: Number(this.nominationAFrom.get("nominationAFacility").value)

      }
      this.commonService.storeInLocalStorage('registerData', { 'isNominationSelected': Number(this.nominationAFrom.get("nominationAFacility").value) })
      this.customerDataService.postNomination1(Obj).subscribe((data) => {
        this.commonService.storeInLocalStorage('registerData', { 'nomination_id': data?.nomination_id })
        var is_feedback_show = 0;
        if (this.commonService.getUserFromLocalStorage()?.leadReviewStatus != undefined) {
          if (this.commonService.getUserFromLocalStorage()?.leadReviewStatus != 'customer_process') {
            is_feedback_show += 1;
          }
          if (is_feedback_show != 0) {
            this.rt.navigate(["/feedback", "feedback-summary"]);
          } 
          if (this.nominationAFrom.controls['nominationAFacility'].value == 1) {
            this.rt.navigate(['/individual-account','nomination2']);
            console.log("1");
          }
          else if(this.nominationAFrom.controls['nominationAFacility'].value == 0) {
            this.rt.navigate(['/individual-account','doc-upload1']);
          }
        }
      })
    } 
  }
}