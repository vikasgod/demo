import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PersonalDtls2Component } from './personal-dtls2.component';

describe('PersonalDtls2Component', () => {
  let component: PersonalDtls2Component;
  let fixture: ComponentFixture<PersonalDtls2Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PersonalDtls2Component ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PersonalDtls2Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
