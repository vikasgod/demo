import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { CommonService } from 'src/app/services/common.service';
import { Router } from '@angular/router';
import { CustomerDataService } from 'src/app/services/customer-data.service';

@Component({
  selector: 'app-personal-dtls2',
  templateUrl: './personal-dtls2.component.html',
  styleUrls: ['./personal-dtls2.component.css']
})
export class PersonalDtls2Component implements OnInit {
  regObj: any;
  currentDate: string = '';
  countryData: any;
  prsnlDtlsForm: any;
  titleData: any;
  titleDataArr: any;
  dateNri: any;
  isDisplayMaidenName: boolean = false;
  isDisplayUpdateBtn: boolean = false;
  fatherTitle: boolean = false
  applicant:any
  account_type_id:any
  constructor(private fb: FormBuilder, private commonService: CommonService, private rt: Router, private customerDataService: CustomerDataService) { }

  ngOnInit(): void {
    this.regObj = this.commonService.getUserFromLocalStorage();

    this.currentDate = this.commonService.getCurrentDate();
    
    let Obj = {
      applicant_id: this.regObj.applicant_id,
      process_id: 5
    }

    this.customerDataService.fetchPersonalDtls2(Obj).subscribe((value) => {
      this.account_type_id = value.data[0]?.account_type_id
      if (value?.data?.length > 0) {
        this.prsnlDtlsForm.controls['prsnlDtlsMothersFirstName'].setValue(value.data[0].mother_first_name);
        this.prsnlDtlsForm.controls['prsnlDtlsMothersMiddleName'].setValue(value.data[0]?.mother_middle_name);
        this.prsnlDtlsForm.controls['prsnlDtlsMothersLastName'].setValue(value.data[0]?.mother_last_name);
        this.prsnlDtlsForm.controls['prsnlDtlsFathersMiddleName'].setValue(value.data[0]?.in_relation_middle_name);
        this.prsnlDtlsForm.controls['prsnlDtlsDtNri'].setValue(value.data[0].date_of_becoming_nri);
        this.isDisplayUpdateBtn = true
        this.dateNri = new Date(value?.data?.[0]?.date_of_becoming_nri);
        this.prsnlDtlsForm = this.fb.group({
          prsnlDtlsMaidenTitle: [value?.data?.[0]?.maiden_title],
          prsnlDtlsMaidenFirstName: [value?.data?.[0]?.maiden_first_name],
          prsnlDtlsMaidenMiddleName: [value?.data?.[0]?.maiden_middle_name],
          prsnlDtlsMaidenLastName: [value?.data?.[0]?.maiden_last_name],
          prsnlDtlsMothersFirstName: [value?.data?.[0]?.mother_first_name, Validators.required],
          prsnlDtlsMothersMiddleName: [value?.data?.[0]?.mother_middle_name],
          prsnlDtlsMothersLastName: [value?.data?.[0]?.mother_last_name],
          prsnlDtlsFathersNameValid: [value?.data?.[0]?.in_relation_type, Validators.required],
          prsnlDtlsFathersTitle: [value?.data?.[0]?.in_relation_title, Validators.required],
          prsnlDtlsFathersFirstName: [value?.data?.[0]?.in_relation_first_name, Validators.required],
          prsnlDtlsFathersMiddleName: [value?.data?.[0]?.in_relation_middle_name],
          prsnlDtlsFathersLastName: [value?.data?.[0]?.in_relation_last_name],
          prsnlDtlsCountry: [value?.data?.[0]?.nationality, Validators.required],
          prsnlDtlsDtNri: [value?.data?.[0]?.date_of_becoming_nri, Validators.required],
        })
      }
    })


    setTimeout(() => {
      this.maidanCondition()
    }, 500);

    this.prsnlDtlsForm = this.fb.group({
      prsnlDtlsMaidenTitle: [null],
      prsnlDtlsMaidenFirstName: [''],
      prsnlDtlsMaidenMiddleName: [''],
      prsnlDtlsMaidenLastName: [''],
      prsnlDtlsMothersFirstName: ['', Validators.required],
      prsnlDtlsMothersMiddleName: [''],
      prsnlDtlsMothersLastName: [''],
      prsnlDtlsFathersNameValid: ['father', Validators.required],
      prsnlDtlsFathersTitle: ['', Validators.required],
      prsnlDtlsFathersFirstName: ['', Validators.required],
      prsnlDtlsFathersMiddleName: [''],
      prsnlDtlsFathersLastName: [''],
      prsnlDtlsCountry: ['', Validators.required],
      prsnlDtlsDtNri: ['', Validators.required],
    })

    this.currentDate = this.commonService.getCurrentDate();
    this.customerDataService.getCountry().subscribe((data) => {
      this.countryData = data;
    })

    this.customerDataService.getTitle().subscribe((data) => {
      this.titleData = data
    })
    this.customerDataService.fetchPersonalDtls1(Obj).subscribe((value) => {
      if(value.data?.length){
        if (value.data[0]?.applicant_title === 'mrs' && value.data[0]?.gender === 'female') {
          this.isDisplayMaidenName = true;
          this.prsnlDtlsForm.controls['prsnlDtlsMaidenTitle'].clearValidators();
          this.prsnlDtlsForm.controls['prsnlDtlsMaidenFirstName'].clearValidators();
          this.prsnlDtlsForm.controls['prsnlDtlsMaidenMiddleName'].clearValidators();
          this.prsnlDtlsForm.controls['prsnlDtlsMaidenLastName'].clearValidators();
          this.prsnlDtlsForm.controls['prsnlDtlsMaidenTitle'].updateValueAndValidity();
          this.prsnlDtlsForm.controls['prsnlDtlsMaidenFirstName'].updateValueAndValidity();
          this.prsnlDtlsForm.controls['prsnlDtlsMaidenMiddleName'].updateValueAndValidity();
          this.prsnlDtlsForm.controls['prsnlDtlsMaidenLastName'].updateValueAndValidity();
        }
        else {
          this.isDisplayMaidenName = false;
          this.prsnlDtlsForm.controls['prsnlDtlsMaidenTitle'].clearValidators();
          this.prsnlDtlsForm.controls['prsnlDtlsMaidenFirstName'].clearValidators();
          this.prsnlDtlsForm.controls['prsnlDtlsMaidenMiddleName'].clearValidators();
          this.prsnlDtlsForm.controls['prsnlDtlsMaidenLastName'].clearValidators();
          this.prsnlDtlsForm.controls['prsnlDtlsMaidenTitle'].updateValueAndValidity();
          this.prsnlDtlsForm.controls['prsnlDtlsMaidenFirstName'].updateValueAndValidity();
          this.prsnlDtlsForm.controls['prsnlDtlsMaidenMiddleName'].updateValueAndValidity();
          this.prsnlDtlsForm.controls['prsnlDtlsMaidenLastName'].updateValueAndValidity();
        }

      }
     
      
    })
    

    this.prsnlDtlsForm.controls['prsnlDtlsMothersLastName'].setValue(this.regObj?.last_name);
    this.prsnlDtlsForm.controls['prsnlDtlsFathersLastName'].setValue(this.regObj?.last_name);
    this.prsnlDtlsForm.controls['prsnlDtlsFathersFirstName'].setValue(this.regObj?.middle_name);
    this.prsnlDtlsForm.controls['prsnlDtlsCountry'].setValue(this.regObj?.country_id);
    this.prsnlDtlsForm.controls['prsnlDtlsFathersTitle'].setValue('mr')
  }

  maidanCondition(){
    let Obj = {
      applicant_id: this.regObj.applicant_id,
      process_id: 4,
      account_type_id: this.account_type_id,
    }

    this.customerDataService.fetchPersonalDtls1(Obj).subscribe((value) => {
      if (value?.data?.length > 0) {
        if (value.data[0].applicant_title_name === 'Mrs') {
          this.isDisplayMaidenName = true;
          this.prsnlDtlsForm.controls['prsnlDtlsMaidenTitle'].clearValidators();
          this.prsnlDtlsForm.controls['prsnlDtlsMaidenFirstName'].clearValidators();
          this.prsnlDtlsForm.controls['prsnlDtlsMaidenMiddleName'].clearValidators();
          this.prsnlDtlsForm.controls['prsnlDtlsMaidenLastName'].clearValidators();
          this.prsnlDtlsForm.controls['prsnlDtlsMaidenTitle'].updateValueAndValidity();
          this.prsnlDtlsForm.controls['prsnlDtlsMaidenFirstName'].updateValueAndValidity();
          this.prsnlDtlsForm.controls['prsnlDtlsMaidenMiddleName'].updateValueAndValidity();
          this.prsnlDtlsForm.controls['prsnlDtlsMaidenLastName'].updateValueAndValidity();
        }
        else {
          this.isDisplayMaidenName = false;
          this.prsnlDtlsForm.controls['prsnlDtlsMaidenTitle'].clearValidators();
          this.prsnlDtlsForm.controls['prsnlDtlsMaidenFirstName'].clearValidators();
          this.prsnlDtlsForm.controls['prsnlDtlsMaidenMiddleName'].clearValidators();
          this.prsnlDtlsForm.controls['prsnlDtlsMaidenLastName'].clearValidators();
          this.prsnlDtlsForm.controls['prsnlDtlsMaidenTitle'].updateValueAndValidity();
          this.prsnlDtlsForm.controls['prsnlDtlsMaidenFirstName'].updateValueAndValidity();
          this.prsnlDtlsForm.controls['prsnlDtlsMaidenMiddleName'].updateValueAndValidity();
          this.prsnlDtlsForm.controls['prsnlDtlsMaidenLastName'].updateValueAndValidity();
        }
      }
    })
  }

  get prsnlDtlsMaidenTitle() { return this.prsnlDtlsForm.get("prsnlDtlsMaidenTitle") }
  get prsnlDtlsMaidenFirstName() { return this.prsnlDtlsForm.get("prsnlDtlsMaidenFirstName") }
  get prsnlDtlsMaidenMiddleName() { return this.prsnlDtlsForm.get("prsnlDtlsMaidenMiddleName") }
  get prsnlDtlsMaidenLastName() { return this.prsnlDtlsForm.get("prsnlDtlsMaidenLastName") }
  get prsnlDtlsMothersFirstName() { return this.prsnlDtlsForm.get("prsnlDtlsMothersFirstName") }
  get prsnlDtlsMothersMiddleName() { return this.prsnlDtlsForm.get("prsnlDtlsMothersMiddleName") }
  get prsnlDtlsMothersLastName() { return this.prsnlDtlsForm.get("prsnlDtlsMothersLastName") }
  get prsnlDtlsFathersNameValid() { return this.prsnlDtlsForm.get("prsnlDtlsFathersNameValid") }
  get prsnlDtlsFathersTitle() { return this.prsnlDtlsForm.get("prsnlDtlsFathersTitle") }
  get prsnlDtlsFathersFirstName() { return this.prsnlDtlsForm.get("prsnlDtlsFathersFirstName") }
  get prsnlDtlsFathersMiddleName() { return this.prsnlDtlsForm.get("prsnlDtlsFathersMiddleName") }
  get prsnlDtlsFathersLastName() { return this.prsnlDtlsForm.get("prsnlDtlsFathersLastName") }
  get prsnlDtlsCountry() { return this.prsnlDtlsForm.get("prsnlDtlsCountry") }
  get prsnlDtlsDtNri() { return this.prsnlDtlsForm.get("prsnlDtlsDtNri") }
  keypressLetters(event: any) {
    return this.commonService.enterOnlyAlphabetsNoSpace(event)
  }

  check(){
    console.log("check");
  }

  submitPersnalDtls() {
    if (this.prsnlDtlsForm.valid) {
      this.prsnlDtlsForm.get("prsnlDtlsMaidenTitle").value
      this.prsnlDtlsForm.get("prsnlDtlsMaidenFirstName").value
      this.prsnlDtlsForm.get("prsnlDtlsMaidenMiddleName").value
      this.prsnlDtlsForm.get("prsnlDtlsMaidenLastName").value
      this.prsnlDtlsForm.get("prsnlDtlsMothersFirstName").value
      this.prsnlDtlsForm.get("prsnlDtlsMothersMiddleName").value
      this.prsnlDtlsForm.get("prsnlDtlsMothersLastName").value
      this.prsnlDtlsForm.get("prsnlDtlsFathersNameValid").value
      this.prsnlDtlsForm.get("prsnlDtlsFathersFirstName").value
      this.prsnlDtlsForm.get("prsnlDtlsFathersMiddleName").value
      this.prsnlDtlsForm.get("prsnlDtlsFathersLastName").value
      this.prsnlDtlsForm.get("prsnlDtlsCountry").value
      this.prsnlDtlsForm.get("prsnlDtlsDtNri").value
      let Obj = {
        applicant_personal_id: String(this.regObj.applicant_id),
        user_id: Number(this.regObj.user_id),
        maiden_title: this.prsnlDtlsForm.get("prsnlDtlsMaidenTitle").value,
        maiden_first_name: this.prsnlDtlsForm.get("prsnlDtlsMaidenFirstName").value,
        maiden_middle_name: this.prsnlDtlsForm.get("prsnlDtlsMaidenMiddleName").value,
        maiden_last_name: this.prsnlDtlsForm.get("prsnlDtlsMaidenLastName").value,
        mother_first_name: this.prsnlDtlsForm.get("prsnlDtlsMothersFirstName").value,
        mother_middle_name: this.prsnlDtlsForm.get("prsnlDtlsMothersMiddleName").value,
        mother_last_name: this.prsnlDtlsForm.get("prsnlDtlsMothersLastName").value,
        in_relation_type: this.prsnlDtlsForm.get("prsnlDtlsFathersNameValid").value,
        in_relation_title: this.prsnlDtlsForm.get("prsnlDtlsFathersTitle").value,
        in_relation_first_name: this.prsnlDtlsForm.get("prsnlDtlsFathersFirstName").value,
        in_relation_middle_name: this.prsnlDtlsForm.get("prsnlDtlsFathersMiddleName").value,
        in_relation_last_name: this.prsnlDtlsForm.get("prsnlDtlsFathersLastName").value,
        nationality: this.prsnlDtlsForm.get("prsnlDtlsCountry").value,
        date_of_becoming_nri: this.customerDataService.formatDob(this.prsnlDtlsForm.get("prsnlDtlsDtNri").value),
        is_consent_declared: 0,
        isSubmitted: this?.regObj?.isSubmitted,
        process_id: 5,
        applicant_id: this.regObj.applicant_id,
      }

      this.customerDataService.postPersonalDtls2(Obj).subscribe((data) => {
        if (this.commonService.getUserFromLocalStorage()?.leadReviewStatus == 'customer_process') {
          // this.rt.navigate(["/feedback", "feedback-summary"]);
          this.rt.navigate(["/individual-account", "fatca"]);
        }
        else if (this.commonService.getUserFromLocalStorage()?.leadReviewStatus == 'agent_review') {
          this.rt.navigate(["/feedback", "feedback-summary"]);
        }
      })


      // if (this.commonService.getUserFromLocalStorage()?.leadStatus !== undefined || this.commonService.getUserFromLocalStorage()?.leadStatus !== 'undefined' || this.commonService.getUserFromLocalStorage()?.leadStatus !== null) {
      //   this.rt.navigate(["/individual-account", "fatca"]);
      // } 
      // else { 
      //   this.rt.navigate(["/feedback", "feedback-summary"]);
      // }
    }
  }

  titleShow(val: any) {
    if (val.target.value == 'father') {
      this.fatherTitle = false;
    }
    else {
      this.fatherTitle = true;
      this.prsnlDtlsForm.controls['prsnlDtlsFathersFirstName'].setValue(null);
    }
  }
}