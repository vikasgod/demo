import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { CommonService } from 'src/app/services/common.service';
import { CustomerDataService } from 'src/app/services/customer-data.service';
import { Router } from '@angular/router';


@Component({
  selector: 'app-doc-address-proof1',
  templateUrl: './doc-address-proof1.component.html',
  styleUrls: ['./doc-address-proof1.component.css']
})
export class DocAddressProof1Component implements OnInit {

  requiredFileType: string = 'image/png,image/jpeg'
  docAddressAFrom: any;
  iSfile1Change: boolean = false;
  errFileExtension: boolean = true;
  imgSrc: any = '';
  currentDate: any;
  fileName: string = '';
  fileDataStr1: any = '';
  regObj: any;
  countryData: any;
  addressProofImg: string = '';
  display: string = "none";
  docAddressProofFailedErr: string = '';
  issueDate: string = '';
  isUpdate: boolean = false
  applicant:any
  banking_doc_id:any
  minDate:any = new Date()
  expiryDate:any

  constructor(private fb: FormBuilder, private commonService: CommonService, private customerDataService: CustomerDataService, private rt: Router) {
    this.getDoc()
  }

  ngOnInit(): void {
    this.regObj = this.commonService.getUserFromLocalStorage();

    let req = {
      user_id: this.regObj?.user_id
    }

    this.customerDataService.fetchAllID(req).subscribe((value) => {
      if (value?.data?.length > 0) {
        this.applicant = value.data[0].applicant_personal_id
        this.banking_doc_id = value.data[0].banking_doc_id
      }
    })

    setTimeout(() => {
      this.getDoc()
    }, 500);

    this.docAddressAFrom = this.fb.group({
      docAddressAPlcIssue: ['', [Validators.required]],
      docAddressAIssAuth: ['', [Validators.required]],
      docAddressADocIndfnNo: ['', [Validators.required]],
      docAddressAIssueDate: [null],
      docAddressAExpiryDate: [null],
      docAddressAFile1: ['', [Validators.required]],
    })

    this.currentDate = this.commonService.getCurrentDate();
    this.customerDataService.getCountry().subscribe((value) => {
      this.countryData = value
    })
  }

  getDoc() {
    let Obj = {
      applicant_id: this.commonService.getUserFromLocalStorage()?.applicant_id,
      document: "address_proof"
    }

    this.customerDataService.fetchGetDoc(Obj).subscribe((value) => {
      if (value?.length > 0) {
        this.isUpdate = true
        this.docAddressAFrom = this.fb.group({
          docAddressAPlcIssue: [value[0]?.place_of_issue, [Validators.required]],
          docAddressAIssAuth: [value[0]?.issuing_authority, [Validators.required]],
          docAddressADocIndfnNo: [value[0]?.document_identification_number, [Validators.required]],
          docAddressAIssueDate: [value[0]?.issue_date?.length ? value[0]?.issue_date :null],
          docAddressAExpiryDate: [value[0]?.expiry_date?.length ? value[0]?.expiry_date:null],
          docAddressAFile1: [value[0]?.file_path, [Validators.required]],
        })

        this.fileName = value[0]?.address_proof;
        this.addressProofImg = value[0]?.file_path;
        this.customerDataService.getBase64ImageFromUrl(value[0]?.file_path).then(result => {
          this.fileDataStr1 = result
          this.fileName = value[0].file_path.split('/').pop()
        })
          .catch(err => console.error(err));
      }
    })
  }

  get docAddressAPlcIssue() { return this.docAddressAFrom.get("docAddressAPlcIssue") }
  get docAddressAIssAuth() { return this.docAddressAFrom.get("docAddressAIssAuth") }
  get docAddressADocIndfnNo() { return this.docAddressAFrom.get("docAddressADocIndfnNo") }
  get docAddressAIssueDate() { return this.docAddressAFrom.get("docAddressAIssueDate") }
  get docAddressAExpiryDate() { return this.docAddressAFrom.get("docAddressAExpiryDate") }
  get docAddressAFile1() { return this.docAddressAFrom.get("docAddressAFile1") }
  
  keypressLetters(event: any) {
    return this.commonService.enterOnlyAlphabetsSpaceNBcktck(event);
  }

  keypressNumbers(event: any) {
    return this.commonService.enterOnlyNumber(event);
  }

  keypressAplhaNumberic(event: any) {
    return this.commonService.allowAlphaNumericSpace(event)
  }

  //Working 1  
  onFilesSelected1(event: any) {
    this.iSfile1Change = true;
    let fileData = event.target.files[0];
    if (fileData != undefined) {
      this.fileName = fileData.name;
      this.docAddressAFrom.get('docAddressAFile1').setValue(this.fileName);
      let arr = String(fileData.name).split('.');
      let len = arr.length;


      if (fileData.size <= 5000000) {
        if (arr[len - 1] === "png" || arr[len - 1] === "jpeg" || arr[len - 1] === "jpg") {
          const reader = new FileReader();
          reader.onloadend = () => {
            // Use a regex to remove data url part
            this.addressProofImg = String(reader.result);
            const base64String = String(reader.result)
              .replace('data:', '')
              .replace(/^.+,/, '');

            this.fileDataStr1 = base64String;
          };
          reader.readAsDataURL(fileData);
        } 
        else {
          this.errFileExtension = false;
        }
      } 
      else {
        this.fileName = '';
        this.docAddressAFrom.get('docAddressAFile1').setValue('');
        this.docAddressProofFailedErr = 'File size exceeds 5mb'
        this.openModal();
      }
    }
    else {
      return
    }

  }

  submitAddressProof() {
    if (this.docAddressAFrom.valid) {
      this.commonService.storeInLocalStorage('registerData', { addressProofdocumentNumber: this.docAddressAFrom.get("docAddressADocIndfnNo").value })
      let Obj = {
        applicant_id: this.regObj.applicant_id,
        process_id: 19,
        banking_doc_id: Number(this.banking_doc_id),
        place_of_issue: Number(this.docAddressAFrom.get("docAddressAPlcIssue").value),
        issuing_authority: this.docAddressAFrom.get("docAddressAIssAuth").value,
        document_identification_number: this.docAddressAFrom.get("docAddressADocIndfnNo").value,
        issue_date: this.customerDataService.formatDob(this.docAddressAFrom.get("docAddressAIssueDate").value).length ?this.customerDataService.formatDob(this.docAddressAFrom.get("docAddressAIssueDate").value) :null ,
        expiry_date: this.customerDataService.formatDob(this.docAddressAFrom.get("docAddressAExpiryDate").value).length ?this.customerDataService.formatDob(this.docAddressAFrom.get("docAddressAExpiryDate").value) :null ,
        address_proof_type: this.commonService.getUserFromLocalStorage()?.docAddressType,  //docAddressType
        address_proof: this.fileDataStr1,
        file: this.fileDataStr1,
        doc_address_plc_address_doc: this.fileDataStr1,
        doc_address_plc_addrss_filename: this.fileName
      }

      this.customerDataService.postCustomerAddressDoc(Obj).subscribe((data) => {
        var is_feedback_show = 0;
        if (this.commonService.getUserFromLocalStorage()?.leadReviewStatus != undefined) {
          if (this.commonService.getUserFromLocalStorage()?.leadReviewStatus != 'customer_process') {
            is_feedback_show += 1;
          }
        }
        if (is_feedback_show != 0) {
          this.rt.navigate(["/feedback", "feedback-summary"]);
          return
        }
        if(this.regObj.docAddressType == 6 || this.regObj.docAddressType == 7 || this.regObj.docAddressType == 8 || this.regObj.docAddressType == 9 || this.regObj.docAddressType == 10 || this.regObj.docAddressType == 11 || this.regObj.docAddressType == 12 || this.regObj.docAddressType == 13){
          this.rt.navigate(["/individual-account", "doc-address-proof2"]);
        }

        else {
          this.rt.navigate(['/individual-account', 'doc-upload1']);
        }  
      })
    }
  }

  openModal() {
    this.display = "block";
  }

  onCloseHandled() {
    this.display = "none";
  }

  setDataTime(val: any) {
    if (val == 'docAddressAIssueDate') {
        const issueDate = new Date(this.docAddressAFrom.controls['docAddressAIssueDate'].value)
        const miniExpiryDate = new Date(issueDate);
        miniExpiryDate.setDate(miniExpiryDate.getDate() + 30);
        this.minDate = miniExpiryDate;
      }
    }
}