import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DocAddressProof1Component } from './doc-address-proof1.component';

describe('DocAddressProof1Component', () => {
  let component: DocAddressProof1Component;
  let fixture: ComponentFixture<DocAddressProof1Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DocAddressProof1Component ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DocAddressProof1Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
