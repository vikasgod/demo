import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Nomination2Component } from './nomination2.component';

describe('Nomination2Component', () => {
  let component: Nomination2Component;
  let fixture: ComponentFixture<Nomination2Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ Nomination2Component ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(Nomination2Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
