import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DocOtherProofComponent } from './doc-other-proof.component';

describe('DocOtherProofComponent', () => {
  let component: DocOtherProofComponent;
  let fixture: ComponentFixture<DocOtherProofComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DocOtherProofComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DocOtherProofComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
