import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { CommonService } from 'src/app/services/common.service';
import { CustomerDataService } from 'src/app/services/customer-data.service';
import { Router } from '@angular/router';


@Component({
  selector: 'app-doc-other-proof',
  templateUrl: './doc-other-proof.component.html',
  styleUrls: ['./doc-other-proof.component.css']
})
export class DocOtherProofComponent implements OnInit {
  fileName: string = '';
  requiredFileType: string = 'image/png,image/jpeg';
  otherDocForm: any;
  regObj: any;
  iSfile1Change: boolean = true;
  fileName1: string = '';
  imgSrc1: string = '';
  fileDataStr1: any = '';
  errFileExtension: boolean = false;

  display: string = "none";
  docOtherFailedErr: string = '';
  isUpdate: boolean = false

  constructor(private fb: FormBuilder, private commonService: CommonService, private customerDataService: CustomerDataService, private rt: Router) {
    this.getDoc()
  }

  ngOnInit(): void {
    this.regObj = this.commonService.getUserFromLocalStorage();

    // if ((this.regObj.isSubmitted != undefined && this.regObj.isSubmitted != 0)
    //   || ((this.regObj.leadReviewStatus != undefined && this.regObj.leadReviewStatus != "customer_process")
    //     && (this.regObj.leadReviewStatus != undefined && this.regObj.leadReviewStatus != "agent_review"))
    // ) {
    //   this.rt.navigate(["/individual-account", "ending"]);
    // }

    this.otherDocForm = this.fb.group({
      otherDocComment: ['', Validators.required],
      otherDocFile: ['', Validators.required]
    })

    this.getDoc()
  }

  getDoc() {
    let Obj = {
      applicant_id: this.commonService.getUserFromLocalStorage()?.applicant_id,
      document: "other"
    }

    this.customerDataService.fetchGetDoc(Obj).subscribe((value) => {
      console.log("/////////////", value);
      if (value != undefined) {
        this.isUpdate = true
      }
      this.imgSrc1 = value[0]?.file_path;
      let name = value[0].file_path.split("/").pop()
      this.fileName1 = name
      this.customerDataService.getBase64ImageFromUrl(value[0].file_path).then(result => {
        this.fileDataStr1 = result
      })
        .catch(err => console.error(err));
      this.otherDocForm = this.fb.group({

        otherDocComment: [value[0].other_document_comment, [Validators.required]],
        otherDocFile: [this.imgSrc1, [Validators.required]]
      })
    })
  }

  get otherDocComment() { return this.otherDocForm.get('otherDocComment') }
  get otherDocFile() { return this.otherDocForm.get('otherDocFile') }

  //Working 1  
  onFilesSelected1(event: any) {

    this.iSfile1Change = true;

    let fileData = event.target.files[0];
    if (fileData != undefined) {
      this.fileName1 = fileData.name;
      this.otherDocForm.get('otherDocFile').setValue(this.fileName1);
      let arr = String(fileData.name).split('.');
      let len = arr.length;


      if (fileData.size <= 5000000) {
        if (arr[len - 1] === "png" || arr[len - 1] === "jpeg" || arr[len - 1] === "pdf" || arr[len - 1] === "jpg") {
          console.log("This is file selected", btoa(String(fileData)))
          const reader = new FileReader();
          reader.onloadend = () => {
            this.imgSrc1 = String(reader.result)
            // Use a regex to remove data url part
            const base64String = String(reader.result)
              .replace('data:', '')
              .replace(/^.+,/, '');
            this.fileDataStr1 = base64String;
            //console.log("THis is file1 base64 string",base64String);
          };
          reader.readAsDataURL(fileData);
        }
        else {
          this.errFileExtension = false;
          console.log("Extension is not valid")
          //return
        }
      }
      else {
        //alert('File size exceed');
        this.fileName = '';
        this.otherDocForm.get('otherDocFile').setValue('');
        this.docOtherFailedErr = 'File size exceeds 5mb'
        this.openModal();
      }
    }
    else {
      return
    }
    //return
  }

  openModal() {
    this.display = "block";
  }

  onCloseHandled() {
    this.display = "none";
  }

  submitOtherDocuments() {
    this.regObj = this.commonService.getUserFromLocalStorage();

    // if(this.regObj.isSubmitted!=undefined || this.regObj.leadReviewStatus != "customer_process")
    // {
    //   this.rt.navigate(["/individual-account","ending"]);
    // }

    if (this.otherDocForm.valid) {
      console.log("This is valid form", this.otherDocForm.value);
      let Obj = {
        applicant_id: this.regObj.applicant_id,
        process_id: 72,
        other_document_comment: this.otherDocForm.get('otherDocComment').value,
        file: this.fileDataStr1
      }

      this.customerDataService.postCustomerOtherDoc(Obj).subscribe((value) => {
        // this.rt.navigate(['/individual-account', 'doc-upload1']);
        var is_feedback_show = 0;
        if (this.commonService.getUserFromLocalStorage()?.leadReviewStatus != undefined) {
          if (this.commonService.getUserFromLocalStorage()?.leadReviewStatus != 'customer_process') {
            is_feedback_show += 1;
          }
        }
        if (is_feedback_show != 0) {
          this.rt.navigate(["/feedback", "feedback-summary"]);
        }
        else {
          this.rt.navigate(['/individual-account', 'doc-upload1']);
        }
      })
    }
  }
}