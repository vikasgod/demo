import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { CommonService } from 'src/app/services/common.service';
import { CustomerDataService } from 'src/app/services/customer-data.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-nomination3',
  templateUrl: './nomination3.component.html',
  styleUrls: ['./nomination3.component.css']
})
export class Nomination3Component implements OnInit {

  nominationCFrom: any;
  regObj: any;
  titleArrData: any;
  isDisplayUpdateBtn: boolean = false;
  nomination_id:any
  constructor(private fb: FormBuilder, private commonService: CommonService, private customerDataService: CustomerDataService, private rt: Router) { }

  ngOnInit(): void {
    this.regObj = this.commonService.getUserFromLocalStorage();
   
    
    let Obj = {
      applicant_id: this.regObj.applicant_id,
      process_id: 26,
      nomination_id: this.nomination_id
    }
    this.customerDataService.fetchNomination3(Obj).subscribe((value) => {
      if (value?.data?.length > 0) {
        this.nomination_id = value.data[0].nomination_id
        this.nominationCFrom = this.fb.group({
          nominationAgeYrs: [this.regObj?.nomineeAgeYears === undefined || this.regObj?.nomineeAgeYears === 'undefined' ? '' : this.regObj?.nomineeAgeYears, [Validators.required]],
          nominationAgeMonths: [this.regObj?.nomineeAgeYears === undefined || this.regObj?.nomineeAgeMonths === 'undefined' ? '' : this.regObj?.nomineeAgeMonths, [Validators.required]],
          nominationCtitle: [value.data?.[0]?.gaurdian_title, [Validators.required]],
          nominationCFirstName: [value.data?.[0]?.gaurdian_first_name, [Validators.required]],
          nominationCMiddleName: [value.data?.[0]?.gaurdian_middle_name, [Validators.required]],
          nominationCLastName: [value.data?.[0]?.gaurdian_last_name, [Validators.required]],
        })
      }
    })

    this.nominationCFrom = this.fb.group({
      nominationAgeYrs: ['', [Validators.required]],
      nominationAgeMonths: ['', [Validators.required]],
      nominationCtitle: [null, [Validators.required]],
      nominationCFirstName: ['', [Validators.required, Validators.minLength(2)]],
      nominationCMiddleName: ['', [Validators.required, Validators.minLength(2)]],
      nominationCLastName: ['', [Validators.required, Validators.minLength(2)]],
    })
    this.customerDataService.getTitle().subscribe((data) => {      
      this.titleArrData = data
    })
  }

  get nominationAgeYrs() { return this.nominationCFrom.get("nominationAgeYrs") }
  get nominationAgeMonths() { return this.nominationCFrom.get("nominationAgeMonths") }
  get nominationCtitle() { return this.nominationCFrom.get("nominationCtitle") }
  get nominationCFirstName() { return this.nominationCFrom.get("nominationCFirstName") }
  get nominationCMiddleName() { return this.nominationCFrom.get("nominationCMiddleName") }
  get nominationCLastName() { return this.nominationCFrom.get("nominationCLastName") }

  keypressAlphabets(event: any) {
    return this.commonService.enterOnlyAlphabetsNoSpace(event);
  }

  keypressNumbers(event: any) {
    return this.commonService.enterOnlyNumber(event);
  }

  submitNominationForm() {
    if (this.nominationCFrom.valid) {
      let Obj = {
        applicant_id: Number(this.regObj.applicant_id),
        nomination_id: Number(this.nomination_id),
        process_id: 27,
        nominee_age_in_month: Number(this.nominationCFrom.get("nominationAgeMonths").value),
        nominee_age_in_year: Number(this.nominationCFrom.get("nominationAgeYrs").value),
        gaurdian_title: this.nominationCFrom.get("nominationCtitle").value,
        gaurdian_first_name: this.nominationCFrom.get("nominationCFirstName").value,
        gaurdian_middle_name: this.nominationCFrom.get("nominationCMiddleName").value,
        gaurdian_last_name: this.nominationCFrom.get("nominationCLastName").value
      }

      this.customerDataService.postNomination3(Obj).subscribe((data) => {
        if (this.commonService.getUserFromLocalStorage()?.leadReviewStatus === 'customer_process') {
          this.rt.navigate(['/individual-account', 'declaration1']);
        } 
        else {
          this.rt.navigate(["/feedback", "feedback-summary"]);
        }
      })
    }
  }
}