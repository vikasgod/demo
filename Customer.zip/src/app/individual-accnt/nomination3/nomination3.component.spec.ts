import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Nomination3Component } from './nomination3.component';

describe('Nomination3Component', () => {
  let component: Nomination3Component;
  let fixture: ComponentFixture<Nomination3Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ Nomination3Component ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(Nomination3Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
