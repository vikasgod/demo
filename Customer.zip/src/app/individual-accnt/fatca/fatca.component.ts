import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { CommonService } from 'src/app/services/common.service';
import { Router } from '@angular/router';
import { CustomerDataService } from 'src/app/services/customer-data.service';

@Component({
  selector: 'app-fatca',
  templateUrl: './fatca.component.html',
  styleUrls: ['./fatca.component.css']
})
export class FatcaComponent implements OnInit {
  regObj: any;
  fatcaForm: any;
  tinDisplay: Boolean = false;
  countryData: any;
  fatcaID: number = 0;
  isDisplayUpdateBtn: boolean = false;
  constructor(private fb: FormBuilder, private commonService: CommonService, private rt: Router, private customerDataService: CustomerDataService) { }

  ngOnInit(): void {
    this.regObj = this.commonService.getUserFromLocalStorage();

    let Obj = {
      applicant_id: this.regObj.applicant_id,
      process_id: 6
    }

    this.customerDataService.fetchFatca(Obj).subscribe((value) => {
      if (value?.data?.length > 0) {
        this.isDisplayUpdateBtn = true
        this.fatcaForm = this.fb.group({
          fatcatxjursdtnOutIndRdBtn: [String(value?.data?.[0]?.is_residence_for_tax), [Validators.required]],
          fatcatxTin: [value?.data?.[0]?.tax_identification_number],
          fatcatxTinDesc: [value?.data?.[0]?.tin_description],
          fatcatxCntrytxJursdtn: [value?.data?.[0]?.tin_country_id == 0 ? "" : value?.data?.[0]?.tin_country_id],
          fatcaTinIssCntry: [value?.data?.[0]?.tin_issue_county_id == 0 ? "" : value?.data?.[0]?.tin_issue_county_id],
          fatcaCtyOfBrth: [value?.data?.[0]?.city_of_birth],
          fatcaCntryOfBrth: [value?.data?.[0]?.birth_county_id == 0 ? "" : value?.data?.[0]?.birth_county_id],
        })
        this.fatcaID = value?.data?.[0]?.fatca_id

        this.displayTin();
      }
    })

    this.fatcaForm = this.fb.group({
      fatcatxjursdtnOutIndRdBtn: [null, [Validators.required]],
      fatcatxTin: [null, Validators.maxLength(9)],
      fatcatxTinDesc: [null],
      fatcatxCntrytxJursdtn: [null],
      fatcaTinIssCntry: [null],
      fatcaCtyOfBrth: [null,[Validators.pattern(/^([a-zA-Z])$/)]],
      fatcaCntryOfBrth: [null],
    })

    this.customerDataService.getCountry().subscribe((data) => {
      this.countryData = data
    })
  }

  get fatcatxjursdtnOutIndRdBtn() { return this.fatcaForm.get("fatcatxjursdtnOutIndRdBtn") }
  get fatcatxTin() { return this.fatcaForm.get("fatcatxTin") }
  get fatcatxTinDesc() { return this.fatcaForm.get("fatcatxTinDesc") }
  get fatcatxCntrytxJursdtn() { return this.fatcaForm.get("fatcatxCntrytxJursdtn") }
  get fatcaTinIssCntry() { return this.fatcaForm.get("fatcaTinIssCntry") }
  get fatcaCtyOfBrth() { return this.fatcaForm.get("fatcaCtyOfBrth") }
  get fatcaCntryOfBrth() { return this.fatcaForm.get("fatcaCntryOfBrth") }

  keypressLetters(event: any) {
    return this.commonService.enterOnlyAlphabetsSpaceNBcktck(event);
  }

  keypressAlphabetNoSpce(event: any) {
    return this.commonService.enterOnlyAlphabetsSpaceNBcktck(event)
  }

  keypressNumbers(event: any) {
    return this.commonService.enterOnlyNumber(event);
  }

  keypressAlphaNumbers(event: any) {
    return this.commonService.allowAlphaNumericSpace(event);
  }
  
  displayTin() {
    if (this.fatcatxjursdtnOutIndRdBtn.value === "1") {
      this.tinDisplay = true;
      //Add Tiny Validators
      this.fatcaForm.controls['fatcatxTin'].setValidators([Validators.required])
      this.fatcaForm.controls['fatcatxTinDesc'].setValidators([Validators.required])
      this.fatcaForm.controls['fatcatxCntrytxJursdtn'].setValidators([Validators.required])
      this.fatcaForm.controls['fatcaTinIssCntry'].setValidators([Validators.required])
      this.fatcaForm.controls['fatcaCtyOfBrth'].setValidators([Validators.required])
      this.fatcaForm.controls['fatcaCntryOfBrth'].setValidators([Validators.required])
    }

    if (this.fatcatxjursdtnOutIndRdBtn.value === "0") {
      //Hide Tiny Value
      this.tinDisplay = false;
      //Remove Tiny Validators
      this.fatcaForm.controls['fatcatxTin'].clearValidators();
      this.fatcaForm.controls['fatcatxTinDesc'].clearValidators();
      this.fatcaForm.controls['fatcatxCntrytxJursdtn'].clearValidators();
      this.fatcaForm.controls['fatcaTinIssCntry'].clearValidators();
      this.fatcaForm.controls['fatcaCtyOfBrth'].clearValidators();
      this.fatcaForm.controls['fatcaCntryOfBrth'].clearValidators();
    }
    //Update Controls according to condition
    this.fatcaForm.controls['fatcatxTin'].updateValueAndValidity()
    this.fatcaForm.controls['fatcatxTinDesc'].updateValueAndValidity()
    this.fatcaForm.controls['fatcatxCntrytxJursdtn'].updateValueAndValidity()
    this.fatcaForm.controls['fatcaTinIssCntry'].updateValueAndValidity()
    this.fatcaForm.controls['fatcaCtyOfBrth'].updateValueAndValidity()
    this.fatcaForm.controls['fatcaCntryOfBrth'].updateValueAndValidity()
    localStorage.setItem('fatca',JSON.stringify(this.tinDisplay))
  }
  submitFatcaForm() {
    if (this.fatcaForm.valid) {
      this.fatcaForm.get("fatcatxjursdtnOutIndRdBtn").value
      this.fatcaForm.get("fatcatxTin").value
      this.fatcaForm.get("fatcatxTinDesc").value
      this.fatcaForm.get("fatcatxCntrytxJursdtn").value
      this.fatcaForm.get("fatcaTinIssCntry").value
      this.fatcaForm.get("fatcaCtyOfBrth").value
      this.fatcaForm.get("fatcaCntryOfBrth").value
      let Obj = {
        fatca_id: String(this.fatcaID),
        applicant_id: this.regObj.applicant_id,
        is_residence_for_tax: Number(this.fatcaForm.get("fatcatxjursdtnOutIndRdBtn").value),
        tax_identification_number: this.fatcaForm.get("fatcatxTin").value,
        tin_description: this.fatcaForm.get("fatcatxTinDesc").value,
        tin_country_id: this.fatcaForm.get("fatcaTinIssCntry").value,

        tin_issue_county_id: this.fatcaForm.get("fatcatxCntrytxJursdtn").value,
        city_of_birth: this.fatcaForm.get("fatcaCtyOfBrth").value,
        birth_county_id: this.fatcaForm.get("fatcaCntryOfBrth").value,
        process_id: 6
      }
      this.customerDataService.postFatca(Obj).subscribe((data) => {
        var is_feedback_show = 0;
        if (this.commonService.getUserFromLocalStorage()?.leadReviewStatus != undefined) {
          if (this.commonService.getUserFromLocalStorage()?.leadReviewStatus != 'customer_process') {
            is_feedback_show += 1;
          }
        }
        if (is_feedback_show != 0) {
          this.rt.navigate(["/feedback", "feedback-summary"]);
        } else {
          this.rt.navigate(["/individual-account", "kyc-dtls1"]);
        }
      })
    }
  }
}