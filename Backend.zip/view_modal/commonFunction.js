var moment = require('moment');
module.exports = {
    checkRequiredFields: function (request, requiredFields) {
        var err = { 'status': 1, 'msg': {}, };

        for (var i = 0; i < requiredFields.length; i++) {
            if (typeof request[requiredFields[i]] == 'undefined' || request[requiredFields[i]] == '' || request[requiredFields[i]].trim() == '') {
                err['status'] = 0;
                err['msg'][requiredFields[i]] = 'This field is required';
            }
        }

        return err;
    },
    currentTimestamp: function(){
		return moment().format('YYYY-MM-DD HH:mm:ss')
	},
    
}