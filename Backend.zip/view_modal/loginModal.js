const bcrypt = require("bcryptjs");
const Convert = require("xml2js");
const https = require("https");
const mysqlconn = require("../db/mysqlconn");
const util = require("util");
const commonFunction = require("./commonFunction");
const { default: axios } = require("axios");
const { v4: uuidv4 } = require("uuid");
const mysqlquery = util.promisify(mysqlconn.query).bind(mysqlconn);

module.exports.loginUser = async function (req, res) {
  var formError = {};
  var formData = {
    username: "",
    password: "",
  };
  try {
    if (req.method === "POST") {
      formData["username"] = req.body.username;
      formData["password"] = req.body.password;
      var requiredFields = ["username", "password"];
      var err = commonFunction.checkRequiredFields(req.body, requiredFields);
      // if(err.status == 1){
      //     let sql = `SELECT user_id , role_id,password from tbl_users WHERE email_address = "${req.body.username}"`
      //     var userData = await mysqlquery(sql)
      //     if(userData.length === 1){
      //         if(userData[0].role_id === 1){
      //             var bResult = await bcrypt.compare(req.body.password, userData[0].password)
      //             if(bResult){
      //                 req.session.isAuthenticated = true;
      //                 req.session.email = req.body.username;
      //                 return res.redirect('/')
      //             }else{
      //                 formError.password = "Invalid password"
      //             }
      //         }else{
      //             formError.username ="Invalid username"
      //         }
      //     }else{
      //         formError.username = "Invalid creadential";
      //     }
      // }else {
      //     formError = err.msg;
      // }

      if (err.status == 1) {
        let sql = `SELECT user_id,role_id,email_address from tbl_users WHERE username = '${req.body.username}'`;
        var userData = await mysqlquery(sql);
        if (userData.length === 1) {
          if (userData[0]?.role_id === 1) {
            try {
              get_token = async () => {
                let payload = {
                  getToken: {
                    RequestHeader: {
                      MessageKey: {
                        RequestUUID: uuidv4(),
                        ServiceRequestId: "GETTOKEN",
                        ServiceRequestVersion: "1.0",
                        ChannelId: "",
                      },
                      RequestMessageInfo: {
                        BankId: "",
                        TimeZone: "",
                        MessageDateTime: "",
                      },
                      Security: {
                        Token: {
                          Certificate: "",
                          MessageHashKey: "",
                          MessageIndex: "",
                          PasswordToken: {
                            UserId: "",
                            Password: "",
                          },
                        },
                      },
                      DeviceInfo: {
                        DeviceFamily: "",
                        DeviceFormat: "",
                        DeviceType: "",
                        DeviceName: "",
                        DeviceIMEI: "",
                        DeviceID: "",
                        DeviceVersion: "",
                        AppVersion: "",
                        DeviceOS: "",
                        DeviceIp: process.env.RBL_DEVICE_IP,
                      },
                      AdditionalInfo: {
                        JourneyId: "",
                        LanguageId: "",
                        SVersion: "",
                        SessionId: "",
                      },
                    },
                    RequestBody: {
                      getTokenRequestBody: {
                        clientId: process.env.RBL_CLIENT_ID,
                        clientSecret: process.env.RBL_SECRET_ID,
                      },
                    },
                  },
                };
                const agent = new https.Agent({
                  rejectUnauthorized: false,
                });
                const axiosConfig = {
                  httpsAgent: agent,
                };
                const response = await axios.post(
                  `${process.env.RBL_SENTINAL_URL}/api/v1/OAUTH/get-token`,
                  payload,
                  axiosConfig
                );
                let responseData = response.data;
                if (responseData) {
                  return responseData.generateTokenResponse.ResponseBody
                    .generateTokenResponseBody.access_token;
                }
              };
              let data = {
                LdapDtls: {
                  Request: {
                    UserId: req.body.username,
                    ChlId: "IIB",
                    DeviceFamily: "",
                    DeviceFormat: "",
                    OperationId: "123",
                    LoginPwd: Buffer.from(req.body.password).toString("base64"),
                    ClientAPIVer: "1.0",
                    SessionId: "1999769OKDDP",
                    TransSeq: "01",
                  },
                },
              };
              var builder = new Convert.Builder();
              var xml = builder.buildObject(data);
              const agent = new https.Agent({
                rejectUnauthorized: false,
              });
              let header = {
                "x-rbl-auth":
                  `Bearer ${await get_token()}`,
                "x-api-key": process.env.RBL_API_KEY,
              };
              const axiosConfig = {
                httpsAgent: agent,
                headers: header,
              };
              const response = await axios.post(
                `${process.env.RBL_URL}/rbl/esb/ldapdetails`,
                xml,
                axiosConfig
              );
              let user = await response.data;
              let resultData;
              Convert.parseString(user, async (err, result) => {
                if (err) {
                  console.error(err);
                  return;
                }
                resultData = result.LdapDtls;
              });
              if (resultData.Response[0]?.Status[0] === "SUCCESS") {
                req.session.isAuthenticated = true;
                req.session.email = resultData.Response[0]?.Email[0].replace(
                  /\s+/g,
                  ""
                );
                return res.redirect("/");
              } else {
                formError.password = "Invalid password";
              }
            } catch (error) {
              formError.temp = "Service Unavailable";
            }
          } else {
            formError.username = "Invalid user can not access this !";
          }
        } else {
          formError.username = "Invalid creadential";
        }
      } else {
        formError = err.msg;
      }
    }
    var pageData = {
      formData: formData,
      formError: formError,
    };
    res.render("login", pageData);
  } catch (error) {
    console.error(error);
  }
};
