const mysqlconn = require("../db/mysqlconn");
const util = require("util");
const mysqlquery = util.promisify(mysqlconn.query).bind(mysqlconn);
const comFun = require("./commonFunction");

module.exports.addUser = async function (req, res) {
  var formError = {};

  var formData = {
    first_name: "",
    last_name: "",
    username: "",
    role_id: "",
    reporting_manager: "",
  };
  try {
    let sqlDATA =
      "SELECT user_id,role_id,email_address,first_name FROM tbl_users where role_id = 2";
    var userName = await mysqlquery(sqlDATA);
    if (req.method === "POST") {
      formData["first_name"] = req.body.first_name;
      formData["last_name"] = req.body.last_name;
      formData["username"] = req.body.username;
      formData["role_id"] = Number(req.body.role_id);
      formData["reporting_manager"] = req?.body?.reporting_manager;
      // var requiredFields = ['first_name', 'last_name', 'username', 'email', 'password', 'confirm_password', 'role_id'];
      var requiredFields = ["first_name", "last_name", "username", "role_id"];
      var err = comFun.checkRequiredFields(req.body, requiredFields);
      if (err.status == 1) {
        var sql = `SELECT username from tbl_users Where username = '${req.body.username}'`;

        var data = await mysqlquery(sql);

        if (data.length == 0) {
          var userdata = {
            first_name: req.body.first_name,
            last_name: req.body.last_name,
            reporting_manager: req.body.reporting_manager
              ? req.body.reporting_manager
              : "",
            created_by: 1,
            username: req.body.username,
            role_id: req.body.role_id,
            created_on: comFun.currentTimestamp(),
          };
          let sql1 = `INSERT INTO tbl_users SET ? `;
          let useData = await mysqlquery(sql1, userdata);
          if (useData.affectedRows == 1) {
            return res.redirect("/");
          } else {
            formError.name = "Something went wrong";
          }
        } else {
          formError.email = "Email is already exists";
        }
      } else {
        formError = err.msg;
      }
    }
    var sql2 =
      'SELECT role_id, role_name FROM tbl_roles where role_name = "manager" OR role_name = "agent"';
    var userRole = await mysqlquery(sql2);
    var pageData = {
      userRole: userRole,
      formData: formData,
      formError: formError,
      isRepoting: userName,
    };
    res.render("add-user", pageData);
  } catch (e) {
    console.log(e);
    res.redirect("/add-user");
  }
};

module.exports.getUser = async function (req, res) {
  const page = parseInt(req.query.page) || 1;

  try {
    let sql = `SELECT user_id,role_id FROM tbl_users WHERE email_address = '${req.session.email}'`;
    var userData = await mysqlquery(sql);
    if (userData[0].role_id == 1) {
      if (req.method == "GET") {
        var sqlUser =
          "SELECT * FROM tbl_users where role_id = 2 or role_id = 3";
        var allUsers = await mysqlquery(sqlUser);
        // let matchMediaCoIn = allUsers.filter(item => item.email_address.endsWith('@rblbank.com'));
        let users = allUsers.filter(
          (user) => user.email_address !== `${req.session.email}`
        );
        var sqlRole = "SELECT role_id, role_name FROM tbl_roles";
        var userRole = await mysqlquery(sqlRole);
        let newArr = users.map((obj) => {
          let newObj = { ...obj }; // Creating a shallow copy of the original object
          let role = userRole.find((role) => role.role_id === obj.role_id); // Finding the role object
          if (role) {
            newObj.role_name = role.role_name; // Adding role_name property to the new object
            delete newObj.role_id; // Removing the role_id property
          }
          return newObj;
        });
        const pageSize = 10;
        const pageCount = Math.ceil(newArr.length / pageSize);
        const startIndex = (page - 1) * pageSize;
        const endIndex = Math.ceil(startIndex + pageSize, newArr.length);
        const currentPageData = newArr.slice(startIndex, endIndex);
    
        var pageData = {
          allUsers: currentPageData,
          currentPage: page,
          totalPages: pageCount,
          title: "RBL IT Admin",
        };
        res.render("index", pageData);
      }
    }
  } catch (error) {
    console.error(error);
  }
};

module.exports.getAgent = async function (req, res) {
  const page = parseInt(req.query.page) || 1;

  try {
    let sql = `SELECT user_id,role_id FROM tbl_users WHERE email_address = '${req.session.email}'`;
    var userData = await mysqlquery(sql);
    if (userData[0].role_id == 1) {
      if (req.method == "GET") {
        var sqlUser =
          "SELECT * FROM tbl_users where role_id = 3";
        var allUsers = await mysqlquery(sqlUser);
        let users = allUsers.filter(
          (user) => user.email_address !== `${req.session.email}`
        );
        var sqlRole = "SELECT role_id, role_name FROM tbl_roles";
        var userRole = await mysqlquery(sqlRole);
        let newArr = users.map((obj) => {
          let newObj = { ...obj }; // Creating a shallow copy of the original object
          let role = userRole.find((role) => role.role_id === obj.role_id); // Finding the role object
          if (role) {
            newObj.role_name = role.role_name; // Adding role_name property to the new object
            delete newObj.role_id; // Removing the role_id property
          }
          return newObj;
        });
        const pageSize = 10;
        const pageCount = Math.ceil(newArr.length / pageSize);
        const startIndex = (page - 1) * pageSize;
        const endIndex = Math.ceil(startIndex + pageSize, newArr.length);
        const currentPageData = newArr.slice(startIndex, endIndex);
        var pageData = {
          allUsers: currentPageData,
          currentPage: page,
          totalPages: pageCount,
          title: "RBL Agent",
        };
        res.render("index", pageData);
      }
    }
  } catch (error) {
    console.error(error);
  }
};

module.exports.getManager = async function (req, res) {
  const page = parseInt(req.query.page) || 1;

  try {
    let sql = `SELECT user_id,role_id FROM tbl_users WHERE email_address = '${req.session.email}'`;
    var userData = await mysqlquery(sql);
    if (userData[0].role_id == 1) {
      if (req.method == "GET") {
        var sqlUser =
          "SELECT * FROM tbl_users where role_id = 2";
        var allUsers = await mysqlquery(sqlUser);
        let users = allUsers.filter(
          (user) => user.email_address !== `${req.session.email}`
        );
        var sqlRole = "SELECT role_id, role_name FROM tbl_roles";
        var userRole = await mysqlquery(sqlRole);
        let newArr = users.map((obj) => {
          let newObj = { ...obj }; // Creating a shallow copy of the original object
          let role = userRole.find((role) => role.role_id === obj.role_id); // Finding the role object
          if (role) {
            newObj.role_name = role.role_name; // Adding role_name property to the new object
            delete newObj.role_id; // Removing the role_id property
          }
          return newObj;
        });
        const pageSize = 10;
        const pageCount = Math.ceil(newArr.length / pageSize);
        const startIndex = (page - 1) * pageSize;
        const endIndex = Math.ceil(startIndex + pageSize, newArr.length);
        const currentPageData = newArr.slice(startIndex, endIndex);
        var pageData = {
          allUsers: currentPageData,
          currentPage: page,
          totalPages: pageCount,
          title: "RBL Manager",
        };
        res.render("index", pageData);
      }
    }
  } catch (error) {
    console.error(error);
  }
};

module.exports.updateUser = async function (req, res) {
  var sql = `SELECT * FROM tbl_users WHERE user_id = '${req.params.id}'`;
  var singleUser = await mysqlquery(sql);
  if (singleUser.length == 1) {
    let sqlDATA =
      "SELECT user_id,role_id,first_name FROM tbl_users where role_id = 2";
    var userName = await mysqlquery(sqlDATA);
    var mainData = userName.filter((item) => item.user_id != req.params.id);
    let newManager = userName.find(
      (data) => data.user_id == singleUser[0]["reporting_manager"]
    );
    var formError = {};
    var formData = {
      user_id: singleUser[0]["user_id"],
      first_name: singleUser[0]["first_name"],
      last_name: singleUser[0]["last_name"],
      username: singleUser[0]["username"],
      role_id: singleUser[0]["role_id"],
      reporting_manager: newManager?.first_name,
    };
    if (req.method == "POST") {
      formData["role_id"] = Number(req.body.role_id);
      formData["reporting_manager"] = req?.body?.reporting_manager;

      var requiredFields = ["role_id"];
      var err = comFun.checkRequiredFields(req.body, requiredFields);

      if (err.status == 1) {
        let newArr = userName.find(
          (data) => data.first_name === req.body.reporting_manager
        );
        var sql = `UPDATE tbl_users SET `;
        sql += "role_id = '" + req.body.role_id + "', ";
        sql +=
          "reporting_manager = '" +
          (req.body.role_id == 3 ? newArr?.user_id : " ") +
          "', ";
        sql += "updated_on = '" + comFun.currentTimestamp() + "'";
        sql += "WHERE user_id = '" + req.params.id + "' ";
        var updateData = await mysqlquery(sql);
        if (updateData.affectedRows == 1) {
          return res.redirect("/");
        } else {
          formError.email = "Something went wrong";
        }
      } else {
        formError = err.msg;
      }
    }
    var sql2 =
      "SELECT role_id, role_name FROM tbl_roles where role_id = 2 or role_id = 3";
    var userRole = await mysqlquery(sql2);
    var pageData = {
      formData: formData,
      formError: formError,
      userRole: userRole,
      isRepoting: mainData,
    };
    res.render("edit-user", pageData);
  } else {
    res.redirect("");
  }
};

module.exports.deleteUser = async function (req, res) {
  try {
    let sql = `Delete from tbl_users where user_id = '${req.params.id}'`;
    let data = await mysqlquery(sql);
    let sqlData = `UPDATE tbl_agent_leads AS Al
            LEFT JOIN tbl_leads AS l ON l.lead_id = Al.lead_id 
            SET l.lead_status = 'lead'
            WHERE Al.agent_id = ${req.params.id} AND l.lead_status = 'agent_process'`;
    await mysqlquery(sqlData);
    if (data.affectedRows == 1) {
      return res.redirect("/");
    }
  } catch (error) {
    console.error(error);
  }
};
