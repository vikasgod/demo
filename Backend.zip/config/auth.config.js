module.exports = {
    secret: "bezkoder-secret-key",
    jwtAccessExpiration: "12h",
    jwtRefreshExpiration: "20h", 
  };