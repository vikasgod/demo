module.exports = app => {
    const express = require("express");
    var router = express.Router();
    var RBLITTeamTemplate = require('../controller/src/api/RblNri/Modules/RBLITTeam');
    var userauthorization = require('../middleware/Jwtverify');
    router.get("/countRBlagent", userauthorization, RBLITTeamTemplate.countRBlagent);
    router.get("/countRblitteamuser", userauthorization, RBLITTeamTemplate.countRblitteamuser);
    router.get("/allRblagent", userauthorization, RBLITTeamTemplate.allRblagent);
    router.get("/allRblitteamuser", userauthorization, RBLITTeamTemplate.allRblitteamuser);
    // router.get("/all_newleads", RBLITTeamTemplate.all_newleads);
    // router.get("/all_processleads", RBLITTeamTemplate.all_processleads);
    // router.get("/all_approvedleads", RBLITTeamTemplate.all_approvedleads);
    // router.get("/all_rejectedleads", RBLITTeamTemplate.all_rejectedleads);
    // router.get("/newleadspdf", RBLITTeamTemplate.newleadspdf);
    // router.post("/allRblagents_perpage", RBLITTeamTemplate.allRblagents_perpage);
    router.get("/agent_no_of_buttons", RBLITTeamTemplate.agent_no_of_buttons);
    router.post("/agent_next_page", RBLITTeamTemplate.agent_next_page);
    router.post("/agent_previous_page", RBLITTeamTemplate.agent_previous_page);
    router.post("/allRblteamuser_perpage", RBLITTeamTemplate.allRblteamuser_perpage);
    router.get("/rblitteam_no_of_buttons", RBLITTeamTemplate.rblitteam_no_of_buttons);
    router.post("/rbluser_next_page", RBLITTeamTemplate.rbluser_next_page);
    router.post("/rbluser_previous_page", RBLITTeamTemplate.rbluser_previous_page);
    app.use("/rblitteam", router);
}