module.exports = (app) => {
  const express = require("express");
  const router = express.Router();
  var AdminModule = require("../controller/src/api/RblNri/Modules/Admin");

  router.post("/add-agent", (req, res) => {
    AdminModule.add_agents(req, res);
  });

  router.post("/delete-agent", (req, res) => {
    AdminModule.delete_agents(req, res);
  });

  router.post("/edit-agent", (req, res) => {
    AdminModule.edit_agent(req, res);
  });

  router.get("/agents-count", (req, res) => {
    AdminModule.counts_agents(req, res);
  });

  router.get("/agents-list/:role_id", (req, res) => {
    AdminModule.get_list(req, res);
  });
  router.get("/reporting-manager", (req, res) => {
    AdminModule.get_reporting_manager(req, res);
  });

  // router.post('/search-agent/:role_id', (req, res) => {
  //   AdminModule.search_agent(req, res)
  // });

  app.use("/admin", router);
};
