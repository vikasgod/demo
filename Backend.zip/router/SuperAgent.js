module.exports = app => {
    const express = require("express");
    var router = express.Router();
    var SuperAgentModule = require('../controller/src/api/RblNri/Modules/SuperAgent');
    var userauthorization = require('../middleware/Jwtverify');
  
    router.get('/agent-list/:agent_id', (req, res) => {
        SuperAgentModule.get_agent_list(req, res)
    });
    
    router.post('/get-lead-count', (req, res) => {
        SuperAgentModule.get_lead_count(req, res);
    });
  
    router.get('/lead-list', (req, res) => {
        SuperAgentModule.lead_list(req, res)
    });
  
    router.post('/assigen-leads', (req, res) => {
        SuperAgentModule.assigen_leads(req, res)
    });
  
    router.get('/assigen-leads-list', (req, res) => {
        SuperAgentModule.assigen_lead_list(req, res)
    });

    //pradeep 
    router.get('/leads-list/:lead_type',(req, res)=>{
        SuperAgentModule.lead_list_new(req, res)
    });
    router.get('/leads-count/:lead_type',(req, res)=>{
        SuperAgentModule.lead_count_new(req, res)
    });
    router.post('/reassign-leads',(req,res)=>{
        SuperAgentModule.reassign_leads(req, res)
    })
    //pradeep
    
    app.use("/superagent", router);
  }