module.exports = app => {
    const express = require("express");
    var router = express.Router();
    var NotificationModule = require('../controller/src/api/RblNri/Modules/Notification');

    router.get("/getnotification",(req,res)=>{
        NotificationModule.getnotification(req,res)
    });
    router.post("/deleteNotification",(req,res)=>{
        NotificationModule.deleteNotification(req,res)
    });
    router.post("/makeReadNotification",(req,res)=>{
        NotificationModule.makeReadNotification(req,res)
    });
    app.use("/notification", router);
}