module.exports = app => {
  const express = require("express");
  var router = express.Router();
  var AgentModule = require('../controller/src/api/RblNri/Modules/Agent');
  var userauthorization = require('../middleware/Jwtverify');

  router.post('/accept_agent_leads', (req, res) => {
    AgentModule.accept_agent_leads(req, res)
  });
  router.post('/incomplete_agent_leads', (req, res) => {
    AgentModule.incomplete_agent_leads(req, res)
  });

  router.post('/get-lead-count', (req, res) => {
    AgentModule.get_lead_count(req, res);
  });

  // router.post('/lead-list', (req, res) => {
  //   AgentModule.lead_list(req, res)
  // });

  router.post('/process-lead-count', (req, res) => {
    AgentModule.get_process_lead_count(req, res);
  });
  router.post('/get-process-status', (req, res) => {
    AgentModule.get_process_status(req, res);
  });

  router.post('/review-lead-count', (req, res) => {
    AgentModule.get_reviewed_lead_count(req, res)
  });

  router.post('/lead-process-review-list', (req, res) => {
    AgentModule.lead_process_review_list(req, res)
  });

  // router.post('/review-lead-list', (req, res) => {
  //   AgentModule.review_lead_list(req, res)
  // });

  router.post('/user-account-data', (req, res) => {
    AgentModule.user_account_data(req, res)
  });

  router.post('/add-comments', (req, res) => {
    AgentModule.add_comments(req, res)
  });

  router.post('/agent-lead-comment', (req, res) => {
    AgentModule.get_agent_lead_comments(req, res)
  });
  router.post('/forms-approved', (req, res) => {
    AgentModule.forms_approved(req, res)
  });

  router.post('/delete-comments', (req, res) => {
    AgentModule.delete_comments(req, res)
  });

  //pradeep 
  router.post('/approve-lead',(req, res)=>{
    AgentModule.approve_lead(req, res)
  });

  router.post('/reject-lead',(req, res)=>{
    AgentModule.reject_lead(req, res)
  });

  router.post('/review-lead',(req, res)=>{
    AgentModule.review_lead(req, res)
  });

  router.post('/leads-list',(req, res)=>{
    AgentModule.lead_list_new(req, res)
  });

  router.post('/leads-count/:lead_type',(req, res)=>{
    AgentModule.lead_count_new(req, res)
  });

  router.post('/search-user', (req, res) => {
    AgentModule.search_user(req, res)
  });

  router.post('/get-applicant-data', (req, res) => {
    AgentModule.get_applicant_data(req, res)
  });

  router.post('/approved-or-reviewed', (req, res) => {
    AgentModule.approved_or_reviewed(req, res)
  })

  // router.post('/get-lead-flag', (req, res) => {
  //   AgentModule.lead_flag(req, res)
  // });

  //pradeep

  
  // router.get("/newleads_no_of_buttons",AgentTemplate.getall_newleads_no_of_buttons);
  // router.get("/newleads_next_page",AgentTemplate.getall_newleads_next_page);
  // router.get("/newleads_previous_page",AgentTemplate.newleads_previous_page);
  // router.get("/count_newlead",userauthorization,AgentTemplate.count_newlead);
  // router.put("/leadacceptcustomer",AgentTemplate.leadacceptcustomer);
  // router.get("/count_processlead",userauthorization,AgentTemplate.count_processlead);
  // router.get("/getall_processlead",AgentTemplate.getall_processlead);
  // router.get("/process_perpage",AgentTemplate.getall_process_perpage);
  // router.get("/process_no_of_buttons",AgentTemplate.getall_process_no_of_buttons);
  // router.get("/process_next_page",AgentTemplate.getall_process_next_page);
  // router.get("/process_previous_page",AgentTemplate.process_previous_page);
  // router.get("/count_leadswith_query",userauthorization,AgentTemplate.count_leadswith_query);
  // router.get("/querylead_perpage",AgentTemplate.getall_querylead_perpage);
  // router.get("/query_no_of_buttons",AgentTemplate.getall_query_no_of_buttons);
  // router.get("/querylead_next_page",AgentTemplate.getall_querylead_next_page);
  // router.get("/querylead_previous_page",AgentTemplate.querylead_previous_page);
  // router.get("/approvedlead_perpage",AgentTemplate.getall_approvedlead_perpage);
  // router.get("/approvedleads_no_of_buttons",AgentTemplate.getall_approvedleads_no_of_buttons);
  // router.get("/approvedlead_next_page",AgentTemplate.getall_approvedlead_next_page);
  // router.get("/approvedlead_previous_page",AgentTemplate.approvedlead_previous_page);
  // router.get("/rejectedlead_perpage",AgentTemplate.getall_rejectedlead_perpage);
  // router.get("/rejectedleads_no_of_buttons",AgentTemplate.getall_rejectedleads_no_of_buttons);
  // router.get("/rejectedlead_next_page",AgentTemplate.getall_rejectedlead_next_page);
  // router.get("/rejectedlead_previous_page",AgentTemplate.rejectedlead_previous_page);
  // router.get("/getall_approvedleads",userauthorization,AgentTemplate.getall_approvedleads);
  // router.get("/getall_rejectedleads",userauthorization,AgentTemplate.getall_rejectedleads);
  // router.post("/add-comments",AgentTemplate.add_comments);
  // router.get("/get_form_comments",userauthorization,AgentTemplate.get_form_comments);
  // router.post("/send_reminder",AgentTemplate.send_reminder);
  app.use("/agent", router);
}