module.exports = app => {
  require('dotenv').config()
  const express = require("express");
  var router = express.Router();
  var CustomerModule = require('../controller/src/api/RblNri/Modules/Customer');
  const { applicant_validation_form_1, applicant_validation_form_2, factas_validation, kyc_details_validation, submit_kyc_poi_dec_validation, contact_details_validation,
    submit_address_details_validation, customer_profilers_validation, banking_facilities_validation, nominations_details_validation_forms_1, nominations_details_validation_forms_2 } = require('../middleware/validation');

  const {
    minor_personal_detail_one_validation,
    minor_personal_detail_two_validation,
    minor_gaurdian_detail_validation
  } = require("../middleware/minorformvalidation");

  var userauthorization = require('../middleware/Jwtverify');
  const multer = require('multer');
  const path = require("path");
  var fs = require("fs");
  var storage = multer.diskStorage({
    destination: function (req, file, callback) {
      let buff = new Buffer(file, 'base64');
      let DIR = `./public/uploads/${req.body.applicant_id}`;
      fs.writeFileSync(DIR, buff);
      if (!fs.existsSync(DIR)) {
        fs.mkdirSync(DIR);
      }
      callback(null, DIR)
      console.log
    },
    filename: function (req, file, callback) {
      var datetimestamp = Date.now();
      callback(null, file.originalname + '-' + datetimestamp + '.' + file.originalname.split('.')[file.originalname.split('.').length - 1])
    }
  });

  var upload = multer({ //multer settings
    storage: storage,
    fileFilter: function (req, file, callback) {
      var ext = path.extname(file.originalname);
      if (ext !== '.pdf' && ext !== '.jpg' && ext !== '.jpeg' && ext !== '.png') {
        return callback(new Error('Invalid file extension'))
      }
      callback(null, true)
    }
  })


  var DcUpload = upload.fields([{ name: 'passport_front', maxCount: 1 }, { name: 'passport_back', maxCount: 1 }])

  var DocUpload = upload.fields([{ name: 'file', maxCount: 1 }])
  //forms api start//
  router.get('/getall_titles', (req, res) => {
    CustomerModule.getall_titles(req, res)
  });

  router.get('/account_type', (req, res) => {
    CustomerModule.getall_account_type(req, res)
  });

  router.get('/card_variant', (req, res) => {
    CustomerModule.getall_card_variant(req, res)
  });

  router.get('/address_type', (req, res) => {
    CustomerModule.getall_address_type(req, res)
  });

  router.get('/religion_category', (req, res) => {
    CustomerModule.getall_religion_category(req, res)
  });

  router.get('/employment_type', (req, res) => {
    CustomerModule.getall_employment_type(req, res)
  });

  router.get('/occupation_type', (req, res) => {
    CustomerModule.getall_occupation_type(req, res)
  });

  router.get('/gross_annual_income', (req, res) => {
    CustomerModule.getall_gross_annual_income(req, res)
  });

  router.get('/industry_type', (req, res) => {
    CustomerModule.getall_industry_type(req, res)
  });

  router.get('/proof_address_type', (req, res) => {
    CustomerModule.getall_proof_address_type(req, res)
  });

  router.get('/religion', (req, res) => {
    CustomerModule.getall_religion(req, res)
  });

  router.get('/visa', (req, res) => {
    CustomerModule.getall_visa_type(req, res)
  });

  router.get('/countries', (req, res) => {
    CustomerModule.getall_countries(req, res)
  });

  router.get('/customer-forms', (req, res) => {
    CustomerModule.getall_customer_forms(req, res)
  });


  //forms api end //
  router.post('/submit_country_account', (req, res) => {
    CustomerModule.submit_country_account(req, res)
  });

  router.post('/submit_account_varient', (req, res) => {
    CustomerModule.submit_account_varient(req, res)
  });

  router.post('/submit_factas', (req, res) => {
    CustomerModule.submit_factas(req, res)
  });

  router.post('/submit_kyc_details_1', (req, res) => {
    CustomerModule.submit_kyc_details_1(req, res)
  });

  router.post('/update_kyc_details_1', (req, res) => {
    CustomerModule.update_kyc_details_1(req, res)
  });

  router.post('/submit_kyc_details_2', (req, res) => {
    CustomerModule.submit_kyc_details_2(req, res)
  });

  router.post('/submit_kyc_poi_dec', (req, res) => {
    CustomerModule.submit_kyc_poi_dec(req, res)
  });

  router.post('/submit_contact_details', (req, res) => {
    CustomerModule.submit_contact_details(req, res)
  });

  router.post('/submit_address_details_1', (req, res) => {
    CustomerModule.submit_address_details_1(req, res)
  });

  router.post('/update_address_details_1', (req, res) => {
    CustomerModule.update_address_details_1(req, res)
  });

  router.post('/submit_address_details_2', (req, res) => {
    CustomerModule.submit_address_details_2(req, res)
  });

  router.post('/get_account_variant', (req, res) => {
    CustomerModule.getAccountVariant(req, res)
  })

  router.post('/submit_customer_profilers', (req, res) => {
    CustomerModule.submit_customer_profilers(req, res)
  });

  router.post('/submit_banking_facilities_1', (req, res) => {
    CustomerModule.submit_banking_facilities_1(req, res)
  });

  router.post('/update_banking_facilities_1', (req, res) => {
    CustomerModule.update_banking_facilities_1(req, res)
  });

  router.post('/submit_banking_facilities_2', (req, res) => {
    CustomerModule.submit_banking_facilities_2(req, res)
  });

  // router.post('/submit_banking_doc', DcUpload, (req, res) => {
  //   CustomerModule.submit_banking_doc(req, res)
  // });

  router.post('/submit_passport_doc', DcUpload, (req, res) => {
    CustomerModule.submit_passport_doc(req, res)
  });

  router.post('/submit_pio_doc', DcUpload, (req, res) => {
    CustomerModule.submit_pio_doc(req, res)
  });

  router.post('/submit_applicant_relative_data', (req, res) => {
    CustomerModule.submit_applicant_relative_data(req, res)
  });


  router.get('/address_proof_types', (req, res) => {
    CustomerModule.address_proof_types(req, res)
  });

  router.post('/submit_address_proof_doc', DocUpload, (req, res) => {
    CustomerModule.submit_address_proof_doc(req, res)
  });

  router.post('/submit_form_sixty_doc', DocUpload, (req, res) => {
    CustomerModule.submit_form_sixty_doc(req, res)
  });

  router.post('/submit_visa_doc', DocUpload, (req, res) => {
    CustomerModule.submit_visa_doc(req, res)
  });

  router.post('/submit_oci_doc', DocUpload, (req, res) => {
    CustomerModule.submit_oci_doc(req, res)
  });

  router.post('/submit_other_doc', DocUpload, (req, res) => {
    CustomerModule.submit_other_doc(req, res)
  });


  router.post('/get_document', (req, res) => {
    CustomerModule.get_document(req, res)
  });


  router.post('/submit_nominations_details_1', (req, res) => {
    CustomerModule.submit_nominations_details_1(req, res)
  });

  router.post('/submit_nominations_details_2', (req, res) => {
    CustomerModule.submit_nominations_details_2(req, res)
  });

  router.post('/submit_nominations_details_3', (req, res) => {
    CustomerModule.submit_nominations_details_3(req, res)
  });

  router.post('/submit_personal_details_1', (req, res) => {
    CustomerModule.submit_applicant_personal_details_1(req, res)
  });

  router.post('/submit_personal_details_2', (req, res) => {
    CustomerModule.submit_applicant_personal_details_2(req, res)
  });

  router.post('/personal_details_form_1', (req, res) => {
    CustomerModule.get_customer_personal_details_form_1(req, res)
  });

  router.post('/personal_details_form_2', (req, res) => {
    CustomerModule.get_customer_personal_details_form_2(req, res)
  });

  router.post('/customer_fatca_form', (req, res) => {
    CustomerModule.get_customer_fatca_form_3(req, res)
  });

  router.post('/customer_kyc_deatil', (req, res) => {
    CustomerModule.get_customer_kyc_deatil(req, res)
  });

  router.post('/customer_kyc_deatil_temp_visa_dec', (req, res) => {
    CustomerModule.get_customer_kyc_deatil_temp_visa_dec(req, res)
  });

  router.post('/customer_kyc_pio_dec', (req, res) => {
    CustomerModule.get_customer_kyc_pio_dec(req, res)
  });

  router.post('/customer_contact_details', (req, res) => {
    CustomerModule.get_customer_contact_details(req, res)
  });

  router.post('/customer_overseas_current_address', (req, res) => {
    CustomerModule.get_customer_overseas_current_address(req, res)
  });

  router.post('/customer_permanent_Jurisdiction_address', (req, res) => {
    CustomerModule.get_customer_permanent_Jurisdiction_address(req, res)
  });

  router.post('/customer_profile', (req, res) => {
    CustomerModule.get_customer_profile(req, res)
  });

  router.post('/customer_banking_facilities', (req, res) => {
    CustomerModule.get_customer_banking_facilities(req, res)
  });

  router.post('/customer_banking_facilities_1', (req, res) => {
    CustomerModule.get_customer_banking_facilities_1(req, res)
  });

  router.post('/customer_banking_document', (req, res) => {
    CustomerModule.get_customer_banking_document(req, res)
  });

  router.post('/nominee_details', (req, res) => {
    CustomerModule.get_nominee_details(req, res)
  });

  router.post('/gaurdian_details', (req, res) => {
    CustomerModule.get_gaurdian_details(req, res)
  });

  router.post('/gaurdian_details', (req, res) => {
    CustomerModule.get_gaurdian_details(req, res)
  });

  router.post('/get_country_form', (req, res) => {
    CustomerModule.get_country_form(req, res)
  });

  router.post('/get_account_varient', (req, res) => {
    CustomerModule.get_account_varient(req, res)
  });

  router.post('/submit_consent_declared', (req, res) => {
    CustomerModule.submit_consent_declared(req, res)
  });

  router.post('/get_consent_declared', (req, res) => {
    CustomerModule.get_consent_declared(req, res)
  });

  router.post('/submit_lead', (req, res) => {
    CustomerModule.submit_lead(req, res)
  });

  router.post('/submit_banking_doc_1', (req, res) => {
    CustomerModule.submit_banking_doc_1(req, res)
  });

  router.post('/submit_terms_conditions', (req, res) => {
    CustomerModule.submit_terms_conditions(req, res)
  });

  router.post('/submit_joint_applicant_details', (req, res) => {
    CustomerModule.submit_joint_applicant_details(req, res)
  });

  router.post('/update_joint_applicant_details', (req, res) => {
    CustomerModule.update_joint_applicant_details(req, res)
  });

  router.post('/get-lead-comments', (req, res) => {
    CustomerModule.get_lead_comments(req, res)
  });

  router.post('/submit-guardian-detail', (req, res) => {
    CustomerModule.submit_guardian_details(req, res)
  });

  router.post('/get-guardian-details', (req, res) => {
    CustomerModule.get_guardian_details(req, res)
  });

  router.post('/customer-relative-details', (req, res) => {
    CustomerModule.get_relative_details(req, res)
  });


  router.post('/fetch_applicant_details', (req, res) => {
    CustomerModule.get_applicant_details(req, res)
  });

  router.post('/fetch_joints_applicants_data', (req, res) => {
    CustomerModule.fetch_joints_data(req, res)
  });

  // router.post('/get-applicant-data', (req, res) => {
  //   CustomerModule.get_applicant_data(req, res)
  // });

  router.post('/get-applicant-name', (req, res) => {
    CustomerModule.get_applicant_name(req, res)
  });
  router.post('/selected-account-type', (req, res) => {
    CustomerModule.selected_account_type(req, res)
  });

  router.post('/get-all-documents', (req, res) => {
    CustomerModule.get_all_documents(req, res)
  });

  // router.post('/get-all-data', (req, res) => {
  //   CustomerModule.get_all_data(req, res)
  // })

  router.post('/address-same-as', (req, res) => {
    CustomerModule.same_as_address(req, res)
  })
  router.post('/get_user_serial_no', (req, res) => {
    CustomerModule.get_user_serial_no(req, res)
  });
  // router.post('/get-address-proof-type', (req, res) => {
  //   CustomerModule.get_address_proof_type(req, res)
  // });

  
  // Minor Account Flow - Pradeep

  //personal detail 1.1
  router.post('/minor/personal-detail-first', minor_personal_detail_one_validation, (req, res) => {
    CustomerModule.minor_personal_detail(req, res)
  });
  //personal detail 1.1

  //personal detail 1.2
  router.post('/minor/personal-detail-second', minor_personal_detail_two_validation, (req, res) => {
    CustomerModule.minor_personal_detail(req, res)
  });
  //personal detail 1.2


  //gaurdian detail
  router.post('/minor/gaurdian_detail', minor_gaurdian_detail_validation, (req, res) => {
    CustomerModule.minor_gaurdian_detail(req, res)
  });
  //gaurdian detail

  //gaurdian detail
  router.post('/minor/fetch_gaurdian_detail', (req, res) => {
    CustomerModule.fetch_minor_gaurdian_detail(req, res)
  });


  //gaurdian detail

  // Minor Account Flow

  app.use("/customer", router);



}