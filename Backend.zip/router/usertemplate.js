module.exports = app => {
  const express = require("express");
  var router = express.Router();
  var UserModule = require('../controller/src/api/RblNri/Modules/User')
  const { signup_Validation, registeritmemberagents, customer_signup_validation, forgot_change_password, send_email_otp_validation, send_mobile_otp_validation } = require('../middleware/validation');
  var userauthorization = require('../middleware/Jwtverify');

  router.post('/customersignup', customer_signup_validation, (req, res) => {
    UserModule.customer_signup(req, res)
  });

  router.post('/techadmin-signup', signup_Validation, (req, res) => {
    UserModule.techadmin_signup(req, res)
  });

  router.post('/register-it-agent', (req, res) => {
    UserModule.register_it_agent_users(req, res)
  });

  router.put('/updateuser', (req, res) => {
    UserModule.updateuser(req, res)
  });

  router.put('/userstatusinactive', (req, res) => {
    UserModule.userstatusinactive(req, res)
  });

  router.post('/login', (req, res) => {
    UserModule.login(req, res)
  });

  router.post('/logout', (req, res) => {
    UserModule.logout(req, res)
  });

  router.post('/email-verify-otp', email_verify_otp_validation, (req, res) => {
    UserModule.email_verify_otp(req, res)
  });

  router.post('/mobile_no_verifyotp', mobile_verify_otp_validation, (req, res) => {
    UserModule.mobile_no_verifyotp(req, res)
  });

  router.post('/process-jwt', mobile_verify_otp_validation, (req, res) => {
    UserModule.process_jwt(req, res)
  });

  router.get('/getallusers',  (req, res) => {
    UserModule.getallusers(req, res)
  });

  router.get('/getuser',  (req, res) => {
    UserModule.getuser(req, res)
  });

  router.post('/reset-password-email', (req, res) => {
    UserModule.resetpasswordemail(req, res)
  });

  router.post('/resetpassword', forgot_change_password, (req, res) => {
    UserModule.resetpassword(req, res)
  });

  router.post('/changepassword', (req, res) => {
    UserModule.changepassword(req, res)
  });

  router.post('/refreshaccesstoken', (req, res) => {
    UserModule.refreshaccesstoken(req, res)
  });

  router.delete('/deleteuser', (req, res) => {
    UserModule.deleteuser(req, res)
  });

  router.post('/send_email_otp', send_email_otp_validation, (req, res) => {
    UserModule.send_email_otp(req, res)
  });

  router.post('/send_mobile_otp', send_mobile_otp_validation, (req, res) => {
    UserModule.send_mobile_otp(req, res)
  });

  router.post('/welcome_mail', (req, res) => {
    UserModule.send_test_mail(req, res)
  })

  router.post('/send_feedback_notification', (req, res) => {
    UserModule.send_feedback_notification(req, res)
  })

  router.post('/account_opening_submition_mail', (req, res) => {
    UserModule.account_opening_submition_mail(req, res)
  })

  router.post('/success_account_opening', (req, res) => {
    UserModule.success_account_opening(req, res)
  })

  router.post('/is-both-otp-verify', (req, res) => {
    UserModule.is_both_otp_verify(req, res)
  })

  
  // router.post('/generate_pdf', (req, res) => {
  //   UserModule.generate_pdf(req, res)
  // })

  // router.post('/download_pdf', (req, res) => {
  //   UserModule.download_pdf(req, res)
  // })

  app.use("/user", router);
}
