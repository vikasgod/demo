var mysqlconn = require("../../../../../db/mysqlconn");
const query = require("../../../../../db/query.json");
const util = require("util");
const mysqlquery = util.promisify(mysqlconn.query).bind(mysqlconn);
const db_table = require("../../../../../db_manipulation/db_constant");
const bcrypt = require("bcryptjs");
const e = require("connect-flash");

module.exports.add_agents = async (req, res) => {
  try {
    const role_id = req.body.role_id;
    const check_email = `select username from ${db_table.users} where username = ?`;
    const check_email_result = await mysqlquery(check_email, [
      req.body.username,
    ]);
    if (check_email_result.length > 0) {
      res.status(402).json({
        message: "This email is already in use!",
      });
    } else {
      // var hash = await bcrypt.hash(req.body.password, 10);
      let sql = `INSERT INTO ${db_table.users} SET ?`;
      var agentdata = {
        role_id: role_id,
        first_name: req.body.first_name,
        middle_name: req.body.middle_name,
        last_name: req.body.last_name,
        mobile_no: req.body.mobile_no,
        username: req.body.username,
        reporting_manager: req?.body?.reporting_manager ? req.body.reporting_manager : "",
        // email_address: req.body.email_address,
        // password: hash,
      };
      var agents_result = await mysqlquery(sql, agentdata);
      if (agents_result.affectedRows > 0) {
        res.status(200).json({
          message: "agent succcessfully added",
          data: agentdata,
        });
      } else {
        res.status(400).json({
          msg: "Something went wrong",
        });
      }
    }
  } catch (error) {
    res.status(400).json({
      msg: error.message ? error.message : error,
    });
  }
};

module.exports.counts_agents = async (req, res) => {
  try {
    const sql = `SELECT * FROM ${db_table.users} WHERE role_id IN (2,3)`;
    const result = await mysqlquery(sql);
    if (result.length > 0) {
      const superarr = [];
      const agentarr = [];
      result.map((a) => {
        if (a.role_id === 2) {
          superarr.push(a.role_id);
        } else {
          agentarr.push(a.role_id);
        }
      });
      const agents_count = {
        super_agent: superarr.length,
        agent: agentarr.length,
      };
      if (agents_count) {
        res.status(200).json({
          data: agents_count,
        });
      }
    } else {
      res.status(400).json({
        msg: "Something went wrong",
      });
    }
  } catch (error) {
    console.log("00000000", error);
    res.status(400).json({
      msg: error.message ? error.message : error,
    });
  }
};

module.exports.get_list = async (req, res) => {
  try {
    const role_id = req.params.role_id;
    if (role_id != "undefined" && role_id != "") {
      const getAgents = `SELECT first_name,user_id,last_name,middle_name,username,reporting_manager,mobile_no FROM ${db_table.users} where role_id = ?`;
      const agentsResult = await mysqlquery(getAgents, role_id);
      if (agentsResult.length > 0) {
        res.status(200).json({
          data: agentsResult,
        });
      } else {
        res.status(404).json({
          message: "data not found",
        });
      }
    } else {
      res.status(400).json({
        msg: "Something went wrong",
      });
    }
  } catch (error) {
    res.status(400).json({
      msg: error.message ? error.message : error,
    });
  }
};

module.exports.get_reporting_manager = async (req, res) => {
  try {
    const getAgents = `SELECT user_id,first_name FROM ${db_table.users} where role_id = 2`;
    const agentsResult = await mysqlquery(getAgents);
    if (agentsResult.length > 0) {
      res.status(200).json({
        data: agentsResult,
      });
    } else {
      res.status(404).json({
        message: "data not found",
      });
    }
  } catch (error) {
    res.status(400).json({
      msg: error.message ? error.message : error,
    });
  }
};

module.exports.delete_agents = async (req, res) => {
  try {
    let user_id = req.body.user_id;
    let userSql = `SELECT user_id,first_name from ${db_table.users} where user_id = ${req.body.user_id}`
    let dataUser = await mysqlquery(userSql);
    let sql = `Delete from tbl_users where user_id = ${user_id}`;
    let data = await mysqlquery(sql);
    if (data.affectedRows == 1) {
      res.status(200).json({
        data:dataUser,
        msg: "User Delete Successfully",
      });
      let sqlData = `UPDATE tbl_agent_leads AS Al
              LEFT JOIN tbl_leads AS l ON l.lead_id = Al.lead_id 
              SET l.lead_status = 'lead'
              WHERE Al.agent_id = ${req.body.user_id} AND l.lead_status = 'agent_process'`;
      await mysqlquery(sqlData);
    }
  } catch (error) {
    res.status(400).json({
      msg: error.message ? error.message : error,
    });
  }
};

module.exports.edit_agent = async (req,res) =>{
  try {
    let sql = `UPDATE ${db_table.users} SET 
              first_name = '${req.body.first_name}',
              middle_name = '${req.body.middle_name}',
              last_name = '${req.body.last_name}',
              username = '${req.body.username}',
              mobile_no = '${req.body.mobile_no}',
              reporting_manager = '${req.body.reporting_manager}' WHERE user_id = ${req.body.role_id}`
    let userData = await mysqlquery(sql)
    if (userData.affectedRows > 0) {
      res.status(200).json({
        message: "user details edit succcessfully",
        data: userData,
      });
    } else {
      res.status(400).json({
        msg: "Something went wrong",
      });
    }
  } catch (error) {
    res.status(400).json({
      msg: error.message ? error.message : error,
    });
  }
}
