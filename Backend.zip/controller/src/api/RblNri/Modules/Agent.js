var mysqlconn = require("../../../../../db/mysqlconn");
const query = require("../../../../../db/query.json");
var notification_function = require("../../../../../utils/function");
const customer_forms = require("../../../../../json/customer_forms.json");
const util = require("util");
var Convert = require("xml2js");
const { v4: uuidv4 } = require("uuid");
const { default: axios } = require("axios");
const https = require("https");
const mysqlquery = util.promisify(mysqlconn.query).bind(mysqlconn);
const registration_email = require("../../../../../utils/emailService");
const account_forms = require("../../../../../json/account.json");
const create_pdf = require("../../../../../utils/pdf");
const db_table = require("../../../../../db_manipulation/db_constant");
const account_json = require("../../../../../json/account.json");
// const path = require("path");
// var fs = require("fs");
// var pdf = require('html-pdf');

module.exports.accept_agent_leads = async (req, res) => {
  try {
    let lead_id = `SELECT * FROM ${db_table.leads} WHERE lead_id=?`;

    var leadid = await mysqlquery(lead_id, [req.body.lead_id]);
    var user_id = leadid[0]["user_id"];
    let accept_agent_lead = { status: "agent_process", user_id: user_id };

    let sql = `INSERT INTO ${db_table.lead_status_history} SET ? `;
    const agent_accept_lead = await mysqlquery(sql, accept_agent_lead);

    let submit_lead_staus = ["agent_process", new Date(), req.body.lead_id];
    let sql1 = `UPDATE  ${db_table.leads} SET lead_status=?,updated_on=? WHERE lead_id=?`;
    const submit_lead_details = await mysqlquery(sql1, submit_lead_staus);

    if (agent_accept_lead.insertId > 0) {
      res.status(200).json({
        msg: "Lead accepted successfully",
      });
    } else {
      res.status(400).json({
        msg: "something went wrong please contact support team",
      });
    }
  } catch (error) {
    res.status(400).json({
      msg: error.message ? error.message : error,
    });
  }
};
module.exports.incomplete_agent_leads = async (req, res) => {
  try {
    let query = `SELECT u.first_name,u.last_name,d.user_id,d.applicant_personal_id,u.email_address,u.isd_code,u.mobile_no,u.created_on as reg_date,d.is_submited
   FROM tbl_applicant_personal_details as d 
   LEFT JOIN  tbl_users as u 
   ON u.user_id = d.user_id
   LEFT JOIN  tbl_leads as l
   ON u.user_id = l.user_id where role_id=4 and (d.is_submited IS NULL and l.lead_status !='approved');`;
    var customer_data = await mysqlquery(query);

    res.status(200).json({
      data: customer_data,
    });
  } catch (error) {
    res.status(400).json({
      msg: error.message ? error.message : error,
    });
  }
};

module.exports.get_lead_count = async (req, res) => {
  try {
    var leads_query = `select user.user_id, user.first_name,user.last_name,personal_detail.account_type_id as account_type 
        from tbl_agent_leads
        left join tbl_leads on tbl_leads.lead_id = tbl_agent_leads.lead_id
        left join tbl_users user on user.user_id=tbl_leads.user_id
        left join tbl_applicant_personal_details personal_detail on personal_detail.user_id=tbl_leads.user_id
        where tbl_agent_leads.agent_id=? and tbl_leads.lead_status='lead' group by user.user_id`;
    var leads = await mysqlquery(leads_query, [req.body.agent_id]);

    if (leads) {
      var lead_count = leads.length;
      res.status(200).json({
        lead_count: lead_count,
      });
    } else {
      res.status(400).json({
        msg: "Something went wrong please contact support team",
      });
    }
  } catch (error) {
    res.status(400).json({
      msg: error.message ? error.message : error,
    });
  }
};

module.exports.get_process_lead_count = async (req, res) => {
  try {
    var leads_query = `select user.user_id, user.first_name,user.last_name,personal_detail.account_type_id as account_type 
        from tbl_agent_leads
        left join tbl_leads on tbl_leads.lead_id = tbl_agent_leads.lead_id
        left join tbl_users user on user.user_id=tbl_leads.user_id
        left join tbl_applicant_personal_details personal_detail on personal_detail.user_id=tbl_leads.user_id
        where tbl_agent_leads.agent_id=? and tbl_leads.lead_status='agent_process' group by user.user_id`;
    var leads = await mysqlquery(leads_query, [req.body.agent_id]);

    if (leads) {
      var lead_count = leads.length;
      res.status(200).json({
        process_lead_count: lead_count,
      });
    } else {
      res.status(400).json({
        msg: "Something went wrong please contact support team",
      });
    }
  } catch (error) {
    res.status(400).json({
      msg: error.message ? error.message : error,
    });
  }
};
module.exports.get_process_status = async (req, res) => {
  try {
    let process_res = [];
    if (req.body.applicant_id) {
      if (req.body.status?.includes("review")) {
        let get_process = `SELECT * FROM ${db_table.process_status} WHERE applicant_id=?`;
        let get_applicant = `SELECT * FROM ${db_table.applicant_persional_details} WHERE applicant_personal_id=?`;
        var query_res = await mysqlquery(get_process, [req.body.applicant_id]);
        var get_applicant_res = await mysqlquery(get_applicant, [
          req.body.applicant_id,
        ]);
        if (get_applicant_res[0].account_type_id == 1) {
          let process_id = [4, 5, 6, 7, 11, 12, 13, 14, 15, 16, 26, 18, 19, 22];
          query_res = query_res.filter((f) =>
            process_id.includes(f.process_id)
          );
        }
        if (get_applicant_res[0].account_type_id == 2) {
          process_id = [4, 5, 6, 7, 11, 12, 13, 14, 15, 16, 21, 18, 19, 22];
          query_res = query_res.filter((f) =>
            process_id.includes(f.process_id)
          );
        }
        if (
          get_applicant_res[0].account_type_id == 3 &&
          get_applicant_res[0].applicant_serial_number == 1
        ) {
          process_id = [33, 34, 35, 39];
          query_res = query_res.filter((f) =>
            process_id.includes(f.process_id)
          );
        }
        if (
          get_applicant_res[0].account_type_id == 3 &&
          get_applicant_res[0].applicant_serial_number == 2
        ) {
          process_id = [
            45, 46, 47, 48, 52, 53, 54, 55, 56, 57, 21, 59, 60, 63, 21,
          ];
          query_res = query_res.filter((f) =>
            process_id.includes(f.process_id)
          );
        }
        let i = 1;
        query_res.forEach((val) => {
          if (val.agent_status == null && i) {
            i = 0;
            let form = customer_forms.find(
              (c) => c.process_id == val.process_id
            );
            val.form_name = form.form_name;
            process_res.push(val);
          }
        });

        res.status(200).json({
          reviewed: !!!process_res.length,
          data: process_res[0],
        });
      }
      if (req.body.status?.includes("approved")) {
        let get_approved = `SELECT * FROM ${db_table.process_status} WHERE applicant_id=? and (agent_status IS NULL or agent_status='feedback')`;
        var approved_res = await mysqlquery(get_approved, [
          req.body.applicant_id,
        ]);
        let get_applicant = `SELECT * FROM ${db_table.applicant_persional_details} WHERE applicant_personal_id=?`;
        var get_applicant_res = await mysqlquery(get_applicant, [
          req.body.applicant_id,
        ]);

        if (get_applicant_res[0].account_type_id == 1) {
          let process_id = [4, 5, 6, 7, 11, 12, 13, 14, 15, 16, 26, 18, 19, 22];
          approved_res = approved_res.filter((f) =>
            process_id.includes(f.process_id)
          );
        }
        if (get_applicant_res[0].account_type_id == 2) {
          process_id = [4, 5, 6, 7, 11, 12, 13, 14, 15, 16, 21, 18, 19, 22];
          approved_res = approved_res.filter((f) =>
            process_id.includes(f.process_id)
          );
        }
        if (
          get_applicant_res[0].account_type_id == 3 &&
          get_applicant_res[0].applicant_serial_number == 1
        ) {
          process_id = [33, 34, 35, 39];
          approved_res = approved_res.filter((f) =>
            process_id.includes(f.process_id)
          );
        }
        if (
          get_applicant_res[0].account_type_id == 3 &&
          get_applicant_res[0].applicant_serial_number == 2
        ) {
          process_id = [
            45, 46, 47, 48, 52, 53, 54, 55, 56, 57, 21, 59, 60, 63, 21,
          ];
          approved_res = approved_res.filter((f) =>
            process_id.includes(f.process_id)
          );
        }
        let i = 1;
        approved_res.forEach((val) => {
          if (
            (val.agent_status == null || val.agent_status == "feedback") &&
            i
          ) {
            i = 0;
            let form = customer_forms.find(
              (c) => c.process_id == val.process_id
            );
            val.form_name = form.form_name;
            process_res.push(val);
          }
        });
        res.status(200).json({
          approved: !!!process_res.length,
          data: process_res[0],
        });
      }
    } else {
      res.status(400).json({
        msg: "Something went wrong please contact support team",
      });
    }
  } catch (error) {
    res.status(400).json({
      msg: error.message ? error.message : error,
    });
  }
};

module.exports.search_agent = async (req, res) => {
  try {
    const search_by = req.body.search_by;
    const searchValue = req.body.search_value;
    if (search_by === "lead_number") {
      //  const searchQuery = `SELECT * FROM ${db_table.leads} WHERE lead_number LIKE '%${searchValue}%' AND (role_id = ${role_id})`
      const searchQuery = `SELECT leads.lead_number,users.*
      FROM ${db_table.leads} as leads
      LEFT JOIN  ${db_table.users} as users
      ON leads.user_id = users.user_id
      WHERE (lead_number LIKE '%${searchValue}%') AND (role_id = ${role_id})`;
      const searchResult = await mysqlquery(searchQuery);
      if (searchResult.length > 0) {
        res.status(200).json({
          message: "data available",
          agentdata: searchResult,
        });
      } else {
        res.status(400).json({
          message: "agent not available !",
        });
      }
    } else {
      if (search_by === "customer_name") {
        const searchQuery = `SELECT * FROM ${db_table.users} WHERE ((first_name LIKE '%${searchValue}%') OR (middle_name LIKE '%${searchValue}%') OR (last_name LIKE '%${searchValue}%')) and role_id IN (2,3) `;
        const searchResult = await mysqlquery(searchQuery);
        if (searchResult.length > 0) {
          res.status(200).json({
            message: "data available",
            agent_data: searchResult,
          });
        } else {
          res.status(400).json({
            message: "agent not available !",
          });
        }
      }
    }
  } catch (error) {
    res.status(400).json({
      msg: error.message ? error.message : error,
    });
  }
};

// module.exports.process_lead_list=async(req,res)=>{
//     try {
//       var leads_query =`select tbl_applicant_personal_details.applicant_personal_id,tbl_agent_leads.lead_id,tbl_users.user_id, CONCAT(tbl_users.first_name, ' ', tbl_users.last_name) as customer_name,
//       tbl_applicant_personal_details.account_type_id as account_type,
//       tbl_users.created_on as applied_on, custom.status from ( select a.* from tbl_lead_status_histories a join tbl_lead_status_histories b
//       where a.created_on >= b.created_on and a.status = 'agent_process' group by a.user_id order by a.lead_status_id ) as custom
//       inner join tbl_users on custom.user_id = tbl_users.user_id
//       inner join tbl_applicant_personal_details on tbl_users.user_id = tbl_applicant_personal_details.user_id
//       inner join tbl_agent_leads on tbl_agent_leads.lead_id = custom.user_id
//       where tbl_applicant_personal_details.account_type_id is not null and tbl_agent_leads.agent_id =?
//       group by tbl_users.user_id`;
//         var leads = await mysqlquery(leads_query,[req.body.agent_id]);
//         leads.forEach(application => {
//             let account_id = application.account_type;
//             var account_form = account_forms;
//             application['account_type_id']= application.account_type
//             var account_type_name = account_form.find(item => item.account_type_id === account_id)
//             var account_type = account_type_name.account_type;
//             application['account_type'] = account_type;
//         })
//         res.status(200).json({
//             data:leads
//         })
//       } catch(error) {
//           res.status(400).json({
//               msg:error
//           })

//       }
// }

module.exports.get_reviewed_lead_count = async (req, res) => {
  try {
    var leads_query = `select user.user_id, user.first_name,user.last_name,personal_detail.account_type_id as account_type 
        from tbl_agent_leads
        left join tbl_leads on tbl_leads.lead_id = tbl_agent_leads.lead_id
        left join tbl_users user on user.user_id=tbl_leads.user_id
        left join tbl_applicant_personal_details personal_detail on personal_detail.user_id=tbl_leads.user_id
        where tbl_agent_leads.agent_id=? and tbl_leads.lead_status='agent_review' group by user.user_id`;
    var leads = await mysqlquery(leads_query, [req.body.agent_id]);

    if (leads) {
      var lead_count = leads.length;
      res.status(200).json({
        review_lead_count: lead_count,
      });
    } else {
      res.status(400).json({
        msg: "Something went wrong please contact support team",
      });
    }
  } catch (error) {
    res.status(400).json({
      msg: error.message ? error.message : error,
    });
  }
};

// module.exports.review_lead_list=async(req,res)=>{
//     try {
//       var leads_query =`select tbl_applicant_personal_details.applicant_personal_id,tbl_agent_leads.lead_id,tbl_users.user_id, CONCAT(tbl_users.first_name, ' ', tbl_users.last_name) as customer_name,
//       tbl_applicant_personal_details.account_type_id as account_type,
//       tbl_users.created_on as applied_on, custom.status from ( select a.* from tbl_lead_status_histories a join tbl_lead_status_histories b
//       where a.created_on >= b.created_on and a.status = 'review' group by a.user_id order by a.lead_status_id ) as custom
//       inner join tbl_users on custom.user_id = tbl_users.user_id
//       inner join tbl_applicant_personal_details on tbl_users.user_id = tbl_applicant_personal_details.user_id
//       inner join tbl_agent_leads on tbl_agent_leads.lead_id = custom.user_id
//       where tbl_applicant_personal_details.account_type_id is not null and tbl_agent_leads.agent_id =?
//       group by tbl_users.user_id`;
//         var leads = await mysqlquery(leads_query,[req.body.agent_id]);
//         leads.forEach(application => {
//             let account_id = application.account_type;
//             var account_form = account_forms;
//             application['account_type_id']= application.account_type
//             var account_type_name = account_form.find(item => item.account_type_id === account_id)
//             var account_type = account_type_name.account_type;
//             application['account_type'] = account_type;

//         })
//         res.status(200).json({
//             data:leads
//         })
//       } catch(error) {
//           res.status(400).json({
//               msg:error
//           })

//       }
// }

module.exports.lead_process_review_list = async (req, res) => {
  try {
    var leads_query = `select user.user_id,personal_detail.applicant_personal_id,tbl_leads.lead_id leadsh.created_on,
        concat(user.first_name,' ',user.last_name) as customer_name,personal_detail.account_type_id as account_type from tbl_agent_leads 
        left join tbl_leads on tbl_leads.lead_id = tbl_agent_leads.lead_id
        left join tbl_users user on user.user_id=tbl_leads.user_id
        left join tbl_applicant_personal_details personal_detail on personal_detail.user_id=tbl_leads.user_id 
        left join tbl_lead_status_histories as leadsh on personal_detail.user_id = leadsh.user_id
        where tbl_agent_leads.agent_id=? and tbl_leads.lead_status=? group by user_id`;
    var leads = await mysqlquery(leads_query, [
      req.body.agent_id,
      req.body.lead_type,
    ]);
    leads.forEach((application) => {
      let account_id = application.account_type;
      var account_form = account_forms;

      var account_type_name = account_form.find(
        (item) => item.account_type_id === account_id
      );
      var account_type = account_type_name.account_type;

      application["account_type"] = account_type;

      delete application["account_type_id"];
    });
    res.status(200).json({
      data: leads,
    });
  } catch (error) {
    res.status(400).json({
      msg: error.message ? error.message : error,
    });
  }
};

module.exports.user_account_data = async (req, res) => {
  try {
    var applicant_data = `SELECT user_id,account_type_id,account_varient FROM ${db_table.applicant_persional_details} where applicant_personal_id=?`;

    var user_find = await mysqlquery(applicant_data, [req.body.applicant_id]);

    const user_data = Object.values(user_find);
    const userid = user_data[0].user_id;

    var leads_query = `SELECT applicant_personal_id, user_id,account_type_id,account_varient FROM ${db_table.applicant_persional_details} where user_id=?`;
    var total_applicant = await mysqlquery(leads_query, [userid]);
    if (user_find) {
      user_find.forEach((application) => {
        let account_id = application.account_type_id;
        var account_form = account_forms;
        application["account_type_id"] = application.account_type;
        var account_type_name = account_form.find(
          (item) => item.account_type_id === account_id
        );
        var account_type = account_type_name.account_type;
        application["account_type"] = account_type;

        application["No_of_Applicants"] = total_applicant.length;
      });
      res.status(200).json({
        data: user_find,
      });
    } else {
      res.status(400).json({
        msg: "Something went wrong please contact support team",
      });
    }
  } catch (error) {
    res.status(400).json({
      msg: error.message ? error.message : error,
    });
  }
};

// module.exports.add_comments=async(req,res)=>{
//     try {

//         if(req.body.comment){
//       let add_comments = {
//         parent_comment_id:req.body.parent_comment_id,lead_id:req.body.lead_id, agent_id: req.body.agent_id,
//         applicant_id:req.body.applicant_id,process_id:req.body.process_id,
//         comment:req.body.comment
//       };
//       let sql = `INSERT INTO ${db_table.comment} SET ? `;
//       const addcomment = await mysqlquery(sql, add_comments);
//      let agent_status='feedback'
//       const update_lead_status = [
//         agent_status,req.body.applicant_id
//     ];
//       let sql1 = `update ${db_table.process_status} SET agent_status=? WHERE applicant_id=?`;
//       let update_status = await mysqlquery(sql1, update_lead_status);

//     // let comment_agent_lead = {status:"agent_review",user_id:req.body.lead_id};
//     // let sql5 = `INSERT INTO ${db_table.lead_status_history} SET ? `;
//     // const agent_comment_lead = await mysqlquery(sql5, comment_agent_lead);

//     let lead_id = `SELECT * FROM ${db_table.leads} WHERE lead_id=?`;

//     var leadid = await mysqlquery(lead_id, [req.body.lead_id]);
//     var user_id=leadid[0]['user_id']
//     let accept_agent_lead = {status:"agent_review",user_id:user_id};

//     let sql8 = `INSERT INTO ${db_table.lead_status_history} SET ? `;
//     const agent_accept_lead = await mysqlquery(sql8, accept_agent_lead);

//       let comment_lead = ["agent_review",new Date(),req.body.lead_id]

//       let sql6 = `UPDATE ${db_table.leads} SET lead_status=?, updated_on=? WHERE lead_id=?`;
//       const comments_lead = await mysqlquery(sql6, comment_lead);

//       if(addcomment.insertId>0){
//           res.status(200).json({
//               msg:'comment save successfully'
//           })
//       }else{
//           res.status(400).json({
//               msg:'bad request'
//           })
//       }
//     }else{
//         let agent_status = 'approved'
//         let update_lead_status = [
//             agent_status,req.body.applicant_id,req.body.process_id
//         ];
//         let sql1 = `update ${db_table.process_status} SET agent_status=? WHERE applicant_id and process_id=?`;
//        let update_status = await mysqlquery(sql1, update_lead_status);

//     //   let approved_agent_lead = {status:"approved",user_id:req.body.lead_id};

//     //   let sql5 = `INSERT INTO ${db_table.lead_status_history} SET ? `;
//     //   const agent_comment_lead = await mysqlquery(sql5, approved_agent_lead);

//     let lead_id = `SELECT * FROM ${db_table.leads} WHERE lead_id=?`;

//     var leadid = await mysqlquery(lead_id, [req.body.lead_id]);
//     var user_id=leadid[0]['user_id']
//     let accept_agent_lead = {status:"agent_review",user_id:user_id};

//     let sql8 = `INSERT INTO ${db_table.lead_status_history} SET ? `;
//     const agent_accept_lead = await mysqlquery(sql8, accept_agent_lead);

//       let comment_lead = ["approved",new Date(),req.body.lead_id]

//       let sql6 = `UPDATE ${db_table.leads} SET lead_status=? updated_on=? WHERE lead_id=?`;
//       const comments_lead = await mysqlquery(sql6, comment_lead);

//         if(update_status.affectedRows ===1 && update_status.insertId ===0){
//             res.status(200).json({
//                 msg:'approved save successfully'
//             })
//         }else{
//             res.status(400).json({
//                 msg:'bad request'
//             })
//         }
//     }

//       } catch(error) {
//           res.status(400).json({
//               msg:error
//           })

//       }
//   }

module.exports.add_comments = async (req, res) => {
  try {
    var comment_id = req.body.comment_id;
    if (!comment_id) {
      let add_comments = {
        parent_comment_id: req.body.parent_comment_id,
        lead_id: req.body.lead_id,
        agent_id: req.body.agent_id,
        applicant_id: req.body.applicant_id,
        process_id: req.body.process_id,
        comment: req.body.comment,
      };
      let sql = `INSERT INTO ${db_table.comment} SET ? `;
      const addcomment = await mysqlquery(sql, add_comments);

      let agent_status = "feedback";
      const update_lead_status = [
        agent_status,
        new Date(),
        req.body.applicant_id,
        req.body.process_id,
      ];
      let sql1 = `update ${db_table.process_status} SET agent_status=?, updated_on=? WHERE applicant_id=? and process_id=?`;
      let update_status = await mysqlquery(sql1, update_lead_status);

      // let comment_agent_lead = {status:"agent_review",user_id:req.body.lead_id};
      // let sql5 = `INSERT INTO ${db_table.lead_status_history} SET ? `;
      // const agent_comment_lead = await mysqlquery(sql5, comment_agent_lead);

      let lead_id = `SELECT * FROM ${db_table.leads} WHERE lead_id=?`;

      var leadid = await mysqlquery(lead_id, [req.body.lead_id]);
      var user_id = leadid[0]["user_id"];
      let reviews_agent_lead = { status: "agent_review", user_id: user_id };

      let sql8 = `INSERT INTO ${db_table.lead_status_history} SET ? `;
      const review_accept_lead = await mysqlquery(sql8, reviews_agent_lead);

      // if (req.body.process_id == 26) {
      //   let comment_lead = ["agent_review", new Date(), req.body.lead_id];

      //   let sql6 = `UPDATE ${db_table.leads} SET lead_status=?, updated_on=? WHERE lead_id=?`;
      //   const comments_lead = await mysqlquery(sql6, comment_lead);
      // }

      //   let comment_lead = ["agent_process",new Date(),req.body.lead_id]
      //   let sql6 = `UPDATE ${db_table.leads} SET lead_status=?, updated_on=? WHERE lead_id=?`;
      //   const comments_lead = await mysqlquery(sql6, comment_lead);

      if (addcomment.insertId > 0) {
        res.status(200).json({
          msg: "comment save successfully",
          comment_id: addcomment.insertId,
        });
      } else {
        res.status(400).json({
          msg: "Something went wrong please contact support team",
        });
      }
    } else {
      let status = "added";
      let update_comments = [
        req.body.parent_comment_id,
        req.body.lead_id,
        req.body.agent_id,
        req.body.applicant_id,
        req.body.process_id,
        req.body.comment,
        new Date(),
        status,
        comment_id,
      ];
      let sql1 = `UPDATE ${db_table.comment} SET parent_comment_id=?, lead_id=?, agent_id=?, applicant_id=?, process_id=?, comment=?,updated_on=?,status=? where comment_id=?`;
      const update_comment = await mysqlquery(sql1, update_comments);

      let agent_status = "feedback";
      const update_lead_status = [
        agent_status,
        new Date(),
        req.body.applicant_id,
        req.body.process_id,
      ];

      let sql2 = `update ${db_table.process_status} SET agent_status=?,updated_on=?  WHERE applicant_id=? and process_id=?`;
      let update_status = await mysqlquery(sql2, update_lead_status);

      // let comment_agent_lead = {status:"agent_review",user_id:req.body.lead_id};
      // let sql5 = `INSERT INTO ${db_table.lead_status_history} SET ? `;
      // const agent_comment_lead = await mysqlquery(sql5, comment_agent_lead);

      let lead_id = `SELECT * FROM ${db_table.leads} WHERE lead_id=?`;

      var leadid = await mysqlquery(lead_id, [req.body.lead_id]);
      var user_id = leadid[0]["user_id"];
      let reviews_agent_lead = { status: "agent_process", user_id: user_id };

      let sql8 = `INSERT INTO ${db_table.lead_status_history} SET ? `;
      const review_accept_lead = await mysqlquery(sql8, reviews_agent_lead);

      // if (req.body.nomination_form == "true") {
      //   let comment_lead = ["agent_review", new Date(), req.body.lead_id];
      //   let sql6 = `UPDATE ${db_table.leads} SET lead_status=?, updated_on=? WHERE lead_id=?`;
      //   const comments_lead = await mysqlquery(sql6, comment_lead);
      // }
      if (update_comment.affectedRows > 0) {
        res.status(200).json({
          msg: "comment updated successfully",
        });
      } else {
        res.status(400).json({
          msg: "Something went wrong please contact support team",
        });
      }
    }
  } catch (error) {
    res.status(400).json({
      msg: error.message ? error.message : error,
    });
  }
};

module.exports.delete_comments = async (req, res) => {
  try {
    var delete_comments_sql = `DELETE FROM ${db_table.comment} WHERE comment_id=?`;
    var delete_comment = await mysqlquery(delete_comments_sql, [
      req.body.comment_id,
    ]);

    if (delete_comment.affectedRows > 0) {
      res.status(200).json({
        msg: "comments delete successfully",
      });
    } else {
      res.status(400).json({
        msg: "Something went wrong please contact support team",
      });
    }
  } catch (error) {
    res.status(400).json({
      msg: error.message ? error.message : error,
    });
  }
};

module.exports.forms_approved = async (req, res) => {
  try {
    let agent_status = "approved";
    let update_lead_status = [
      agent_status,
      new Date(),
      req.body.applicant_id,
      req.body.process_id,
    ];
    let sql1 = `UPDATE ${db_table.process_status} SET agent_status=?,updated_on=? WHERE applicant_id=? and process_id=?`;

    let update_status = await mysqlquery(sql1, update_lead_status);

    //   let approved_agent_lead = {status:"approved",user_id:req.body.lead_id};
    //   let sql5 = `INSERT INTO ${db_table.lead_status_history} SET ? `;
    //   const agent_comment_lead = await mysqlquery(sql5, approved_agent_lead);

    let lead_id = `SELECT * FROM ${db_table.leads} WHERE lead_id=?`;

    var leadid = await mysqlquery(lead_id, [req.body.lead_id]);
    var user_id = leadid[0]["user_id"];
    let accept_agent_lead = { status: "agent_review", user_id: user_id };

    let sql8 = `INSERT INTO ${db_table.lead_status_history} SET ? `;
    const agent_accept_lead = await mysqlquery(sql8, accept_agent_lead);

    var process_sql = `SELECT applicant_id, process_id, agent_status FROM ${db_table.process_status} WHERE applicant_id=?`;
    var process_result = await mysqlquery(process_sql, [req.body.applicant_id]);

    var process_approved_sql = `SELECT applicant_id, process_id, agent_status FROM ${db_table.process_status} WHERE applicant_id=? and agent_status='approved'`;
    var process_approved = await mysqlquery(process_approved_sql, [
      req.body.applicant_id,
    ]);

    if (process_result.length == process_approved.length) {
      let comment_lead = ["approved", new Date(), req.body.lead_id];

      let sql6 = `UPDATE ${db_table.leads} SET lead_status=? updated_on=? WHERE lead_id=?`;
      const comments_lead = await mysqlquery(sql6, comment_lead);
    }
    if (update_status.affectedRows > 0) {
      res.status(200).json({
        msg: "Approved successfully",
      });
    } else {
      res.status(400).json({
        msg: "Something went wrong please contact support team",
      });
    }
  } catch (error) {
    res.status(400).json({
      msg: error.message ? error.message : error,
    });
  }
};

/*  module.exports.get_agent_lead_comments = async (req, res) => {
    try {
        let get_comments = `select c.*,s.agent_status from ${db_table.comment} c inner join ${db_table.process_status} s on c.process_id= s.process_id and c.applicant_id = s.applicant_id where c.agent_id=? and c.lead_id=? and c.process_id=?`
        const comments_details = await mysqlquery(get_comments, [req.body.agent_id, req.body.lead_id,req.body.process_id]);
        comments_details.forEach(application => {
            let process_id = application.process_id;
            var process_data_id = customer_forms;
            var customer_process = process_data_id.find(item => item.process_id === process_id)
            var process_type = customer_process.form_name;
            application['process_name'] = process_type;

        })

        res.status(200).json({
            data: comments_details
        })
    } catch (error) {
        res.status(400).json({
            msg:error.message?error.message:error
        })

    }
} */
module.exports.get_agent_lead_comments = async (req, res) => {
  try {
    let get_comments = `select * from ${db_table.comment} where applicant_id = ? and process_id =? order by comment_id desc`;
    const comments_details = await mysqlquery(get_comments, [
      req.body.applicant_id,
      req.body.process_id,
    ]);
    let get_agent_status = `select * from ${db_table.process_status} where applicant_id = ? and process_id = ?`;
    const agent_status_details = await mysqlquery(get_agent_status, [
      req.body.applicant_id,
      req.body.process_id,
    ]);
    let data = {
      comment_id: "",
      comment: "",
      agent_status: "",
    };
    if (agent_status_details.length != 0) {
      if (agent_status_details[0].agent_status != undefined) {
        data.agent_status = agent_status_details[0].agent_status;
      }
    }
    if (comments_details.length != 0) {
      if (comments_details[0].comment != undefined) {
        data.comment_id = comments_details[0].comment_id;
        data.comment = comments_details[0].comment;
      }
    }
    res.status(200).json({
      data: data,
    });
  } catch (error) {
    res.status(400).json({
      msg: error.message ? error.message : error,
    });
  }
};

module.exports.get_applicant_data = async (req, res) => {
  try {
    const applicant_id = req.body.applicant_id;
    if (applicant_id != undefined) {
      const query = `select * from ${db_table.applicant_persional_details} where applicant_personal_id = ?`;
      const result = await mysqlquery(query, applicant_id);
      const user_id = result[0].user_id;
      const query1 = `select applicant_personal_id,user_id,applicant_serial_number from ${db_table.applicant_persional_details} where user_id = ?`;
      const result1 = await mysqlquery(query1, user_id);
      res.status(200).json({
        msg: "data retrive successfully",
        data: result1,
      });
    } else {
      res.status(400).json({
        msg: "Something went wrong please contact support team",
      });
    }
  } catch (error) {
    res.status(400).json({
      msg: error.message ? error.message : error,
    });
  }
};

module.exports.review_lead = async (req, res) => {
  try {
    if (req.body.lead_id != undefined) {
      var update_data = ["agent_review", new Date(), req.body.lead_id];
      var query = `update ${db_table.leads} set lead_status=?, updated_on=? where lead_id=?`;
      var result = await mysqlquery(query, update_data);

      const search_username = `SELECT leads.user_id,
            CONCAT(users.first_name,' ',COALESCE(users.last_name, '')) AS user_name,users.email_address
            FROM  tbl_leads AS leads
            LEFT JOIN  tbl_users AS users
            ON users.user_id = leads.user_id
            WHERE lead_id = ?`;
      const customer_name = await mysqlquery(search_username, [
        req.body.lead_id,
      ]);
      const url = `${process.env.CustomerURL}/feedback/feedback-summary`;
      const params = {
        name: customer_name[0].user_name,
        email: customer_name[0].email_address,
        url: url,
        image: process.env.URL,
      };
      if (params.email) {
        let data = {
          sendMessage: {
            version: "1.0",
            appID: "FINACLE",
            topicName: "nriactact",
            recipient: {
              subscriber: {
                customerID: "",
                accountNo: "",
                contact: {
                  emailID: customer_name[0].email_address,
                  mobileNo: "",
                },
              },
            },
            mergeVarArray: {
              mergeVar: {
                name: "CUSTNAME",
                content: {
                  stringContent: customer_name[0].user_name,
                },
              },
              mergeVar: {
                name: "URL",
                content: {
                  stringContent: url,
                },
              },
            },
            referenceNo: `nriactact_ + ${
              new Date().getSeconds() * new Date().getMilliseconds()
            }`,
          },
        };

        var builder = new Convert.Builder();
        var xml = builder.buildObject(data);
        const agent = new https.Agent({
          rejectUnauthorized: false,
        });
        let header = {
          "x-rbl-auth": `Bearer ${req.session.token}`,
          'Content-Type':'application/xml'
        };
        const axiosConfig = {
          httpsAgent: agent,
          headers: header,
        };
        await axios.post(
          `${process.env.RBL_SENTINAL_URL}/ralert/alrt`,
          xml,
          axiosConfig
        );
        // await registration_email.account_reviwed(params);
      } else {
        res.status(400).json({ message: "email not exist" });
      }
      res.status(200).json({
        msg: "lead reviewed successfully",
      });
    } else {
      res.status(400).json({
        msg: "Something went wrong please contact support team",
      });
    }
  } catch (error) {
    res.status(400).json({
      msg: error.message ? error.message : error,
    });
  }
};

get_token = async (req) => {
  try {
    let payload = {
      getToken: {
        RequestHeader: {
          MessageKey: {
            RequestUUID: uuidv4(),
            ServiceRequestId: "GETTOKEN",
            ServiceRequestVersion: "1.0",
            ChannelId: "",
          },
          RequestMessageInfo: {
            BankId: "",
            TimeZone: "",
            MessageDateTime: "",
          },
          Security: {
            Token: {
              Certificate: "",
              MessageHashKey: "",
              MessageIndex: "",
              PasswordToken: {
                UserId: "",
                Password: "",
              },
            },
          },
          DeviceInfo: {
            DeviceFamily: "",
            DeviceFormat: "",
            DeviceType: "",
            DeviceName: "",
            DeviceIMEI: "",
            DeviceID: "",
            DeviceVersion: "",
            AppVersion: "",
            DeviceOS: "",
            DeviceIp: process.env.RBL_DEVICE_IP,
          },
          AdditionalInfo: {
            JourneyId: "",
            LanguageId: "",
            SVersion: "",
            SessionId: "",
          },
        },
        RequestBody: {
          getTokenRequestBody: {
            clientId: process.env.RBL_CLIENT_ID,
            clientSecret: process.env.RBL_SECRET_ID,
          },
        },
      },
    };

    const agent = new https.Agent({
      rejectUnauthorized: false,
    });
    const axiosConfig = {
      httpsAgent: agent,
    };
    const response = await axios.post(
      `${process.env.RBL_SENTINAL_URL}/api/v1/OAUTH/get-token`,
      payload,
      axiosConfig
    );
    let responseData =
      response.data.generateTokenResponse.Status.StatusCode == "0";
    if (responseData) {
      req.session.token =
        response.data.generateTokenResponse?.ResponseBody?.generateTokenResponseBody?.access_token;
      req.session.expires_in =
        Date.now() +
        response.data.generateTokenResponse?.ResponseBody
          ?.generateTokenResponseBody?.expires_in *
          1000;
    } else {
      console.log("something went wrong");
    }
  } catch (error) {
    console.error("Getting error while generate the token", error);
  }
};

module.exports.approve_lead = async (req, res) => {
  try {
    const lead_id = req.body.lead_id;
    if (lead_id != undefined) {
      var update_data = ["approved", new Date(), req.body.lead_id];
      var query = `update ${db_table.leads} set lead_status=?, updated_on=? where lead_id=?`;
      var result = await mysqlquery(query, update_data);
      if (result.affectedRows > 0) {
        const query = `SELECT users.email_address,leads.lead_number
            FROM tbl_users AS users
            LEFT JOIN tbl_leads AS leads
            ON users.user_id = leads.user_id
            WHERE leads.lead_id = ?`;
        const queryResult = await mysqlquery(query, lead_id);
        const url = `${process.env.URL}/forms/${queryResult[0].lead_number}.pdf`;
        const params = {
          email: queryResult[0].email_address,
          lead_number: queryResult[0].lead_number,
          url: url,
          image: process.env.URL,
        };
        if (url) {
          if (params.email) {
            let sql = `select user_id from tbl_users where email_address=?`;
            const accountDetails = await mysqlquery(sql, [params.email]);
            let userId = accountDetails.map((x) => x["user_id"]);
            let accountData = await customerAccountInfo(userId);
            let account = account_json.find(
              (item) => item.account_type_id === accountData[0].account_type_id
            );
            let accountType = account.account_type;

            let final_result = {
              account_type: accountType,
            };

            accountData.forEach((element, index) => {
              final_result["applicant_" + (index + 1)] = element;
            });
            if (accountData.length > 0) {
              await create_pdf(final_result);
              if (!req?.session?.token) {
                await get_token(req);
              } else if (Date.now() > req.session.expires_in) {
                await get_token(req);
              }
              let data = {
                sendMessage: {
                  version: "1.0",
                  appID: "FINACLE",
                  topicName: "nriactacpt",
                  recipient: {
                    subscriber: {
                      customerID: "",
                      accountNo: "",
                      contact: {
                        emailID: queryResult[0].email_address,
                        mobileNo: "",
                      },
                    },
                  },
                  mergeVarArray: {
                    mergeVar: {
                      name: "CUSTNAME",
                      content: {
                        stringContent: "",
                      },
                    },
                    mergeVar: {
                      name: "URL",
                      content: {
                        stringContent: url,
                      },
                    },
                  },
                  referenceNo: `nriactacpt_${
                    new Date().getSeconds() * new Date().getMilliseconds()
                  }`,
                },
              };
              var builder = new Convert.Builder();
              var xml = builder.buildObject(data);
              const agent = new https.Agent({
                rejectUnauthorized: false,
              });
              let header = {
                "x-rbl-auth": `Bearer ${req.session.token}`,
                'Content-Type':'application/xml'
              };
              const axiosConfig = {
                httpsAgent: agent,
                headers: header,
              };
              await axios.post(
                `${process.env.RBL_SENTINAL_URL}/ralert/alrt`,
                xml,
                axiosConfig
              );
              res.status(200).json({
                msg: "lead approved successfully",
              });
              // await registration_email.send_pdf_mail(params);
            }
          } else {
            res.status(401).json({ msg: "User not found for this email" });
          }
        }
      }
    } else {
      res.status(400).json({
        msg: "Something went wrong please contact support team",
      });
    }
  } catch (error) {
    res.status(400).json({
      msg: error.message ? error.message : error,
    });
  }
};

module.exports.reject_lead = async (req, res) => {
  try {
    if (req.body.lead_id != undefined && req.body.comment != undefined) {
      var update_data = [
        "rejected",
        req.body.comment,
        new Date(),
        req.body.lead_id,
      ];
      var query = `update ${db_table.leads} set lead_status=?, reject_reason=?, updated_on=? where lead_id=?`;
      var result = mysqlquery(query, update_data);
      res.status(200).json({
        msg: "lead rejected successfully",
      });
    } else {
      res.status(400).json({
        msg: "Something went wrong please contact support team",
      });
    }
  } catch (error) {
    res.status(400).json({
      msg: error.message ? error.message : error,
    });
  }
};

module.exports.lead_list_new = async (req, res) => {
  try {
    if (req.body.agent_id != undefined) {
      var agent_id = req.body.agent_id;
      var lead_status = "";
      if (req.body.lead_type != undefined) {
        var lead_type = req.body.lead_type;
        switch (lead_type) {
          case "assigned":
            lead_status = "lead";
            break;
          case "reviewed":
            lead_status = "agent_review";
            break;
          case "agent_process":
            lead_status = "agent_process";
            break;
          case "rejected":
            lead_status = "rejected";
            break;
          case "approved":
            lead_status = "approved";
            break;
        }
      }
      var result = [];
      if (lead_status != "") {
        var query = `SELECT 
                  l.lead_id,l.lead_number,
                  a.applicant_personal_id,
                  CONCAT(a.applicant_first_name,' ', COALESCE(a.applicant_middle_name, ''),' ',COALESCE(a.applicant_last_name, '')) AS applicant_name,
                  CASE
                      WHEN a.account_type_id = 1 THEN "Individual"
                      WHEN a.account_type_id = 2 THEN "Joint"
                      WHEN a.account_type_id = 3 THEN "Minor"
                  END AS account_type,
                  l.lead_status,
                  CONCAT (ag.first_name,' ',COALESCE(ag.last_name, '')) AS agent_name
                  FROM 
                    tbl_applicant_personal_details  AS a
                  INNER JOIN  tbl_users AS u ON a.user_id = u.user_id
                  LEFT JOIN tbl_leads AS l ON a.user_id = l.user_id
                  LEFT JOIN tbl_agent_leads AS al ON l.lead_id = al.lead_id
                  LEFT JOIN tbl_users AS ag ON al.agent_id = ag.user_id
                  WHERE a.applicant_serial_number = 1
                  AND l.lead_status = '${lead_status}'
                  AND al.agent_id = '${agent_id}'
                  GROUP BY a.user_id
                  ORDER BY a.applicant_personal_id DESC`;
        result = await mysqlquery(query);
      }
      res.status(200).json({
        data: result,
      });
    } else {
      res.status(400).json({
        data: [],
      });
    }
  } catch (error) {
    res.status(400).json({
      msg: error.message ? error.message : error,
    });
  }
};

module.exports.approved_or_reviewed = async (req, res) => {
  try {
    const data = {
      is_approved: 0,
      is_reviewed: 0,
    };
    const applicantId = req.body.applicant_id;

    let sql = `select agent_status from ${db_table.process_status} where applicant_id=? and agent_status is null`;
    const result = await mysqlquery(sql, [applicantId]);

    if (result.length == 0) {
      let sql1 = `select agent_status from ${db_table.process_status} where agent_status = 'feedback' and applicant_id=?`;
      const reviewedResult = await mysqlquery(sql1, [applicantId]);
      if (reviewedResult.length == 0) {
        data.is_approved = 1;
      } else {
        data.is_reviewed = 1;
      }
    }
    res.status(200).json({
      data,
    });
  } catch (err) {
    res.status(400).json({
      msg: err.message ? err.message : err,
    });
  }
};

module.exports.search_user = async (req, res) => {
  try {
    const agent_id = req.body.agent_id;
    const search_by = req.body.search_by;
    const searchValue = req.body.search_value;
    if (search_by === "lead_number") {
      //    const searchQuery = `SELECT * FROM ${db_table.leads} WHERE lead_number LIKE '%${searchValue}%' AND lead_status = 'agent_review'`
      const searchQuery = `SELECT  leads.*,aglead.*
       FROM  ${db_table.leads} AS leads
       LEFT JOIN  ${db_table.agent_leads} AS aglead
       ON leads.lead_id= aglead.lead_id
       WHERE leads.lead_number LIKE '%${searchValue}%' AND aglead.agent_id = ${agent_id}`;
      const searchResult = await mysqlquery(searchQuery);
      if (searchResult.length > 0) {
        res.status(200).json({
          message: "data available",
          agentdata: searchResult,
        });
      } else {
        res.status(400).json({
          message: "data not available !",
        });
      }
    } else {
      if (search_by === "customer_name") {
        const searchQuery = `SELECT * from ${db_table.users} WHERE CONCAT(first_name,' ', middle_name,' ',last_name) LIKE '%${searchValue}%'`;
        const searchResult = await mysqlquery(searchQuery);
        if (searchResult.length > 0) {
          res.status(200).json({
            message: "data available",
            agent_data: searchResult,
          });
        } else {
          res.status(400).json({
            message: "data not available !",
          });
        }
      }
    }
  } catch (error) {
    res.status(400).json({
      msg: error.message ? error.message : error,
    });
  }
};

async function customerAccountInfo(userId) {
  let sql = `SELECT users.user_id,applicant.*,fatca.*,customerprofile.*,addressdetail.*,contactdetail.*,kycdetail.*,kycpio.*,bankfaciliti.*,nominations.*,leads.*, `;
  sql += `(SELECT countrie_name FROM ${db_table.countires} c WHERE FIND_IN_SET(c.countrie_id,applicant.country_id)) country_name, `;
  sql += `(SELECT countrie_name FROM ${db_table.countires} c WHERE FIND_IN_SET(c.countrie_id,applicant.nationality)) nationality_name, `;
  sql += `(SELECT countrie_name FROM ${db_table.countires} c WHERE FIND_IN_SET(c.countrie_id,fatca.tin_country_id)) tin_country_name, `;
  sql += `(SELECT countrie_name FROM ${db_table.countires} c WHERE FIND_IN_SET(c.countrie_id,fatca.tin_issue_county_id)) tin_issue_country_name, `;
  sql += `(SELECT countrie_name FROM ${db_table.countires} c WHERE FIND_IN_SET(c.countrie_id,fatca.birth_county_id)) birth_country_name, `;
  sql += `(SELECT religion_name FROM ${db_table.religions} r WHERE FIND_IN_SET(r.religion_id,applicant.religion_id)) religion_name, `;
  sql += `(SELECT employment_types_name FROM ${db_table.employment_types} e WHERE FIND_IN_SET(e.employment_types_id,customerprofile.employment_type_id)) employment_type, `;
  sql += `(SELECT industrie_name FROM ${db_table.industries} i WHERE FIND_IN_SET(i.industrie_id,customerprofile.industry_type_id)) industrie_name, `;
  sql += `(SELECT address_type_name  FROM ${db_table.address_type} address WHERE FIND_IN_SET(address.address_type_id,addressdetail.current_address_type)) address_type, `;
  sql += `(SELECT countrie_name FROM ${db_table.countires} c WHERE FIND_IN_SET(c.countrie_id,addressdetail.current_country_id)) current_country_name, `;
  sql += `(SELECT address_type_name  FROM ${db_table.address_type} address WHERE FIND_IN_SET(address.address_type_id,addressdetail.overseas_address_type)) overseas_type_address, `;
  sql += `(SELECT countrie_name FROM ${db_table.countires} c WHERE FIND_IN_SET(c.countrie_id,addressdetail.overseas_country_id)) overseas_country, `;
  sql += `(SELECT address_type_name  FROM ${db_table.address_type} address WHERE FIND_IN_SET(address.address_type_id,addressdetail.permenant_address_type)) permenant_type_address, `;
  sql += `(SELECT countrie_name FROM ${db_table.countires} c WHERE FIND_IN_SET(c.countrie_id,addressdetail.permenant_country_id)) permenant_country, `;
  sql += `(SELECT address_type_name  FROM ${db_table.address_type} address WHERE FIND_IN_SET(address.address_type_id,addressdetail.jurisdiction_address_type)) jurisdiction_type_address, `;
  sql += `(SELECT countrie_name FROM ${db_table.countires} c WHERE FIND_IN_SET(c.countrie_id,addressdetail.jurisdiction_country_id)) jurisdiction_country, `;
  sql += `(SELECT visa_type_name FROM ${db_table.visa_type} v WHERE FIND_IN_SET(v.visa_type_id,kycdetail.visa_type)) visa_type_name `;
  sql += `FROM tbl_users as users `;
  sql += `LEFT JOIN ${db_table.applicant_persional_details} as applicant on applicant.user_id=users.user_id `;
  sql += `LEFT JOIN ${db_table.customer_profilers} as customerprofile on  applicant.applicant_personal_id=customerprofile.applicant_id `;
  sql += `LEFT JOIN ${db_table.address_details} as addressdetail on applicant.applicant_personal_id=addressdetail.applicant_id `;
  sql += `LEFT JOIN ${db_table.factas} as fatca on applicant.applicant_personal_id=fatca.applicant_id `;
  sql += `LEFT JOIN ${db_table.contact_details} as contactdetail on applicant.applicant_personal_id=contactdetail.applicant_id `;
  sql += `LEFT JOIN ${db_table.kyc_details} as kycdetail on applicant.applicant_personal_id=kycdetail.applicant_id `;
  sql += `LEFT JOIN ${db_table.kyc_pio_declarations} as kycpio on applicant.applicant_personal_id=kycpio.applicant_id `;
  sql += `LEFT JOIN ${db_table.banking_facilities} as bankfaciliti on applicant.applicant_personal_id=bankfaciliti.applicant_id `;
  sql += `LEFT JOIN ${db_table.nominations} as nominations on applicant.applicant_personal_id=nominations.applicant_id `;
  sql += `LEFT JOIN ${db_table.leads} as leads on leads.user_id=users.user_id `;
  sql += `WHERE users.user_id=?`;

  return await mysqlquery(sql, [userId]);
}

//   module.exports.createPdf = function(req,res){

//         try{
//         // var path = 'file:///home/fortune4/Desktop/Rbl_Nri/nri_new-20220228T081349Z-001/nri_new/controller/src/api/RblNri/Modules/mount3.jpg';
//         var path = 'https://images-htschool.hindustantimes.com/wp-content/uploads/2021/03/Entrepreneurship-Essentials.jpg';
//       var table
//       table += "<tr>";
//       table += "<table  border='1' style='width:100%;word-break:break-word;'>";

//       table += "</tr>";

//           table += "<tr>";
//          table+= "<img src=https://images-htschool.hindustantimes.com/wp-content/uploads/2021/03/Entrepreneurship-Essentials.jpg>"

//           table += "</tr>";

//       table += "</table>";
//       var options = {
//         format: "A2",
//         orientation: "portrait",
//         border: "10mm",
//         header: {
//             height: "20mm",

//         },

//       };

//       pdf.create(table, options).toFile('newljj.pdf', function(err, result) {
//         if (err) return console.log(err);
//         console.log("pdf create");
//         res.download('newljj.pdf');
//       });
//       }catch(error) {
//         res.status(400).json({
//             msg:error
//         })
//       }
//       }

// getall_newleads_perpage=async(req,res)=>{
//     let pageno =0;
//     req.body.pageno===undefined?pageno=1:pageno=req.body.pageno;
//     offset = 3 * (pageno-1);
//     try {
//         const newlead = await mysqlquery(query.select.getll_newleads_perpage,["new",offset]);
//         res.status(200).json({
//             msg:newlead
//         })
//       } catch(error) {
//           res.status(400).json({
//               msg:error
//           })

//       }
//   }

//   getall_newleads_no_of_buttons=async(req,res)=>{
//     try {
//         const getall_newleads = await mysqlquery(query.select.count_newlead,['new']);
//         const getall_newlead = JSON.stringify(getall_newleads);
//         const allnewlead = JSON.parse(getall_newlead);
//         var total = allnewlead.map(function(obj) {
//           return obj.totalnewleads;
//           });

//           var iterator = total.values();
//           var totalnewleads = iterator.next().value;

//           var total_button = totalnewleads/3;
//           var totalnewleads_buttons = Math.ceil(total_button);

//         res.status(200).json({
//             data:totalnewleads_buttons
//         })
//       } catch(error) {
//           res.status(400).json({
//               msg:error
//           })

//       }
//   }

//   getall_newleads_next_page=async(req,res)=>{
//     try {
//         const getall_newleads = await mysqlquery(query.select.count_newlead,['new']);
//         const getall_newlead = JSON.stringify(getall_newleads);
//         const allnewlead = JSON.parse(getall_newlead);
//         var total = allnewlead.map(function(obj) {
//           return obj.totalnewleads;
//           });

//           var iterator = total.values();
//           var totalnewleads = iterator.next().value;

//           var total_button = totalnewleads/3;
//           var totalnewleads_buttons = Math.ceil(total_button);

//   if(req.body.pageno>=1 && req.body.pageno<=totalnewleads_buttons){

//     var pageno = req.body.pageno;
//     offset = 3 * ((pageno+1)-1);

//         const newleads_perpage = await mysqlquery(query.select.getll_newleads_perpage,['new',offset]);
//         res.status(200).json({
//             data:newleads_perpage
//         })
//       }else{
//           res.status(400).json({
//             msg:"bad request"
//           })
//         }
//       } catch(error) {
//           res.status(400).json({
//               msg:error
//           })

//       }
//   }

//   newleads_previous_page=async(req,res)=>{
//     try {
//         const getall_newleads = await mysqlquery(query.select.count_newlead,['new']);
//         const getall_newlead = JSON.stringify(getall_newleads);
//         const allnewlead = JSON.parse(getall_newlead);
//         var total = allnewlead.map(function(obj) {
//           return obj.totalnewleads;
//           });

//           var iterator = total.values();
//           var totalnewleads = iterator.next().value;

//           var total_button = totalnewleads/3;
//           var totalnewleads_buttons = Math.ceil(total_button);

//   if(req.body.pageno>=1 && req.body.pageno<=totalnewleads_buttons){

//     var pageno = req.body.pageno;
//     offset = 3 * ((pageno-1)-1);
//     offset<0?offset=0:offset=offset;
//         const newleads_perpage = await mysqlquery(query.select.getll_newleads_perpage,['new',offset]);
//         res.status(200).json({
//             msg:newleads_perpage
//         })
//       }else{
//         let offset=0;
//         const newleads_perpage = await mysqlquery(query.select.getll_newleads_perpage,['new',offset]);
//         res.status(200).json({
//             msg:newleads_perpage
//         })
//       }
//       } catch(error) {
//           res.status(400).json({
//               msg:error
//           })
//       }
//   }

// count_newlead=async(req,res)=>{
// try {
//     const countnewlead = await mysqlquery(query.select.count_newlead,["new"]);
//     res.status(200).json({
//         msg:countnewlead
//     })
//   } catch(error) {
//       res.status(400).json({
//           msg:error
//       })

//   }
// }

// leadacceptcustomer=async(req,res)=>{
//     try {
//         const leadacceptcustomer = await mysqlquery(query.update.leadacceptcustomer,[req.body.agent_id,"process",req.body.id]);
//         res.status(200).json({
//             msg:leadacceptcustomer
//         })
//       } catch(error) {
//           res.status(400).json({
//               msg:error
//           })

//       }
//     }

// count_processlead=async(req,res)=>{
//     try {
//         const count_processlead = await mysqlquery(query.select.count_processlead,[req.body.agent_id,'process']);
//         res.status(200).json({
//             msg:count_processlead
//         })
//       } catch(error) {
//           res.status(400).json({
//               msg:error
//           })

//       }
//     }

//     getall_process_perpage=async(req,res)=>{
//       let pageno =0;
//       req.body.pageno===undefined?pageno=1:pageno=req.body.pageno;
//       offset = 3 * (pageno-1);
//         try {
//             const processleasd = await mysqlquery(query.select.getall_processlead_perpage,[req.body.agent_id,"process",offset]);
//             res.status(200).json({
//                 data:processleasd
//             })
//           } catch(error) {
//               res.status(400).json({
//                   msg:error
//               })

//           }
//       }

//       getall_process_no_of_buttons=async(req,res)=>{
//         try {
//             const getall_processleads= await mysqlquery(query.select.count_processlead,[req.body.agent_id,"process"]);
//             const getall_processlead = JSON.stringify(getall_processleads);
//             const processleads = JSON.parse(getall_processlead);
//             var total = processleads.map(function(obj) {
//               return obj.totalprocesslead;
//               });

//               var iterator = total.values();
//               var totalprocesslead = iterator.next().value;

//               var total_button = totalprocesslead/3;
//               var totalprocess_buttons = Math.ceil(total_button);

//             res.status(200).json({
//                 data:totalprocess_buttons
//             })
//           } catch(error) {
//               res.status(400).json({
//                   msg:error
//               })

//           }
//       }

//       getall_process_next_page=async(req,res)=>{
//         try {
//             const getall_processleads = await mysqlquery(query.select.count_processlead,[req.body.agent_id,"process"]);
//             const getall_processlead = JSON.stringify(getall_processleads);
//             const allprocesslead = JSON.parse(getall_processlead);
//             var total = allprocesslead.map(function(obj) {
//               return obj.totalprocesslead;
//               });

//               var iterator = total.values();
//               var totalprocesslead = iterator.next().value;

//               var total_button = totalprocesslead/3;
//               var totalprocess_buttons = Math.ceil(total_button);

//       if(req.body.pageno>=1 && req.body.pageno<=totalprocess_buttons){

//         var pageno = req.body.pageno;
//         offset = 3 * ((pageno+1)-1);

//             const processleads_perpage = await mysqlquery(query.select.getall_processlead_perpage,[req.body.agent_id,"process",offset]);
//             res.status(200).json({
//                 data:processleads_perpage
//             })
//           }else{
//               res.status(400).json({
//                 msg:"bad request"
//               })
//             }
//           } catch(error) {
//               res.status(400).json({
//                   msg:error
//               })

//           }
//       }

//       process_previous_page=async(req,res)=>{
//         try {
//             const getall_processleads = await mysqlquery(query.select.count_processlead,[req.body.agent_id,"process"]);
//             const getall_processlead = JSON.stringify(getall_processleads);
//             const allprocesslead = JSON.parse(getall_processlead);
//             var total = allprocesslead.map(function(obj) {
//               return obj.totalprocesslead;
//               });

//               var iterator = total.values();
//               var totalprocesslead = iterator.next().value;

//               var total_button = totalprocesslead/3;
//               var totalprocess_buttons = Math.ceil(total_button);
//       if(req.body.pageno>=1 && req.body.pageno<=totalprocess_buttons){

//         var pageno = req.body.pageno;
//         offset = 3 * ((pageno-1)-1);

//             const process_perpage = await mysqlquery(query.select.getall_processlead_perpage,[req.body.agent_id,"process",offset]);
//             res.status(200).json({
//                 msg:process_perpage
//             })
//           }else{
//             res.status(400).json({
//               msg:"bad request"
//             })
//           }
//           } catch(error) {
//               res.status(400).json({
//                   msg:error
//               })
//           }
//       }

// getall_processlead=async(req,res)=>{
//     try {
//         const getall_processlead = await mysqlquery(query.select.getall_processlead,[req.body.agent_id,"process"]);
//         res.status(200).json({
//             msg:getall_processlead
//         })
//       } catch(error) {
//           res.status(400).json({
//               msg:error
//           })

//       }
//     }

// count_leadswith_query=async(req,res)=>{
//     try {
//         const count_leadswithquery = await mysqlquery(query.select.count_leadswithquery,[req.body.agent_id,'leads with query']);
//         res.status(200).json({
//             msg:count_leadswithquery
//         })
//       } catch(error) {
//           res.status(400).json({
//               msg:error
//           })

//       }
//     }

// // getall_leadswith_query=async(req,res)=>{
// //     try {
// //         const gellall_leadswithquery = await mysqlquery(query.select.gellall_leadswithquery,[req.body.agent_id,'leads with query']);
// //         res.status(200).json({
// //             msg:gellall_leadswithquery
// //         })
// //       } catch(error) {
// //           res.status(400).json({
// //               msg:error
// //           })

// //       }
// //     }

//     getall_querylead_perpage=async(req,res)=>{
//       let pageno =0;
//       req.body.pageno===undefined?pageno=1:pageno=req.body.pageno;
//       offset = 3 * (pageno-1);
//         try {
//             const queryleads = await mysqlquery(query.select.gellall_leadswithquery_perpage,[req.body.agent_id,"leads with query",offset]);
//             res.status(200).json({
//                 data:queryleads
//             })
//           } catch(error) {
//               res.status(400).json({
//                   msg:error
//               })

//           }
//       }

//       getall_query_no_of_buttons=async(req,res)=>{
//         try {
//             const getall_queryleads= await mysqlquery(query.select.count_leadswithquery,[req.body.agent_id,"leads with query"]);
//             const getall_querylead = JSON.stringify(getall_queryleads);
//             const queryleads = JSON.parse(getall_querylead);
//             var total = queryleads.map(function(obj) {
//               return obj.totalquerylead;
//               });

//               var iterator = total.values();
//               var totalquerylead = iterator.next().value;

//               var total_button = totalquerylead/3;
//               var totalquerylead_buttons = Math.ceil(total_button);

//             res.status(200).json({
//                 data:totalquerylead_buttons
//             })
//           } catch(error) {
//               res.status(400).json({
//                   msg:error
//               })

//           }
//       }

//       getall_querylead_next_page=async(req,res)=>{
//         try {
//             const getall_queryleads= await mysqlquery(query.select.count_leadswithquery,[req.body.agent_id,"leads with query",offset]);
//             const getall_querylead = JSON.stringify(getall_queryleads);
//             const queryleads = JSON.parse(getall_querylead);
//             var total = queryleads.map(function(obj) {
//               return obj.totalquerylead;
//               });

//               var iterator = total.values();
//               var totalquerylead = iterator.next().value;

//               var total_button = totalquerylead/3;
//               var totalquerylead_buttons = Math.ceil(total_button);

//       if(req.body.pageno>=1 && req.body.pageno<=totalquerylead_buttons){

//         var pageno = req.body.pageno;
//         offset = 3 * ((pageno+1)-1);

//             const queryleads_perpage = await mysqlquery(query.select.gellall_leadswithquery_perpage,[req.body.agent_id,"leads with query",offset]);
//             res.status(200).json({
//                 data:queryleads_perpage
//             })
//           }else{
//               res.status(400).json({
//                 msg:"bad request"
//               })
//             }
//           } catch(error) {
//               res.status(400).json({
//                   msg:error
//               })

//           }
//       }

//       querylead_previous_page=async(req,res)=>{
//         try {
//             const getall_queryleads= await mysqlquery(query.select.count_leadswithquery,[req.body.agent_id,"leads with query",offset]);
//             const getall_querylead = JSON.stringify(getall_queryleads);
//             const queryleads = JSON.parse(getall_querylead);
//             var total = queryleads.map(function(obj) {
//               return obj.totalquerylead;
//               });

//               var iterator = total.values();
//               var totalquerylead = iterator.next().value;

//               var total_button = totalquerylead/3;
//               var totalquerylead_buttons = Math.ceil(total_button);
//       if(req.body.pageno>=1 && req.body.pageno<=totalquerylead_buttons){

//         var pageno = req.body.pageno;
//         offset = 3 * ((pageno-1)-1);

//         const queryleads_perpage = await mysqlquery(query.select.gellall_leadswithquery_perpage,[req.body.agent_id,"leads with query",offset]);
//         res.status(200).json({
//             data:queryleads_perpage
//         })
//           }else{
//             res.status(400).json({
//               msg:"bad request"
//             })
//           }
//           } catch(error) {
//               res.status(400).json({
//                   msg:error
//               })
//           }
//       }

// getall_approvedleads=async(req,res)=>{
//     try {
//         const getall_approvedleads = await mysqlquery(query.select.getall_approvedleads,[req.body.agent_id,'approved']);
//         res.status(200).json({
//             msg:getall_approvedleads
//         })
//       } catch(error) {
//           res.status(400).json({
//               msg:error
//           })

//       }
//     }

//     getall_approvedlead_perpage=async(req,res)=>{
//       let pageno =0;
//       req.body.pageno===undefined?pageno=1:pageno=req.body.pageno;
//       offset = 3 * (pageno-1);
//         try {
//             const approved = await mysqlquery(query.select.gellall_approved_perpage,[req.body.agent_id,"approved",offset]);
//             res.status(200).json({
//                 data:approved
//             })
//           } catch(error) {
//               res.status(400).json({
//                   msg:error
//               })

//           }
//       }

//       getall_approvedleads_no_of_buttons=async(req,res)=>{
//         try {
//             const getall_approvedleads= await mysqlquery(query.select.count_approverlead,[req.body.agent_id,"approved"]);
//             const getall_approvedlead = JSON.stringify(getall_approvedleads);
//             const approvedleads = JSON.parse(getall_approvedlead);
//             var total = approvedleads.map(function(obj) {
//               return obj.totalapprovedlead;
//               });

//               var iterator = total.values();
//               var totalapprovedlead = iterator.next().value;

//               var total_button = totalapprovedlead/3;
//               var totalapprovedlead_buttons = Math.ceil(total_button);

//             res.status(200).json({
//                 data:totalapprovedlead_buttons
//             })
//           } catch(error) {
//               res.status(400).json({
//                   msg:error
//               })

//           }
//       }

//       getall_approvedlead_next_page=async(req,res)=>{
//         try {
//             const getall_approvedleads= await mysqlquery(query.select.count_approverlead,[req.body.agent_id,"approved"]);
//             const getall_approvedlead = JSON.stringify(getall_approvedleads);
//             const approvedleads = JSON.parse(getall_approvedlead);
//             var total = approvedleads.map(function(obj) {
//               return obj.totalapprovedlead;
//               });

//               var iterator = total.values();
//               var totalapprovedlead = iterator.next().value;

//               var total_button = totalapprovedlead/3;
//               var totalapprovedlead_buttons = Math.ceil(total_button);

//       if(req.body.pageno>=1 && req.body.pageno<=totalapprovedlead_buttons){

//         var pageno = req.body.pageno;
//         offset = 3 * ((pageno+1)-1);

//             const approvedleads_perpage = await mysqlquery(query.select.gellall_approved_perpage,[req.body.agent_id,"approved",offset]);
//             res.status(200).json({
//                 data:approvedleads_perpage
//             })
//           }else{
//               res.status(400).json({
//                 msg:"bad request"
//               })
//             }
//           } catch(error) {
//               res.status(400).json({
//                   msg:error
//               })

//           }
//       }

//       approvedlead_previous_page=async(req,res)=>{
//         try {
//             const getall_approvedleads= await mysqlquery(query.select.count_approverlead,[req.body.agent_id,"approved"]);
//             const getall_approvedlead = JSON.stringify(getall_approvedleads);
//             const approvedleads = JSON.parse(getall_approvedlead);
//             var total = approvedleads.map(function(obj) {
//               return obj.totalapprovedlead;
//               });

//               var iterator = total.values();
//               var totalapprovedlead = iterator.next().value;

//               var total_button = totalapprovedlead/3;
//               var totalapprovedlead_buttons = Math.ceil(total_button);;
//       if(req.body.pageno>=1 && req.body.pageno<=totalapprovedlead_buttons){

//         var pageno = req.body.pageno;
//         offset = 3 * ((pageno-1)-1);

//         const approvedleads_perpage = await mysqlquery(query.select.gellall_approved_perpage,[req.body.agent_id,"approved",offset]);
//         res.status(200).json({
//             data:approvedleads_perpage
//         })
//           }else{
//             res.status(400).json({
//               msg:"bad request"
//             })
//           }
//           } catch(error) {
//               res.status(400).json({
//                   msg:error
//               })
//           }
//       }

// getall_rejectedleads=async(req,res)=>{
//     try {
//         const getall_rejectedleads = await mysqlquery(query.select.getall_rejectedleads,[req.body.agent_id,'rejected']);
//         res.status(200).json({
//             msg:getall_rejectedleads
//         })
//       } catch(error) {
//           res.status(400).json({
//               msg:error
//           })

//       }
//     }

// getall_rejectedlead_perpage=async(req,res)=>{
//   let pageno =0;
//   req.body.pageno===undefined?pageno=1:pageno=req.body.pageno;
//   offset = 3 * (pageno-1);
//         try {
//             const rejected = await mysqlquery(query.select.gellall_rejected_perpage,[req.body.agent_id,"rejected",offset]);
//             res.status(200).json({
//                 data:rejected
//             })
//           } catch(error) {
//               res.status(400).json({
//                   msg:error
//               })

//           }
//       }

//       getall_rejectedleads_no_of_buttons=async(req,res)=>{
//         try {
//             const getall_rejectedleads= await mysqlquery(query.select.count_rejectedlead,[req.body.agent_id,"rejected"]);
//             const getall_rejectedlead = JSON.stringify(getall_rejectedleads);
//             const rejectedleads = JSON.parse(getall_rejectedlead);
//             var total = rejectedleads.map(function(obj) {
//               return obj.totalrejectedlead;
//               });

//               var iterator = total.values();
//               var totalrejectedlead = iterator.next().value;

//               var total_button = totalrejectedlead/3;
//               var totalrejectedlead_buttons = Math.ceil(total_button);

//             res.status(200).json({
//                 data:totalrejectedlead_buttons
//             })
//           } catch(error) {
//               res.status(400).json({
//                   msg:error
//               })

//           }
//       }

//       getall_rejectedlead_next_page=async(req,res)=>{
//         try {
//             const getall_rejectedleads= await mysqlquery(query.select.count_rejectedlead,[req.body.agent_id,"rejected"]);
//             const getall_rejectedlead = JSON.stringify(getall_rejectedleads);
//             const rejectedleads = JSON.parse(getall_rejectedlead);
//             var total = rejectedleads.map(function(obj) {
//               return obj.totalrejectedlead;
//               });

//               var iterator = total.values();
//               var totalrejectedlead = iterator.next().value;

//               var total_button = totalrejectedlead/3;
//               var totalrejectedlead_buttons = Math.ceil(total_button);

//       if(req.body.pageno>=1 && req.body.pageno<=totalrejectedlead_buttons){

//         var pageno = req.body.pageno;
//         offset = 3 * ((pageno+1)-1);

//             const rejectedlead_perpage = await mysqlquery(query.select.gellall_rejected_perpage,[req.body.agent_id,"rejected",offset]);
//             res.status(200).json({
//                 data:rejectedlead_perpage
//             })
//           }else{
//               res.status(400).json({
//                 msg:"bad request"
//               })
//             }
//           } catch(error) {
//               res.status(400).json({
//                   msg:error
//               })

//           }
//       }

//       rejectedlead_previous_page=async(req,res)=>{
//         try {
//             const getall_rejectedleads= await mysqlquery(query.select.count_rejectedlead,[req.body.agent_id,"rejected"]);
//             const getall_rejectedlead = JSON.stringify(getall_rejectedleads);
//             const rejectedleads = JSON.parse(getall_rejectedlead);
//             var total = rejectedleads.map(function(obj) {
//               return obj.totalrejectedlead;
//               });

//               var iterator = total.values();
//               var totalrejectedlead = iterator.next().value;

//               var total_button = totalrejectedlead/3;
//               var totalrejectedlead_buttons = Math.ceil(total_button);
//       if(req.body.pageno>=1 && req.body.pageno<=totalrejectedlead_buttons){

//         var pageno = req.body.pageno;
//         offset = 3 * ((pageno-1)-1);

//         const rejectedlead_perpage = await mysqlquery(query.select.gellall_rejected_perpage,[req.body.agent_id,"rejected",offset]);
//         res.status(200).json({
//             data:rejectedlead_perpage
//         })
//           }else{
//             res.status(400).json({
//               msg:"bad request"
//             })
//           }
//           } catch(error) {
//               res.status(400).json({
//                   msg:error
//               })
//           }
//       }

// add_comments=async(req,res)=>{
//     if(!req.body.comment_lead_id){
//         if(req.body.comments_text){
//             try{
//             let addcomments={form_id:req.body.form_id,comments_text:req.body.comments_text,lead_form_comment_status:"inprocess",lead_id:req.body.lead_id,user_id:req.body.user_id,status:"true",created_at:new Date()};
//            const add_lead_comments_approved= await mysqlquery(query.insert.add_lead_comments,addcomments);
//            res.status(200).json({
//             msg:"comment save successfully",
//             data:add_lead_comments_approved
//         })
//           }catch(error) {
//           res.status(400).json({
//               msg:error
//             })
//         }
//         }else{
//         try{
//         let addcomments={form_id:req.body.form_id,comments_text:req.body.comments_text,lead_form_comment_status:"approved",lead_id:req.body.lead_id,user_id:req.body.user_id,status:"true",created_at:new Date()};
//            const add_lead_comments_approved= await mysqlquery(query.insert.add_lead_comments,addcomments);
//            res.status(200).json({
//             msg:"approved successfully",
//             data:add_lead_comments_approved
//         })
//           }catch(error) {
//           res.status(400).json({
//               msg:error
//             })
//         }
//       }
//             }else{
//                if(req.body.comment_lead_id){
//                 if(req.body.comments_text){
//                     try{
//                     let leadcomments=[req.body.comments_text,"inprocess","true",new Date(),req.body.comment_lead_id]
//                const updatecomments = await mysqlquery(query.update.updatecomments,leadcomments)
//                res.status(200).json({
//                 msg:"comment update successfully",
//                 data:updatecomments
//             })
//               }catch(error) {
//               res.status(400).json({
//                   msg:error
//                 })
//               }
//                 }else{
//                    try{
//             let leadcomments=[req.body.comments_text,"approved","true",new Date(),req.body.comment_lead_id]
//                const updatecomments = await mysqlquery(query.update.updatecomments,leadcomments)
//                res.status(200).json({
//                 msg:"approved update successfully",
//                 data:updatecomments
//             })
//               }catch(error) {
//               res.status(400).json({
//                   msg:error
//                 })
//               }
//             }
//            }
//          }
//        }

// get_form_comments=async(req,res)=>{
//  try {
//     const form_comments_approved = await mysqlquery(query.select.get_form_comments,[req.body.lead_id,req.body.form_id]);
//     res.status(200).json({
//         msg:form_comments_approved
//     })
//   } catch(error) {
//       res.status(400).json({
//           msg:error
//       })

//   }
// }

// send_reminder=async(req,res)=>{
//     try{
//         const lead_data = await mysqlquery(query.select.find_lead_data,[req.body.lead_id]);
//         console.log(lead_data)
//         const customer_data = JSON.stringify(lead_data);
//         const customerdata = JSON.parse(customer_data);
//      var customer_id= customerdata.map(function(obj) {
//         return obj.customer_id;
//     });
//     var iterator = customer_id.values();
//     var customerid = iterator.next().value;
//     console.log(customerid)

//     var action = "reminder";
//      var notification_data =" your lead is in with query please updated";
//      const users = await mysqlquery(query.select.customer_id,[customerid]);
//      users.forEach(function(user){
//          notification_function.notification(action,notification_data,user.id)
//       })

//        res.status(200).json({
//         msg:"send_reminder successfully",
//     })
//       }catch(error) {
//       res.status(400).json({
//           msg:error
//         })
//     }
// }

// module.exports={
// getall_newleads_perpage,
// getall_newleads_no_of_buttons,
// getall_newleads_next_page,
// newleads_previous_page,
// count_newlead,
// leadacceptcustomer,
// count_processlead,
// getall_processlead,
// getall_process_next_page,
// getall_process_perpage,
// getall_process_no_of_buttons,
// process_previous_page,
// count_leadswith_query,
// // getall_leadswith_query,
// getall_querylead_perpage,
// getall_query_no_of_buttons,
// getall_querylead_next_page,
// querylead_previous_page,
// getall_approvedlead_perpage,
// getall_approvedleads_no_of_buttons,
// getall_approvedlead_next_page,
// approvedlead_previous_page,
// getall_approvedleads,
// getall_rejectedleads,
// getall_rejectedlead_perpage,
// getall_rejectedleads_no_of_buttons,
// getall_rejectedlead_next_page,
// rejectedlead_previous_page,
// add_comments,
// get_form_comments,
// send_reminder,
// getall_newleads

// }comment
