var moment = require('moment');
var path = require('path');
var fs = require('fs');
const query = require('../../../../../db/query.json')
var mysqlconn = require('../../../../../db/mysqlconn');
const util = require('util');
const mysqlquery = util.promisify(mysqlconn.query).bind(mysqlconn);

module.exports.getnotification = async (req, res) => {
    try {
        var view_data = [];
        var notification_no = 0;
        var data = await mysqlquery(query.select.getnotifications, ["false", req.body.userId])
        data.forEach(function (application) {
            // 
            if (application.read_notification == 'false') {
                notification_no += 1;
            }
            view_data.push({
                id: application._id,
                notification_data: application.notification_data,
                read: application.read_notification,
                created_at: moment(application.createdOn).fromNow(),
                url_data: application.url_data,
                query_param: application.query_params,
                action: application.action,
            })
        })
        setTimeout(function () {
            res.status(200).send({
                data: view_data,
                notification_no: notification_no
            })
        }, 1000)
    } catch (error) {
        res.status(400).json({
            msg:error.message?error.message:error
        })
    }
}

module.exports.deleteNotification = async (req, res) => {
    try {
        var notification_id = req.body.noti_id;
        const notification_delete = await mysqlquery(query.update.notification_delete, ["true", notification_id]);
        if (notification_delete.affectedRows > 0) {
            res.status(200).json({
                msg: "notification delete",
                data: notification_delete,
                applicant_id: req.body.applicant_id,
                account_type_id: account_type_id

            })
        } else {
            res.status(400).json({
                msg: "something went wrong",

            })
        }

    } catch (error) {
        res.status(400).json({
            msg:error.message?error.message:error
        })

    }
}

module.exports.makeReadNotification = async (req, res) => {
    try {
        var notification_id = req.body.noti_id;
        const notification_read = await mysqlquery(query.update.notification_read, ["true", notification_id]);
        res.status(200).json({
            msg: "notification delete",
            data: notification_read
        })
    } catch (error) {
        res.status(400).json({
            msg:error.message?error.message:error
        })

    }
}

