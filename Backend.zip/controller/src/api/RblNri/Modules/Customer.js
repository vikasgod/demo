var mysqlconn = require("../../../../../db/mysqlconn");
const registration_email = require("../../../../../utils/emailService");
const query = require("../../../../../db/query.json");
const { validationResult, Result } = require("express-validator");
var notification_function = require("../../../../../utils/function");
const util = require("util");
var Convert = require("xml2js");
const https = require("https");
const { v4: uuidv4 } = require("uuid");
const { nextTick } = require("process");
const { NULL } = require("mysql/lib/protocol/constants/types");
const mysqlquery = util.promisify(mysqlconn.query).bind(mysqlconn);
const db_table = require("../../../../../db_manipulation/db_constant");
const fs = require("fs");
const fsPromises = require("fs").promises;
const { Console } = require("console");
const moment = require("moment");
const { default: axios } = require("axios");

const religion_categories_json = require("../../../../../json/religion_categories.json");
const occuption_json = require("../../../../../json/occutption.json");
const gross_income_json = require("../../../../../json/gross_income_range.json");
const account_json = require("../../../../../json/account.json");
const card_variant_json = require("../../../../../json/card_variant.json");
const customer_forms = require("../../../../../json/customer_forms.json");
const titles_json = require("../../../../../json/title.json");

const path = require("path");
const { forEachLimit } = require("async");
const { Connection } = require("puppeteer");
const e = require("connect-flash");

//forms start//

module.exports.getall_account_type = async (req, res) => {
  try {
    let account = account_json;
    res.status(200).json({
      data: account,
    });
  } catch (error) {
    res.status(400).json({
      msg: error.message ? error.message : error,
    });
  }
};

module.exports.getall_titles = async (req, res) => {
  try {
    let titles = titles_json;

    res.status(200).json({
      data: titles,
    });
  } catch (error) {
    res.status(400).json({
      msg: error.message ? error.message : error,
    });
  }
};

module.exports.getall_card_variant = async (req, res) => {
  try {
    let card_variant = card_variant_json;
    res.status(200).json({
      data: card_variant,
    });
  } catch (error) {
    res.status(400).json({
      msg: error.message ? error.message : error,
    });
  }
};

module.exports.getall_address_type = async (req, res) => {
  try {
    let customer_address_type = `SELECT * FROM ${db_table.address_type}`;
    const getall_customer_address_type = await mysqlquery(
      customer_address_type
    );
    res.status(200).json({
      data: getall_customer_address_type,
    });
  } catch (error) {
    res.status(400).json({
      msg: error.message ? error.message : error,
    });
  }
};

module.exports.getall_religion_category = async (req, res) => {
  try {
    const getall_customer_category = religion_categories_json;
    res.status(200).json({
      data: getall_customer_category,
    });
  } catch (error) {
    res.status(400).json({
      msg: error.message ? error.message : error,
    });
  }
};

module.exports.getall_employment_type = async (req, res) => {
  try {
    let employment_types = `SELECT * FROM ${db_table.employment_types}`;
    const getall_customer_employment_type = await mysqlquery(employment_types);
    res.status(200).json({
      data: getall_customer_employment_type,
    });
  } catch (error) {
    res.status(400).json({
      msg: error.message ? error.message : error,
    });
  }
};

module.exports.getall_gross_annual_income = async (req, res) => {
  try {
    let gross_income = gross_income_json;

    res.status(200).json({
      data: gross_income,
    });
  } catch (error) {
    res.status(400).json({
      msg: error.message ? error.message : error,
    });
  }
};

module.exports.getall_industry_type = async (req, res) => {
  try {
    let industries = `SELECT * FROM ${db_table.industries}`;
    const getall_industries_type = await mysqlquery(industries);
    res.status(200).json({
      data: getall_industries_type,
    });
  } catch (error) {
    res.status(400).json({
      msg: error.message ? error.message : error,
    });
  }
};

module.exports.getall_occupation_type = async (req, res) => {
  try {
    let occuption = { occuption_json };
    res.status(200).json({
      data: occuption,
    });
  } catch (error) {
    res.status(400).json({
      msg: error.message ? error.message : error,
    });
  }
};

module.exports.getall_proof_address_type = async (req, res) => {
  try {
    let proof_address_type = `SELECT * FROM ${db_table.address_proof_type}`;
    const getall_customer_proof_address_type = await mysqlquery(
      proof_address_type
    );
    res.status(200).json({
      data: getall_customer_proof_address_type,
    });
  } catch (error) {
    res.status(400).json({
      msg: error.message ? error.message : error,
    });
  }
};

module.exports.getall_religion = async (req, res) => {
  try {
    let religions = `SELECT * FROM ${db_table.religions}`;
    const getall_customer_religion = await mysqlquery(religions);
    res.status(200).json({
      data: getall_customer_religion,
    });
  } catch (error) {
    res.status(400).json({
      msg: error.message ? error.message : error,
    });
  }
};

module.exports.getall_visa_type = async (req, res) => {
  try {
    let visa = `SELECT * FROM ${db_table.visa_type}`;
    const getall_customer_visa_type = await mysqlquery(visa);
    res.status(200).json({
      data: getall_customer_visa_type,
    });
  } catch (error) {
    res.status(400).json({
      msg: error.message ? error.message : error,
    });
  }
};

module.exports.getall_countries = async (req, res) => {
  try {
    let countries = `SELECT * FROM ${db_table.countires} order by countrie_name`;
    const getall_country_customer = await mysqlquery(countries);
    res.status(200).json({
      data: getall_country_customer,
    });
  } catch (error) {
    res.status(400).json({
      msg: error.message ? error.message : error,
    });
  }
};

module.exports.getall_customer_forms = async (req, res) => {
  try {
    let customer_form = customer_forms;
    res.status(200).json({
      data: customer_form,
    });
  } catch (error) {
    res.status(400).json({
      msg: error.message ? error.message : error,
    });
  }
};

async function get_table_id(table_params) {
  if (table_params.tableName && table_params.applicant_per_id) {
    table_id = `SELECT * FROM ${table_params.tableName} WHERE ${table_params.applicant_per_id}=?`;
  } else {
    table_id = `SELECT * FROM ${table_params.tableName} WHERE  ${table_params.applicantid}=?`;
  }

  return table_id;
}

module.exports.submit_country_account = async (req, res) => {
  try {
    if (
      req.body.user_id &&
      (req.body.applicant_id === null ||
        req.body.applicant_id === undefined ||
        req.body.applicant_id === "udefined")
    ) {
      //let applicant_serial_num = parseInt(userfind.length)+1;
      //    var aadhar_number=req.body.aadhaar_number.trim();

      let submit_perso_details = {
        user_id: req.body.user_id,
        country_id: req.body.country_id,
        account_type_id: req.body.account_type_id,
        is_trading_facility_opt: req.body.is_trading_facility_opt,
      };
      let sql = `INSERT INTO ${db_table.applicant_persional_details} SET ? `;
      const submit_per_details = await mysqlquery(sql, submit_perso_details);

      const submit_process_data = {
        applicant_id: submit_per_details.insertId,
        process_id: req.body.process_id,
        agent_status: req.body.agent_status,
      };
      let sql_process_data = `INSERT INTO ${db_table.process_status} SET ? `;
      const submit_process = await mysqlquery(
        sql_process_data,
        submit_process_data
      );

      if (submit_per_details.insertId > 0) {
        const submit_lead_history_data = {
          user_id: req.body.user_id,
          status: "customer_process",
        };
        let sql_lead_history__data = `INSERT INTO ${db_table.lead_status_history} SET ? `;
        const submit_lead_history = await mysqlquery(
          sql_lead_history__data,
          submit_lead_history_data
        );
      }
      let find_user = `SELECT * FROM ${db_table.applicant_persional_details} WHERE user_id=? `;
      const userfind = await mysqlquery(find_user, [req.body.user_id]);
      var account_type_id = userfind[0].account_type_id;

      res.status(200).json({
        msg: "save account information successfully",
        applicant_id: submit_per_details.insertId,
        account_type_id: account_type_id,
      });
    } else {
      if (req.body.applicant_id) {
        let applicant_id = req.body.applicant_id;
        let process_id = req.body.process_id;
        let user_sql = `SELECT * FROM ${db_table.applicant_persional_details} WHERE applicant_personal_id=?`;
        let user_result = await mysqlquery(user_sql, [applicant_id]);
        let user_id = user_result[0].user_id;

        const find_appli_id = `SELECT * FROM ${db_table.applicant_persional_details} WHERE applicant_personal_id=?`;
        const Appli_id_result = await mysqlquery(find_appli_id, [
          req.body.applicant_id,
        ]);

        const user_data = Object.values(Appli_id_result);
        const userid = user_data[0].user_id;

        const processdelete = `DELETE FROM  ${db_table.process_status} WHERE applicant_Id=? and process_id=?`;
        const delete_data = await mysqlquery(processdelete, [
          req.body.applicant_id,
          req.body.process_id,
        ]);

        const update_personal_data = [
          userid,
          req.body.country_id,
          req.body.account_type_id,
          req.body.is_trading_facility_opt,
          req.body.applicant_id,
        ];
        let sql = `update ${db_table.applicant_persional_details} SET user_id=?,country_id=?,account_type_id=?, is_trading_facility_opt=? WHERE applicant_personal_id=?`;
        const update_per_data = await mysqlquery(sql, update_personal_data);

        const submit_process_data = {
          applicant_id: req.body.applicant_id,
          process_id: req.body.process_id,
          agent_status: req.body.agent_status,
        };
        let sql_process_data = `INSERT INTO ${db_table.process_status} SET ? `;
        const submit_process = await mysqlquery(
          sql_process_data,
          submit_process_data
        );

        let find_user = `SELECT * FROM ${db_table.applicant_persional_details} WHERE user_id=? `;
        const userfind = await mysqlquery(find_user, [userid]);
        var account_type_id = userfind[0].account_type_id;

        if (update_per_data.affectedRows > 0) {
          let find_user = `SELECT * FROM ${db_table.applicant_persional_details} WHERE user_id=? `;
          let userfind = await mysqlquery(find_user, user_id);

          const sqli = `select lead_status from ${db_table.leads} where user_id=?`;
          const sqli_result = await mysqlquery(sqli, user_id);

          if (sqli_result[0].lead_status === "agent_review") {
            let get_status = `update ${db_table.comment} SET status = 'replied' WHERE applicant_id = ${applicant_id} and process_id = ${process_id}`;
            const status_query = await mysqlquery(get_status);

            const check_all_status = `SELECT status FROM ${db_table.comment} WHERE applicant_id = ? AND STATUS != 'replied'`;
            const check_all_status_result = await mysqlquery(
              check_all_status,
              applicant_id
            );

            if (check_all_status_result.length >= 0) {
              var in_query = "";
              userfind.forEach((uf) => {
                in_query += uf.applicant_personal_id + ",";
              });
              if (in_query != "") {
                in_query = in_query.substring(0, in_query.length - 1);
                const check_all_status = `SELECT status FROM ${db_table.comment} WHERE applicant_id IN (${in_query}) AND STATUS = 'added'`;
                const status_result = await mysqlquery(check_all_status);

                const lead_id = `SELECT lead_id FROM ${db_table.comment} WHERE applicant_id = ?`;
                const result = await mysqlquery(lead_id, applicant_id);

                if (status_result.length === 0) {
                  const update_status = `update ${db_table.leads} set lead_status = 'agent_process' where lead_id = ?`;
                  const results = await mysqlquery(
                    update_status,
                    result[0].lead_id
                  );
                }
              }
            }
          }

          res.status(200).json({
            msg: "update account information successfully",
            applicant_id: req.body.applicant_id,
            account_type_id: account_type_id,
          });
        } else {
          res.status(400).json({
            msg: "something went wrong",
          });
        }
      } else {
        res.status(400).json({
          msg: "bad request",
        });
      }
    }
  } catch (error) {
    res.status(400).json({
      msg: error.message ? error.message : error,
    });
  }
};

module.exports.submit_account_varient = async (req, res) => {
  try {
    if (req.body.applicant_id) {
      const find_appli_id = `SELECT * FROM ${db_table.applicant_persional_details} WHERE applicant_personal_id=?`;
      const Appli_id_result = await mysqlquery(find_appli_id, [
        req.body.applicant_id,
      ]);
      const user_data = Object.values(Appli_id_result);
      const userid = user_data[0].user_id;

      const processdelete = `DELETE FROM  ${db_table.process_status} WHERE applicant_Id=? and process_id=?`;
      const delete_data = await mysqlquery(processdelete, [
        req.body.applicant_id,
        req.body.process_id,
      ]);

      const update_personal_data = [
        userid,
        req.body.account_varient,
        req.body.saving_account,
        req.body.applicant_id,
      ];
      let sql = `update ${db_table.applicant_persional_details} SET user_id=?,account_varient=?,saving_account=? WHERE applicant_personal_id=?`;
      const update_per_data = await mysqlquery(sql, update_personal_data);
      const submit_process_data = {
        applicant_id: req.body.applicant_id,
        process_id: req.body.process_id,
        agent_status: req.body.agent_status,
      };
      let sql_process_data = `INSERT INTO ${db_table.process_status} SET ? `;
      const submit_process = await mysqlquery(
        sql_process_data,
        submit_process_data
      );

      if (update_per_data.affectedRows > 0) {
        res.status(200).json({
          msg: "update account information successfully",
        });
      } else {
        res.status(400).json({
          msg: "something went wrong",
        });
      }
    }
  } catch (error) {
    res.status(400).json({
      msg: error.message ? error.message : error,
    });
  }
};

// module.exports.submit_joint_applicant_details = async (req, res) => {
//     try {
//         const errors = validationResult(req);
//         if (!errors.isEmpty()) {
//             res.status(409).json({ errors: errors.array() });
//         }
//         if (req.body.user_id) {
//             if (req.body.applicant_title && req.body.applicant_first_name && req.body.applicant_middle_name && req.body.applicant_last_name) {

//                 var fist_applicant_sql = `SELECT applicant_personal_id, account_varient, account_type_id FROM ${db_table.applicant_persional_details} Where user_id=?`
//                 var first_applicant_result = await mysqlquery(fist_applicant_sql, [req.body.user_id])

//                 const account_varient = first_applicant_result[0].account_varient
//                 const account_type_id = first_applicant_result[0].account_type_id

//                 const updatequery = `UPDATE ${db_table.applicant_persional_details} SET account_varient = ?, account_type_id=? where user_id = ?`
//                 const updateresult = await mysqlquery(updatequery,[account_varient,account_type_id,req.body.user_id])

//                 var first_applicant_id = first_applicant_result[0].applicant_personal_id;
//                 const update_first_applicant_details = [
//                     1, req.body.applicant_title, req.body.applicant_first_name, req.body.applicant_middle_name, req.body.applicant_last_name, 0, first_applicant_id,
//                 ]

//                 let sql = `UPDATE ${db_table.applicant_persional_details} SET applicant_serial_number=?, applicant_title=?,applicant_first_name=?,applicant_middle_name=?,applicant_last_name=?,is_submited=? WHERE applicant_personal_id=?`;
//                 let update_first_applicant = await mysqlquery(sql, update_first_applicant_details);

//                 let submit_process_data = {
//                     applicant_id: req.body.applicant_id, process_id: req.body.process_id, agent_status: req.body.agent_status
//                 };
//                 let sql_process_data = `INSERT INTO ${db_table.process_status} SET ? `;

//                 let submit_process = await mysqlquery(sql_process_data, submit_process_data);
//             }
//             if (req.body.sec_applicant_title && req.body.sec_applicant_first_name && req.body.sec_applicant_middle_name && req.body.sec_applicant_last_name) {
//                 let finduser1 = `SELECT * FROM ${db_table.applicant_persional_details} WHERE user_id=? `
//                 let userfind1 = await mysqlquery(finduser1, [req.body.user_id]);

//                 if (req.body.account_type_id === 2) {
//                     if (userfind1.length < 3) {
//                         applicant_serial_num1 = (userfind1.length) + 1;
//                     } else {
//                         res.status(200).json({
//                             msg: "minimum 3 applicant allowed",
//                         })
//                     }

//                 }
//                 const submit_applicant_details = {
//                     user_id: req.body.user_id, applicant_serial_number: applicant_serial_num1, applicant_title: req.body.sec_applicant_title, applicant_first_name: req.body.sec_applicant_first_name,
//                     applicant_middle_name: req.body.sec_applicant_middle_name, applicant_last_name: req.body.sec_applicant_last_name, is_submited: 0
//                 };

//                 let sql = `INSERT INTO ${db_table.applicant_persional_details} SET ? `;
//                 var submit_joint_applicant_sec = await mysqlquery(sql, submit_applicant_details);

//                 let submit_process_data = {
//                     applicant_id: req.body.applicant_id, process_id: req.body.process_id, agent_status: req.body.agent_status
//                 };
//                 let sql_process_data = `INSERT INTO ${db_table.process_status} SET ? `;

//                 let submit_process = await mysqlquery(sql_process_data, submit_process_data);

//                 if (req.body.thrd_applicant_title && req.body.thrd_applicant_first_name && req.body.thrd_applicant_middle_name && req.body.thrd_applicant_last_name ) {
//                     let finduser1 = `SELECT * FROM ${db_table.applicant_persional_details} WHERE user_id=? `
//                     let userfind1 = await mysqlquery(finduser1, [req.body.user_id]);

//                     if (req.body.account_type_id === 2) {
//                         if (userfind1.length < 3) {
//                             applicant_serial_num1 = (userfind1.length) + 1;
//                         } else {
//                             res.status(200).json({
//                                 msg: "minimum 3 applicant allowed",
//                             })
//                         }

//                     }
//                     const submit_applicant_details_third = {
//                         user_id: req.body.user_id, applicant_serial_number: applicant_serial_num1, applicant_title: req.body.third_applicant_title, applicant_first_name: req.body.third_applicant_first_name,
//                         applicant_middle_name: req.body.third_applicant_middle_name, applicant_last_name: req.body.third_applicant_last_name, is_submited: 0
//                     };

//                     let sql = `INSERT INTO ${db_table.applicant_persional_details} SET ? `;
//                     var submit_joint_applicant_third = await mysqlquery(sql, submit_applicant_details_third);

//                     let submit_process_data_third = {
//                         applicant_id: req.body.applicant_id, process_id: req.body.process_id, agent_status: req.body.agent_status
//                     };
//                     let sql_process_data = `INSERT INTO ${db_table.process_status} SET ? `;

//                     let submit_process_third = await mysqlquery(sql_process_data, submit_process_data_third);

//                     if (submit_joint_applicant_third.insertId > 0) {
//                         res.status(200).json({
//                             msg: "save applicant data successfully",
//                         })
//                     } else {
//                         res.status(400).json({
//                             msg: "something went wrong"
//                         })
//                     }

//                 } else {
//                     if (submit_joint_applicant_sec.insertId > 0) {
//                         res.status(200).json({
//                             msg: "save applicant data successfully",
//                         })
//                     } else {
//                         res.status(400).json({
//                             msg: "something went wrong"
//                         })
//                     }
//                 }
//             }
//             // if (req.body.third_applicant_title && req.body.third_applicant_first_name && req.body.third_applicant_middle_name && req.body.third_applicant_last_name) {
//             //     let finduser1 = `SELECT * FROM ${db_table.applicant_persional_details} WHERE user_id=? `
//             //     let userfind1 = await mysqlquery(finduser1, [req.body.user_id]);

//             //     if (req.body.account_type_id === 2) {
//             //         if (userfind1.length < 3) {
//             //             applicant_serial_num1 = (userfind1.length) + 1;
//             //         } else {
//             //             res.status(200).json({
//             //                 data: "minimum ",
//             //             })
//             //         }
//             //
//             //     }
//             //     const submit_applicant_details = {
//             //         user_id: req.body.user_id, applicant_serial_number: applicant_serial_num1, applicant_title: req.body.sec_applicant_title, applicant_first_name: req.body.sec_applicant_first_name,
//             //         applicant_middle_name: req.body.sec_applicant_middle_name, applicant_last_name: req.body.sec_applicant_last_name,is_submited:0
//             //     };

//             //     let sql = `INSERT INTO ${db_table.applicant_persional_details} SET ? `;
//             //     const submit_joint_applicant = await mysqlquery(sql, submit_applicant_details);

//             //     const submit_process_data = {
//             //         applicant_id: req.body.applicant_id, process_id: req.body.process_id, agent_status: req.body.agent_status
//             //     };
//             //     let sql_process_data = `INSERT INTO ${db_table.process_status} SET ? `;

//             //     const submit_process = await mysqlquery(sql_process_data, submit_process_data);

//             //     if (submit_joint_applicant.insertId > 0) {
//             //         res.status(200).json({
//             //             data: "save applicant data successfully",
//             //         })
//             //     } else {
//             //         res.status(400).json({
//             //             msg: "something went wrong"
//             //         })
//             //     }
//             // }

//         } else {
//             if (req.body.applicant_id) {

//                 const find_appli_id = `SELECT * FROM ${db_table.applicant_persional_details} WHERE applicant_personal_id=?`
//                 const Appli_id_result = await mysqlquery(find_appli_id, [req.body.applicant_id]);

//                 const user_data = Object.values(Appli_id_result);
//                 const userid = user_data[0].user_id;

//                 const processdelete = `DELETE FROM  ${db_table.process_status} WHERE applicant_Id=? and process_id=?`
//                 const delete_data = await mysqlquery(processdelete, [req.body.applicant_id, req.body.process_id]);

//                 const update_personal_data = [
//                     userid, req.body.applicant_title, req.body.applicant_first_name, req.body.applicant_middle_name, req.body.applicant_last_name,
//                     req.body.applicant_id,
//                 ];
//                 console.log(update_personal_data);
//                 let sql = `update ${db_table.applicant_persional_details} SET user_id=?,applicant_title=?,applicant_first_name=?,applicant_middle_name=?,applicant_last_name=? WHERE applicant_personal_id=?`;
//                 const update_per_data = await mysqlquery(sql, update_personal_data);

//                 const submit_process_data = {
//                     applicant_id: req.body.applicant_id, process_id: req.body.process_id, agent_status: req.body.agent_status
//                 };
//                 let sql_process_data = `INSERT INTO ${db_table.process_status} SET ? `;
//                 const submit_process = await mysqlquery(sql_process_data, submit_process_data);

//                 if (update_per_data.affectedRows > 0) {
//                     res.status(200).json({
//                         msg: "update personal information successfully",
//                     })
//                 } else {
//                     res.status(400).json({
//                         msg: "something went wrong",
//                     })
//                 }
//             } else {
//                 res.status(400).json({
//                     msg: "bad request"
//                 })
//             }
//         }
//     } catch (error) {
//         res.status(400).json({
//             msg: error.message ? error.message : error
//         })
//     }
// }

module.exports.submit_joint_applicant_details = async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      res.status(409).json({ errors: errors.array() });
    }
    if (req.body.user_id) {
      var status = 0;
      var msg = "";
      if (req.body.applicant_title && req.body.applicant_first_name) {
        var fist_applicant_sql = `SELECT applicant_personal_id, account_varient, account_type_id FROM ${db_table.applicant_persional_details} Where user_id=?`;
        var first_applicant_result = await mysqlquery(fist_applicant_sql, [
          req.body.user_id,
        ]);

        const account_varient = first_applicant_result[0].account_varient;
        const account_type_id = first_applicant_result[0].account_type_id;

        const updatequery = `UPDATE ${db_table.applicant_persional_details} SET account_varient = ?, account_type_id=? where user_id = ?`;
        const updateresult = await mysqlquery(updatequery, [
          account_varient,
          account_type_id,
          req.body.user_id,
        ]);

        var first_applicant_id =
          first_applicant_result[0].applicant_personal_id;
        const update_first_applicant_details = [
          1,
          req.body.applicant_title,
          req.body.applicant_first_name,
          req.body.applicant_middle_name,
          req.body.applicant_last_name,
          0,
          first_applicant_id,
        ];

        let sql = `UPDATE ${db_table.applicant_persional_details} SET applicant_serial_number=?, applicant_title=?,applicant_first_name=?,applicant_middle_name=?,applicant_last_name=?,is_submited=? WHERE applicant_personal_id=?`;
        let update_first_applicant = await mysqlquery(
          sql,
          update_first_applicant_details
        );

        let submit_process_data = {
          applicant_id: req.body.applicant_id,
          process_id: req.body.process_id,
          agent_status: req.body.agent_status,
        };
        let sql_process_data = `INSERT INTO ${db_table.process_status} SET ? `;
        let submit_process = await mysqlquery(
          sql_process_data,
          submit_process_data
        );
      }
      if (req.body.sec_applicant_title && req.body.sec_applicant_first_name) {
        // let finduser1 = `SELECT * FROM ${db_table.applicant_persional_details} WHERE user_id=? `
        //   let userfind1 = await mysqlquery(finduser1, [req.body.user_id]);
        //   if (req.body.account_type_id == 2) {
        //       if (userfind1.length < 3) {
        //           applicant_serial_num2 = (userfind1.length) + 1;
        //       } else {
        //           res.status(200).json({
        //               msg: "minimum 3 applicant allowed",
        //           })
        //       }
        //   }
        const finduser = `select * from ${db_table.applicant_persional_details} where user_id = ? and applicant_serial_number = '2'`;
        const result = await mysqlquery(finduser, [req.body.user_id]);

        if (result.length == 0) {
          const submit_applicant_details = {
            user_id: req.body.user_id,
            applicant_serial_number: 2,
            applicant_title: req.body.sec_applicant_title,
            applicant_first_name: req.body.sec_applicant_first_name,
            applicant_middle_name: req.body.sec_applicant_middle_name,
            applicant_last_name: req.body.sec_applicant_last_name,
            is_submited: 0,
          };
          let sql = `INSERT INTO ${db_table.applicant_persional_details} SET ? `;
          const submit_joint_applicant_sec = await mysqlquery(
            sql,
            submit_applicant_details
          );
          const sec_user_id = submit_applicant_details.user_id;
          const serial_no = "2";

          const selectQuery = `select applicant_personal_id from ${db_table.applicant_persional_details} where user_id = ${sec_user_id} and applicant_serial_number = ${serial_no} `;
          const result = await mysqlquery(selectQuery);
          const sec_applicant_id = result[0].applicant_personal_id;

          let submit_process_data = {
            applicant_id: sec_applicant_id,
            process_id: 1,
            agent_status: req.body.agent_status,
          };

          let sql_process_data = `INSERT INTO ${db_table.process_status} SET ?`;
          let submit_process = await mysqlquery(
            sql_process_data,
            submit_process_data
          );

          if (submit_process.affectedRows > 0) {
            status = 1;
          } else {
            status = 0;
          }
        } else {
          const sec_applicant_id = result[0].applicant_personal_id;
          const update_second_applicant_details = [
            2,
            req.body.sec_applicant_title,
            req.body.sec_applicant_first_name,
            req.body.sec_applicant_middle_name,
            req.body.sec_applicant_last_name,
            0,
            sec_applicant_id,
          ];
          const update_user = `update ${db_table.applicant_persional_details} set applicant_serial_number=?, applicant_title=?,applicant_first_name=?,applicant_middle_name=?,applicant_last_name=?,is_submited=? WHERE applicant_personal_id=${sec_applicant_id}`;
          const update_result = await mysqlquery(
            update_user,
            update_second_applicant_details
          );
          if (update_result.affectedRows > 0) {
            status = 1;
            msg += "user update successfully";
          } else {
            status = 0;
          }
        }
      }
      if (req.body.thrd_applicant_title && req.body.thrd_applicant_first_name) {
        let finduser1 = `SELECT * FROM ${db_table.applicant_persional_details} WHERE user_id=? `;
        let userfind1 = await mysqlquery(finduser1, [req.body.user_id]);
        // if (req.body.account_type_id === 2) {
        //     if (userfind1.length < 3) {
        //         applicant_serial_num3 = (userfind1.length) + 1;
        //     } else {
        //         res.status(200).json({
        //             msg: "minimum 3 applicant allowed",
        //         })
        //     }
        // }
        const finduser = `select * from ${db_table.applicant_persional_details} where user_id = ? and applicant_serial_number = '3'`;
        const result = await mysqlquery(finduser, [req.body.user_id]);
        if (result.length == 0) {
          const submit_applicant_details_third = {
            user_id: req.body.user_id,
            applicant_serial_number: 3,
            applicant_title: req.body.thrd_applicant_title,
            applicant_first_name: req.body.thrd_applicant_first_name,
            applicant_middle_name: req.body.thrd_applicant_middle_name,
            applicant_last_name: req.body.thrd_applicant_last_name,
            is_submited: 0,
          };

          let sql = `INSERT INTO ${db_table.applicant_persional_details} SET ? `;
          var submit_joint_applicant_third = await mysqlquery(
            sql,
            submit_applicant_details_third
          );

          let submit_process_data_third = {
            applicant_id: req.body.applicant_id,
            process_id: req.body.process_id,
            agent_status: req.body.agent_status,
          };
          let sql_process_data = `INSERT INTO ${db_table.process_status} SET ? `;
          let submit_process_third = await mysqlquery(
            sql_process_data,
            submit_process_data_third
          );

          if (submit_process_third.insertId > 0) {
            status = 1;
          } else {
            status = 0;
          }
        } else {
          const thrd_applicant_id = result[0].applicant_personal_id;
          const update_thrd_applicant_details = [
            3,
            req.body.thrd_applicant_title,
            req.body.thrd_applicant_first_name,
            req.body.thrd_applicant_middle_name,
            req.body.thrd_applicant_last_name,
            0,
            thrd_applicant_id,
          ];
          const update_user = `update ${db_table.applicant_persional_details} set applicant_serial_number=?, applicant_title=?,applicant_first_name=?,applicant_middle_name=?,applicant_last_name=?,is_submited=? WHERE applicant_personal_id=${thrd_applicant_id}`;
          const update_result = await mysqlquery(
            update_user,
            update_thrd_applicant_details
          );
          if (update_result.affectedRows > 0) {
            status = 1;
            msg += "user update successfully";
          } else {
            status = 0;
          }
        }
      }
      if (status === 1) {
        res.status(200).json({
          msg: "save applicant data successfully",
        });
      } else {
        res.status(400).json({
          msg: "something went wrong",
        });
      }
    } else {
      if (req.body.applicant_id) {
        const find_appli_id = `SELECT * FROM ${db_table.applicant_persional_details} WHERE applicant_personal_id=?`;
        const Appli_id_result = await mysqlquery(find_appli_id, [
          req.body.applicant_id,
        ]);

        const user_data = Object.values(Appli_id_result);
        const userid = user_data[0].user_id;

        const processdelete = `DELETE FROM  ${db_table.process_status} WHERE applicant_Id=? and process_id=?`;
        const delete_data = await mysqlquery(processdelete, [
          req.body.applicant_id,
          req.body.process_id,
        ]);

        const update_personal_data = [
          userid,
          req.body.applicant_title,
          req.body.applicant_first_name,
          req.body.applicant_middle_name,
          req.body.applicant_last_name,
          req.body.applicant_id,
        ];
        let sql = `update ${db_table.applicant_persional_details} SET user_id=?,applicant_title=?,applicant_first_name=?,applicant_middle_name=?,applicant_last_name=? WHERE applicant_personal_id=?`;
        const update_per_data = await mysqlquery(sql, update_personal_data);

        const submit_process_data = {
          applicant_id: req.body.applicant_id,
          process_id: req.body.process_id,
          agent_status: req.body.agent_status,
        };
        let sql_process_data = `INSERT INTO ${db_table.process_status} SET ? `;
        const submit_process = await mysqlquery(
          sql_process_data,
          submit_process_data
        );

        if (update_per_data.affectedRows > 0) {
          res.status(200).json({
            msg: "update personal information successfully",
          });
        } else {
          res.status(400).json({
            msg: "something went wrong",
          });
        }
      } else {
        res.status(400).json({
          msg: "bad request",
        });
      }
    }
  } catch (error) {
    res.status(400).json({
      msg: error.message ? error.message : error,
    });
  }
};

module.exports.update_joint_applicant_details = async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      res.status(409).json({ errors: errors.array() });
    }
    //}
  } catch (error) {
    res.status(400).json({
      msg: error.message ? error.message : error,
    });
  }
};

module.exports.submit_guardian_details = async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      res.status(409).json({ errors: errors.array() });
    }
    if (!req.body.applicant_id) {
      let find_user = `SELECT * FROM ${db_table.applicant_persional_details} WHERE user_id=? `;
      let userfind = await mysqlquery(find_user, [req.body.user_id]);
      if (req.body.account_type_id === 3) {
        if (userfind.length < 2) {
          var applicant_serial_num = userfind.length + 1;
        } else {
          res.status(200).json({
            msg: "minimum 2 applicant",
          });
        }
      }
      const submit_guardian_details = {
        user_id: req.body.user_id,
        applicant_serial_number: applicant_serial_num,
        applicant_title: req.body.gur_applicant_title,
        applicant_first_name: req.body.gur_applicant_first_name,
        applicant_middle_name: req.body.gur_applicant_middle_name,
        applicant_last_name: req.body.gur_applicant_last_name,
        guardian_customer_id: req.body.guardian_customer_id,
        guardian_relation: req.body.guardian_relation,
      };

      let sql = `INSERT INTO ${db_table.applicant_persional_details} SET ? `;
      const submit_minor_applicant = await mysqlquery(
        sql,
        submit_guardian_details
      );

      const submit_process_data = {
        applicant_id: submit_minor_applicant.insertId,
        process_id: req.body.process_id,
      };
      let sql_process_data = `INSERT INTO ${db_table.process_status} SET ? `;

      const submit_process = await mysqlquery(
        sql_process_data,
        submit_process_data
      );

      if (submit_minor_applicant.insertId > 0) {
        res.status(200).json({
          msg: "save guardian data successfully",
        });
      } else {
        res.status(400).json({
          msg: "something went wrong",
        });
      }
    } else {
      if (req.body.applicant_id) {
        const find_appli_id = `SELECT * FROM ${db_table.applicant_persional_details} WHERE applicant_personal_id=?`;
        const Appli_id_result = await mysqlquery(find_appli_id, [
          req.body.applicant_id,
        ]);

        const user_data = Object.values(Appli_id_result);
        const userid = user_data[0].user_id;

        const processdelete = `DELETE FROM  ${db_table.process_status} WHERE applicant_Id=? and process_id=?`;
        const delete_data = await mysqlquery(processdelete, [
          req.body.applicant_id,
          req.body.process_id,
        ]);

        const update_guardian_data = [
          userid,
          req.body.applicant_title,
          req.body.applicant_first_name,
          req.body.applicant_middle_name,
          req.body.applicant_last_name,
          req.body.applicant_id,
          req.body.guardian_customer_id,
          req.body.guardian_relation,
          req.body.date_of_birth,
        ];
        let sql = `update ${db_table.applicant_persional_details} SET user_id=?,applicant_title=?,applicant_first_name=?,applicant_middle_name=?,applicant_last_name=?,guardian_customer_id=?,guardian_relation=?, date_of_birth=? WHERE applicant_personal_id=?`;
        const update_per_data = await mysqlquery(sql, update_guardian_data);

        const submit_process_data = {
          applicant_id: req.body.applicant_id,
          process_id: req.body.process_id,
          agent_status: req.body.agent_status,
        };
        let sql_process_data = `INSERT INTO ${db_table.process_status} SET ? `;
        const submit_process = await mysqlquery(
          sql_process_data,
          submit_process_data
        );

        if (update_per_data.affectedRows > 0) {
          res.status(200).json({
            msg: "update guardian information successfully",
          });
        } else {
          res.status(400).json({
            msg: "something went wrong",
          });
        }
      } else {
        res.status(400).json({
          msg: "bad request",
        });
      }
    }
  } catch (error) {
    res.status(400).json({
      msg: error.message ? error.message : error,
    });
  }
};

module.exports.submit_applicant_personal_details_1 = async (req, res, next) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      res.status(409).json({ errors: errors.array() });
    }
    if (req.body.applicant_id) {
      let applicant_id = req.body.applicant_id;
      let process_id = req.body.process_id;
      let user_sql = `SELECT * FROM ${db_table.applicant_persional_details} WHERE applicant_personal_id=?`;
      let user_result = await mysqlquery(user_sql, [applicant_id]);
      let user_id = user_result[0].user_id;

      let find_user = `SELECT * FROM ${db_table.applicant_persional_details} WHERE user_id=? `;
      const userfind = await mysqlquery(find_user, [req.body.user_id]);

      const account_type_id = userfind[0].account_type_id;
      const account_varient = userfind[0].account_varient;

      const updatequery = `update ${db_table.applicant_persional_details} set account_type_id = ?,account_varient=? where user_id = ?`;
      const updateresult = await mysqlquery(updatequery, [
        account_type_id,
        account_varient,
        req.body.user_id,
      ]);

      if (userfind.length === 4) {
        res.status(200).json({
          msg: "minimum 3 applicant allowed",
        });
      } else {
        var applicant_serial_num = 1;
        if (req.body.account_type_id === 1) {
          applicant_serial_num = 1;
        }

        // let find_user = `SELECT * FROM ${db_table.applicant_persional_details} WHERE user_id=? `
        // let userfind = await mysqlquery(find_user, [req.body.user_id]);

        if (req.body.account_type_id === 3) {
          if (
            userfind.length === 1 &&
            req.body.applicant_id == userfind[0].applicant_personal_id
          ) {
            applicant_serial_num = 1;
          }
        }

        if (req.body.account_type_id === 3) {
          if (
            userfind.length === 2 &&
            req.body.applicant_id == userfind[1].applicant_personal_id
          ) {
            applicant_serial_num = 2;
          }
        }

        let applicant = "applicant_personal_id";
        let table_params = {
          tableName: db_table.applicant_persional_details,
          applicant_per_id: applicant,
        };

        const table_row_query = await get_table_id(table_params);
        const table_record_id = await mysqlquery(table_row_query, [
          req.body.applicant_id,
        ]);
        record_id = null;
        if (table_record_id.length > 0) {
          const applicant_data = Object.values(table_record_id);
          var record_id = applicant_data[0].applicant_personal_id;
        }

        const find_appli_id = `SELECT * FROM ${db_table.applicant_persional_details} WHERE applicant_personal_id=?`;
        const Appli_id_result = await mysqlquery(find_appli_id, [
          req.body.applicant_id,
        ]);

        const user_data = Object.values(Appli_id_result);
        const userid = user_data[0].user_id;

        const processdelete = `DELETE FROM  ${db_table.process_status} WHERE applicant_Id=? and process_id=?`;
        const delete_data = await mysqlquery(processdelete, [
          req.body.applicant_id,
          req.body.process_id,
        ]);

        var birth_date = req.body.date_of_birth;

        if (
          account_type_id === 1 ||
          account_type_id === 2 ||
          account_type_id === 3
        ) {
          const update_personal_data = [
            userid,
            applicant_serial_num,
            req.body.applicant_title,
            req.body.applicant_first_name,
            req.body.applicant_middle_name,
            req.body.applicant_last_name,
            req.body.aadhaar_number,
            req.body.religion_id,
            req.body.religion_category_id,
            req.body.is_politically_exposed,
            birth_date,
            req.body.marital_status,
            req.body.gender,
            req.body.applicant_id,
          ];
          let sql = `update ${db_table.applicant_persional_details} SET user_id=?,applicant_serial_number=?,applicant_title=?,applicant_first_name=?,applicant_middle_name=?,applicant_last_name=?,aadhaar_number=?, religion_id=?,religion_category_id=?, is_politically_exposed=?,
                   date_of_birth=?,marital_status=?, gender=? WHERE applicant_personal_id=?`;
          const update_per_data = await mysqlquery(sql, update_personal_data);

          const submit_process_data = {
            applicant_id: req.body.applicant_id,
            process_id: req.body.process_id,
            agent_status: req.body.agent_status,
          };
          let sql_process_data = `INSERT INTO ${db_table.process_status} SET ? `;
          const submit_process = await mysqlquery(
            sql_process_data,
            submit_process_data
          );

          let find_user = `SELECT * FROM ${db_table.applicant_persional_details} WHERE user_id=? `;
          let userfind = await mysqlquery(find_user, [req.body.user_id]);
          const sqli = `select lead_status from ${db_table.leads} where user_id=?`;

          const sqli_result = await mysqlquery(sqli, user_id);

          if (sqli_result[0].lead_status === "agent_review") {
            let get_status = `update ${db_table.comment} SET status = 'replied' WHERE applicant_id = ${applicant_id} and process_id = ${process_id}`;
            const status_query = await mysqlquery(get_status);
          }

          const check_all_status = `SELECT status FROM ${db_table.comment} WHERE applicant_id = ? AND STATUS != 'replied'`;
          const status_result = await mysqlquery(
            check_all_status,
            applicant_id
          );

          if (status_result.length > 0) {
            var in_query = "";
            userfind.forEach((uf) => {
              in_query += uf.applicant_personal_id + ",";
            });
            if (in_query != "") {
              in_query = in_query.substring(0, in_query.length - 1);
              const check_all_status = `SELECT status FROM ${db_table.comment} WHERE applicant_id IN (${in_query}) AND STATUS = 'added'`;
              const status_result = await mysqlquery(check_all_status);

              const lead_id = `SELECT lead_id FROM ${db_table.comment} WHERE applicant_id = ?`;
              const result = await mysqlquery(lead_id, applicant_id);

              if (status_result.length === 0) {
                const update_status = `update ${db_table.leads} set lead_status = 'agent_process' where lead_id = ?`;
                const results = await mysqlquery(
                  update_status,
                  result[0].lead_id
                );
              }
            }
          }
          if (update_per_data.affectedRows > 0) {
            res.status(200).json({
              msg: "update personal information successfully",
              record_id: record_id,
            });
          } else {
            res.status(400).json({
              msg: "something went wrong",
            });
          }
        } else {
          res.status(400).json({
            msg: "account type not found",
          });
          //         const update_perso_data = [
          //             userid, req.body.applicant_title, req.body.applicant_first_name, req.body.applicant_middle_name, req.body.applicant_last_name, req.body.aadhaar_number, req.body.religion_id, req.body.religion_category_id, req.body.is_politically_exposed, birth_date,
          //             req.body.marital_status, req.body.gender,
          //             req.body.applicant_id
          //         ];
          //         let sql = `update ${db_table.applicant_persional_details} SET user_id=?,applicant_title=?,applicant_first_name=?,applicant_middle_name=?,applicant_last_name=?,aadhaar_number=?, religion_id=?,religion_category_id=?, is_politically_exposed=?,
          //      date_of_birth=?,marital_status=?, gender=? WHERE applicant_personal_id=?`;
          //         const update_per_data = await mysqlquery(sql, update_perso_data);

          //         const submit_proc_data = {
          //             applicant_id: req.body.applicant_id, process_id: req.body.process_id, agent_status: req.body.agent_status
          //         };
          //         let sql_process_data = `INSERT INTO ${db_table.process_status} SET ? `;
          //         const submit_process = await mysqlquery(sql_process_data, submit_proc_data);

          //         res.status(200).json({
          //             data: "update personal information successfully",
          //             record_id: record_id
          //         })
        }
      }
    } else {
      res.status(400).json({
        msg: "bad request",
      });
    }

    //}
  } catch (error) {
    res.status(400).json({
      msg: error.message ? error.message : error,
    });
  }
};

module.exports.submit_applicant_personal_details_2 = async (req, res, next) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      res.status(409).json({ errors: errors.array() });
    }
    if (req.body.applicant_id) {
      let applicant_id = req.body.applicant_id;
      let process_id = req.body.process_id;
      let user_sql = `SELECT * FROM ${db_table.applicant_persional_details} WHERE applicant_personal_id=?`;
      let user_result = await mysqlquery(user_sql, [applicant_id]);
      let user_id = user_result[0].user_id;

      let applicant = "applicant_personal_id";
      let table_params = {
        tableName: db_table.applicant_persional_details,
        applicant_per_id: applicant,
      };

      const table_row_query = await get_table_id(table_params);
      const table_record_id = await mysqlquery(table_row_query, [
        req.body.applicant_id,
      ]);

      record_id = null;
      if (table_record_id.length > 0) {
        const applicant_data = Object.values(table_record_id);
        var record_id = applicant_data[0].applicant_personal_id;
      }

      const find_appli_id = `SELECT * FROM ${db_table.applicant_persional_details} WHERE applicant_personal_id=?`;
      const Appli_id_result = await mysqlquery(find_appli_id, [
        req.body.applicant_id,
      ]);

      const user_data = Object.values(Appli_id_result);
      const userid = user_data[0].user_id;

      const processdelete = `DELETE FROM  ${db_table.process_status} WHERE applicant_Id=? and process_id=?`;
      const delete_data = await mysqlquery(processdelete, [
        req.body.applicant_id,
        req.body.process_id,
      ]);

      var date_of_becoming_nri = req.body.date_of_becoming_nri;
      date_of_becoming_nri = date_of_becoming_nri.slice(0, 10);
      const update_personal_data = [
        userid,
        req.body.maiden_title,
        req.body.maiden_first_name,
        req.body.maiden_middle_name,
        req.body.maiden_last_name,
        req.body.mother_first_name,
        req.body.mother_middle_name,
        req.body.mother_last_name,
        req.body.in_relation_type,
        req.body.in_relation_title,
        req.body.in_relation_first_name,
        req.body.in_relation_middle_name,
        req.body.in_relation_last_name,
        req.body.nationality,
        date_of_becoming_nri,
        req.body.applicant_id,
      ];
      let sql = `update ${db_table.applicant_persional_details} SET user_id=?,maiden_title=?,maiden_first_name=?,maiden_middle_name=?,maiden_last_name=?,mother_first_name=?,mother_middle_name=?,mother_last_name=?,
                 in_relation_type=?,in_relation_title=?,in_relation_first_name=?,in_relation_middle_name=?,in_relation_last_name=?,nationality=?,date_of_becoming_nri=? WHERE applicant_personal_id=?`;
      const update_per_data = await mysqlquery(sql, update_personal_data);

      const submit_process_data = {
        applicant_id: req.body.applicant_id,
        process_id: req.body.process_id,
        agent_status: req.body.agent_status,
      };
      let sql_process_data = `INSERT INTO ${db_table.process_status} SET ? `;
      const submit_process = await mysqlquery(
        sql_process_data,
        submit_process_data
      );

      let find_user = `SELECT * FROM ${db_table.applicant_persional_details} WHERE user_id=? `;
      let userfind = await mysqlquery(find_user, [req.body.user_id]);

      const sqli = `select lead_status from ${db_table.leads} where user_id=?`;
      const sqli_result = await mysqlquery(sqli, user_id);

      if (sqli_result[0].lead_status === "agent_review") {
        let get_status = `update ${db_table.comment} SET status = 'replied' WHERE applicant_id = ${applicant_id} and process_id = ${process_id}`;
        const status_query = await mysqlquery(get_status);

        const check_all_status = `SELECT status FROM ${db_table.comment} WHERE applicant_id = ? AND STATUS != 'replied'`;
        const status_check_all_status = await mysqlquery(
          check_all_status,
          applicant_id
        );

        if (status_check_all_status.length >= 0) {
          var in_query = "";
          userfind.forEach((uf) => {
            in_query += uf.applicant_personal_id + ",";
          });
          if (in_query != "") {
            in_query = in_query.substring(0, in_query.length - 1);
            const check_all_status = `SELECT status FROM ${db_table.comment} WHERE applicant_id IN (${in_query}) AND STATUS = 'added'`;
            const status_result = await mysqlquery(check_all_status);

            const lead_id = `SELECT lead_id FROM ${db_table.comment} WHERE applicant_id = ?`;
            const result = await mysqlquery(lead_id, applicant_id);

            if (status_result.length === 0) {
              const update_status = `update ${db_table.leads} set lead_status = 'agent_process' where lead_id = ?`;
              const results = await mysqlquery(
                update_status,
                result[0].lead_id
              );
            }
          }
        }
      }

      if (update_per_data.affectedRows > 0) {
        res.status(200).json({
          msg: "update personal information successfully",
          record_id: record_id,
        });
      } else {
        res.status(400).json({
          msg: "something went wrong",
        });
      }
    } else {
      res.status(400).json({
        msg: "bad request",
      });
    }
  } catch (error) {
    res.status(400).json({
      msg: error.message ? error.message : error,
    });
  }
};

module.exports.submit_factas = async (req, res, next) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      res.status(409).json({ errors: errors.array() });
    }
    if (
      req.body.fatca_id === "" ||
      req.body.fatca_id === "undefined" ||
      req.body.fatca_id === "0" ||
      req.body.fatca_id === null ||
      req.body.fatca_id === undefined
    ) {
      const submit_facts = {
        applicant_id: req.body.applicant_id,
        is_residence_for_tax: req.body.is_residence_for_tax,
        tax_identification_number: req.body.tax_identification_number,
        tin_description: req.body.tin_description,
        tin_country_id: req.body.tin_country_id,
        tin_issue_county_id: req.body.tin_issue_county_id,
        city_of_birth: req.body.city_of_birth,
        birth_county_id: req.body.birth_county_id,
      };
      let sql = `INSERT INTO ${db_table.factas} SET ? `;
      const submitfacta = await mysqlquery(sql, submit_facts);
      const submit_process_data = {
        applicant_id: req.body.applicant_id,
        process_id: req.body.process_id,
        agent_status: req.body.agent_status,
      };
      let sql_process_data = `INSERT INTO ${db_table.process_status} SET ? `;
      const submit_process = await mysqlquery(
        sql_process_data,
        submit_process_data
      );

      if (submitfacta.insertId > 0) {
        res.status(200).json({
          msg: "save factas successfully",
        });
      } else {
        res.status(400).json({
          msg: "something went wrong",
        });
      }
    } else {
      if (req.body.fatca_id) {
        let applicant_id = req.body.applicant_id;
        let process_id = req.body.process_id;
        let user_sql = `SELECT * FROM ${db_table.applicant_persional_details} WHERE applicant_personal_id=?`;
        let user_result = await mysqlquery(user_sql, [applicant_id]);
        let user_id = user_result[0].user_id;

        const processdelete = `DELETE FROM  ${db_table.process_status} WHERE applicant_Id=? and process_id=?`;
        const delete_data = await mysqlquery(processdelete, [
          req.body.applicant_id,
          req.body.process_id,
        ]);

        const updatefacts = [
          req.body.applicant_id,
          req.body.is_residence_for_tax,
          req.body.tax_identification_number,
          req.body.tin_description,
          req.body.tin_country_id,
          req.body.tin_issue_county_id,
          req.body.city_of_birth,
          req.body.birth_county_id,
          req.body.fatca_id,
        ];
        let sql = `update ${db_table.factas} SET applicant_id=?,is_residence_for_tax=?,tax_identification_number=?,tin_description=?, tin_country_id=?,tin_issue_county_id=?, city_of_birth=?, birth_county_id=?  WHERE fatca_id=?`;
        const updatefacta = await mysqlquery(sql, updatefacts);

        const submit_process_data = {
          applicant_id: req.body.applicant_id,
          process_id: req.body.process_id,
          agent_status: req.body.agent_status,
        };
        let sql_process_data = `INSERT INTO ${db_table.process_status} SET ? `;
        const submit_process = await mysqlquery(
          sql_process_data,
          submit_process_data
        );

        let find_user = `SELECT * FROM ${db_table.applicant_persional_details} WHERE user_id=? `;
        let userfind = await mysqlquery(find_user, user_id);

        const sqli = `select lead_status from ${db_table.leads} where user_id=?`;
        const sqli_result = await mysqlquery(sqli, user_id);

        if (sqli_result[0].lead_status === "agent_review") {
          let get_status = `update ${db_table.comment} SET status = 'replied' WHERE applicant_id = ${applicant_id} and process_id = ${process_id}`;
          const status_query = await mysqlquery(get_status);

          const check_all_status = `SELECT status FROM ${db_table.comment} WHERE applicant_id = ? AND STATUS != 'replied'`;
          const status_check_all_status = await mysqlquery(
            check_all_status,
            applicant_id
          );

          if (status_check_all_status.length >= 0) {
            var in_query = "";
            userfind.forEach((uf) => {
              in_query += uf.applicant_personal_id + ",";
            });

            if (in_query != "") {
              in_query = in_query.substring(0, in_query.length - 1);
              const check_status = `SELECT status FROM ${db_table.comment} WHERE applicant_id IN (${in_query}) AND STATUS = 'added'`;
              const status_result = await mysqlquery(check_status);

              const lead_id = `SELECT lead_id FROM ${db_table.comment} WHERE applicant_id = ?`;
              const result = await mysqlquery(lead_id, applicant_id);

              if (status_result.length == 0) {
                const update_status = `update ${db_table.leads} set lead_status = 'agent_process' where lead_id = ?`;
                const results = await mysqlquery(
                  update_status,
                  result[0].lead_id
                );
              }
            }
          }
        }

        if (updatefacta.affectedRows > 0) {
          res.status(200).json({
            msg: "update factas successfully",
          });
        } else {
          res.status(400).json({
            msg: "something went wrong",
          });
        }
      } else {
        res.status(400).json({
          msg: "bad request",
        });
      }
    }
  } catch (error) {
    res.status(400).json({
      msg: error.message ? error.message : error,
    });
  }
};

module.exports.submit_kyc_details_1 = async (req, res) => {
  try {
    let applicant_id = req.body.applicant_id;
    let process_id = req.body.process_id;
    let user_sql = `SELECT * FROM ${db_table.applicant_persional_details} WHERE applicant_personal_id=?`;
    let user_result = await mysqlquery(user_sql, [applicant_id]);
    let user_id = user_result[0].user_id;

    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      res.status(409).json({ errors: errors.array() });
    }
    if (
      req.body.kyc_details_id === "" ||
      req.body.kyc_details_id === "undefined" ||
      req.body.kyc_details_id === "0" ||
      req.body.kyc_details_id === null ||
      req.body.kyc_details_id === undefined
    ) {
      var issue_date = req.body.issue_date;
      issue_date = issue_date.slice(0, 10);
      var expiry_date = req.body.expiry_date;
      expiry_date = expiry_date.slice(0, 10);
      var visa_permit_expiry_date = req.body.visa_permit_expiry_date;
      visa_permit_expiry_date = visa_permit_expiry_date.slice(0, 10);
      const submit_kyc_details = {
        applicant_id: req.body.applicant_id,
        is_other_than_indian_passport: req.body.is_other_than_indian_passport,
        passport_number: req.body.passport_number,
        issue_date: issue_date != "" ? issue_date : null,
        expiry_date: expiry_date != "" ? expiry_date : null,
        issueing_authority: req.body.issueing_authority,
        place_of_issue: req.body.place_of_issue,
        visa_type: req.body.visa_type,
        visa_permit_expiry_date: visa_permit_expiry_date?.length
          ? visa_permit_expiry_date
          : null,
        is_resident_permit: req.body.is_resident_permit,
        pan_number: req.body.pan_number,
        is_form_60: req.body.is_form_60,
      };
      let sql = `INSERT INTO ${db_table.kyc_details} SET ? `;
      const submit_kycdetails = await mysqlquery(sql, submit_kyc_details);
      const submit_process_data = {
        applicant_id: req.body.applicant_id,
        process_id: req.body.process_id,
        agent_status: req.body.agent_status,
      };
      let sql_process_data = `INSERT INTO ${db_table.process_status} SET ? `;
      const submit_process = await mysqlquery(
        sql_process_data,
        submit_process_data
      );

      if (submit_kycdetails.insertId > 0) {
        res.status(200).json({
          msg: "save submit_kyc_details successfully",
          kyc_details_id: submit_kycdetails.insertId,
        });
      } else {
        res.status(200).json({
          msg: "something went wrong",
        });
      }
    } else {
      if (req.body.kyc_details_id) {
        // let Applicant_Id='applicant_id'
        // let table_params = {
        //    'tableName':db_table.kyc_details,
        //    "applicantid":Applicant_Id
        //  };

        //  const table_row_query =  await get_table_id(table_params);
        //  const table_record_id = await mysqlquery(table_row_query, [req.body.applicant_id]);

        //  if(table_record_id.length>0){
        //  const applicant_data = Object.values(table_record_id);
        //  var record_id = applicant_data[0].kyc_details_id;
        //  }
        //  record_id=null

        const processdelete = `DELETE FROM  ${db_table.process_status} WHERE applicant_Id=? and process_id=?`;
        const delete_data = await mysqlquery(processdelete, [
          req.body.applicant_id,
          req.body.process_id,
        ]);

        var issue_date = req.body.issue_date;
        issue_date = issue_date.slice(0, 10);
        var expiry_date = req.body.expiry_date;
        expiry_date = expiry_date.slice(0, 10);
        var visa_permit_expiry_date = req.body.visa_permit_expiry_date;
        visa_permit_expiry_date = visa_permit_expiry_date.slice(0, 10);
        const update_kyc_details = [
          req.body.applicant_id,
          req.body.is_other_than_indian_passport,
          req.body.passport_number,
          issue_date != "" ? issue_date : null,
          expiry_date != "" ? expiry_date : null,
          req.body.issueing_authority,
          req.body.place_of_issue,
          req.body.visa_type,
          visa_permit_expiry_date?.length ? visa_permit_expiry_date : null,
          req.body.pan_number,
          req.body.is_form_60,
          req.body.kyc_details_id,
        ];
        // if(is_temporary_visa_declaration==is_temporary_visa_declaration)
        let sql = `update ${db_table.kyc_details} SET applicant_id=?, is_other_than_indian_passport=?, passport_number=?,issue_date=?,
          expiry_date=?,issueing_authority=?,place_of_issue=?,visa_type=?,visa_permit_expiry_date=?,pan_number=?,is_form_60=? WHERE kyc_details_id=?`;
        const update_kycdetails = await mysqlquery(sql, update_kyc_details);

        const submit_process_data = {
          applicant_id: req.body.applicant_id,
          process_id: req.body.process_id,
          agent_status: req.body.agent_status,
        };
        let sql_process_data = `INSERT INTO ${db_table.process_status} SET ? `;
        const submit_process = await mysqlquery(
          sql_process_data,
          submit_process_data
        );

        let find_user = `SELECT * FROM ${db_table.applicant_persional_details} WHERE user_id=? `;
        let userfind = await mysqlquery(find_user, user_id);

        const sqli = `select lead_status from ${db_table.leads} where user_id=?`;
        const sqli_result = await mysqlquery(sqli, user_id);

        if (sqli_result[0].lead_status === "agent_review") {
          let get_status = `update ${db_table.comment} SET status = 'replied' WHERE applicant_id = ${applicant_id} and process_id = ${process_id}`;
          const status_query = await mysqlquery(get_status);

          const check_all_status = `SELECT status FROM ${db_table.comment} WHERE applicant_id = ? AND STATUS != 'replied'`;
          const status_check_all_status = await mysqlquery(
            check_all_status,
            applicant_id
          );

          if (status_check_all_status.length >= 0) {
            var in_query = "";
            userfind.forEach((uf) => {
              in_query += uf.applicant_personal_id + ",";
            });
            if (in_query != "") {
              in_query = in_query.substring(0, in_query.length - 1);
              const check_all_status = `SELECT status FROM ${db_table.comment} WHERE applicant_id IN (${in_query}) AND STATUS = 'added'`;
              const status_result = await mysqlquery(check_all_status);

              const lead_id = `SELECT lead_id FROM ${db_table.comment} WHERE applicant_id = ?`;
              const result = await mysqlquery(lead_id, applicant_id);

              if (status_result.length === 0) {
                const update_status = `update ${db_table.leads} set lead_status = 'agent_process' where lead_id = ?`;
                const results = await mysqlquery(
                  update_status,
                  result[0].lead_id
                );
              }
            }
          }
        }

        if (update_kycdetails.affectedRows > 0) {
          res.status(200).json({
            msg: "update kyc_details successfully",
            kyc_details_id: req.body.kyc_details_id,
            // record_id:record_id
          });
        } else {
          res.status(400).json({
            msg: "something went wrong",
          });
        }
      } else {
        res.status(400).json({
          msg: "bad request",
        });
      }
    }
  } catch (error) {
    res.status(400).json({
      msg: error.message ? error.message : error,
    });
  }
};

module.exports.submit_kyc_details_2 = async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      res.status(409).json({ errors: errors.array() });
    }

    let sql1 =
      "SELECT kyc_details_id FROM `tbl_kyc_details` WHERE applicant_id =?";
    const getKycdetails = await mysqlquery(sql1, [req.body.applicant_id]);

    if (getKycdetails.length > 0) {
      let kycId = getKycdetails[0].kyc_details_id;

      let Applicant_Id = "applicant_id";
      let table_params = {
        tableName: db_table.kyc_details,
        applicantid: Applicant_Id,
      };
      const table_row_query = await get_table_id(table_params);
      const table_record_id = await mysqlquery(table_row_query, [
        req.body.applicant_id,
      ]);
      record_id = null;
      if (table_record_id.length > 0) {
        const applicant_data = Object.values(table_record_id);
        var record_id = applicant_data[0].kyc_details_id;
      }

      const processdelete = `DELETE FROM  ${db_table.process_status} WHERE applicant_Id=? and process_id=?`;
      const delete_data = await mysqlquery(processdelete, [
        req.body.applicant_id,
        req.body.process_id,
      ]);
      var temporary_visa_declare_issue_date =
        req.body.temporary_visa_declare_issue_date;
      temporary_visa_declare_issue_date =
        temporary_visa_declare_issue_date.slice(0, 10);
      var temporary_visa_declare_expiry_date =
        req.body.temporary_visa_declare_expiry_date;
      temporary_visa_declare_expiry_date =
        temporary_visa_declare_expiry_date.slice(0, 10);
      let kyc_dtls_chk1 = req.body.kyc_dtls_chk1;
      let kyc_dtls_chk2 = req.body.kyc_dtls_chk2;
      let is_temporary_visa_declaration = 0;
      if (kyc_dtls_chk1 == kyc_dtls_chk2) {
        is_temporary_visa_declaration = 1;
      }
      const update_kyc_details = [
        req.body.applicant_id,
        temporary_visa_declare_issue_date,
        temporary_visa_declare_expiry_date,
        is_temporary_visa_declaration,
        kycId,
      ];
      // if(is_temporary_visa_declaration==is_temporary_visa_declaration)
      let sql = `update ${db_table.kyc_details} SET applicant_id=?, temporary_visa_declare_issue_date=?, temporary_visa_declare_expiry_date=?,is_temporary_visa_declaration=? WHERE kyc_details_id=?`;
      const update_kycdetails = await mysqlquery(sql, update_kyc_details);
      const submit_process_data = {
        applicant_id: req.body.applicant_id,
        process_id: req.body.process_id,
        agent_status: req.body.agent_status,
      };
      let sql_process_data = `INSERT INTO ${db_table.process_status} SET ? `;
      const submit_process = await mysqlquery(
        sql_process_data,
        submit_process_data
      );
      if (update_kycdetails.affectedRows > 0) {
        res.status(200).json({
          msg: "update kyc_details successfully",
          kyc_details_id: kycId,
          record_id: record_id,
        });
      } else {
        res.status(400).json({
          msg: "something went wrong",
        });
      }
    } else {
      res.status(400).json({
        msg: "bad request",
      });
    }
  } catch (error) {
    res.status(400).json({
      msg: error.message ? error.message : error,
    });
  }
};

module.exports.submit_kyc_poi_dec = async (req, res, next) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      res.status(409).json({ errors: errors.array() });
    }
    if (
      req.body.kyc_pio_dec_id === "" ||
      req.body.kyc_pio_dec_id === "undefined" ||
      req.body.kyc_pio_dec_id === null ||
      req.body.kyc_pio_dec_id === "0" ||
      req.body.kyc_pio_dec_id === undefined
    ) {
      const submit_poi_dec = {
        applicant_id: req.body.applicant_id,
        is_held_indian_passport:
          req.body.pio_declaration == "is_held_indian_passport" ? 1 : 0,
        is_citizen_of_india_by_virtue:
          req.body.pio_declaration == "is_citizen_of_india_by_virtue" ? 1 : 0,
        is_belong_after_15_8_1947:
          req.body.pio_declaration == "is_belong_after_15_8_1947" ? 1 : 0,
        is_family_indian_by_virtue:
          req.body.pio_declaration == "is_family_indian_by_virtue" ? 1 : 0,
        is_spouse_held_indian_passport:
          req.body.pio_declaration == "is_spouse_held_indian_passport" ? 1 : 0,
        is_spouse_family_indian_by_virtue:
          req.body.pio_declaration == "is_spouse_family_indian_by_virtue"
            ? 1
            : 0,
        indian_family_name: req.body.indian_family_name,
        indian_spouse_name: req.body.indian_spouse_name,
        indian_spouse_family_name: req.body.indian_spouse_family_name,
      };

      let sql = `INSERT INTO ${db_table.kyc_pio_declarations} SET ? `;
      const submitpoidec = await mysqlquery(sql, submit_poi_dec);

      const submit_process_data = {
        applicant_id: req.body.applicant_id,
        process_id: req.body.process_id,
        agent_status: req.body.agent_status,
      };
      let sql_process_data = `INSERT INTO ${db_table.process_status} SET ? `;
      const submit_process = await mysqlquery(
        sql_process_data,
        submit_process_data
      );
      if (submitpoidec.insertId > 0) {
        res.status(200).json({
          msg: "save kyc poi decleration successfully",
        });
      } else {
        res.status(400).json({
          msg: "something went wrong",
        });
      }
    } else {
      if (req.body.kyc_pio_dec_id) {
        let applicant_id = req.body.applicant_id;
        let process_id = req.body.process_id;
        let user_sql = `SELECT * FROM ${db_table.applicant_persional_details} WHERE applicant_personal_id=?`;
        let user_result = await mysqlquery(user_sql, [applicant_id]);
        let user_id = user_result[0].user_id;

        const processdelete = `DELETE FROM  ${db_table.process_status} WHERE applicant_Id=? and process_id=?`;
        const delete_data = await mysqlquery(processdelete, [
          req.body.applicant_id,
          req.body.process_id,
        ]);
        const update_poi_dec = [
          req.body.applicant_id,
          req.body.pio_declaration == "is_held_indian_passport" ? 1 : 0,
          req.body.pio_declaration == "is_citizen_of_india_by_virtue" ? 1 : 0,
          req.body.pio_declaration == "is_belong_after_15_8_1947" ? 1 : 0,
          req.body.pio_declaration == "is_family_indian_by_virtue" ? 1 : 0,
          req.body.pio_declaration == "is_spouse_held_indian_passport" ? 1 : 0,
          req.body.pio_declaration == "is_spouse_family_indian_by_virtue"
            ? 1
            : 0,
          req.body.indian_family_name,
          req.body.indian_spouse_name,
          req.body.indian_spouse_family_name,
          req.body.kyc_pio_dec_id,
        ];

        let sql = `update ${db_table.kyc_pio_declarations} SET 
                applicant_id=?,
                is_held_indian_passport=?, 
                is_citizen_of_india_by_virtue=?,
                is_belong_after_15_8_1947=?, 
                is_family_indian_by_virtue=?,
                is_spouse_held_indian_passport=?,
                is_spouse_family_indian_by_virtue=?,
                indian_family_name=?,
                indian_spouse_name=?,
                indian_spouse_family_name=? 
                WHERE kyc_pio_dec_id=?`;
        const updatepoidec = await mysqlquery(sql, update_poi_dec);

        const submit_process_data = {
          applicant_id: req.body.applicant_id,
          process_id: req.body.process_id,
          agent_status: req.body.agent_status,
        };
        let sql_process_data = `INSERT INTO ${db_table.process_status} SET ? `;
        const submit_process = await mysqlquery(
          sql_process_data,
          submit_process_data
        );

        let find_user = `SELECT * FROM ${db_table.applicant_persional_details} WHERE user_id=? `;
        let userfind = await mysqlquery(find_user, user_id);

        const sqli = `select lead_status from ${db_table.leads} where user_id=?`;
        const sqli_result = await mysqlquery(sqli, user_id);

        if (sqli_result[0].lead_status === "agent_review") {
          let get_status = `update ${db_table.comment} SET status = 'replied' WHERE applicant_id = ${applicant_id} and process_id = ${process_id}`;
          const status_query = await mysqlquery(get_status);

          const check_all_status = `SELECT status FROM ${db_table.comment} WHERE applicant_id = ? AND STATUS != 'replied'`;
          const status_check_all_status = await mysqlquery(
            check_all_status,
            applicant_id
          );

          if (status_check_all_status.length >= 0) {
            var in_query = "";
            userfind.forEach((uf) => {
              in_query += uf.applicant_personal_id + ",";
            });
            if (in_query != "") {
              in_query = in_query.substring(0, in_query.length - 1);
              const check_all_status = `SELECT status FROM ${db_table.comment} WHERE applicant_id IN (${in_query}) AND STATUS = 'added'`;
              const status_result = await mysqlquery(check_all_status);

              const lead_id = `SELECT lead_id FROM ${db_table.comment} WHERE applicant_id = ?`;
              const result = await mysqlquery(lead_id, applicant_id);

              if (status_result.length === 0) {
                const update_status = `update ${db_table.leads} set lead_status = 'agent_process' where lead_id = ?`;
                const results = await mysqlquery(
                  update_status,
                  result[0].lead_id
                );
              }
            }
          }
        }

        if (updatepoidec.affectedRows > 0) {
          res.status(200).json({
            msg: "update kyc poi decleration successfully",
            kyc_pio_dec_id: req.body.kyc_pio_dec_id,
          });
        } else {
          res.status(400).json({
            msg: "something went wrong",
          });
        }
      } else {
        res.status(400).json({
          msg: "bad request",
        });
      }
    }
  } catch (error) {
    res.status(400).json({
      msg: error.message ? error.message : error,
    });
  }
};

module.exports.submit_contact_details = async (req, res) => {
  let applicant_id = req.body.applicant_id;
  let process_id = req.body.process_id;
  let user_sql = `SELECT * FROM ${db_table.applicant_persional_details} WHERE applicant_personal_id=?`;
  let user_result = await mysqlquery(user_sql, [applicant_id]);
  let user_id = user_result[0].user_id;

  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      res.status(409).json({ errors: errors.array() });
    }

    let sql1 =
      "SELECT contact_details_id FROM `tbl_contact_details` WHERE applicant_id = ?";
    const getContactId = await mysqlquery(sql1, applicant_id);

    if (getContactId.length == 0) {
      const submit_contact_details = {
        applicant_id: req.body.applicant_id,
        office_country_code: req.body.office_country_code,
        office_std_code: req.body.office_std_code,
        office_tel_number: req.body.office_tel_number,
        residence_std_code: req.body.residence_std_code,
        residence_country_code: req.body.residence_country_code,
        residence_tel_number: req.body.residence_tel_number,
        country_code: req.body.country_code,
        mobile_number: req.body.mobile_number,
        fax_country_code: req.body.fax_country_code,
        fax_std_code: req.body.fax_std_code,
        fax_number: req.body.fax_number,
        email_address: req.body.email_address,
      };
      let sql = `INSERT INTO ${db_table.contact_details} SET ? `;
      const submitcontact = await mysqlquery(sql, submit_contact_details);
      const submit_process_data = {
        applicant_id: req.body.applicant_id,
        process_id: req.body.process_id,
        agent_status: req.body.agent_status,
      };
      let sql_process_data = `INSERT INTO ${db_table.process_status} SET ? `;
      const submit_process = await mysqlquery(
        sql_process_data,
        submit_process_data
      );

      if (submitcontact.insertId > 0) {
        res.status(200).json({
          msg: "save contact details successfully",
        });
      } else {
        res.status(400).json({
          msg: "something went wrong",
        });
      }
    } else {
      if (getContactId[0].contact_details_id) {
        const processdelete = `DELETE FROM  ${db_table.process_status} WHERE applicant_Id=? and process_id=?`;
        const delete_data = await mysqlquery(processdelete, [
          req.body.applicant_id,
          req.body.process_id,
        ]);
        const update_contact_details = [
          req.body.applicant_id,
          req.body.office_country_code,
          req.body.office_std_code,
          req.body.office_tel_number,
          req.body.residence_std_code,
          req.body.residence_country_code,
          req.body.residence_tel_number,
          req.body.country_code,
          req.body.mobile_number,
          req.body.fax_country_code,
          req.body.fax_std_code,
          req.body.fax_number,
          req.body.email_address,
          getContactId[0].contact_details_id,
        ];
        let sql = `update ${db_table.contact_details} SET applicant_id=?,office_country_code=?, office_std_code=?,office_tel_number=?,residence_std_code=?,residence_country_code=?,residence_tel_number=?, country_code=?, mobile_number=?, fax_country_code=?, fax_std_code=?, fax_number=?,email_address=? WHERE contact_details_id=?`;
        const updatepoidec = await mysqlquery(sql, update_contact_details);
        const submit_process_data = {
          applicant_id: req.body.applicant_id,
          process_id: req.body.process_id,
          agent_status: req.body.agent_status,
        };
        let sql_process_data = `INSERT INTO ${db_table.process_status} SET ? `;
        const submit_process = await mysqlquery(
          sql_process_data,
          submit_process_data
        );

        let find_user = `SELECT * FROM ${db_table.applicant_persional_details} WHERE user_id=? `;
        let userfind = await mysqlquery(find_user, user_id);

        const sqli = `select lead_status from ${db_table.leads} where user_id=?`;
        const sqli_result = await mysqlquery(sqli, user_id);

        if (sqli_result[0].lead_status === "agent_review") {
          let get_status = `update ${db_table.comment} SET status = 'replied' WHERE applicant_id = ${applicant_id} and process_id = ${process_id}`;
          const status_query = await mysqlquery(get_status);

          const check_all_status = `SELECT status FROM ${db_table.comment} WHERE applicant_id = ? AND STATUS != 'replied'`;
          const status_check_all_status = await mysqlquery(
            check_all_status,
            applicant_id
          );

          if (status_check_all_status.length >= 0) {
            var in_query = "";
            userfind.forEach((uf) => {
              in_query += uf.applicant_personal_id + ",";
            });
            if (in_query != "") {
              in_query = in_query.substring(0, in_query.length - 1);
              const check_all_status = `SELECT status FROM ${db_table.comment} WHERE applicant_id IN (${in_query}) AND STATUS = 'added'`;
              const status_result = await mysqlquery(check_all_status);
              const lead_id = `SELECT lead_id FROM ${db_table.comment} WHERE applicant_id = ?`;
              const result = await mysqlquery(lead_id, applicant_id);

              if (status_result.length === 0) {
                const update_status = `update ${db_table.leads} set lead_status = 'agent_process' where lead_id = ?`;
                const results = await mysqlquery(
                  update_status,
                  result[0].lead_id
                );
              }
            }
          }
        }

        if (updatepoidec.affectedRows > 0) {
          res.status(200).json({
            msg: "update contact details successfully",
          });
        } else {
          res.status(400).json({
            msg: "something went wrong",
          });
        }
      } else {
        res.status(400).json({
          msg: "bad request",
        });
      }
    }
  } catch (error) {
    res.status(400).json({
      msg: error.message ? error.message : error,
    });
  }
};

module.exports.submit_address_details_1 = async (req, res) => {
  let applicant_id = req.body.applicant_id;
  let process_id = req.body.process_id;
  let user_sql = `SELECT * FROM ${db_table.applicant_persional_details} WHERE applicant_personal_id=?`;
  let user_result = await mysqlquery(user_sql, [applicant_id]);
  let user_id = user_result[0].user_id;

  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      res.status(409).json({ errors: errors.array() });
    }
    const submit_address_details = {
      applicant_id: req.body.applicant_id,
      current_address_type: req.body.current_address_type,
      current_house_number: req.body.current_house_number,
      current_house_or_building_name: req.body.current_house_or_building_name,
      current_road_or_street_name: req.body.current_road_or_street_name,
      current_landmark: req.body.current_landmark,
      current_state: req.body.current_state,
      current_city: req.body.current_city,
      current_country_id: req.body.current_country_id,
      current_pincode: req.body.current_pincode,
      overseas_address_type: req.body.overseas_address_type,
      overseas_house_number: req.body.overseas_house_number,
      overseas_house_or_building_name: req.body.overseas_house_or_building_name,
      overseas_road_or_street_name: req.body.overseas_road_or_street_name,
      overseas_landmark: req.body.overseas_landmark,
      overseas_state: req.body.overseas_state,
      overseas_city: req.body.overseas_city,
      overseas_country_id: req.body.overseas_country_id,
      overseas_pincode: req.body.overseas_pincode,
    };
    var sql1 =
      "SELECT address_id FROM `tbl_address_details` WHERE applicant_id = ?";
    let getAddressid = await mysqlquery(sql1, [req.body.applicant_id]);

    if (getAddressid.length == 0) {
      let sql = `INSERT INTO ${db_table.address_details} SET ? `;
      const submitaddress = await mysqlquery(sql, submit_address_details);
      const submit_process_data = {
        applicant_id: req.body.applicant_id,
        process_id: req.body.process_id,
        agent_status: req.body.agent_status,
      };
      let sql_process_data = `INSERT INTO ${db_table.process_status} SET ? `;
      const submit_process = await mysqlquery(
        sql_process_data,
        submit_process_data
      );

      if (submitaddress.insertId > 0) {
        res.status(200).json({
          msg: "save address details successfully",
          address_id: submitaddress.insertId,
        });
      } else {
        res.status(400).json({
          msg: "something went wrong",
        });
      }
    } else {
      if (getAddressid[0].address_id) {
        // let Applicant_Id='applicant_id'
        // let table_params = {
        //    'tableName':db_table.kyc_details,
        //    "applicantid":Applicant_Id
        //  };

        //  const table_row_query =  await get_table_id(table_params);
        //  const table_record_id = await mysqlquery(table_row_query, [req.body.applicant_id]);

        //  if(table_record_id.length>0){
        //  const applicant_data = Object.values(table_record_id);
        //  var record_id = applicant_data[0].address_id;
        //  }
        //  record_id=null
        const processdelete = `DELETE FROM  ${db_table.process_status} WHERE applicant_Id=? and process_id=?`;
        const delete_data = await mysqlquery(processdelete, [
          req.body.applicant_id,
          req.body.process_id,
        ]);

        const searchApplicant = `select address_id from ${db_table.address_details} where applicant_id = ?`;
        const applicantResult = await mysqlquery(
          searchApplicant,
          req.body.applicant_id
        );

        if (applicantResult.length > 0) {
          const update_address_details = [
            req.body.current_address_type,
            req.body.current_house_number,
            req.body.current_house_or_building_name,
            req.body.current_road_or_street_name,
            req.body.current_landmark,
            req.body.current_state,
            req.body.current_city,
            req.body.current_country_id,
            req.body.current_pincode,
            req.body.overseas_address_type,
            req.body.overseas_house_number,
            req.body.overseas_house_or_building_name,
            req.body.overseas_road_or_street_name,
            req.body.overseas_landmark,
            req.body.overseas_state,
            req.body.overseas_city,
            req.body.overseas_country_id,
            req.body.overseas_pincode,
            req.body.applicant_id,
          ];

          let sql = `update ${db_table.address_details} SET 
                          current_address_type=?,current_house_number=?,
                          current_house_or_building_name=?,
                           current_road_or_street_name=?,
                           current_landmark=?,current_state=?,
                           current_city=?,current_country_id=?,
                           current_pincode=?,overseas_address_type=?,
                           overseas_house_number=?,overseas_house_or_building_name=?,
                           overseas_road_or_street_name=?,overseas_landmark=?,overseas_state=?,
                           overseas_city=?,overseas_country_id=?,overseas_pincode=? where applicant_id =?`;

          const updateaddress = await mysqlquery(sql, update_address_details);

          let find_user = `SELECT * FROM ${db_table.applicant_persional_details} WHERE user_id=? `;
          let userfind = await mysqlquery(find_user, user_id);

          const sqli = `select lead_status from ${db_table.leads} where user_id=?`;
          const sqli_result = await mysqlquery(sqli, user_id);
          if (sqli_result[0].lead_status === "agent_review") {
            let get_status = `update ${db_table.comment} SET status = 'replied' WHERE applicant_id = ${applicant_id} and process_id = ${process_id}`;
            const status_query = await mysqlquery(get_status);

            const check_all_status = `SELECT status FROM ${db_table.comment} WHERE applicant_id = ? AND STATUS != 'replied'`;
            const status_check_all_status = await mysqlquery(
              check_all_status,
              applicant_id
            );

            if (status_check_all_status.length >= 0) {
              var in_query = "";
              userfind.forEach((uf) => {
                in_query += uf.applicant_personal_id + ",";
              });
              if (in_query != "") {
                in_query = in_query.substring(0, in_query.length - 1);
                const check_all_status = `SELECT status FROM ${db_table.comment} WHERE applicant_id IN (${in_query}) AND STATUS = 'added'`;
                const status_result = await mysqlquery(check_all_status);

                const lead_id = `SELECT lead_id FROM ${db_table.comment} WHERE applicant_id = ?`;
                const result = await mysqlquery(lead_id, applicant_id);

                if (status_result.length === 0) {
                  const update_status = `update ${db_table.leads} set lead_status = 'agent_process' where lead_id = ?`;
                  const results = await mysqlquery(
                    update_status,
                    result[0].lead_id
                  );
                }
              }
            }
          }

          if (updateaddress.affectedRows > 0) {
            res.status(200).json({
              data: "update address details successfully",
              address_id: getAddressid[0].address_id,
              // record_id:record_id
            });
          } else {
            res.status(400).json({
              msg: "something went wrong",
            });
          }
        } else {
          let sql = `INSERT INTO ${db_table.address_details} SET ? `;
          const submitaddress = await mysqlquery(sql, submit_address_details);
          if (submitaddress.insertId > 0) {
            res.status(200).json({
              msg: "save address details successfully",
              address_id: submitaddress.insertId,
            });
          } else {
            res.status(400).json({
              msg: "something went wrong",
            });
          }
        }

        const submit_process_data = {
          applicant_id: req.body.applicant_id,
          process_id: req.body.process_id,
          agent_status: req.body.agent_status,
        };
        let sql_process_data = `INSERT INTO ${db_table.process_status} SET ? `;
        const submit_process = await mysqlquery(
          sql_process_data,
          submit_process_data
        );
      } else {
        res.status(400).json({
          msg: "bad request",
        });
      }
    }
  } catch (error) {
    res.status(400).json({
      msg: error.message ? error.message : error,
    });
  }
};

module.exports.submit_address_details_2 = async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      res.status(409).json({ errors: errors.array() });
    }

    var sql1 =
      "SELECT address_id FROM `tbl_address_details` WHERE applicant_id = ?";
    let getAddressid = await mysqlquery(sql1, [req.body.applicant_id]);

    if (getAddressid.length > 0) {
      let applicant_id = req.body.applicant_id;
      let process_id = req.body.process_id;
      let user_sql = `SELECT * FROM ${db_table.applicant_persional_details} WHERE applicant_personal_id=?`;
      let user_result = await mysqlquery(user_sql, [applicant_id]);
      let user_id = user_result[0].user_id;

      let Applicant_Id = "applicant_id";
      let table_params = {
        tableName: db_table.kyc_details,
        applicantid: Applicant_Id,
      };
      const table_row_query = await get_table_id(table_params);
      const table_record_id = await mysqlquery(table_row_query, [
        req.body.applicant_id,
      ]);
      record_id = null;
      if (table_record_id.length > 0) {
        const applicant_data = Object.values(table_record_id);
        var record_id = applicant_data[0].address_id;
      }
      const processdelete = `DELETE FROM  ${db_table.process_status} WHERE applicant_Id=? and process_id=?`;
      const delete_data = await mysqlquery(processdelete, [
        req.body.applicant_id,
        req.body.process_id,
      ]);

      const update_address_details = [
        req.body.permenant_address_type,
        req.body.permenant_house_number,
        req.body.permenant_house_or_building_name,
        req.body.permenant_road_or_street_name,
        req.body.permenant_landmark,
        req.body.permenant_city,
        req.body.permenant_state,
        req.body.permenant_country_id,
        req.body.permenant_pincode,
        req.body.jurisdiction_address_type,
        req.body.jurisdiction_house_number,
        req.body.jurisdiction_house_or_building_name,
        req.body.jurisdiction_road_or_street_name,
        req.body.jurisdiction_landmark,
        req.body.jurisdiction_state,
        req.body.jurisdiction_city,
        req.body.jurisdiction_country_id,
        req.body.jurisdiction_pincode,
        req.body.preffered_mailing,
        req.body.jurisdiction_address_as,
        req.body.permenant_address_as,
        req.body.applicant_id,
      ];
      let sql = `update ${db_table.address_details} SET
            permenant_address_type=?,permenant_house_number=?,  
            permenant_house_or_building_name=?,
            permenant_road_or_street_name=?,
            permenant_landmark=?,permenant_state=?,
            permenant_city=?,permenant_country_id=?,permenant_pincode=?,
            jurisdiction_address_type=?,jurisdiction_house_number=?,
            jurisdiction_house_or_building_name=?,
            jurisdiction_road_or_street_name=?,
            jurisdiction_landmark=?,jurisdiction_state=?,
            jurisdiction_city=?,jurisdiction_country_id=?,
            jurisdiction_pincode=?,preffered_mailing=?,jurisdiction_address_as=?,permenant_address_as=? where applicant_id=?`;
      const updateaddress = await mysqlquery(sql, update_address_details);

      const submit_process_data = {
        applicant_id: req.body.applicant_id,
        process_id: req.body.process_id,
        agent_status: req.body.agent_status,
      };
      let sql_process_data = `INSERT INTO ${db_table.process_status} SET ? `;
      const submit_process = await mysqlquery(
        sql_process_data,
        submit_process_data
      );

      let find_user = `SELECT * FROM ${db_table.applicant_persional_details} WHERE user_id=? `;
      let userfind = await mysqlquery(find_user, user_id);

      const sqli = `select lead_status from ${db_table.leads} where user_id=?`;
      const sqli_result = await mysqlquery(sqli, user_id);

      if (sqli_result[0].lead_status === "agent_review") {
        let get_status = `update ${db_table.comment} SET status = 'replied' WHERE applicant_id = ${applicant_id} and process_id = ${process_id}`;
        const status_query = await mysqlquery(get_status);

        const check_all_status = `SELECT status FROM ${db_table.comment} WHERE applicant_id = ? AND STATUS != 'replied'`;
        const status_check_all_status = await mysqlquery(
          check_all_status,
          applicant_id
        );

        if (status_check_all_status.length >= 0) {
          var in_query = "";
          userfind.forEach((uf) => {
            in_query += uf.applicant_personal_id + ",";
          });
          if (in_query != "") {
            in_query = in_query.substring(0, in_query.length - 1);
            const check_all_status = `SELECT status FROM ${db_table.comment} WHERE applicant_id IN (${in_query}) AND STATUS = 'added'`;
            const status_result = await mysqlquery(check_all_status);

            const lead_id = `SELECT lead_id FROM ${db_table.comment} WHERE applicant_id = ?`;
            const result = await mysqlquery(lead_id, applicant_id);

            if (status_result.length === 0) {
              const update_status = `update ${db_table.leads} set lead_status = 'agent_process' where lead_id = ?`;
              const results = await mysqlquery(
                update_status,
                result[0].lead_id
              );
            }
          }
        }
      }

      if (updateaddress.affectedRows > 0) {
        res.status(200).json({
          msg: "update address details successfully",
          address_id: getAddressid[0].address_id,
          record_id: record_id,
        });
      } else {
        res.status(400).json({
          msg: "something went wrong",
        });
      }
    } else {
      res.status(400).json({
        msg: "bad request",
      });
    }
  } catch (error) {
    res.status(400).json({
      msg: error.message ? error.message : error,
    });
  }
};

module.exports.getAccountVariant = async (req, res) => {
  try {
    let request = req.body;

    if (request.applicant_id) {
      let sql1 =
        "SELECT account_varient FROM `tbl_applicant_personal_details` WHERE applicant_personal_id = ?";
      const getApplicantVariant = await mysqlquery(sql1, request.applicant_id);

      res.status(200).json({
        data: getApplicantVariant,
      });
    } else {
      res.status(400).json({
        msg: "bad request",
      });
    }
  } catch (error) {
    res.status(400).json({
      msg: error.message ? error.message : error,
    });
  }
};

module.exports.submit_customer_profilers = async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      res.status(409).json({ errors: errors.array() });
    }

    if (
      req.body.customer_profiler === "" ||
      req.body.customer_profiler === undefined ||
      req.body.customer_profiler === "0" ||
      req.body.customer_profiler === null
    ) {
      const submit_address_details = {
        applicant_id: req.body.applicant_id,
        qualification: req.body.qualification,
        employment_type_id: req.body.employment_type_id,
        occupation_id: req.body.occupation_id,
        source_income: req.body.source_income,
        gross_annual_income: req.body.gross_annual_income,
        industry_type_id: req.body.industry_type_id,
      };

      let sql = `INSERT INTO ${db_table.customer_profilers} SET ? `;
      const submitaddress = await mysqlquery(sql, submit_address_details);
      const submit_process_data = {
        applicant_id: req.body.applicant_id,
        process_id: req.body.process_id,
        agent_status: req.body.agent_status,
      };
      let sql_process_data = `INSERT INTO ${db_table.process_status} SET ? `;
      const submit_process = await mysqlquery(
        sql_process_data,
        submit_process_data
      );
      if (submitaddress.insertId > 0) {
        res.status(200).json({
          msg: "save customers details successfully",
        });
      } else {
        res.status(400).json({
          msg: "something went wrong",
        });
      }
    } else {
      if (req.body.customer_profiler) {
        let applicant_id = req.body.applicant_id;
        let process_id = req.body.process_id;
        let user_sql = `SELECT * FROM ${db_table.applicant_persional_details} WHERE applicant_personal_id=?`;
        let user_result = await mysqlquery(user_sql, [applicant_id]);
        let user_id = user_result[0].user_id;

        const processdelete = `DELETE FROM  ${db_table.process_status} WHERE applicant_Id=? and process_id=?`;
        const delete_data = await mysqlquery(processdelete, [
          req.body.applicant_id,
          req.body.process_id,
        ]);

        const update_customers_details = [
          req.body.applicant_id,
          req.body.qualification,
          req.body.employment_type_id,
          req.body.occupation_id,
          req.body.source_income,
          req.body.gross_annual_income,
          req.body.industry_type_id,
          req.body.applicant_id,
        ];
        let sql = `update ${db_table.customer_profilers} SET applicant_id=?,qualification=?, employment_type_id=?,occupation_id=?, source_income=?,gross_annual_income=?,industry_type_id=? WHERE applicant_id=?`;
        const updatecustomerdet = await mysqlquery(
          sql,
          update_customers_details
        );

        let find_user = `SELECT * FROM ${db_table.applicant_persional_details} WHERE user_id=? `;
        let userfind = await mysqlquery(find_user, user_id);

        const sqli = `select lead_status from ${db_table.leads} where user_id=?`;
        const sqli_result = await mysqlquery(sqli, user_id);

        if (sqli_result[0].lead_status === "agent_review") {
          let get_status = `update ${db_table.comment} SET status = 'replied' WHERE applicant_id = ${applicant_id} and process_id = ${process_id}`;
          const status_query = await mysqlquery(get_status);

          const check_all_status = `SELECT status FROM ${db_table.comment} WHERE applicant_id = ? AND STATUS != 'replied'`;
          const status_check_all_status = await mysqlquery(
            check_all_status,
            applicant_id
          );

          if (status_check_all_status.length >= 0) {
            var in_query = "";
            userfind.forEach((uf) => {
              in_query += uf.applicant_personal_id + ",";
            });
            if (in_query != "") {
              in_query = in_query.substring(0, in_query.length - 1);
              const check_all_status = `SELECT status FROM ${db_table.comment} WHERE applicant_id IN (${in_query}) AND STATUS = 'added'`;
              const status_result = await mysqlquery(check_all_status);

              const lead_id = `SELECT lead_id FROM ${db_table.comment} WHERE applicant_id = ?`;
              const result = await mysqlquery(lead_id, applicant_id);

              if (status_result.length === 0) {
                const update_status = `update ${db_table.leads} set lead_status = 'agent_process' where lead_id = ?`;
                const results = await mysqlquery(
                  update_status,
                  result[0].lead_id
                );
              }
            }
          }
        }

        const submit_process_data = {
          applicant_id: req.body.applicant_id,
          process_id: req.body.process_id,
          agent_status: req.body.agent_status,
        };
        let sql_process_data = `INSERT INTO ${db_table.process_status} SET ? `;
        const submit_process = await mysqlquery(
          sql_process_data,
          submit_process_data
        );

        if (updatecustomerdet.affectedRows > 0) {
          res.status(200).json({
            msg: "update customers details successfully",
          });
        } else {
          res.status(400).json({
            msg: "something went wrong",
          });
        }
      } else {
        res.status(400).json({
          msg: "bad request",
        });
      }
    }
  } catch (error) {
    res.status(400).json({
      msg: error.message ? error.message : error,
    });
  }
};

module.exports.submit_banking_facilities_1 = async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      res.status(409).json({ errors: errors.array() });
    }
    if (!!!req.body.banking_facilities_id) {
      const submit_banking_facility = {
        applicant_id: req.body.applicant_id,
        is_internet_banking_selected: req.body.is_internet_banking_selected,
        is_mobile_banking_selected: req.body.is_mobile_banking_selected,
        debit_card_type: req.body.debit_card_type,
        card_variant: req.body.card_variant,
      };
      let sql = `INSERT INTO ${db_table.banking_facilities} SET ? `;
      const submitbanfacility = await mysqlquery(sql, submit_banking_facility);
      const submit_process_data = {
        applicant_id: req.body.applicant_id,
        process_id: req.body.process_id,
        agent_status: req.body.agent_status,
      };
      let sql_process_data = `INSERT INTO ${db_table.process_status} SET ? `;
      const submit_process = await mysqlquery(
        sql_process_data,
        submit_process_data
      );

      if (submitbanfacility.insertId > 0) {
        let user_id = submit_banking_facility.user_id;
        res.status(200).json({
          msg: "save banking facilities successfully",
          banking_facilities_id: submitbanfacility.insertId,
        });
      } else {
        res.status(400).json({
          msg: "something went wrong",
        });
      }
    } else {
      if (!!req.body.banking_facilities_id) {
        let applicant_id = req.body.applicant_id;
        let process_id = req.body.process_id;
        let user_sql = `SELECT * FROM ${db_table.applicant_persional_details} WHERE applicant_personal_id=?`;
        let user_result = await mysqlquery(user_sql, [applicant_id]);
        let user_id = user_result[0].user_id;

        // let Applicant_Id='applicant_id'
        // let table_params = {
        //    'tableName':db_table.kyc_details,
        //    "applicantid":Applicant_Id
        //  };

        //  const table_row_query =  await get_table_id(table_params);
        //  const table_record_id = await mysqlquery(table_row_query, [req.body.applicant_id]);

        //  if(table_record_id.length>0){
        //  const applicant_data = Object.values(table_record_id);
        //  var record_id = applicant_data[0].banking_facilities_id;
        //  }
        //  record_id=null

        const processdelete = `DELETE FROM  ${db_table.process_status} WHERE applicant_Id=? and process_id=?`;
        const delete_data = await mysqlquery(processdelete, [
          req.body.applicant_id,
          req.body.process_id,
        ]);
        const update_customers_details = [
          req.body.applicant_id,
          req.body.is_internet_banking_selected,
          req.body.is_mobile_banking_selected,
          req.body.debit_card_type,
          req.body.card_variant,
          req.body.banking_facilities_id,
        ];

        let sql = `update ${db_table.banking_facilities} SET applicant_id=?,is_internet_banking_selected=?,
            is_mobile_banking_selected=?,debit_card_type=?,card_variant=? WHERE banking_facilities_id=?`;
        const updatecustomerdet = await mysqlquery(
          sql,
          update_customers_details
        );

        const submit_process_data = {
          applicant_id: req.body.applicant_id,
          process_id: req.body.process_id,
          agent_status: req.body.agent_status,
        };
        let sql_process_data = `INSERT INTO ${db_table.process_status} SET ? `;
        const submit_process = await mysqlquery(
          sql_process_data,
          submit_process_data
        );

        let find_user = `SELECT * FROM ${db_table.applicant_persional_details} WHERE user_id=? `;
        let userfind = await mysqlquery(find_user, user_id);

        const sqli = `select lead_status from ${db_table.leads} where user_id=?`;
        const sqli_result = await mysqlquery(sqli, user_id);

        if (sqli_result[0].lead_status === "agent_review") {
          let get_status = `update ${db_table.comment} SET status = 'replied' WHERE applicant_id = ${applicant_id} and process_id = ${process_id}`;
          const status_query = await mysqlquery(get_status);

          const check_all_status = `SELECT status FROM ${db_table.comment} WHERE applicant_id = ? AND STATUS != 'replied'`;
          const status_check_all_status = await mysqlquery(
            check_all_status,
            applicant_id
          );

          if (status_check_all_status.length >= 0) {
            var in_query = "";
            userfind.forEach((uf) => {
              in_query += uf.applicant_personal_id + ",";
            });
            if (in_query != "") {
              in_query = in_query.substring(0, in_query.length - 1);
              const check_all_status = `SELECT status FROM ${db_table.comment} WHERE applicant_id IN (${in_query}) AND STATUS = 'added'`;
              const status_result = await mysqlquery(check_all_status);

              const lead_id = `SELECT lead_id FROM ${db_table.comment} WHERE applicant_id = ?`;
              const result = await mysqlquery(lead_id, applicant_id);

              if (status_result.length === 0) {
                const update_status = `update ${db_table.leads} set lead_status = 'agent_process' where lead_id = ?`;
                const results = await mysqlquery(
                  update_status,
                  result[0].lead_id
                );
              }
            }
          }
        }

        if (updatecustomerdet.affectedRows > 0) {
          res.status(200).json({
            msg: "update customers details successfully",
            banking_facilities_id: req.body.banking_facilities_id,
            // record_id:record_id
          });
        } else {
          res.status(400).json({
            msg: "something went wrong",
          });
        }
      } else {
        res.status(400).json({
          msg: "bad request",
        });
      }
    }
  } catch (error) {
    res.status(400).json({
      msg: error.message ? error.message : error,
    });
  }
};

module.exports.submit_banking_facilities_2 = async (req, res) => {
  try {
    let applicant_id = req.body.applicant_id;
    let process_id = req.body.process_id;
    let user_sql = `SELECT * FROM ${db_table.applicant_persional_details} WHERE applicant_personal_id=?`;
    let user_result = await mysqlquery(user_sql, [applicant_id]);
    let user_id = user_result[0].user_id;

    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      res.status(409).json({ errors: errors.array() });
    }
    var daily_balance_alert_mode = JSON.stringify(
      req.body.daily_balance_alert_mode
    );
    var card_alert_mode = JSON.stringify(req.body.card_alert_mode);
    let sql1 =
      "SELECT banking_facilities_id FROM `tbl_banking_facilities` WHERE applicant_id =?";
    const getBankingId = await mysqlquery(sql1, [req.body.applicant_id]);
    if (getBankingId.length > 0) {
      let BamkingId = getBankingId[0].banking_facilities_id;

      let Applicant_Id = "applicant_id";
      let table_params = {
        tableName: db_table.kyc_details,
        applicantid: Applicant_Id,
      };

      const table_row_query = await get_table_id(table_params);
      const table_record_id = await mysqlquery(table_row_query, [
        req.body.applicant_id,
      ]);
      record_id = null;
      if (table_record_id.length > 0) {
        const applicant_data = Object.values(table_record_id);
        var record_id = applicant_data[0].banking_facilities_id;
      }

      const processdelete = `DELETE FROM  ${db_table.process_status} WHERE applicant_Id=? and process_id=?`;
      const delete_data = await mysqlquery(processdelete, [
        req.body.applicant_id,
        req.body.process_id,
      ]);

      const update_customers_details = [
        req.body.applicant_id,
        req.body.is_cheque_book_selected,
        req.body.is_daily_balance_alert_selected,
        daily_balance_alert_mode,
        req.body.is_card_alert_selected,
        card_alert_mode,
        BamkingId,
      ];
      let sql = `update ${db_table.banking_facilities} SET applicant_id=?,is_cheque_book_selected=?,is_daily_balance_alert_selected=?,daily_balance_alert_mode=?,is_card_alert_selected=?,card_alert_mode=? WHERE banking_facilities_id=?`;
      const updatecustomerdet = await mysqlquery(sql, update_customers_details);

      const submit_process_data = {
        applicant_id: req.body.applicant_id,
        process_id: req.body.process_id,
        agent_status: req.body.agent_status,
      };
      let sql_process_data = `INSERT INTO ${db_table.process_status} SET ? `;
      const submit_process = await mysqlquery(
        sql_process_data,
        submit_process_data
      );

      let find_user = `SELECT * FROM ${db_table.applicant_persional_details} WHERE user_id=? `;
      let userfind = await mysqlquery(find_user, user_id);

      const sqli = `select lead_status from ${db_table.leads} where user_id=?`;
      const sqli_result = await mysqlquery(sqli, user_id);

      if (sqli_result[0].lead_status === "agent_review") {
        let get_status = `update ${db_table.comment} SET status = 'replied' WHERE applicant_id = ${applicant_id} and process_id = ${process_id}`;
        const status_query = await mysqlquery(get_status);

        const check_all_status = `SELECT status FROM ${db_table.comment} WHERE applicant_id = ? AND STATUS != 'replied'`;
        const status_result = await mysqlquery(check_all_status, applicant_id);

        if (status_result.length >= 0) {
          var in_query = "";
          userfind.forEach((uf) => {
            in_query += uf.applicant_personal_id + ",";
          });
          if (in_query != "") {
            in_query = in_query.substring(0, in_query.length - 1);
            const check_all_status = `SELECT status FROM ${db_table.comment} WHERE applicant_id IN (${in_query}) AND STATUS = 'added'`;
            const status_result = await mysqlquery(check_all_status);

            const lead_id = `SELECT lead_id FROM ${db_table.comment} WHERE applicant_id = ?`;
            const result = await mysqlquery(lead_id, applicant_id);

            if (status_result.length === 0) {
              const update_status = `update ${db_table.leads} set lead_status = 'agent_process' where lead_id = ?`;
              const results = await mysqlquery(
                update_status,
                result[0].lead_id
              );
            }
          }
        }
      }

      if (updatecustomerdet.affectedRows > 0) {
        res.status(200).json({
          msg: "update customers details successfully",
          record_id: record_id,
        });
      } else {
        res.status(400).json({
          msg: "something went wrong",
        });
      }
    } else {
      res.status(400).json({
        msg: "bad resquest",
      });
    }
  } catch (error) {
    console.log(error);
    res.status(400).json({
      msg: error.message ? error.message : error,
    });
  }
};

module.exports.submit_passport_doc = async (req, res, next) => {
  try {
    let applicant_id = req.body.applicant_id;
    let process_id = req.body.process_id;
    let user_sql = `SELECT * FROM ${db_table.applicant_persional_details} WHERE applicant_personal_id=?`;
    let user_result = await mysqlquery(user_sql, [applicant_id]);
    let user_id = user_result[0].user_id;

    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      res.status(409).json({ errors: errors.array() });
    }
    let dir_name = `./public/documents/${req.body.applicant_id}`;
    if (!fs.existsSync(dir_name)) {
      fs.mkdirSync(dir_name, { recursive: true });
    }
    let document_uploaded = 0;
    let banking_doc_id = 0;

    let file_name = `passport_front.jpg`;
    let file_path = `${dir_name}/${file_name}`;
    let saved_file = await store_file(file_path, req.body.passport_front);
    if (saved_file.status) {
      let file_name_1 = `passport_back.jpg`;
      let file_path_1 = `${dir_name}/${file_name_1}`;
      let saved_file = await store_file(file_path_1, req.body.passport_back);
      if (saved_file.status) {
        let check_document_exixst = await is_document_exists(
          req.body.applicant_id
        );
        if (check_document_exixst.length == 0) {
          const submit_bank_doc_data = {
            applicant_id: req.body.applicant_id,
            passport_front: file_name,
            passport_back: file_name_1,
          };
          const insert_abank_doc_sql = `INSERT INTO ${db_table.banking_document} SET ? `;
          const submit_bank_doc_result = await mysqlquery(
            insert_abank_doc_sql,
            submit_bank_doc_data
          );
          if (submit_bank_doc_result.insertId > 0) {
            banking_doc_id = submit_bank_doc_result.insertId;
            document_uploaded++;
          }
        } else {
          const update_bank_doc_data = [
            file_name,
            file_name_1,
            req.body.applicant_id,
          ];
          const update_bank_doc_sql = `UPDATE ${db_table.banking_document} SET passport_front = ?,  passport_back = ? WHERE applicant_Id = ?`;
          const update_bank_doc_result = await mysqlquery(
            update_bank_doc_sql,
            update_bank_doc_data
          );
          const submit_process_data = {
            applicant_id: req.body.applicant_id,
            process_id: req.body.process_id,
            agent_status: req.body.agent_status,
          };

          const processdelete = `DELETE FROM  ${db_table.process_status} WHERE applicant_Id=? and process_id=?`;
          const delete_data = await mysqlquery(processdelete, [
            req.body.applicant_id,
            req.body.process_id,
          ]);
          let sql_process_data = `INSERT INTO ${db_table.process_status} SET ? `;
          const submit_process = await mysqlquery(
            sql_process_data,
            submit_process_data
          );
          if (update_bank_doc_result.affectedRows > 0) {
            banking_doc_id = update_bank_doc_result.affectedRows;
            document_uploaded++;
          }
          let find_user = `SELECT * FROM ${db_table.applicant_persional_details} WHERE user_id=? `;
          let userfind = await mysqlquery(find_user, user_id);

          const sqli = `select lead_status from ${db_table.leads} where user_id=?`;
          const sqli_result = await mysqlquery(sqli, user_id);
          console.log("sqli_result", sqli_result);
          if (sqli_result[0].lead_status === "agent_review") {
            let get_status = `update ${db_table.comment} SET status = 'replied' WHERE applicant_id = ${applicant_id} and process_id = ${process_id}`;
            const status_query = await mysqlquery(get_status);

            const check_all_status = `SELECT status FROM ${db_table.comment} WHERE applicant_id = ? AND STATUS != 'replied'`;
            const status_check_all_status = await mysqlquery(
              check_all_status,
              applicant_id
            );

            if (status_check_all_status.length >= 0) {
              var in_query = "";
              userfind.forEach((uf) => {
                in_query += uf.applicant_personal_id + ",";
              });
              if (in_query != "") {
                in_query = in_query.substring(0, in_query.length - 1);
                const check_all_status = `SELECT status FROM ${db_table.comment} WHERE applicant_id IN (${in_query}) AND STATUS = 'added'`;
                const status_result = await mysqlquery(check_all_status);

                const lead_id = `SELECT lead_id FROM ${db_table.comment} WHERE applicant_id = ?`;
                const result = await mysqlquery(lead_id, applicant_id);

                if (status_result.length === 0) {
                  const update_status = `update ${db_table.leads} set lead_status = 'agent_process' where lead_id = ?`;
                  const results = await mysqlquery(
                    update_status,
                    result[0].lead_id
                  );
                }
              }
            }
          }
        }

        if (document_uploaded > 0) {
          await insert_process(req.body.applicant_id, req.body.process_id);
          res.status(200).json({
            data: "document saved successfully",
            banking_doc_id: banking_doc_id,
          });
        } else {
          res.status(400).json({
            msg: "something went wrong",
          });
        }
      } else {
        res.status(400).json({
          msg: saved_file.message,
        });
      }
    } else {
      res.status(400).json({
        msg: saved_file.message,
      });
    }
  } catch (error) {
    console.log(error);
    res.status(400).json({
      msg: error.message ? error.message : error,
    });
  }
};

module.exports.address_proof_types = async (req, res, next) => {
  const address_proof_types_sql = `SELECT address_proof_types_id as id,address_proof_types_name as name FROM ${db_table.address_proof_type}`;
  const address_proof_types_result = await mysqlquery(address_proof_types_sql);
  res.status(200).json({
    address_proof_types: address_proof_types_result,
  });
};

module.exports.address_proof_types = async (req, res, next) => {
  const address_proof_types_sql = `SELECT address_proof_types_id as id,address_proof_types_name as name FROM ${db_table.address_proof_type}`;
  const address_proof_types_result = await mysqlquery(address_proof_types_sql);
  res.status(200).json({
    address_proof_types: address_proof_types_result,
  });
};

module.exports.submit_address_proof_doc = async (req, res, next) => {
  try {
    var applicant_id = req.body.applicant_id;
    var process_id = req.body.process_id;
    let user_sql = `SELECT * FROM ${db_table.applicant_persional_details} WHERE applicant_personal_id=${applicant_id}`;
    let user_result = await mysqlquery(user_sql, [applicant_id]);
    const user_id = user_result[0].user_id;

    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      res.status(409).json({ errors: errors.array() });
    }
    let dir_name = `./public/documents/${req.body.applicant_id}`;
    if (!fs.existsSync(dir_name)) {
      fs.mkdirSync(dir_name);
    }
    let document_uploaded = 0;
    let banking_doc_id = 0;
    let file_name = `address_proof.jpg`;
    let file_path = `${dir_name}/${file_name}`;
    let saved_file = await store_file(file_path, req.body.file);
    var issu_date = req.body.issue_date;
    var iss_date = issu_date?.split("T")[0];
    var expi_date = req.body.expiry_date;
    var expir_date = expi_date?.split("T")[0];
    if (saved_file.status) {
      let check_document_exixst = await is_document_exists(
        req.body.applicant_id
      );
      if (check_document_exixst.length == 0) {
        const submit_bank_doc_data = {
          applicant_id: req.body.applicant_id,
          address_proof_type_id: req.body.address_proof_type,
          place_of_issue: req.body.place_of_issue,
          issuing_authority: req.body.issuing_authority,
          document_identification_number:
            req.body.document_identification_number,
          issue_date: iss_date,
          expiry_date: expir_date,
          address_proof: file_name,
        };
        const insert_bank_doc_sql = `INSERT INTO ${db_table.banking_document} SET ? `;
        const submit_bank_doc_result = await mysqlquery(
          insert_bank_doc_sql,
          submit_bank_doc_data
        );
        if (submit_bank_doc_result.insertId > 0) {
          banking_doc_id = submit_bank_doc_result.insertId;
          document_uploaded++;
        }
      } else {
        const submit_process_data = {
          applicant_id: req.body.applicant_id,
          process_id: req.body.process_id,
          agent_status: req.body.agent_status,
        };

        const processdelete = `DELETE FROM  ${db_table.process_status} WHERE applicant_Id=? and process_id=?`;
        const delete_data = await mysqlquery(processdelete, [
          req.body.applicant_id,
          req.body.process_id,
        ]);
        let sql_process_data = `INSERT INTO ${db_table.process_status} SET ? `;
        const submit_process = await mysqlquery(
          sql_process_data,
          submit_process_data
        );
        const update_bank_doc_data = [
          req.body.address_proof_type,
          req.body.place_of_issue,
          req.body.issuing_authority,
          req.body.document_identification_number,
          iss_date,
          expir_date,
          file_name,
          req.body.applicant_id,
        ];
        let applicant_id = req.body.applicant_id;
        const update_bank_doc_sql = `UPDATE ${db_table.banking_document} SET address_proof_type_id = ?,  place_of_issue = ?, issuing_authority = ?, document_identification_number = ?, issue_date = ?, expiry_date = ?, address_proof = ? WHERE applicant_Id = ?`;
        const update_bank_doc_result = await mysqlquery(
          update_bank_doc_sql,
          update_bank_doc_data
        );
        if (update_bank_doc_result.affectedRows > 0) {
          banking_doc_id = update_bank_doc_result.affectedRows;
          document_uploaded++;
        }
        let find_user = `SELECT * FROM ${db_table.applicant_persional_details} WHERE user_id=? `;
        let userfind = await mysqlquery(find_user, user_id);

        const sqli = `select lead_status from ${db_table.leads} where user_id=?`;
        const sqli_result = await mysqlquery(sqli, user_id);

        if (sqli_result[0].lead_status === "agent_review") {
          let get_status = `update ${db_table.comment} SET status = 'replied' WHERE applicant_id = ${applicant_id} and process_id = ${process_id}`;
          const status_query = await mysqlquery(get_status);

          const check_all_status = `SELECT status FROM ${db_table.comment} WHERE applicant_id = ? AND STATUS != 'replied'`;
          const status_check_all_status = await mysqlquery(
            check_all_status,
            applicant_id
          );

          if (status_check_all_status.length >= 0) {
            var in_query = "";
            userfind.forEach((uf) => {
              in_query += uf.applicant_personal_id + ",";
            });
            if (in_query != "") {
              in_query = in_query.substring(0, in_query.length - 1);
              const check_all_status = `SELECT status FROM ${db_table.comment} WHERE applicant_id IN (${in_query}) AND STATUS = 'added'`;
              const status_result = await mysqlquery(check_all_status);

              const lead_id = `SELECT lead_id FROM ${db_table.comment} WHERE applicant_id = ?`;
              const result = await mysqlquery(lead_id, applicant_id);

              if (status_result.length === 0) {
                const update_status = `update ${db_table.leads} set lead_status = 'agent_process' where lead_id = ?`;
                const results = await mysqlquery(
                  update_status,
                  result[0].lead_id
                );
              }
            }
          }
        }
      }

      if (document_uploaded > 0) {
        await insert_process(req.body.applicant_id, req.body.process_id);
        res.status(200).json({
          msg: "document saved successfully",
          banking_doc_id: banking_doc_id,
        });
      } else {
        res.status(400).json({
          msg: "something went wrong",
        });
      }
    } else {
      res.status(400).json({
        msg: saved_file.message,
      });
    }
  } catch (error) {
    res.status(400).json({
      msg: error.message ? error.message : error,
    });
  }
};

module.exports.submit_form_sixty_doc = async (req, res, next) => {
  try {
    var applicant_id = req.body.applicant_id;
    var process_id = req.body.process_id;
    let user_sql = `SELECT * FROM ${db_table.applicant_persional_details} WHERE applicant_personal_id=${applicant_id}`;
    let user_result = await mysqlquery(user_sql, [applicant_id]);
    const user_id = user_result[0].user_id;

    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      res.status(409).json({ errors: errors.array() });
    }
    let dir_name = `./public/documents/${req.body.applicant_id}`;
    if (!fs.existsSync(dir_name)) {
      fs.mkdirSync(dir_name);
    }
    let document_uploaded = 0;
    let banking_doc_id = 0;
    let file_name = `form_sixty.jpg`;
    let file_path = `${dir_name}/${file_name}`;
    let saved_file = await store_file(file_path, req.body.file);
    if (saved_file.status) {
      let check_document_exixst = await is_document_exists(
        req.body.applicant_id
      );
      if (check_document_exixst.length == 0) {
        const submit_bank_doc_data = {
          applicant_id: req.body.applicant_id,
          form_sixty: file_name,
        };
        const insert_abank_doc_sql = `INSERT INTO ${db_table.banking_document} SET ? `;
        const submit_bank_doc_result = await mysqlquery(
          insert_abank_doc_sql,
          submit_bank_doc_data
        );
        if (submit_bank_doc_result.insertId > 0) {
          banking_doc_id = submit_bank_doc_result.insertId;
          document_uploaded++;
        }
      } else {
        const update_bank_doc_data = [file_name, req.body.applicant_id];
        const update_bank_doc_sql = `UPDATE ${db_table.banking_document} SET form_sixty = ? WHERE applicant_Id = ?`;
        const update_bank_doc_result = await mysqlquery(
          update_bank_doc_sql,
          update_bank_doc_data
        );
        if (update_bank_doc_result.affectedRows > 0) {
          banking_doc_id = update_bank_doc_result.affectedRows;
          document_uploaded++;
        }
        let find_user = `SELECT * FROM ${db_table.applicant_persional_details} WHERE user_id=? `;
        let userfind = await mysqlquery(find_user, user_id);

        const sqli = `select lead_status from ${db_table.leads} where user_id=?`;
        const sqli_result = await mysqlquery(sqli, user_id);

        const submit_process_data = {
          applicant_id: req.body.applicant_id,
          process_id: req.body.process_id,
          agent_status: req.body.agent_status,
        };

        const processdelete = `DELETE FROM  ${db_table.process_status} WHERE applicant_Id=? and process_id=?`;
        const delete_data = await mysqlquery(processdelete, [
          req.body.applicant_id,
          req.body.process_id,
        ]);
        let sql_process_data = `INSERT INTO ${db_table.process_status} SET ? `;
        const submit_process = await mysqlquery(
          sql_process_data,
          submit_process_data
        );

        if (sqli_result[0].lead_status === "agent_review") {
          let get_status = `update ${db_table.comment} SET status = 'replied' WHERE applicant_id = ${applicant_id} and process_id = ${process_id}`;
          const status_query = await mysqlquery(get_status);

          const check_all_status = `SELECT status FROM ${db_table.comment} WHERE applicant_id = ? AND STATUS != 'replied'`;
          const status_check_all_status = await mysqlquery(
            check_all_status,
            applicant_id
          );

          if (status_check_all_status.length >= 0) {
            var in_query = "";
            userfind.forEach((uf) => {
              in_query += uf.applicant_personal_id + ",";
            });
            if (in_query != "") {
              in_query = in_query.substring(0, in_query.length - 1);
              const check_all_status = `SELECT status FROM ${db_table.comment} WHERE applicant_id IN (${in_query}) AND STATUS = 'added'`;
              const status_result = await mysqlquery(check_all_status);

              const lead_id = `SELECT lead_id FROM ${db_table.comment} WHERE applicant_id = ?`;
              const result = await mysqlquery(lead_id, applicant_id);

              if (status_result.length === 0) {
                const update_status = `update ${db_table.leads} set lead_status = 'agent_process' where lead_id = ?`;
                const results = await mysqlquery(
                  update_status,
                  result[0].lead_id
                );
              }
            }
          }
        }
      }

      if (document_uploaded > 0) {
        await insert_process(req.body.applicant_id, req.body.process_id);
        res.status(200).json({
          msg: "document saved successfully",
          banking_doc_id: banking_doc_id,
        });
      } else {
        res.status(400).json({
          msg: "something went wrong",
        });
      }
    } else {
      res.status(400).json({
        msg: saved_file.message,
      });
    }
  } catch (error) {
    res.status(400).json({
      msg: error.message ? error.message : error,
    });
  }
};

module.exports.submit_visa_doc = async (req, res, next) => {
  try {
    var applicant_id = req.body.applicant_id;
    var process_id = req.body.process_id;
    let user_sql = `SELECT * FROM ${db_table.applicant_persional_details} WHERE applicant_personal_id=${applicant_id}`;
    let user_result = await mysqlquery(user_sql, [applicant_id]);
    const user_id = user_result[0].user_id;

    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      res.status(409).json({ errors: errors.array() });
    }
    let dir_name = `./public/documents/${req.body.applicant_id}`;
    if (!fs.existsSync(dir_name)) {
      fs.mkdirSync(dir_name);
    }
    let document_uploaded = 0;
    let banking_doc_id = 0;
    let file_name = `visa.jpg`;
    let file_path = `${dir_name}/${file_name}`;
    let saved_file = await store_file(file_path, req.body.file);
    if (saved_file.status) {
      let check_document_exixst = await is_document_exists(
        req.body.applicant_id
      );
      if (check_document_exixst.length == 0) {
        const submit_bank_doc_data = {
          applicant_id: req.body.applicant_id,
          visa: file_name,
        };
        const insert_abank_doc_sql = `INSERT INTO ${db_table.banking_document} SET ? `;
        const submit_bank_doc_result = await mysqlquery(
          insert_abank_doc_sql,
          submit_bank_doc_data
        );
        if (submit_bank_doc_result.insertId > 0) {
          banking_doc_id = submit_bank_doc_result.insertId;
          document_uploaded++;
        }
      } else {
        const update_bank_doc_data = [file_name, req.body.applicant_id];
        const update_bank_doc_sql = `UPDATE ${db_table.banking_document} SET visa = ? WHERE applicant_Id = ?`;
        const update_bank_doc_result = await mysqlquery(
          update_bank_doc_sql,
          update_bank_doc_data
        );
        if (update_bank_doc_result.affectedRows > 0) {
          banking_doc_id = update_bank_doc_result.affectedRows;
          document_uploaded++;
        }
        let find_user = `SELECT * FROM ${db_table.applicant_persional_details} WHERE user_id=? `;
        let userfind = await mysqlquery(find_user, user_id);

        const sqli = `select lead_status from ${db_table.leads} where user_id=?`;
        const sqli_result = await mysqlquery(sqli, user_id);

        if (sqli_result[0].lead_status === "agent_review") {
          let get_status = `update ${db_table.comment} SET status = 'replied' WHERE applicant_id = ${applicant_id} and process_id = ${process_id}`;
          const status_query = await mysqlquery(get_status);

          const check_all_status = `SELECT status FROM ${db_table.comment} WHERE applicant_id = ? AND STATUS != 'replied'`;
          const status_check_all_status = await mysqlquery(
            check_all_status,
            applicant_id
          );

          if (status_check_all_status.length >= 0) {
            var in_query = "";
            userfind.forEach((uf) => {
              in_query += uf.applicant_personal_id + ",";
            });
            if (in_query != "") {
              in_query = in_query.substring(0, in_query.length - 1);
              const check_all_status = `SELECT status FROM ${db_table.comment} WHERE applicant_id IN (${in_query}) AND STATUS = 'added'`;
              const status_result = await mysqlquery(check_all_status);

              const lead_id = `SELECT lead_id FROM ${db_table.comment} WHERE applicant_id = ?`;
              const result = await mysqlquery(lead_id, applicant_id);

              if (status_result.length === 0) {
                const update_status = `update ${db_table.leads} set lead_status = 'agent_process' where lead_id = ?`;
                const results = await mysqlquery(
                  update_status,
                  result[0].lead_id
                );
              }
            }
          }
        }
      }

      if (document_uploaded > 0) {
        await insert_process(req.body.applicant_id, req.body.process_id);
        res.status(200).json({
          msg: "document saved successfully",
          banking_doc_id: banking_doc_id,
        });
      } else {
        res.status(400).json({
          msg: "something went wrong",
        });
      }
    } else {
      res.status(400).json({
        msg: saved_file.message,
      });
    }
  } catch (error) {
    res.status(400).json({
      msg: error.message ? error.message : error,
    });
  }
};

module.exports.submit_pio_doc = async (req, res, next) => {
  try {
    var applicant_id = req.body.applicant_id;
    var process_id = req.body.process_id;
    let user_sql = `SELECT * FROM ${db_table.applicant_persional_details} WHERE applicant_personal_id=${applicant_id}`;
    let user_result = await mysqlquery(user_sql, [applicant_id]);
    const user_id = user_result[0].user_id;

    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      res.status(409).json({ errors: errors.array() });
    }
    let dir_name = `./public/documents/${req.body.applicant_id}`;
    if (!fs.existsSync(dir_name)) {
      fs.mkdirSync(dir_name);
    }
    let document_uploaded = 0;
    let banking_doc_id = 0;
    let file_name = `old_indian_passport_front.jpg`;
    let file_path = `${dir_name}/${file_name}`;
    let saved_file = await store_file(file_path, req.body.passport_front);
    if (saved_file.status) {
      let file_name_1 = `old_indian_passport_back.jpg`;
      let file_path_1 = `${dir_name}/${file_name_1}`;
      let saved_file = await store_file(file_path_1, req.body.passport_back);
      if (saved_file.status) {
        let check_document_exixst = await is_document_exists(
          req.body.applicant_id
        );
        if (check_document_exixst.length == 0) {
          const submit_bank_doc_data = {
            applicant_id: req.body.applicant_id,
            old_indian_passport_front: file_name,
            old_indian_passport_back: file_name_1,
          };
          const insert_abank_doc_sql = `INSERT INTO ${db_table.banking_document} SET ? `;
          const submit_bank_doc_result = await mysqlquery(
            insert_abank_doc_sql,
            submit_bank_doc_data
          );
          if (submit_bank_doc_result.insertId > 0) {
            banking_doc_id = submit_bank_doc_result.insertId;
            document_uploaded++;
          }
        } else {
          const update_bank_doc_data = [
            file_name,
            file_name_1,
            req.body.applicant_id,
          ];
          const update_bank_doc_sql = `UPDATE ${db_table.banking_document} SET old_indian_passport_front = ?,  old_indian_passport_back = ? WHERE applicant_Id = ?`;
          const update_bank_doc_result = await mysqlquery(
            update_bank_doc_sql,
            update_bank_doc_data
          );
          if (update_bank_doc_result.affectedRows > 0) {
            banking_doc_id = update_bank_doc_result.affectedRows;
            document_uploaded++;
          }
          let find_user = `SELECT * FROM ${db_table.applicant_persional_details} WHERE user_id=? `;
          let userfind = await mysqlquery(find_user, user_id);

          const sqli = `select lead_status from ${db_table.leads} where user_id=?`;
          const sqli_result = await mysqlquery(sqli, user_id);

          if (sqli_result[0].lead_status === "agent_review") {
            let get_status = `update ${db_table.comment} SET status = 'replied' WHERE applicant_id = ${applicant_id} and process_id = ${process_id}`;
            const status_query = await mysqlquery(get_status);

            const check_all_status = `SELECT status FROM ${db_table.comment} WHERE applicant_id = ? AND STATUS != 'replied'`;
            const status_check_all_status = await mysqlquery(
              check_all_status,
              applicant_id
            );

            if (status_check_all_status.length >= 0) {
              var in_query = "";
              userfind.forEach((uf) => {
                in_query += uf.applicant_personal_id + ",";
              });
              if (in_query != "") {
                in_query = in_query.substring(0, in_query.length - 1);
                const check_all_status = `SELECT status FROM ${db_table.comment} WHERE applicant_id IN (${in_query}) AND STATUS = 'added'`;
                const status_result = await mysqlquery(check_all_status);

                const lead_id = `SELECT lead_id FROM ${db_table.comment} WHERE applicant_id = ?`;
                const result = await mysqlquery(lead_id, applicant_id);

                if (status_result.length === 0) {
                  const update_status = `update ${db_table.leads} set lead_status = 'agent_process' where lead_id = ?`;
                  const results = await mysqlquery(
                    update_status,
                    result[0].lead_id
                  );
                }
              }
            }
          }
        }

        if (document_uploaded > 0) {
          await insert_process(req.body.applicant_id, req.body.process_id);
          res.status(200).json({
            msg: "document saved successfully",
            banking_doc_id: banking_doc_id,
          });
        } else {
          res.status(400).json({
            msg: "something went wrong",
          });
        }
      } else {
        res.status(400).json({
          msg: saved_file.message,
        });
      }
    } else {
      res.status(400).json({
        msg: saved_file.message,
      });
    }
  } catch (error) {
    res.status(400).json({
      msg: error.message ? error.message : error,
    });
  }
};

module.exports.submit_oci_doc = async (req, res, next) => {
  try {
    var applicant_id = req.body.applicant_id;
    var process_id = req.body.process_id;
    let user_sql = `SELECT * FROM ${db_table.applicant_persional_details} WHERE applicant_personal_id=${applicant_id}`;
    let user_result = await mysqlquery(user_sql, [applicant_id]);
    const user_id = user_result[0].user_id;

    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      res.status(409).json({ errors: errors.array() });
    }
    let dir_name = `./public/documents/${req.body.applicant_id}`;
    if (!fs.existsSync(dir_name)) {
      fs.mkdirSync(dir_name);
    }
    let document_uploaded = 0;
    let banking_doc_id = 0;
    let file_name = `oci.jpg`;
    let file_path = `${dir_name}/${file_name}`;
    let saved_file = await store_file(file_path, req.body.file);
    if (saved_file.status) {
      let check_document_exixst = await is_document_exists(
        req.body.applicant_id
      );
      if (check_document_exixst.length == 0) {
        const submit_bank_doc_data = {
          applicant_id: req.body.applicant_id,
          oci: file_name,
        };
        const insert_abank_doc_sql = `INSERT INTO ${db_table.banking_document} SET ? `;
        const submit_bank_doc_result = await mysqlquery(
          insert_abank_doc_sql,
          submit_bank_doc_data
        );
        if (submit_bank_doc_result.insertId > 0) {
          banking_doc_id = submit_bank_doc_result.insertId;
          document_uploaded++;
        }
      } else {
        const update_bank_doc_data = [file_name, req.body.applicant_id];
        const update_bank_doc_sql = `UPDATE ${db_table.banking_document} SET oci = ? WHERE applicant_Id = ?`;
        const update_bank_doc_result = await mysqlquery(
          update_bank_doc_sql,
          update_bank_doc_data
        );
        if (update_bank_doc_result.affectedRows > 0) {
          banking_doc_id = update_bank_doc_result.affectedRows;
          document_uploaded++;
        }
        let find_user = `SELECT * FROM ${db_table.applicant_persional_details} WHERE user_id=? `;
        let userfind = await mysqlquery(find_user, user_id);

        const sqli = `select lead_status from ${db_table.leads} where user_id=?`;
        const sqli_result = await mysqlquery(sqli, user_id);

        if (sqli_result[0].lead_status === "agent_review") {
          let get_status = `update ${db_table.comment} SET status = 'replied' WHERE applicant_id = ${applicant_id} and process_id = ${process_id}`;
          const status_query = await mysqlquery(get_status);

          const check_all_status = `SELECT status FROM ${db_table.comment} WHERE applicant_id = ? AND STATUS != 'replied'`;
          const status_check_all_status = await mysqlquery(
            check_all_status,
            applicant_id
          );

          if (status_check_all_status.length >= 0) {
            var in_query = "";
            userfind.forEach((uf) => {
              in_query += uf.applicant_personal_id + ",";
            });
            if (in_query != "") {
              in_query = in_query.substring(0, in_query.length - 1);
              const check_all_status = `SELECT status FROM ${db_table.comment} WHERE applicant_id IN (${in_query}) AND STATUS = 'added'`;
              const status_result = await mysqlquery(check_all_status);

              const lead_id = `SELECT lead_id FROM ${db_table.comment} WHERE applicant_id = ?`;
              const result = await mysqlquery(lead_id, applicant_id);

              if (status_result.length === 0) {
                const update_status = `update ${db_table.leads} set lead_status = 'agent_process' where lead_id = ?`;
                const results = await mysqlquery(
                  update_status,
                  result[0].lead_id
                );
              }
            }
          }
        }
      }
      if (document_uploaded > 0) {
        await insert_process(req.body.applicant_id, req.body.process_id);
        res.status(200).json({
          msg: "document saved successfully",
          banking_doc_id: banking_doc_id,
        });
      } else {
        res.status(400).json({
          msg: "something went wrong",
        });
      }
    } else {
      res.status(400).json({
        msg: saved_file.message,
      });
    }
  } catch (error) {
    res.status(400).json({
      msg: error.message ? error.message : error,
    });
  }
};

module.exports.submit_other_doc = async (req, res, next) => {
  try {
    var applicant_id = req.body.applicant_id;
    var process_id = req.body.process_id;
    let user_sql = `SELECT * FROM ${db_table.applicant_persional_details} WHERE applicant_personal_id=${applicant_id}`;
    let user_result = await mysqlquery(user_sql, [applicant_id]);
    const user_id = user_result[0].user_id;

    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      res.status(409).json({ errors: errors.array() });
    }
    let dir_name = `./public/documents/${req.body.applicant_id}`;
    if (!fs.existsSync(dir_name)) {
      fs.mkdirSync(dir_name);
    }
    let document_uploaded = 0;
    let banking_doc_id = 0;
    let file_name = `other.jpg`;
    let file_path = `${dir_name}/${file_name}`;
    let saved_file = await store_file(file_path, req.body.file);
    if (saved_file.status) {
      let check_document_exixst = await is_document_exists(
        req.body.applicant_id
      );
      if (check_document_exixst.length == 0) {
        const submit_bank_doc_data = {
          applicant_id: req.body.applicant_id,
          other_document: file_name,
          other_document_comment: req.body.other_document_comment,
        };
        const insert_abank_doc_sql = `INSERT INTO ${db_table.banking_document} SET ? `;
        const submit_bank_doc_result = await mysqlquery(
          insert_abank_doc_sql,
          submit_bank_doc_data
        );
        if (submit_bank_doc_result.insertId > 0) {
          banking_doc_id = submit_bank_doc_result.insertId;
          document_uploaded++;
        }
      } else {
        const update_bank_doc_data = [
          file_name,
          req.body.other_document_comment,
          req.body.applicant_id,
        ];
        const update_bank_doc_sql = `UPDATE ${db_table.banking_document} SET other_document = ?, other_document_comment = ? WHERE applicant_Id = ?`;
        const update_bank_doc_result = await mysqlquery(
          update_bank_doc_sql,
          update_bank_doc_data
        );
        if (update_bank_doc_result.affectedRows > 0) {
          banking_doc_id = update_bank_doc_result.affectedRows;
          document_uploaded++;
        }
        let find_user = `SELECT * FROM ${db_table.applicant_persional_details} WHERE user_id=? `;
        let userfind = await mysqlquery(find_user, user_id);

        const sqli = `select lead_status from ${db_table.leads} where user_id=?`;
        const sqli_result = await mysqlquery(sqli, user_id);

        if (sqli_result[0].lead_status === "agent_review") {
          let get_status = `update ${db_table.comment} SET status = 'replied' WHERE applicant_id = ${applicant_id} and process_id = ${process_id}`;
          const status_query = await mysqlquery(get_status);

          const check_all_status = `SELECT status FROM ${db_table.comment} WHERE applicant_id = ? AND STATUS != 'replied'`;
          const status_check_all_status = await mysqlquery(
            check_all_status,
            applicant_id
          );

          if (status_check_all_status.length >= 0) {
            var in_query = "";
            userfind.forEach((uf) => {
              in_query += uf.applicant_personal_id + ",";
            });
            if (in_query != "") {
              in_query = in_query.substring(0, in_query.length - 1);
              const check_all_status = `SELECT status FROM ${db_table.comment} WHERE applicant_id IN (${in_query}) AND STATUS = 'added'`;
              const status_result = await mysqlquery(check_all_status);

              const lead_id = `SELECT lead_id FROM ${db_table.comment} WHERE applicant_id = ?`;
              const result = await mysqlquery(lead_id, applicant_id);

              if (status_result.length === 0) {
                const update_status = `update ${db_table.leads} set lead_status = 'agent_process' where lead_id = ?`;
                const results = await mysqlquery(
                  update_status,
                  result[0].lead_id
                );
              }
            }
          }
        }
      }

      if (document_uploaded > 0) {
        await insert_process(req.body.applicant_id, req.body.process_id);
        res.status(200).json({
          msg: "document saved successfully",
          banking_doc_id: banking_doc_id,
        });
      } else {
        res.status(400).json({
          msg: "something went wrong",
        });
      }
    } else {
      res.status(400).json({
        msg: saved_file.message,
      });
    }
  } catch (error) {
    res.status(400).json({
      msg: error.message ? error.message : error,
    });
  }
};

module.exports.get_document = async (req, res, next) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      res.status(409).json({ errors: errors.array() });
    }
    var applicant_id = req.body.applicant_id;
    var document = req.body.document;
    const sql = `SELECT applicant_personal_id,tbl_leads.lead_status
        FROM ${db_table.applicant_persional_details} 
        LEFT JOIN tbl_leads on tbl_applicant_personal_details.user_id = tbl_leads.user_id
        WHERE applicant_personal_id = ?`;
    const result = await mysqlquery(sql, [applicant_id]);
    const kyc_poi_sql = `SELECT *
        FROM ${db_table.kyc_pio_declarations}  where
        applicant_id = ?`;
    const kyc_poi_result = await mysqlquery(kyc_poi_sql, [applicant_id]);
    if (result.length != 0) {
      if (fs.existsSync(`./public/documents/${applicant_id}/${document}.jpg`)) {
        let file_path = `${req.protocol}://${req.headers.host}/documents/${applicant_id}/${document}.jpg`;
        let data = {
          file_path: file_path,
          lead_status: result[0].lead_status,
        };
        if (document == "address_proof") {
          var sql1 = `SELECT tbl_banking_docs.banking_doc_id, 
                    tbl_banking_docs.applicant_id, tbl_banking_docs.passport_front,
                    tbl_banking_docs.passport_back,tbl_banking_docs.address_proof_type_id,tbl_address_proof_types.address_proof_types_name,
                    tbl_banking_docs.address_proof,tbl_banking_docs.place_of_issue,tbl_countries.countrie_name place_of_issue_name,
                    tbl_banking_docs.issuing_authority,tbl_banking_docs.document_identification_number,
                    if(tbl_banking_docs.issue_date = 0000-00-00,"",tbl_banking_docs.issue_date) as issue_date,
                    if(tbl_banking_docs.expiry_date = 0000-00-00,"",tbl_banking_docs.expiry_date) as expiry_date,
                     tbl_banking_docs.form_sixty,tbl_banking_docs.visa,tbl_banking_docs.oci,
                    tbl_banking_docs.other_document,tbl_banking_docs.other_document_comment,tbl_banking_docs.old_indian_passport_front,
                    tbl_banking_docs.old_indian_passport_back,
                    (SELECT lead_status FROM tbl_leads WHERE user_id IN (SELECT user_id FROM tbl_applicant_personal_details WHERE applicant_personal_id IN (SELECT applicant_id FROM tbl_banking_documents WHERE applicant_id = ?))) as lead_status
                    FROM tbl_banking_documents tbl_banking_docs 
                    left join tbl_countries on tbl_banking_docs.place_of_issue=tbl_countries.countrie_id 
                    left join tbl_address_proof_types on tbl_banking_docs.address_proof_type_id=tbl_address_proof_types.address_proof_types_id 
                    where tbl_banking_docs.applicant_id=?`;
          var result1 = await mysqlquery(sql1, [applicant_id, applicant_id]);
          result1.forEach((element) => {
            element["file_path"] = data.file_path;
          });
          if (result1[0]) result1[0].kyc_poi = kyc_poi_result[0];
          res.status(200).json(result1);
        } else if (document == "other") {
          let sql2 = `select other_document, other_document_comment ,
                    (SELECT lead_status FROM tbl_leads WHERE user_id IN (SELECT user_id FROM tbl_applicant_personal_details WHERE applicant_personal_id IN (SELECT applicant_id FROM tbl_banking_documents WHERE applicant_id = ?))) as lead_status
                    from tbl_banking_documents
                    where applicant_id = ?`;
          let result = await mysqlquery(sql2, [applicant_id, applicant_id]);
          result.forEach((e) => {
            e["file_path"] = data.file_path;
          });
          res.status(200).json(result);
        } else {
          res.status(200).json(data);
        }
      } else {
        res.status(400).json({
          msg: "File not found",
          kyc_poi: kyc_poi_result[0],
        });
      }
    } else {
      res.status(400).json({
        msg: "Applicant not found",
      });
    }
  } catch (error) {
    res.status(400).json({
      msg: error.message ? error.message : error,
    });
  }
};

module.exports.submit_banking_doc_1 = async (req, res, next) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      res.status(409).json({ errors: errors.array() });
    }
    if (req.body.banking_doc_id) {
      let Applicant_Id = "applicant_id";
      let table_params = {
        tableName: db_table.kyc_details,
        applicantid: Applicant_Id,
      };

      const table_row_query = await get_table_id(table_params);
      const table_record_id = await mysqlquery(table_row_query, [
        req.body.applicant_id,
      ]);
      record_id = null;
      if (table_record_id.length > 0) {
        const applicant_data = Object.values(table_record_id);
        var record_id = applicant_data[0].banking_doc_id;
      }

      const processdelete = `DELETE FROM  ${db_table.process_status} WHERE applicant_Id=? and process_id=?`;
      const delete_data = await mysqlquery(processdelete, [
        req.body.applicant_id,
        req.body.process_id,
      ]);

      let dirFname = `./public/documents/${req.body.applicant_id}`;
      if (!fs.existsSync(dirFname)) {
        fs.mkdirSync(dirFname);
      }

      let address_proof = req.body.doc_address_plc_address_doc;

      fs.writeFile(
        `${dirFname}/${req.body.doc_address_plc_addrss_filename}`,
        address_proof,
        { encoding: "base64" },
        function (err) {}
      );

      var issu_date = req.body.issue_date;
      var iss_date = issu_date.split("T")[0];
      var expi_date = req.body.expiry_date;
      var expir_date = expi_date.split("T")[0];

      const url = req.protocol + "://" + req.get("host");
      const update_bank_doc = [
        req.body.applicant_id,
        req.body.address_proof_type_id,
        url +
          `/public/uploads/${req.body.applicant_id}/` +
          req.body.doc_address_plc_addrss_filename,
        req.body.place_of_issue,
        req.body.issuing_authority,
        req.body.document_identification_number,
        iss_date,
        expir_date,
        req.body.banking_doc_id,
      ];
      let sql = `update ${db_table.banking_document} SET applicant_id=?,address_proof_type_id=?, address_proof=?,place_of_issue=?,issuing_authority=?,document_identification_number=?,issue_date=?,expiry_date=? WHERE banking_doc_id=?`;
      const update_bank_dcou = await mysqlquery(sql, update_bank_doc);

      const submit_process_data = {
        applicant_id: req.body.applicant_id,
        process_id: req.body.process_id,
        agent_status: req.body.agent_status,
      };
      let sql_process_data = `INSERT INTO ${db_table.process_status} SET ? `;
      const submit_process = await mysqlquery(
        sql_process_data,
        submit_process_data
      );

      if (update_bank_dcou.affectedRows > 0) {
        res.status(200).json({
          msg: "update document successfully",
          record_id: record_id,
        });
      } else {
        res.status(400).json({
          msg: "something went wrong",
        });
      }
    } else {
      res.status(400).json({
        msg: "bad request",
      });
    }
  } catch (error) {
    res.status(400).json({
      msg: error.message ? error.message : error,
    });
  }
};

module.exports.submit_nominations_details_1 = async (req, res, next) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      res.status(409).json({ errors: errors.array() });
    }
    if (
      req.body.nomination_id === "" ||
      req.body.nomination_id === "undefined" ||
      req.body.nomination_id === null ||
      req.body.nomination_id === "0" ||
      req.body.nomination_id === undefined
    ) {
      const submit_nomi_details = {
        applicant_id: req.body.applicant_id,
        is_opted: req.body.is_opted,
      };
      let sql = `INSERT INTO ${db_table.nominations} SET ? `;
      const submit_nomini_details = await mysqlquery(sql, submit_nomi_details);
      const submit_process_data = {
        applicant_id: req.body.applicant_id,
        process_id: req.body.process_id,
        agent_status: req.body.agent_status,
      };
      let sql_process_data = `INSERT INTO ${db_table.process_status} SET ? `;
      const submit_process = await mysqlquery(
        sql_process_data,
        submit_process_data
      );
      if (submit_nomini_details.insertId > 0) {
        res.status(200).json({
          msg: "save nominee deatils successfully",
          nomination_id: submit_nomini_details.insertId,
        });
      } else {
        res.status(400).json({
          msg: "something went wrong",
        });
      }
    } else {
      if (req.body.nomination_id) {
        const processdelete = `DELETE FROM  ${db_table.process_status} WHERE applicant_Id=? and process_id=?`;
        const delete_data = await mysqlquery(processdelete, [
          req.body.applicant_id,
          req.body.process_id,
        ]);

        const update_nomination_details = [
          req.body.applicant_id,
          req.body.is_opted,
          req.body.nomination_id,
        ];
        let sql = `update ${db_table.nominations} SET applicant_id=?,is_opted=? WHERE nomination_id=?`;
        const update_nominee_deatils = await mysqlquery(
          sql,
          update_nomination_details
        );

        const submit_process_data = {
          applicant_id: req.body.applicant_id,
          process_id: req.body.process_id,
          agent_status: req.body.agent_status,
        };
        let sql_process_data = `INSERT INTO ${db_table.process_status} SET ? `;
        const submit_process = await mysqlquery(
          sql_process_data,
          submit_process_data
        );

        if (update_nominee_deatils.affectedRows > 0) {
          res.status(200).json({
            msg: "update nominee deatils successfully",
            nomination_id: req.body.nomination_id,
          });
        } else {
          res.status(400).json({
            msg: "something went wrong",
          });
        }
      } else {
        res.status(400).json({
          msg: "bad request",
        });
      }
    }
  } catch (error) {
    res.status(400).json({
      msg: error.message ? error.message : error,
    });
  }
};

module.exports.submit_nominations_details_2 = async (req, res, next) => {
  try {
    let applicant_id = req.body.applicant_id;
    let process_id = req.body.process_id;
    let user_sql = `SELECT * FROM ${db_table.applicant_persional_details} WHERE applicant_personal_id=?`;
    let user_result = await mysqlquery(user_sql, [applicant_id]);
    let user_id = user_result[0]?.user_id;

    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      res.status(409).json({ errors: errors.array() });
    }
    if (req.body.nomination_id) {
      let Applicant_Id = "applicant_id";
      let table_params = {
        tableName: db_table.kyc_details,
        applicantid: Applicant_Id,
      };

      const table_row_query = await get_table_id(table_params);
      const table_record_id = await mysqlquery(table_row_query, [
        req.body.applicant_id,
      ]);
      record_id = null;
      if (table_record_id.length > 0) {
        const applicant_data = Object.values(table_record_id);
        var record_id = applicant_data[0].nomination_id;
      }

      const processdelete = `DELETE FROM  ${db_table.process_status} WHERE applicant_Id=? and process_id=?`;
      const delete_data = await mysqlquery(processdelete, [
        req.body.applicant_id,
        req.body.process_id,
      ]);
      var nominee_date_of_birth = req.body.nominee_date_of_birth;
      nominee_date_of_birth = nominee_date_of_birth.slice(0, 10);
      const update_nomination_details = [
        req.body.applicant_id,
        req.body.nominee_title,
        req.body.nominee_first_name,
        req.body.nominee_middle_name,
        req.body.nominee_last_name,
        req.body.nominee_house_number,
        req.body.nominee_house_or_building_name,
        req.body.nominee_road_or_street_name,
        req.body.nominee_state,
        req.body.nominee_city,
        req.body.nominee_landkmark,
        req.body.nominee_country_id,
        req.body.nominee_pincode,
        req.body.relationship,
        nominee_date_of_birth,
        req.body.nomination_id,
      ];
      let sql = `update ${db_table.nominations} SET applicant_id=?,
            nominee_title=?,nominee_first_name=?,
            nominee_middle_name=?,nominee_last_name=?,
             nominee_house_number=?,nominee_house_or_building_name=?,
             nominee_road_or_street_name=?, 
            nominee_state=?, nominee_city=?,
            nominee_landkmark=?,nominee_country_id=?,nominee_pincode=?,
            relationship=?, nominee_date_of_birth=? WHERE nomination_id=?`;
      const update_nominee_deatils = await mysqlquery(
        sql,
        update_nomination_details
      );

      const submit_process_data = {
        applicant_id: req.body.applicant_id,
        process_id: req.body.process_id,
        agent_status: req.body.agent_status,
      };

      let sql_process_data = `INSERT INTO ${db_table.process_status} SET ? `;
      const submit_process = await mysqlquery(
        sql_process_data,
        submit_process_data
      );

      let find_user = `SELECT * FROM ${db_table.applicant_persional_details} WHERE user_id=? `;
      let userfind = await mysqlquery(find_user, user_id);

      const sqli = `select lead_status from ${db_table.leads} where user_id=?`;
      const sqli_result = await mysqlquery(sqli, user_id);

      if (sqli_result[0].lead_status === "agent_review") {
        let get_status = `update ${db_table.comment} SET status = 'replied' WHERE applicant_id = ${applicant_id} and process_id = ${process_id}`;
        const status_query = await mysqlquery(get_status);

        const check_all_status = `SELECT status FROM ${db_table.comment} WHERE applicant_id = ? AND STATUS != 'replied'`;
        const status_check_all_status = await mysqlquery(
          check_all_status,
          applicant_id
        );

        if (status_check_all_status.length >= 0) {
          var in_query = "";
          userfind.forEach((uf) => {
            in_query += uf.applicant_personal_id + ",";
          });
          if (in_query != "") {
            in_query = in_query.substring(0, in_query.length - 1);
            const check_all_status = `SELECT status FROM ${db_table.comment} WHERE applicant_id IN (${in_query}) AND STATUS = 'added'`;
            const status_result = await mysqlquery(check_all_status);

            const lead_id = `SELECT lead_id FROM ${db_table.comment} WHERE applicant_id = ?`;
            const result = await mysqlquery(lead_id, applicant_id);

            if (status_result.length === 0) {
              const update_status = `update ${db_table.leads} set lead_status = 'agent_process' where lead_id = ?`;
              const results = await mysqlquery(
                update_status,
                result[0].lead_id
              );
            }
          }
        }
      }

      if (update_nominee_deatils.affectedRows > 0) {
        res.status(200).json({
          msg: "update nominee deatils successfully",
          record_id: record_id,
        });
      } else {
        res.status(400).json({
          msg: "something went wrong",
        });
      }
    } else {
      res.status(400).json({
        msg: "bad request",
      });
    }
  } catch (error) {
    res.status(400).json({
      msg: error.message ? error.message : error,
    });
  }
};

module.exports.submit_nominations_details_3 = async (req, res, next) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      res.status(409).json({ errors: errors.array() });
    }
    if (req.body.nomination_id) {
      let Applicant_Id = "applicant_id";
      let table_params = {
        tableName: db_table.kyc_details,
        applicantid: Applicant_Id,
      };

      const table_row_query = await get_table_id(table_params);
      const table_record_id = await mysqlquery(table_row_query, [
        req.body.applicant_id,
      ]);
      record_id = null;
      if (table_record_id.length > 0) {
        const applicant_data = Object.values(table_record_id);
        var record_id = applicant_data[0].nomination_id;
      }

      const processdelete = `DELETE FROM  ${db_table.process_status} WHERE applicant_Id=? and process_id=?`;
      const delete_data = await mysqlquery(processdelete, [
        req.body.applicant_id,
        req.body.process_id,
      ]);
      const update_nomination_details = [
        req.body.applicant_id,
        req.body.nominee_age_in_year,
        req.body.nominee_age_in_month,
        req.body.gaurdian_title,
        req.body.gaurdian_first_name,
        req.body.gaurdian_middle_name,
        req.body.gaurdian_last_name,
        req.body.nomination_id,
      ];
      let sql = `update ${db_table.nominations} SET applicant_id=?,nominee_age_in_year=?,nominee_age_in_month=?,gaurdian_title=?,gaurdian_first_name=?,gaurdian_middle_name=?,gaurdian_last_name=? WHERE nomination_id=?`;
      const update_nominee_deatils = await mysqlquery(
        sql,
        update_nomination_details
      );

      const submit_process_data = {
        applicant_id: req.body.applicant_id,
        process_id: req.body.process_id,
        agent_status: req.body.agent_status,
      };
      let sql_process_data = `INSERT INTO ${db_table.process_status} SET ? `;
      const submit_process = await mysqlquery(
        sql_process_data,
        submit_process_data
      );

      if (update_nominee_deatils.affectedRows > 0) {
        res.status(200).json({
          msg: "update nominee deatils successfully",
          record_id: record_id,
        });
      } else {
        res.status(400).json({
          msg: "something went wrong",
        });
      }
    } else {
      res.status(400).json({
        msg: "bad request",
      });
    }
  } catch (error) {
    res.status(400).json({
      msg: error.message ? error.message : error,
    });
  }
};

module.exports.submit_applicant_relative_data = async (req, res, next) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      res.status(409).json({ errors: errors.array() });
    }
    let data_modify = 0;
    if (req.body.process_id === 21 || req.body.process_id === 62) {
      let check_relative_data_exist_sql = `SELECT applicant_relative_id FROM ${db_table.applicant_relatives} WHERE applicant_id=?`;
      const check_relative_data_exist_result = await mysqlquery(
        check_relative_data_exist_sql,
        [req.body.applicant_id]
      );
      if (check_relative_data_exist_result.length == 0) {
        const relative_data = {
          applicant_id: req.body.applicant_id,
          declarant_title: req.body.declarant_title,
          declarant_first_name: req.body.declarant_first_name,
          declarant_middle_name: req.body.declarant_middle_name,
          declarant_last_name: req.body.declarant_last_name,
          declarant_house_number: req.body.declarant_house_number,
          declarant_house_and_building_name:
            req.body.declarant_house_and_building_name,
          declarant_road_or_street_name: req.body.declarant_road_or_street_name,
          declarant_landmark: req.body.declarant_landmark,
          declarant_state: req.body.declarant_state,
          declarant_city: req.body.declarant_city,
          declarant_country_id: req.body.declarant_country_id,
          declarant_pincode: req.body.declarant_pincode,
          declarant_relation: req.body.declarant_relation,
        };
        let insert_relative_data_sql = `INSERT INTO ${db_table.applicant_relatives} SET ?`;
        const insert_relative_data_result = await mysqlquery(
          insert_relative_data_sql,
          relative_data
        );
        if (insert_relative_data_result.insertId > 0) {
          banking_doc_id = insert_relative_data_result.insertId;
          data_modify++;
        }
      } else {
        let update_relative_data = [
          req.body.declarant_title,
          req.body.declarant_first_name,
          req.body.declarant_middle_name,
          req.body.declarant_last_name,
          req.body.declarant_house_number,
          req.body.declarant_house_and_building_name,
          req.body.declarant_road_or_street_name,
          req.body.declarant_landmark,
          req.body.declarant_state,
          req.body.declarant_city,
          req.body.declarant_country_id,
          req.body.declarant_pincode,
          req.body.declarant_relation,
          req.body.applicant_id,
        ];
        let update_relative_data_sql = `UPDATE ${db_table.applicant_relatives} SET declarant_title = ?, declarant_first_name = ?, declarant_middle_name = ?, declarant_last_name = ?, declarant_house_number = ?, declarant_house_and_building_name = ?, declarant_road_or_street_name = ?, declarant_landmark = ?, declarant_state = ?, declarant_city = ?, declarant_country_id = ?, declarant_pincode = ?, declarant_relation = ? WHERE applicant_id = ?`;
        const update_relative_data_result = await mysqlquery(
          update_relative_data_sql,
          update_relative_data
        );
        if (update_relative_data_result.affectedRows > 0) {
          banking_doc_id = update_relative_data_result.affectedRows;
          data_modify++;
        }

        const submit_process_data = {
          applicant_id: req.body.applicant_id,
          process_id: req.body.process_id,
          agent_status: req.body.agent_status,
        };
        let sql_process_data = `INSERT INTO ${db_table.process_status} SET ? `;
        const submit_process = await mysqlquery(
          sql_process_data,
          submit_process_data
        );
        let applicant_id = req.body.applicant_id;
        let user_sql = `SELECT * FROM ${db_table.applicant_persional_details} WHERE applicant_personal_id=?`;
        let user_result = await mysqlquery(user_sql, [applicant_id]);
        let user_id = user_result[0].user_id;

        let find_user = `SELECT * FROM ${db_table.applicant_persional_details} WHERE user_id=? `;
        let userfind = await mysqlquery(find_user, user_id);

        const sqli = `select lead_status from ${db_table.leads} where user_id=?`;
        const sqli_result = await mysqlquery(sqli, user_id);

        if (sqli_result[0].lead_status === "agent_review") {
          let get_status = `update ${db_table.comment} SET status = 'replied' WHERE applicant_id = ${applicant_id} and process_id = ${req.body.process_id}`;
          const status_query = await mysqlquery(get_status);

          const check_all_status = `SELECT status FROM ${db_table.comment} WHERE applicant_id = ? AND STATUS != 'replied'`;
          const status_check_all_status = await mysqlquery(
            check_all_status,
            applicant_id
          );

          if (status_check_all_status.length >= 0) {
            var in_query = "";
            userfind.forEach((uf) => {
              in_query += uf.applicant_personal_id + ",";
            });
            if (in_query != "") {
              in_query = in_query.substring(0, in_query.length - 1);
              const check_all_status = `SELECT status FROM ${db_table.comment} WHERE applicant_id IN (${in_query}) AND STATUS = 'added'`;
              const status_result = await mysqlquery(check_all_status);

              const lead_id = `SELECT lead_id FROM ${db_table.comment} WHERE applicant_id = ?`;
              const result = await mysqlquery(lead_id, applicant_id);

              if (status_result.length === 0) {
                const update_status = `update ${db_table.leads} set lead_status = 'agent_process' where lead_id = ?`;
                const results = await mysqlquery(
                  update_status,
                  result[0].lead_id
                );
              }
            }
          }
        }
      }
      if (data_modify > 0) {
        await insert_process(req.body.applicant_id, req.body.process_id);
        res.status(200).json({
          msg: "Data modify successfully",
        });
      } else {
        res.status(400).json({
          msg: "Something went wrong",
        });
      }
    } else {
      res.status(400).json({
        msg: "bad request",
      });
    }
  } catch (error) {
    res.status(400).json({
      msg: error.message ? error.message : error,
    });
  }
};

module.exports.submit_consent_declared = async (req, res, next) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      res.status(409).json({ errors: errors.array() });
    }
    if (req.body.applicant_id) {
      let applicant = "applicant_personal_id";
      let table_params = {
        tableName: db_table.applicant_persional_details,
        applicant_per_id: applicant,
      };

      const table_row_query = await get_table_id(table_params);
      const table_record_id = await mysqlquery(table_row_query, [
        req.body.applicant_id,
      ]);
      record_id = null;
      if (table_record_id.length > 0) {
        const applicant_data = Object.values(table_record_id);
        var record_id = applicant_data[0].applicant_personal_id;
      }

      const processdelete = `DELETE FROM  ${db_table.process_status} WHERE applicant_Id=? and process_id=?`;
      const delete_data = await mysqlquery(processdelete, [
        req.body.applicant_id,
        req.body.process_id,
      ]);

      const update_personal_data = [
        req.body.is_consent_declared,
        req.body.is_info_consent_declared,
        1,
        req.body.applicant_id,
      ];
      let sql = `update ${db_table.applicant_persional_details} SET is_consent_declared=?,is_info_consent_declared=?,is_submited=? WHERE applicant_personal_id=?`;
      const update_per_data = await mysqlquery(sql, update_personal_data);

      const submit_process_data = {
        applicant_id: req.body.applicant_id,
        process_id: req.body.process_id,
        agent_status: req.body.agent_status,
      };
      let sql_process_data = `INSERT INTO ${db_table.process_status} SET ? `;
      const submit_process = await mysqlquery(
        sql_process_data,
        submit_process_data
      );

      if (update_per_data.affectedRows > 0) {
        res.status(200).json({
          msg: "update personal information successfully",
          record_id: record_id,
        });
      } else {
        res.status(400).json({
          msg: "something went wrong",
        });
      }
    } else {
      res.status(400).json({
        msg: "bad request",
      });
    }
    //}
  } catch (error) {
    res.status(400).json({
      msg: error.message ? error.message : error,
    });
  }
};

module.exports.submit_terms_conditions = async (req, res) => {
  try {
    if (req.body.process_id === 29) {
      if (req.body.account_type_id === 1) {
        res.status(200).json({
          is_completed: true,
          applicant_serial_number: 0,
          applicant_id: 0,
        });
      } else {
        if (req.body.account_type_id === 2) {
          const user_applicant_sql = `SELECT applicant_personal_id,applicant_serial_number,is_submited FROM ${db_table.applicant_persional_details} WHERE user_id = ? order by applicant_personal_id ASC`;
          const user_applicant_result = await mysqlquery(user_applicant_sql, [
            req.body.user_id,
          ]);
          if (user_applicant_result.length > 0) {
            var current_applicant_id = 0;
            var current_applicant_serial_number = 0;
            var is_complete_flag = true;
            try {
              user_applicant_result.forEach((applicant) => {
                current_applicant_id = applicant.applicant_personal_id;
                current_applicant_serial_number =
                  applicant.applicant_serial_number;
                if (applicant.is_submited == 0) {
                  is_complete_flag = false;
                  throw "Break";
                }
              });
            } catch (e) {
              if (e !== "Break") throw e;
            }

            res.status(200).json({
              is_completed: is_complete_flag,
              applicant_serial_number: current_applicant_serial_number,
              applicant_id: current_applicant_id,
            });
          } else {
            res.status(400).json({
              msg: "bad request",
            });
          }

          // let find_user = `SELECT applicant_personal_id,applicant_serial_number FROM ${db_table.applicant_persional_details} WHERE user_id=?`;
          // const applicant_number = await mysqlquery(find_user, [req.body.user_id]);
          // let find_users = `SELECT applicant_personal_id FROM ${db_table.applicant_persional_details} WHERE is_submited!=1 and user_id=? order by applicant_personal_id ASC`;
          // const applicant_user = await mysqlquery(find_users, [req.body.user_id]);
          // var applicant_per_id = applicant_user[0].applicant_personal_id;
          // let find_auery = `SELECT applicant_personal_id,applicant_serial_number FROM ${db_table.applicant_persional_details} WHERE is_submited=1 and user_id=?`;
          // const userfind = await mysqlquery(find_auery, [req.body.user_id]);
          // if (userfind.length === 1) {
          //     res.status(200).json({
          //         is_completed: false,
          //         applicant_serial_number: 2,
          //         applicant_id:applicant_per_id

          //     })
          // } else {

          //     if (applicant_number.length === 2) {
          //         if (userfind.length === 2) {
          //             res.status(200).json({
          //                 is_completed: true,

          //             })
          //         }
          //     }
          //     else {
          //         if (userfind.length === 2) {
          //             if (applicant_number.length === 3) {
          //                 res.status(200).json({
          //                     is_completed: false,
          //                     applicant_serial_number: 3,
          //                     applicant_id:applicant_per_id
          //                 })
          //             }
          //         }
          //         if (applicant_number.length === 3) {
          //             res.status(200).json({
          //                 is_completed: true,
          //             })
          //         }

          //     }

          // }
        }
      }
    } else {
      res.status(400).json({
        msg: "bad request",
      });
    }
  } catch (error) {
    res.status(400).json({
      msg: error.message ? error.message : error,
    });
  }
};

get_token = async (req) => {
  try {
    let payload = {
      getToken: {
        RequestHeader: {
          MessageKey: {
            RequestUUID: uuidv4(),
            ServiceRequestId: "GETTOKEN",
            ServiceRequestVersion: "1.0",
            ChannelId: "",
          },
          RequestMessageInfo: {
            BankId: "",
            TimeZone: "",
            MessageDateTime: "",
          },
          Security: {
            Token: {
              Certificate: "",
              MessageHashKey: "",
              MessageIndex: "",
              PasswordToken: {
                UserId: "",
                Password: "",
              },
            },
          },
          DeviceInfo: {
            DeviceFamily: "",
            DeviceFormat: "",
            DeviceType: "",
            DeviceName: "",
            DeviceIMEI: "",
            DeviceID: "",
            DeviceVersion: "",
            AppVersion: "",
            DeviceOS: "",
            DeviceIp: process.env.RBL_DEVICE_IP,
          },
          AdditionalInfo: {
            JourneyId: "",
            LanguageId: "",
            SVersion: "",
            SessionId: "",
          },
        },
        RequestBody: {
          getTokenRequestBody: {
            clientId: process.env.RBL_CLIENT_ID,
            clientSecret: process.env.RBL_SECRET_ID,
          },
        },
      },
    };

    const agent = new https.Agent({
      rejectUnauthorized: false,
    });
    const axiosConfig = {
      httpsAgent: agent,
    };
    const response = await axios.post(
      `${process.env.RBL_SENTINAL_URL}/api/v1/OAUTH/get-token`,
      payload,
      axiosConfig
    );
    let responseData =
      response.data.generateTokenResponse.Status.StatusCode == "0";
    if (responseData) {
      req.session.token =
        response.data.generateTokenResponse?.ResponseBody?.generateTokenResponseBody?.access_token;
      req.session.expires_in =
        Date.now() +
        response.data.generateTokenResponse?.ResponseBody
          ?.generateTokenResponseBody?.expires_in *
          1000;
    } else {
      console.log("something went wrong");
    }
  } catch (error) {
    console.error("Getting error while generate the token", error);
  }
};

module.exports.submit_lead = async (req, res) => {
  try {
    if (req.body.user_id) {
      var submit_lead_hist_data = {
        user_id: req.body.user_id,
        status: "lead",
      };
      let sql_lead_history__data = `INSERT INTO ${db_table.lead_status_history} SET ? `;
      const submit_lead_history = await mysqlquery(
        sql_lead_history__data,
        submit_lead_hist_data
      );

      let submit_lead_status = [
        req.body.user_id,
        "lead",
        new Date(),
        req.body.user_id,
      ];
      let sql1 = `UPDATE  ${db_table.leads} SET user_id=?,lead_status=?,updated_on=? WHERE user_id=?`;
      const submit_lead_details = await mysqlquery(sql1, submit_lead_status);

      if (submit_lead_history.insertId > 0) {
        var lead_id = submit_lead_history.insertId;
        let sql = `select lead_number from ${db_table.leads} where user_id = ${req.body.user_id}`;
        let result = await mysqlquery(sql);

        let query_for_email = `SELECT email_address,first_name FROM ${db_table.users} WHERE user_id=?`;
        let user_result = await mysqlquery(query_for_email, req.body.user_id);
        const name = user_result[0].first_name;
        const email = user_result[0].email_address;
        if (!req?.session?.token) {
          try {
            let payload = {
              getToken: {
                RequestHeader: {
                  MessageKey: {
                    RequestUUID: uuidv4(),
                    ServiceRequestId: "GETTOKEN",
                    ServiceRequestVersion: "1.0",
                    ChannelId: "",
                  },
                  RequestMessageInfo: {
                    BankId: "",
                    TimeZone: "",
                    MessageDateTime: "",
                  },
                  Security: {
                    Token: {
                      Certificate: "",
                      MessageHashKey: "",
                      MessageIndex: "",
                      PasswordToken: {
                        UserId: "",
                        Password: "",
                      },
                    },
                  },
                  DeviceInfo: {
                    DeviceFamily: "",
                    DeviceFormat: "",
                    DeviceType: "",
                    DeviceName: "",
                    DeviceIMEI: "",
                    DeviceID: "",
                    DeviceVersion: "",
                    AppVersion: "",
                    DeviceOS: "",
                    DeviceIp: process.env.RBL_DEVICE_IP,
                  },
                  AdditionalInfo: {
                    JourneyId: "",
                    LanguageId: "",
                    SVersion: "",
                    SessionId: "",
                  },
                },
                RequestBody: {
                  getTokenRequestBody: {
                    clientId: process.env.RBL_CLIENT_ID,
                    clientSecret: process.env.RBL_SECRET_ID,
                  },
                },
              },
            };

            const agent = new https.Agent({
              rejectUnauthorized: false,
            });
            const axiosConfig = {
              httpsAgent: agent,
            };
            const response = await axios.post(
              `${process.env.RBL_SENTINAL_URL}/api/v1/OAUTH/get-token`,
              payload,
              axiosConfig
            );
            let responseData =
              response.data.generateTokenResponse.Status.StatusCode == "0";
            if (responseData) {
              req.session.token =
                response.data.generateTokenResponse?.ResponseBody?.generateTokenResponseBody?.access_token;
              req.session.expires_in =
                Date.now() +
                response.data.generateTokenResponse?.ResponseBody
                  ?.generateTokenResponseBody?.expires_in *
                  1000;
            } else {
              console.log("something went wrong");
            }
          } catch (error) {
            console.error("Getting error while generate the token", error);
          }
        } else if (Date.now() > req.session.expires_in) {
          try {
            let payload = {
              getToken: {
                RequestHeader: {
                  MessageKey: {
                    RequestUUID: uuidv4(),
                    ServiceRequestId: "GETTOKEN",
                    ServiceRequestVersion: "1.0",
                    ChannelId: "",
                  },
                  RequestMessageInfo: {
                    BankId: "",
                    TimeZone: "",
                    MessageDateTime: "",
                  },
                  Security: {
                    Token: {
                      Certificate: "",
                      MessageHashKey: "",
                      MessageIndex: "",
                      PasswordToken: {
                        UserId: "",
                        Password: "",
                      },
                    },
                  },
                  DeviceInfo: {
                    DeviceFamily: "",
                    DeviceFormat: "",
                    DeviceType: "",
                    DeviceName: "",
                    DeviceIMEI: "",
                    DeviceID: "",
                    DeviceVersion: "",
                    AppVersion: "",
                    DeviceOS: "",
                    DeviceIp: process.env.RBL_DEVICE_IP,
                  },
                  AdditionalInfo: {
                    JourneyId: "",
                    LanguageId: "",
                    SVersion: "",
                    SessionId: "",
                  },
                },
                RequestBody: {
                  getTokenRequestBody: {
                    clientId: process.env.RBL_CLIENT_ID,
                    clientSecret: process.env.RBL_SECRET_ID,
                  },
                },
              },
            };

            const agent = new https.Agent({
              rejectUnauthorized: false,
            });
            const axiosConfig = {
              httpsAgent: agent,
            };
            const response = await axios.post(
              `${process.env.RBL_SENTINAL_URL}/api/v1/OAUTH/get-token`,
              payload,
              axiosConfig
            );
            let responseData =
              response.data.generateTokenResponse.Status.StatusCode == "0";
            if (responseData) {
              req.session.token =
                response.data.generateTokenResponse?.ResponseBody?.generateTokenResponseBody?.access_token;
              req.session.expires_in =
                Date.now() +
                response.data.generateTokenResponse?.ResponseBody
                  ?.generateTokenResponseBody?.expires_in *
                  1000;
            } else {
              console.log("something went wrong");
            }
          } catch (error) {
            console.error("Getting error while generate the token", error);
          }
        }
        if (user_result.length > 0) {
          let otp_params = {
            email_address: email,
            name: name,
            image: process.env.URL,
            login: `${process.env.CustomerURL}/login`,
          };
          let data = {
            sendMessage: {
              version: "1.0",
              appID: "FINACLE",
              topicName: "nriactcnf",
              recipient: {
                subscriber: {
                  customerID: "",
                  accountNo: "",
                  contact: {
                    emailID: email,
                    mobileNo: "",
                  },
                },
              },
              mergeVarArray: {
                mergeVar: {
                  name: "CUSTNAME",
                  content: {
                    stringContent: name,
                  },
                },
                mergeVar: {
                  name: "URL",
                  content: {
                    stringContent: `${process.env.CustomerURL}/login`,
                  },
                },
              },
              referenceNo: `nriactcnf_${
                new Date().getSeconds() * new Date().getMilliseconds()
              }`,
            },
          };
          
          var builder = new Convert.Builder();
          var xml = builder.buildObject(data);
          const agent = new https.Agent({
            rejectUnauthorized: false,
          });
          let header = {
            "x-rbl-auth": `Bearer ${req.session.token}`,
            'Content-Type':'application/xml'
          };
          const axiosConfig = {
            httpsAgent: agent,
            headers: header,
          };

         await axios.post(
            `${process.env.RBL_SENTINAL_URL}/ralert/alrt`,
            xml,
            axiosConfig
          );
          // const result = await registration_email.account_opening_submition(
          //   otp_params
          // );
        } else {
          res.status(401).json({
            msg: "something went wrong",
          });
        }
        res.status(200).json({
          msg: "save lead successfully",
          lead_reference_number: result[0]["lead_number"],
        });
      } else {
        res.status(400).json({
          msg: "something went wrong",
        });
      }
    } else {
      res.status(400).json({
        msg: "bad request",
      });
    }
  } catch (error) {
    res.status(400).json({
      msg: error.message ? error.message : error,
    });
  }
};

module.exports.get_country_form = async (req, res) => {
  try {
    let customer_personal_details = `SELECT personal_detail.applicant_personal_id,tbl_users.first_name,tbl_users.last_name,
        personal_detail.country_id,personal_detail.account_type_id,personal_detail.is_trading_facility_opt,
        tbl_process_status.process_id  FROM tbl_applicant_personal_details personal_detail 
        left join tbl_countries on personal_detail.country_id=tbl_countries.countrie_id 
        left join tbl_process_status on personal_detail.applicant_personal_id=tbl_process_status.applicant_id 
        left join tbl_users on personal_detail.user_id=tbl_users.user_id  where tbl_users.user_id=? and process_id=?`;
    const get_customer_personal_deatil = await mysqlquery(
      customer_personal_details,
      [req.body.user_id, req.body.process_id]
    );
    let applicant_id = req.body.applicant_id;
    let user_sql = `SELECT * FROM ${db_table.applicant_persional_details} WHERE applicant_personal_id=?`;
    let user_result = await mysqlquery(user_sql, [applicant_id]);
    let user_id = 0;
    if (req.body.user_id) {
      user_id = req.body.user_id;
    } else if (user_result != undefined) {
      user_id = user_result[0].user_id;
    }

    let lead_status_sql = `SELECT lead_status FROM ${db_table.leads} WHERE user_id=? `;
    var lead_result = await mysqlquery(lead_status_sql, [user_id]);
    var user_lead_status = "";
    if (lead_result.length != 0) {
      user_lead_status = lead_result[0].lead_status;
    }

    var comments_approved_result = "";
    if (user_lead_status == "agent_review") {
      let lead_id = req.body.lead_id;
      let process_id = req.body.process_id;
      var comments_approved_result = await get_customer_forms_comments_approved(
        applicant_id,
        lead_id,
        process_id
      );
      // var comments_data = await get_customer_forms_comments_approved()

      // var comments__approved_data = [comments_approved_result]

      var comments__approved_data = comments_approved_result;
    }
    get_customer_personal_deatil.forEach((application) => {
      let account_type_id = application.account_type_id;
      var data = account_json;
      var customer_account_type = data.find(
        (item) => item.account_type_id === account_type_id
      );
      var account_type = customer_account_type.account_type;

      application["account_type_name"] = account_type;

      let process_id = application.process_id;
      var process_data_id = customer_forms;

      var customer_process = process_data_id.find(
        (item) => item.process_id === process_id
      );
      var process_type = customer_process.form_name;

      application["process_name"] = process_type;
    });

    res.status(200).json({
      data: get_customer_personal_deatil,
      agent_feedback: comments__approved_data,
    });
  } catch (error) {
    res.status(400).json({
      msg: error.message ? error.message : error,
    });
  }
};

module.exports.get_account_varient = async (req, res) => {
  try {
    let customer_personal_details = `SELECT personal_detail.account_varient,
        tbl_process_status.process_id  FROM tbl_applicant_personal_details personal_detail 
        left join tbl_countries on personal_detail.country_id=tbl_countries.countrie_id 
        left join tbl_process_status on personal_detail.applicant_personal_id=tbl_process_status.applicant_id 
        left join tbl_users on personal_detail.user_id=tbl_users.user_id  where tbl_users.user_id=? and tbl_process_status.process_id=? and personal_detail.applicant_personal_id = ?`;
    const get_customer_personal_deatil = await mysqlquery(
      customer_personal_details,
      [req.body.user_id, req.body.process_id, req.body.applicant_id]
    );
    let applicant_id = req.body.applicant_id;
    let user_sql = `SELECT * FROM ${db_table.applicant_persional_details} WHERE applicant_personal_id=?`;
    let user_result = await mysqlquery(user_sql, [applicant_id]);
    let user_id = 0;
    if (req.body.user_id) {
      user_id = req.body.user_id;
    } else if (user_result != undefined) {
      user_id = user_result[0].user_id;
    }
    let lead_status_sql = `SELECT lead_status FROM ${db_table.leads} WHERE user_id=? `;
    var lead_result = await mysqlquery(lead_status_sql, [user_id]);
    //var user_lead_status = lead_result[0].lead_status;
    user_lead_status = "agent_process";
    var comments_approved_result = "";
    if (user_lead_status == "agent_review") {
      let lead_id = req.body.lead_id;
      let process_id = req.body.process_id;
      var comments_approved_result = await get_customer_forms_comments_approved(
        applicant_id,
        lead_id,
        process_id
      );
      // var comments_data = await get_customer_forms_comments_approved()
      // var comments__approved_data = [comments_approved_result]
      var comments__approved_data = comments_approved_result;
    }
    get_customer_personal_deatil.forEach((application) => {
      let process_id = application.process_id;
      var process_data_id = customer_forms;

      var customer_process = process_data_id.find(
        (item) => item.process_id === process_id
      );
      var process_type = customer_process.form_name;

      application["process_name"] = process_type;
    });

    res.status(200).json({
      data: get_customer_personal_deatil,
      agent_feedback: comments__approved_data,
      lead_result: lead_result,
    });
  } catch (error) {
    res.status(400).json({
      msg: error.message ? error.message : error,
    });
  }
};

module.exports.get_customer_personal_details_form_1 = async (req, res) => {
  try {
    let customer_personal_details = `SELECT personal_detail.applicant_personal_id,personal_detail.applicant_title,personal_detail.applicant_first_name,personal_detail.applicant_middle_name,personal_detail.applicant_last_name,
            personal_detail.country_id,tbl_countries.countrie_name,personal_detail.account_type_id,
            personal_detail.is_trading_facility_opt,personal_detail.account_varient,
            if (personal_detail.aadhaar_number = 0, "", personal_detail.aadhaar_number) as aadhaar_number,personal_detail.religion_id,tbl_religions.religion_name,
            personal_detail.religion_category_id,personal_detail.is_politically_exposed,
            personal_detail.date_of_birth,personal_detail.marital_status,
            personal_detail.gender,tbl_process_status.process_id,tbl_leads.lead_number, tbl_leads.lead_status,tbl_leads.created_on FROM tbl_applicant_personal_details personal_detail 
            left join tbl_leads on tbl_leads.user_id = personal_detail.user_id
            left join tbl_countries on personal_detail.country_id=tbl_countries.countrie_id 
            left join tbl_religions on personal_detail.religion_id=tbl_religions.religion_id 
            left join tbl_process_status on personal_detail.applicant_personal_id=tbl_process_status.applicant_id 
            left join tbl_users on personal_detail.user_id=tbl_users.user_id  where personal_detail.applicant_personal_id=? and process_id=? `;
    const get_customer_personal_deatil = await mysqlquery(
      customer_personal_details,
      [req.body.applicant_id, req.body.process_id]
    );
    if (get_customer_personal_deatil.length > 0) {
      let applicant_id = req.body.applicant_id;
      let user_sql = `SELECT * FROM ${db_table.applicant_persional_details} WHERE applicant_personal_id=${applicant_id}`;
      let user_result = await mysqlquery(user_sql, [applicant_id]);
      // let user_id = 0;
      // if (user_result[0] != undefined) {
      //     let user_id = user_result[0].user_id;
      // }
      const user_id = user_result[0].user_id;

      let lead_status_sql = `SELECT lead_status,lead_number FROM ${db_table.leads} WHERE user_id= ${user_id} `;
      var lead_result = await mysqlquery(lead_status_sql, [user_id]);

      var user_lead_status = "";
      var lead_number = "";
      if (lead_result[0] != undefined) {
        user_lead_status = lead_result[0].lead_status;
        lead_number = lead_result[0].lead_number;
      }
      var comments_approved_result = "";
      if (user_lead_status == "agent_review") {
        let lead_id = req.body.lead_id;
        let process_id = req.body.process_id;
        var comments_approved_result =
          await get_customer_forms_comments_approved(
            applicant_id,
            lead_id,
            process_id
          );
        // var comments_data = await get_customer_forms_comments_approved()

        // var comments__approved_data = [comments_approved_result]

        var comments__approved_data = comments_approved_result;
      }
      get_customer_personal_deatil.forEach((application) => {
        let account_type_id = application.account_type_id;
        var data = account_json;

        var customer_account_type = data.find(
          (item) => item.account_type_id === account_type_id
        );
        var account_type = "";
        if (customer_account_type != undefined) {
          account_type = customer_account_type.account_type;
        }

        application["account_type_name"] = account_type;

        let applicant_tit = application.applicant_title;
        var data = titles_json;

        var applicant_title = data.find(
          (item) => item.title_id === applicant_tit
        );
        var title = applicant_title.title_name;

        application["applicant_title_name"] = title;

        let religion_category = application.religion_category_id;
        var category_data = religion_categories_json;

        var customer_religion_category = category_data.find(
          (item) => item.religion_categories_id === religion_category
        );
        var religions_category =
          customer_religion_category.religion_categories_name;
        application["religion_category_name"] = religions_category;

        var trading_facility = application.is_trading_facility_opt;
        if (trading_facility == 0) {
          facility = "no";
        }
        if (trading_facility == 1) {
          facility = "yes";
        }
        if (trading_facility == null) {
          facility = "";
        }
        application["is_trading_facility_opt_name"] = facility;

        var politically_exposed = application.is_politically_exposed;
        if (politically_exposed == 0) {
          politically_expo = "no";
        }
        if (politically_exposed == 1) {
          politically_expo = "yes";
        }
        if (politically_exposed == null) {
          politically_expo = "";
        }

        application["is_politically_exposed_name"] = politically_expo;

        let process_id = application.process_id;
        var process_data_id = customer_forms;

        var customer_process = process_data_id.find(
          (item) => item.process_id === process_id
        );
        var process_type = customer_process.form_name;

        application["process_name"] = process_type;
      });

      res.status(200).json({
        data: get_customer_personal_deatil,
        agent_feedback: comments__approved_data,
      });
    } else {
      const sql = `select applicant_title , applicant_first_name , applicant_middle_name ,applicant_last_name from ${db_table.applicant_persional_details} where applicant_personal_id = ? `;
      const result = await mysqlquery(sql, [req.body.applicant_id]);
      if (
        result[0].applicant_first_name == null ||
        result[0].applicant_last_name == null
      ) {
        const sql1 = `select u.title as applicant_title, u.first_name as applicant_first_name, u.last_name as applicant_last_name from ${db_table.users} as u
                        left join ${db_table.applicant_persional_details} as apd on apd.user_id = u.user_id
                        where apd.applicant_personal_id = ?`;
        const sql1result = await mysqlquery(sql1, [req.body.applicant_id]);
        if (sql1result.length > 0) {
          res
            .status(200)
            .json({ message: "user fetch successfullly", data: sql1result });
        }
      } else {
        if (result.length > 0) {
          res
            .status(200)
            .json({ message: "user fetch successfullly", data: result });
        }
      }
    }
  } catch (error) {
    res.status(400).json({
      msg: error.message ? error.message : error,
    });
  }
};

module.exports.get_customer_personal_details_form_2 = async (req, res) => {
  try {
    let customer_personal_details = `SELECT personal_detail.applicant_personal_id,personal_detail.maiden_title,personal_detail.maiden_first_name,personal_detail.maiden_middle_name,
        personal_detail.maiden_last_name,personal_detail.mother_first_name,personal_detail.mother_middle_name,
        personal_detail.mother_last_name,personal_detail.in_relation_type,personal_detail.in_relation_title,
        personal_detail.in_relation_first_name,personal_detail.in_relation_middle_name,personal_detail.in_relation_last_name,
        personal_detail.date_of_becoming_nri,personal_detail.is_consent_declared,personal_detail.is_info_consent_declared,personal_detail.is_submited,
        tbl_users.first_name,tbl_users.last_name,tbl_leads.lead_status,
        personal_detail.nationality,tbl_countries.countrie_name applicant_nationality,tbl_process_status.process_id  FROM tbl_applicant_personal_details personal_detail 
        left join tbl_leads on tbl_leads.user_id = personal_detail.user_id
        left join tbl_countries on personal_detail.nationality=tbl_countries.countrie_id
        left join tbl_process_status on personal_detail.applicant_personal_id=tbl_process_status.applicant_id 
        left join tbl_users on personal_detail.user_id=tbl_users.user_id where personal_detail.applicant_personal_id=? and tbl_process_status.process_id=?`;
    const get_customer_personal_deatil = await mysqlquery(
      customer_personal_details,
      [req.body.applicant_id, req.body.process_id]
    );
    let applicant_id = req.body.applicant_id;
    let user_sql = `SELECT * FROM ${db_table.applicant_persional_details} WHERE applicant_personal_id=?`;
    let user_result = await mysqlquery(user_sql, [applicant_id]);

    let user_id = user_result[0].user_id;

    let lead_status_sql = `SELECT lead_status FROM ${db_table.leads} WHERE user_id=? `;
    var lead_result = await mysqlquery(lead_status_sql, [user_id]);

    var user_lead_status = lead_result[0].lead_status;
    var comments_approved_result = "";
    if (user_lead_status == "agent_review") {
      let lead_id = req.body.lead_id;
      let process_id = req.body.process_id;
      var comments_approved_result = await get_customer_forms_comments_approved(
        applicant_id,
        lead_id,
        process_id
      );
      // var comments_data = await get_customer_forms_comments_approved()

      // var comments__approved_data = [comments_approved_result]

      var comments__approved_data = comments_approved_result;
    }
    get_customer_personal_deatil.forEach((application) => {
      let maiden_tit = application.maiden_title;
      var data = titles_json;

      application["maiden_title_name"] = "";
      if (maiden_tit !== "") {
        var maiden_title = data.find((item) => item.title_id === maiden_tit);
        if (maiden_title != undefined) {
          var maidentitle = maiden_title.title_name;
          application["maiden_title_name"] = maidentitle;
        }
      }

      let in_relation_tit = application.in_relation_title;
      var data = titles_json;
      application["in_relation_title_name"] = "";
      if (in_relation_tit != "") {
        var relation_tit = data.find(
          (item) => item.title_id === in_relation_tit
        );
        if (relation_tit != undefined) {
          var relation_title = relation_tit.title_name;
          application["in_relation_title_name"] = relation_title;
        }
      }

      var consent_declared = application.is_consent_declared;
      let consent = "";

      if (consent_declared == 0) {
        consent = "no";
      }
      if (consent_declared == 1) {
        consent = "yes";
      }
      if (consent_declared == null) {
        consent = "";
      }
      application["is_consent_declared_name"] = consent;

      let consent1 = "";
      var consent_declared_1 = application.is_info_consent_declared;
      if (consent_declared_1 == 0) {
        consent1 = "no";
      }
      if (consent_declared_1 == 1) {
        consent1 = "yes";
      }
      if (consent_declared_1 == null) {
        consent1 = "";
      }
      application["is_consent_declared_name_1"] = consent1;

      var submited = application.is_submited;
      let submit = "";

      if (submited == 0) {
        submit = "no";
      }
      if (submited == 1) {
        submit = "yes";
      }
      if (submited == null) {
        submit = "";
      }

      application["is_submited_value"] = submit;

      let process_id = application.process_id;
      var process_data_id = customer_forms;

      var customer_process = process_data_id.find(
        (item) => item.process_id === process_id
      );
      var process_type = customer_process.form_name;

      application["process_name"] = process_type;
    });

    res.status(200).json({
      data: get_customer_personal_deatil,
      agent_feedback: comments__approved_data,
    });
  } catch (error) {
    res.status(400).json({
      msg: error.message ? error.message : error,
    });
  }
};

module.exports.get_customer_fatca_form_3 = async (req, res) => {
  try {
    let customer_fatca_details = `SELECT tbl_fatcas.fatca_id,tbl_fatcas.applicant_id,tbl_fatcas.is_residence_for_tax,
        tbl_fatcas.tax_identification_number,tbl_fatcas.tin_description,tbl_fatcas.tin_country_id,
        tbl_countri.countrie_name tin_country_name, tbl_leads.lead_status,
        tbl_fatcas.tin_issue_county_id,tbl_country.countrie_name tin_issues_country,tbl_fatcas.city_of_birth,
        tbl_fatcas.birth_county_id,tbl_countries.countrie_name  birth_country,tbl_process_status.process_id  FROM tbl_fatcas 
        inner join tbl_applicant_personal_details on tbl_fatcas.applicant_id = tbl_applicant_personal_details.applicant_personal_id
        left join tbl_leads on tbl_applicant_personal_details.user_id = tbl_leads.user_id
        left join tbl_countries tbl_countri on tbl_fatcas.tin_country_id=tbl_countri.countrie_id
        left join tbl_countries tbl_country on tbl_fatcas.tin_issue_county_id=tbl_country.countrie_id
        left join tbl_countries  on tbl_fatcas.birth_county_id=tbl_countries.countrie_id 
        left join tbl_process_status  on tbl_fatcas.applicant_id=tbl_process_status.applicant_id 
        where tbl_fatcas.applicant_id=? and process_id=?`;
    const get_customer_facta_deatil = await mysqlquery(customer_fatca_details, [
      req.body.applicant_id,
      req.body.process_id,
    ]);
    let applicant_id = req.body.applicant_id;
    let user_sql = `SELECT * FROM ${db_table.applicant_persional_details} WHERE applicant_personal_id=?`;
    let user_result = await mysqlquery(user_sql, [applicant_id]);

    let user_id = user_result[0].user_id;

    let lead_status_sql = `SELECT lead_status FROM ${db_table.leads} WHERE user_id=? `;
    var lead_result = await mysqlquery(lead_status_sql, [user_id]);

    var user_lead_status = lead_result[0].lead_status;
    var comments_approved_result = "";
    if (user_lead_status == "agent_review") {
      let lead_id = req.body.lead_id;
      let process_id = req.body.process_id;
      var comments_approved_result = await get_customer_forms_comments_approved(
        applicant_id,
        lead_id,
        process_id
      );
      // var comments_data = await get_customer_forms_comments_approved()

      // var comments__approved_data = [comments_approved_result]

      var comments__approved_data = comments_approved_result;
    }
    get_customer_facta_deatil.forEach((application) => {
      var residence_for_tax = application.is_residence_for_tax;
      if (residence_for_tax == 0) {
        residence_tax = "no";
      }
      if (residence_for_tax == 1) {
        residence_tax = "yes";
      }
      if (residence_for_tax == null) {
        residence_tax = "";
      }

      application["is_residence_for_tax_name"] = residence_tax;

      let process_id = application.process_id;
      var process_data_id = customer_forms;

      var customer_process = process_data_id.find(
        (item) => item.process_id === process_id
      );
      var process_type = customer_process.form_name;

      application["process_name"] = process_type;
    });

    res.status(200).json({
      data: get_customer_facta_deatil,
      agent_feedback: comments__approved_data,
    });
  } catch (error) {
    res.status(400).json({
      msg: error.message ? error.message : error,
    });
  }
};

module.exports.get_customer_kyc_deatil = async (req, res) => {
  try {
    let customer_kyc_details = `SELECT tbl_kyc_details.kyc_details_id, tbl_kyc_details.applicant_id,tbl_kyc_details.is_other_than_indian_passport,
        tbl_kyc_details.passport_number,tbl_kyc_details.issue_date,tbl_kyc_details.expiry_date,tbl_kyc_details.issueing_authority,
       tbl_kyc_details.place_of_issue,tbl_kyc_details.visa_type,tbl_visa_types.visa_type_name, tbl_kyc_details.visa_permit_expiry_date,tbl_kyc_details.is_resident_permit,
       tbl_kyc_details.pan_number,tbl_kyc_details.is_form_60,tbl_leads.lead_status,
       tbl_process_status.process_id  FROM tbl_kyc_details
       inner join tbl_applicant_personal_details on tbl_kyc_details.applicant_id = tbl_applicant_personal_details.applicant_personal_id
        left join tbl_leads on tbl_applicant_personal_details.user_id = tbl_leads.user_id
       left join tbl_visa_types on tbl_kyc_details.visa_type=tbl_visa_types.visa_type_id
       left join tbl_process_status  on tbl_kyc_details.applicant_id=tbl_process_status.applicant_id 
       where tbl_kyc_details.applicant_id=? and process_id=?`;
    const get_customer_kyc_deatil = await mysqlquery(customer_kyc_details, [
      req.body.applicant_id,
      req.body.process_id,
    ]);
    let applicant_id = req.body.applicant_id;
    let user_sql = `SELECT * FROM ${db_table.applicant_persional_details} WHERE applicant_personal_id=?`;
    let user_result = await mysqlquery(user_sql, [applicant_id]);

    let user_id = user_result[0].user_id;

    let lead_status_sql = `SELECT lead_status FROM ${db_table.leads} WHERE user_id=? `;
    var lead_result = await mysqlquery(lead_status_sql, [user_id]);

    var user_lead_status = lead_result[0].lead_status;
    var comments_approved_result = "";
    if (user_lead_status == "agent_review") {
      let lead_id = req.body.lead_id;
      let process_id = req.body.process_id;
      var comments_approved_result = await get_customer_forms_comments_approved(
        applicant_id,
        lead_id,
        process_id
      );
      // var comments_data = await get_customer_forms_comments_approved()

      // var comments__approved_data = [comments_approved_result]

      var comments__approved_data = comments_approved_result;
    }
    get_customer_kyc_deatil.forEach((application) => {
      var other_than_indian_passport =
        application.is_other_than_indian_passport;
      if (other_than_indian_passport == 0) {
        indian_passport = "no";
      }
      if (other_than_indian_passport == 1) {
        indian_passport = "yes";
      }

      if (other_than_indian_passport == null) {
        indian_passport = "";
      }

      application["is_other_than_indian_passport_name"] = indian_passport;

      var form_60 = application.is_form_60;
      if (form_60 == 0) {
        form_is_60 = "no";
      }
      if (form_60 == 1) {
        form_is_60 = "yes";
      }
      if (form_60 == null) {
        form_is_60 = "";
      }

      application["resident_permit_value"] = "no";
      if (application.is_resident_permit == 1) {
        application["resident_permit_value"] = "yes";
      }

      application["form_is_60_value"] = form_is_60;

      let process_id = application.process_id;
      var process_data_id = customer_forms;

      var customer_process = process_data_id.find(
        (item) => item.process_id === process_id
      );
      var process_type = customer_process.form_name;

      application["process_name"] = process_type;
    });
    res.status(200).json({
      data: get_customer_kyc_deatil,
      agent_feedback: comments__approved_data,
    });
  } catch (error) {
    res.status(400).json({
      msg: error.message ? error.message : error,
    });
  }
};

module.exports.get_customer_kyc_deatil_temp_visa_dec = async (req, res) => {
  try {
    let customer_kyc_details = `SELECT tbl_kyc_details.kyc_details_id, tbl_kyc_details.applicant_id,
                 tbl_kyc_details.temporary_visa_declare_issue_date,
                 tbl_kyc_details.temporary_visa_declare_expiry_date,
                 tbl_kyc_details.is_temporary_visa_declaration,tbl_leads.lead_status,
                tbl_process_status.process_id  FROM tbl_kyc_details
                inner join tbl_applicant_personal_details on tbl_kyc_details.applicant_id = tbl_applicant_personal_details.applicant_personal_id
                left join tbl_leads on tbl_applicant_personal_details.user_id = tbl_leads.user_id
                left join tbl_process_status  on tbl_kyc_details.applicant_id=tbl_process_status.applicant_id 
                where tbl_kyc_details.applicant_id=? and process_id=?`;
    const customer_kyc_deatil_temp_visa_dec = await mysqlquery(
      customer_kyc_details,
      [req.body.applicant_id, req.body.process_id]
    );
    let applicant_id = req.body.applicant_id;
    let user_sql = `SELECT * FROM ${db_table.applicant_persional_details} WHERE applicant_personal_id=?`;
    let user_result = await mysqlquery(user_sql, [applicant_id]);

    let user_id = user_result[0].user_id;

    let lead_status_sql = `SELECT lead_status FROM ${db_table.leads} WHERE user_id=? `;
    var lead_result = await mysqlquery(lead_status_sql, [user_id]);

    var user_lead_status = lead_result[0].lead_status;
    var comments_approved_result = "";
    if (user_lead_status == "agent_review") {
      let lead_id = req.body.lead_id;
      let process_id = req.body.process_id;
      var comments_approved_result = await get_customer_forms_comments_approved(
        applicant_id,
        lead_id,
        process_id
      );
      // var comments_data = await get_customer_forms_comments_approved()

      // var comments__approved_data = [comments_approved_result]

      var comments__approved_data = comments_approved_result;
    }
    customer_kyc_deatil_temp_visa_dec.forEach((application) => {
      var temporary_visa_declaration =
        application.is_temporary_visa_declaration;
      if (temporary_visa_declaration == 0) {
        visa_declaration = "no";
      }
      if (temporary_visa_declaration == 1) {
        visa_declaration = "yes";
      }
      if (temporary_visa_declaration == null) {
        visa_declaration = "";
      }

      application["is_temporary_visa_declaration_name"] = visa_declaration;

      let process_id = application.process_id;
      var process_data_id = customer_forms;

      var customer_process = process_data_id.find(
        (item) => item.process_id === process_id
      );
      var process_type = customer_process.form_name;

      application["process_name"] = process_type;
    });
    const applicantid = req.body.applicant_id;
    const processid = req.body.process_id;
    const sql = `select lead_status from ${db_table.leads} where user_id= ?`;
    const result = await mysqlquery(sql, user_id);
    if (result[0].lead_status === "agent_review") {
      let get_status = `update ${db_table.comment} SET status = 'replied' WHERE applicant_id = ${applicantid} and process_id = ${processid}`;
      const status_query = await mysqlquery(get_status);
    }

    res.status(200).json({
      data: customer_kyc_deatil_temp_visa_dec,
      agent_feedback: comments__approved_data,
    });
  } catch (error) {
    res.status(400).json({
      msg: error.message ? error.message : error,
    });
  }
};

module.exports.get_customer_kyc_pio_dec = async (req, res) => {
  try {
    let customer_kyc_pio_dec = `SELECT
        tbl_kyc_pio_declarations.kyc_pio_dec_id,
        tbl_kyc_pio_declarations.applicant_id,
        tbl_kyc_pio_declarations.is_held_indian_passport,
        tbl_kyc_pio_declarations.is_citizen_of_india_by_virtue,
        tbl_kyc_pio_declarations.is_belong_after_15_8_1947,
        tbl_kyc_pio_declarations.is_family_indian_by_virtue,
        tbl_kyc_pio_declarations.is_spouse_held_indian_passport,
        tbl_kyc_pio_declarations.is_spouse_family_indian_by_virtue,
        tbl_kyc_pio_declarations.indian_family_name,
        tbl_kyc_pio_declarations.indian_spouse_name,
        tbl_kyc_pio_declarations.indian_spouse_family_name,
        tbl_process_status.process_id,
        tbl_leads.lead_status
        FROM tbl_kyc_pio_declarations
        inner join tbl_applicant_personal_details on tbl_kyc_pio_declarations.applicant_id = tbl_applicant_personal_details.applicant_personal_id
        left join tbl_leads on tbl_applicant_personal_details.user_id = tbl_leads.user_id
        left join tbl_process_status  on tbl_kyc_pio_declarations.applicant_id=tbl_process_status.applicant_id 
        where tbl_kyc_pio_declarations.applicant_id=? and process_id=? group by tbl_kyc_pio_declarations.kyc_pio_dec_id`;
    let customer_kyc_pio_decleration = await mysqlquery(customer_kyc_pio_dec, [
      req.body.applicant_id,
      req.body.process_id,
    ]);
    let applicant_id = req.body.applicant_id;
    let user_sql = `SELECT * FROM ${db_table.applicant_persional_details} WHERE applicant_personal_id=?`;
    let user_result = await mysqlquery(user_sql, [applicant_id]);

    let user_id = user_result[0].user_id;

    let lead_status_sql = `SELECT lead_status FROM ${db_table.leads} WHERE user_id=? `;
    var lead_result = await mysqlquery(lead_status_sql, [user_id]);

    var user_lead_status = lead_result[0].lead_status;
    var comments_approved_result = "";
    if (user_lead_status == "agent_review") {
      let lead_id = req.body.lead_id;
      let process_id = req.body.process_id;
      var comments_approved_result = await get_customer_forms_comments_approved(
        applicant_id,
        lead_id,
        process_id
      );
      // var comments_data = await get_customer_forms_comments_approved()
      // var comments__approved_data = [comments_approved_result]
      var comments__approved_data = comments_approved_result;
    }

    customer_kyc_pio_decleration.forEach((application) => {
      var held_indian_passport = application.is_held_indian_passport;
      if (held_indian_passport == 0) {
        indian_passport = "no";
      }
      if (held_indian_passport == 1) {
        indian_passport = "yes";
      }
      if (held_indian_passport == null) {
        indian_passport = "";
      }

      application["is_held_indian_passport_name"] = indian_passport;

      var citizen_of_india_by_virtue =
        application.is_citizen_of_india_by_virtue;
      if (citizen_of_india_by_virtue == 0) {
        india_by_virtue = "no";
      }
      if (citizen_of_india_by_virtue == 1) {
        india_by_virtue = "yes";
      }
      if (citizen_of_india_by_virtue == null) {
        india_by_virtue = "";
      }
      application["is_citizen_of_india_by_virtue_name"] = india_by_virtue;
      var belong_after_15_8_1947 = application.is_belong_after_15_8_1947;
      if (belong_after_15_8_1947 == 0) {
        after_15_8_1947 = "no";
      }
      if (belong_after_15_8_1947 == 1) {
        after_15_8_1947 = "yes";
      }
      if (belong_after_15_8_1947 == null) {
        after_15_8_1947 = "";
      }

      application["is_belong_after_15_8_1947_name"] = after_15_8_1947;

      var family_indian_by_virtue = application.is_family_indian_by_virtue;
      if (family_indian_by_virtue == 0) {
        familyindian_by_virtue = "no";
      }
      if (family_indian_by_virtue == 1) {
        familyindian_by_virtue = "yes";
      }
      if (family_indian_by_virtue == null) {
        familyindian_by_virtue = "";
      }

      application["is_family_indian_by_virtue_name"] = familyindian_by_virtue;

      var spouse_held_indian_passport =
        application.is_spouse_held_indian_passport;
      if (spouse_held_indian_passport == 0) {
        spo_held_indian_passport = "no";
      }
      if (spouse_held_indian_passport == 1) {
        spo_held_indian_passport = "yes";
      }
      if (spouse_held_indian_passport == null) {
        spo_held_indian_passport = "";
      }

      application["is_spouse_held_indian_passport_name"] =
        spo_held_indian_passport;

      var spouse_family_indian_by_virtue =
        application.is_spouse_family_indian_by_virtue;
      if (spouse_family_indian_by_virtue == 0) {
        family_indian_by_virtue = "no";
      }
      if (spouse_family_indian_by_virtue == 1) {
        family_indian_by_virtue = "yes";
      }
      if (spouse_family_indian_by_virtue == null) {
        family_indian_by_virtue = "";
      }

      application["is_spouse_family_indian_by_virtue_name"] =
        family_indian_by_virtue;

      let process_id = application.process_id;
      var process_data_id = customer_forms;

      var customer_process = process_data_id.find(
        (item) => item.process_id === process_id
      );
      var process_type = customer_process.form_name;

      application["process_name"] = process_type;
    });
    let obj = customer_kyc_pio_decleration[0];
    if (customer_kyc_pio_decleration[0]) {
      Object.keys(obj).map((c) => {
        if (obj[c] == 1) {
          customer_kyc_pio_decleration[0].pio_declaration = c;
        }
      });
    }

    res.status(200).json({
      data: customer_kyc_pio_decleration,
      agent_feedback: comments__approved_data,
    });
  } catch (error) {
    console.log(error);
    res.status(400).json({
      msg: error.message ? error.message : error,
    });
  }
};

module.exports.get_customer_contact_details = async (req, res) => {
  try {
    let customer_contact_details = `SELECT tbl_contact_details.contact_details_id,tbl_contact_details.applicant_id,
        tbl_contact_details.residence_country_code,tbl_contact_details.residence_std_code,
        if ( tbl_contact_details.residence_tel_number = 0, "",  tbl_contact_details.residence_tel_number) as residence_tel_number,
        tbl_contact_details.office_country_code,tbl_contact_details.office_std_code,
        tbl_contact_details.office_tel_number,tbl_contact_details.country_code,
        if (tbl_contact_details.office_tel_number = 0, "", tbl_contact_details.office_tel_number) as office_tel_number,
        tbl_contact_details.mobile_number,tbl_contact_details.fax_country_code,
        tbl_contact_details.fax_std_code,tbl_contact_details.fax_number,
        tbl_contact_details.email_address,
        tbl_process_status.process_id,
        tbl_leads.lead_status 
        FROM tbl_contact_details
        inner join tbl_applicant_personal_details on tbl_contact_details.applicant_id = tbl_applicant_personal_details.applicant_personal_id
        left join tbl_leads on tbl_applicant_personal_details.user_id = tbl_leads.user_id
        left join tbl_process_status  on tbl_contact_details.applicant_id=tbl_process_status.applicant_id 
        where tbl_contact_details.applicant_id=? and process_id=?`;
    const customer_contact_detail = await mysqlquery(customer_contact_details, [
      req.body.applicant_id,
      req.body.process_id,
    ]);
    if (customer_contact_detail.length === 0) {
      const address_details = `SELECT users.user_id ,users.isd_code as country_code ,users.mobile_no as mobile_number ,users.email_address
            FROM tbl_applicant_personal_details AS apd
            LEFT JOIN tbl_users AS users
            ON apd.user_id = users.user_id
            WHERE apd.applicant_personal_id = ? `;
      const seach_details = await mysqlquery(
        address_details,
        req.body.applicant_id
      );
      res.status(200).json({
        data: seach_details,
      });
    } else {
      let applicant_id = req.body.applicant_id;
      let user_sql = `SELECT * FROM ${db_table.applicant_persional_details} WHERE applicant_personal_id=?`;
      let user_result = await mysqlquery(user_sql, [applicant_id]);
      let user_id = user_result[0].user_id;

      let lead_status_sql = `SELECT lead_status FROM ${db_table.leads} WHERE user_id=? `;
      var lead_result = await mysqlquery(lead_status_sql, [user_id]);

      var user_lead_status = lead_result[0].lead_status;
      var comments_approved_result = "";
      if (user_lead_status == "agent_review") {
        let lead_id = req.body.lead_id;
        let process_id = req.body.process_id;
        var comments_approved_result =
          await get_customer_forms_comments_approved(
            applicant_id,
            lead_id,
            process_id
          );
        // var comments_data = await get_customer_forms_comments_approved()

        // var comments__approved_data = [comments_approved_result]

        var comments__approved_data = comments_approved_result;
      }
      customer_contact_detail.forEach((application) => {
        let process_id = application.process_id;
        var process_data_id = customer_forms;

        var customer_process = process_data_id.find(
          (item) => item.process_id === process_id
        );
        var process_type = customer_process.form_name;

        application["process_name"] = process_type;
      });
      res.status(200).json({
        data: customer_contact_detail,
        agent_feedback: comments__approved_data,
      });
    }
  } catch (error) {
    res.status(400).json({
      msg: error.message ? error.message : error,
    });
  }
};

module.exports.get_customer_overseas_current_address = async (req, res) => {
  try {
    let customer_overseas_current_address = `SELECT tbl_address_details.address_id,tbl_address_details.applicant_id,
        tbl_address_details.current_address_type,tbl_address_types.address_type_name current_address_type_name,tbl_address_details.current_house_number,
        tbl_address_details.current_house_or_building_name,tbl_address_details.current_landmark,tbl_address_details.current_road_or_street_name,tbl_address_details.current_state,tbl_address_details.current_city,
        tbl_address_details.current_country_id,tbl_countries.countrie_name current_country_name,tbl_address_details.current_pincode, 
        tbl_address_typ.address_type_name overseas_address_type_name,tbl_address_details.overseas_address_type,
        tbl_address_details.overseas_house_number,
        tbl_address_details.overseas_house_or_building_name,
        tbl_address_details.overseas_landmark, tbl_address_details.overseas_road_or_street_name, tbl_address_details.overseas_state,
        tbl_address_details.overseas_city,tbl_address_details.overseas_country_id,
        tbl_countrie.countrie_name overseas_country_name,
        tbl_address_details.overseas_pincode,tbl_process_status.process_id,
        tbl_leads.lead_status
        FROM tbl_address_details
        inner join tbl_applicant_personal_details on tbl_address_details.applicant_id = tbl_applicant_personal_details.applicant_personal_id
        left join tbl_leads on tbl_applicant_personal_details.user_id = tbl_leads.user_id
        left join tbl_process_status  on tbl_address_details.applicant_id=tbl_process_status.applicant_id
        left join tbl_address_types  on tbl_address_details.current_address_type=tbl_address_types.address_type_id
        left join tbl_countries  on tbl_address_details.current_country_id=tbl_countries.countrie_id 
        left join tbl_address_types tbl_address_typ  on tbl_address_details.overseas_address_type=tbl_address_typ.address_type_id 
        left join tbl_countries tbl_countrie on tbl_address_details.overseas_country_id=tbl_countrie.countrie_id 
        where tbl_address_details.applicant_id=? and process_id=? group by tbl_address_details.address_id`;
    const customer_overseas_current_addre = await mysqlquery(
      customer_overseas_current_address,
      [req.body.applicant_id, req.body.process_id]
    );
    let applicant_id = req.body.applicant_id;
    let user_sql = `SELECT * FROM ${db_table.applicant_persional_details} WHERE applicant_personal_id=?`;
    let user_result = await mysqlquery(user_sql, [applicant_id]);
    let user_id = user_result[0].user_id;

    let lead_status_sql = `SELECT lead_status FROM ${db_table.leads} WHERE user_id=? `;
    var lead_result = await mysqlquery(lead_status_sql, [user_id]);

    var user_lead_status = lead_result[0].lead_status;
    var comments_approved_result = "";
    if (user_lead_status == "agent_review") {
      let lead_id = req.body.lead_id;
      let process_id = req.body.process_id;
      var comments_approved_result = await get_customer_forms_comments_approved(
        applicant_id,
        lead_id,
        process_id
      );
      // var comments_data = await get_customer_forms_comments_approved()

      // var comments__approved_data = [comments_approved_result]

      var comments__approved_data = comments_approved_result;
    }
    customer_overseas_current_addre.forEach((application) => {
      let process_id = application.process_id;
      var process_data_id = customer_forms;

      var customer_process = process_data_id.find(
        (item) => item.process_id === process_id
      );
      var process_type = customer_process.form_name;

      application["process_name"] = process_type;
    });
    /* const sql = `select lead_status from ${db_table.leads} where user_id= ?`
            const result = await mysqlquery(sql,user_id);
            if(result[0].lead_status === 'agent_review'){
            let get_status = `update ${db_table.comment} 
            SET status = 'replied' 
            WHERE applicant_id = ${req.body.applicant_id} and process_id = ${req.body.process_id}`;
            const status_query = await mysqlquery(get_status)
         } */

    res.status(200).json({
      data: customer_overseas_current_addre,
      agent_feedback: comments__approved_data,
    });
  } catch (error) {
    res.status(400).json({
      msg: error.message ? error.message : error,
    });
  }
};

module.exports.get_customer_permanent_Jurisdiction_address = async (
  req,
  res
) => {
  try {
    let customer_permanent_Jurisdiction_address = `SELECT tbl_address_details.address_id,tbl_address_details.applicant_id,
        tbl_address_details.permenant_address_type,tbl_address_types.address_type_name permanent_address_type,tbl_address_details.permenant_house_number, tbl_address_details.permenant_house_or_building_name,
        tbl_address_details.permenant_landmark,tbl_address_details.permenant_road_or_street_name,tbl_address_details.permenant_state,tbl_address_details.permenant_city,tbl_countries.countrie_name permanent_country_name, tbl_address_details.permenant_country_id,
        tbl_address_details.permenant_pincode, tbl_address_details.jurisdiction_address_type,
        tbl_address_typ.address_type_name jurisdiction_address_type_name,
        tbl_address_details.jurisdiction_house_number,
        tbl_address_details.jurisdiction_house_or_building_name,
        tbl_address_details.jurisdiction_landmark,
        tbl_address_details.jurisdiction_road_or_street_name,tbl_address_details.jurisdiction_state,tbl_address_details.jurisdiction_city,
        tbl_address_details.jurisdiction_country_id,tbl_address_details.jurisdiction_address_as,tbl_address_details.permenant_address_as,
        tbl_countrie.countrie_name jurisdiction_countrie_name,
        tbl_address_details.jurisdiction_pincode,tbl_address_details.preffered_mailing,tbl_process_status.process_id,tbl_leads.lead_status  
        FROM tbl_address_details
        inner join tbl_applicant_personal_details on tbl_address_details.applicant_id = tbl_applicant_personal_details.applicant_personal_id
        left join tbl_leads on tbl_applicant_personal_details.user_id = tbl_leads.user_id
        left join tbl_process_status  on tbl_address_details.applicant_id=tbl_process_status.applicant_id
        left join tbl_address_types  on tbl_address_details.permenant_address_type=tbl_address_types.address_type_id
        left join tbl_countries  on tbl_address_details.permenant_country_id=tbl_countries.countrie_id 
        left join tbl_address_types tbl_address_typ  on tbl_address_details.jurisdiction_address_type=tbl_address_typ.address_type_id 
        left join tbl_countries tbl_countrie on tbl_address_details.jurisdiction_country_id=tbl_countrie.countrie_id 
        where tbl_address_details.applicant_id=? and process_id=?`;
    const customer_permanent_Jurisdiction_addr = await mysqlquery(
      customer_permanent_Jurisdiction_address,
      [req.body.applicant_id, req.body.process_id]
    );
    let applicant_id = req.body.applicant_id;
    let user_sql = `SELECT * FROM ${db_table.applicant_persional_details} WHERE applicant_personal_id=?`;
    let user_result = await mysqlquery(user_sql, [applicant_id]);

    let user_id = user_result[0].user_id;

    let lead_status_sql = `SELECT lead_status FROM ${db_table.leads} WHERE user_id=? `;
    var lead_result = await mysqlquery(lead_status_sql, [user_id]);

    var user_lead_status = lead_result[0].lead_status;
    var comments_approved_result = "";
    if (user_lead_status == "agent_review") {
      let lead_id = req.body.lead_id;
      let process_id = req.body.process_id;
      var comments_approved_result = await get_customer_forms_comments_approved(
        applicant_id,
        lead_id,
        process_id
      );
      // var comments_data = await get_customer_forms_comments_approved()

      // var comments__approved_data = [comments_approved_result]

      var comments__approved_data = comments_approved_result;
    }
    customer_permanent_Jurisdiction_addr.forEach((application) => {
      let process_id = application.process_id;
      var process_data_id = customer_forms;

      var customer_process = process_data_id.find(
        (item) => item.process_id === process_id
      );
      var process_type = customer_process.form_name;

      application["process_name"] = process_type;
    });

    res.status(200).json({
      data: customer_permanent_Jurisdiction_addr,
      agent_feedback: comments__approved_data,
    });
  } catch (error) {
    res.status(400).json({
      msg: error.message ? error.message : error,
    });
  }
};

module.exports.get_customer_profile = async (req, res) => {
  try {
    let customer_profile = `SELECT tbl_customer_profilers.customer_profile_id,tbl_customer_profilers.applicant_id,
        tbl_customer_profilers.qualification,tbl_customer_profilers.employment_type_id,tbl_employment_types.employment_types_name,
        tbl_customer_profilers.occupation_id,tbl_customer_profilers.source_income,
        tbl_customer_profilers.gross_annual_income,tbl_customer_profilers.industry_type_id,tbl_industries.industrie_name,
        tbl_process_status.process_id,tbl_leads.lead_status  FROM tbl_customer_profilers
        inner join tbl_applicant_personal_details on tbl_customer_profilers.applicant_id = tbl_applicant_personal_details.applicant_personal_id
        left join tbl_leads on tbl_applicant_personal_details.user_id = tbl_leads.user_id
        left join tbl_process_status  on tbl_customer_profilers.applicant_id=tbl_process_status.applicant_id 
        left join tbl_employment_types  on tbl_customer_profilers.employment_type_id=tbl_employment_types.employment_types_id 
        left join tbl_industries  on tbl_customer_profilers.industry_type_id=tbl_industries.industrie_id 
        where tbl_customer_profilers.applicant_id=? and process_id=? group by tbl_customer_profilers.customer_profile_id`;
    const customer_profiles = await mysqlquery(customer_profile, [
      req.body.applicant_id,
      req.body.process_id,
    ]);
    let applicant_id = req.body.applicant_id;
    let user_sql = `SELECT * FROM ${db_table.applicant_persional_details} WHERE applicant_personal_id=?`;
    let user_result = await mysqlquery(user_sql, [applicant_id]);

    let user_id = user_result[0].user_id;

    let lead_status_sql = `SELECT lead_status FROM ${db_table.leads} WHERE user_id=? `;
    var lead_result = await mysqlquery(lead_status_sql, [user_id]);

    var user_lead_status = lead_result[0].lead_status;
    var comments_approved_result = "";
    if (user_lead_status == "agent_review") {
      let lead_id = req.body.lead_id;
      let process_id = req.body.process_id;
      var comments_approved_result = await get_customer_forms_comments_approved(
        applicant_id,
        lead_id,
        process_id
      );
      // var comments_data = await get_customer_forms_comments_approved()

      // var comments__approved_data = [comments_approved_result]

      var comments__approved_data = comments_approved_result;
    }
    customer_profiles.forEach((application) => {
      let occupation_id = application.occupation_id;
      var data = occuption_json;

      var customer_occupation = data.find(
        (item) => item.occuption_id === occupation_id
      );
      var occuption_type = customer_occupation.occupation_title;

      application["occuption_type_name"] = occuption_type;

      let gross_annual_income_id = application.gross_annual_income;
      var gross_annual_income = gross_income_json;

      var gross_annual_inco = gross_annual_income.find(
        (item) => item.gross_income_id === gross_annual_income_id
      );
      var gross_income_range = gross_annual_inco.gross_income_range;
      application["gross_income_range_name"] = gross_income_range;

      let process_id = application.process_id;
      var process_data_id = customer_forms;

      var customer_process = process_data_id.find(
        (item) => item.process_id === process_id
      );
      var process_type = customer_process.form_name;

      application["process_name"] = process_type;
    });

    res.status(200).json({
      data: customer_profiles,
      agent_feedback: comments__approved_data,
    });
  } catch (error) {
    res.status(400).json({
      msg: error.message ? error.message : error,
    });
  }
};

module.exports.get_customer_banking_facilities = async (req, res) => {
  try {
    let customer_banking_facilities = `SELECT tbl_banking_facilities.banking_facilities_id,
        tbl_banking_facilities.applicant_id,tbl_banking_facilities.is_internet_banking_selected,
        tbl_banking_facilities.is_mobile_banking_selected,
        tbl_banking_facilities.debit_card_type,tbl_banking_facilities.card_variant,
        tbl_process_status.process_id,tbl_leads.lead_status  FROM tbl_banking_facilities
        inner join tbl_applicant_personal_details on tbl_banking_facilities.applicant_id = tbl_applicant_personal_details.applicant_personal_id
        left join tbl_leads on tbl_applicant_personal_details.user_id = tbl_leads.user_id
        left join tbl_process_status  on tbl_banking_facilities.applicant_id=tbl_process_status.applicant_id 
        where tbl_banking_facilities.applicant_id=? and process_id=?`;
    const customer_banking_facilitie = await mysqlquery(
      customer_banking_facilities,
      [req.body.applicant_id, req.body.process_id]
    );
    let applicant_id = req.body.applicant_id;
    let process_id = req.body.process_id;
    let user_sql = `SELECT * FROM ${db_table.applicant_persional_details} WHERE applicant_personal_id=?`;
    let user_result = await mysqlquery(user_sql, [applicant_id]);
    let user_id = user_result[0].user_id;

    let lead_status_sql = `SELECT lead_status FROM ${db_table.leads} WHERE user_id=? `;
    var lead_result = await mysqlquery(lead_status_sql, [user_id]);

    var user_lead_status = lead_result[0].lead_status;
    var comments_approved_result = "";
    if (user_lead_status == "agent_review") {
      let lead_id = req.body.lead_id;
      let process_id = req.body.process_id;
      var comments_approved_result = await get_customer_forms_comments_approved(
        applicant_id,
        lead_id,
        process_id
      );
      // var comments_data = await get_customer_forms_comments_approved()

      // var comments__approved_data = [comments_approved_result]

      var comments__approved_data = comments_approved_result;
    }
    customer_banking_facilitie.forEach((application) => {
      let card_varient_id = application.card_variant;

      var data = card_variant_json;
      var card_variant = data.find(
        (item) => item.card_type_id === card_varient_id
      );
      var varient_type = data.card_type;

      application["card_variant_name"] = varient_type;

      var internet_banking_selected = application.is_internet_banking_selected;
      if (internet_banking_selected == 0) {
        banking_selected = "no";
      }
      if (internet_banking_selected == 1) {
        banking_selected = "yes";
      }
      if (internet_banking_selected == null) {
        banking_selected = "";
      }

      application["is_internet_banking_selected_name"] = banking_selected;

      var mobile_banking_selected = application.is_mobile_banking_selected;
      if (mobile_banking_selected == 0) {
        mobile_banking = "no";
      }
      if (mobile_banking_selected == 1) {
        mobile_banking = "yes";
      }
      if (mobile_banking_selected == null) {
        mobile_banking = "";
      }

      application["is_mobile_banking_selected_name"] = mobile_banking;

      let process_id = application.process_id;
      var process_data_id = customer_forms;

      var customer_process = process_data_id.find(
        (item) => item.process_id === process_id
      );
      var process_type = customer_process.form_name;

      application["process_name"] = process_type;
    });

    // const sqli = `select lead_status from ${db_table.leads} where user_id=?`
    // const result = await mysqlquery(sqli,user_id);
    //  if(result[0].lead_status === 'agent_review'){
    //  let get_status = `update ${db_table.comment} SET status = 'replied' WHERE applicant_id = ${applicant_id} and process_id = ${process_id}`;
    //  const status_query = await mysqlquery(get_status)
    //  }
    //  const check_all_status = `SELECT status FROM ${db_table.comment} WHERE applicant_id = ? AND STATUS != 'replied'`
    //  const status_result = await mysqlquery(check_all_status,applicant_id)
    //  if(status_result.length == 0){
    //     const lead_id = `SELECT lead_id FROM ${db_table.comment} WHERE applicant_id = ?`
    //    const result = await mysqlquery(lead_id,applicant_id)
    //  const update_status = `update ${db_table.leads} set lead_status = 'agent_process' where lead_id = ?`
    //  const results  = await mysqlquery(update_status,result[0].lead_id)
    //  }

    res.status(200).json({
      data: customer_banking_facilitie,
      agent_feedback: comments__approved_data,
    });
  } catch (error) {
    res.status(400).json({
      msg: error.message ? error.message : error,
    });
  }
};

module.exports.get_customer_banking_facilities_1 = async (req, res) => {
  try {
    let customer_banking_facilities_1 = `SELECT tbl_banking_facilities.banking_facilities_id,
        tbl_banking_facilities.applicant_id,tbl_banking_facilities.is_cheque_book_selected,
        tbl_banking_facilities.is_daily_balance_alert_selected,
        tbl_banking_facilities.daily_balance_alert_mode,tbl_banking_facilities.is_card_alert_selected,
        tbl_banking_facilities.card_alert_mode,
        tbl_process_status.process_id,tbl_leads.lead_status  
        FROM tbl_banking_facilities
        inner join tbl_applicant_personal_details on tbl_banking_facilities.applicant_id = tbl_applicant_personal_details.applicant_personal_id
        left join tbl_leads on tbl_applicant_personal_details.user_id = tbl_leads.user_id
        left join tbl_process_status  on tbl_banking_facilities.applicant_id=tbl_process_status.applicant_id 
        where tbl_banking_facilities.applicant_id=? and process_id=?`;
    const customer_banking_facilities = await mysqlquery(
      customer_banking_facilities_1,
      [req.body.applicant_id, req.body.process_id]
    );
    let applicant_id = req.body.applicant_id;
    let user_sql = `SELECT * FROM ${db_table.applicant_persional_details} WHERE applicant_personal_id=?`;
    let user_result = await mysqlquery(user_sql, [applicant_id]);
    let user_id = user_result[0].user_id;

    let lead_status_sql = `SELECT lead_status FROM ${db_table.leads} WHERE user_id=? `;
    var lead_result = await mysqlquery(lead_status_sql, [user_id]);

    var user_lead_status = lead_result[0].lead_status;
    var comments_approved_result = "";
    if (user_lead_status == "agent_review") {
      let lead_id = req.body.lead_id;
      let process_id = req.body.process_id;
      var comments_approved_result = await get_customer_forms_comments_approved(
        applicant_id,
        lead_id,
        process_id
      );
      // var comments_data = await get_customer_forms_comments_approved()

      // var comments__approved_data = [comments_approved_result]

      var comments__approved_data = comments_approved_result;
    }
    customer_banking_facilities.forEach((application) => {
      var cheque_book_selected = application.is_cheque_book_selected;
      if (cheque_book_selected == 0) {
        che_book_selected = "no";
      }
      if (cheque_book_selected == 1) {
        che_book_selected = "yes";
      }
      if (cheque_book_selected == null) {
        che_book_selected = "";
      }

      application["is_cheque_book_selected_value"] = che_book_selected;

      var daily_balance_alert_selected =
        application.is_daily_balance_alert_selected;
      if (daily_balance_alert_selected == 0) {
        balance_alert_selected = "no";
      }
      if (daily_balance_alert_selected == 1) {
        balance_alert_selected = "yes";
      }
      if (daily_balance_alert_selected == null) {
        balance_alert_selected = "";
      }

      application["is_daily_balance_alert_selected_value"] =
        balance_alert_selected;

      var card_alert_selected = application.is_card_alert_selected;
      if (card_alert_selected == 0) {
        alert_selected = "no";
      }
      if (card_alert_selected == 1) {
        alert_selected = "yes";
      }
      if (card_alert_selected == null) {
        alert_selected = "";
      }

      application["is_card_alert_selected_value"] = alert_selected;
      let process_id = application.process_id;
      var process_data_id = customer_forms;

      var customer_process = process_data_id.find(
        (item) => item.process_id === process_id
      );
      var process_type = customer_process.form_name;
      application["process_name"] = process_type;
    });

    res.status(200).json({
      data: customer_banking_facilities,
      agent_feedback: comments__approved_data,
    });
  } catch (error) {
    res.status(400).json({
      msg: error.message ? error.message : error,
    });
  }
};

module.exports.get_customer_banking_document = async (req, res) => {
  try {
    let customer_banking_document = `SELECT tbl_banking_documents.banking_doc_id,tbl_banking_documents.applicant_id,
        tbl_banking_documents.passport_front,tbl_banking_documents.passport_back,
        tbl_banking_documents.address_proof_type_id,tbl_address_proof_types.address_proof_types_name,
        tbl_banking_documents.address_proof,
        tbl_banking_documents.place_of_issue place_of_issues_id,
        tbl_countries.countrie_name place_of_issue,
        tbl_banking_documents.issuing_authority,
        tbl_banking_documents.document_identification_number,
        tbl_banking_documents.issue_date,tbl_banking_documents.expiry_date,
        tbl_process_status.process_id, tbl_leads.lead_status
        FROM tbl_banking_documents
        inner join tbl_applicant_personal_details on tbl_banking_documents.applicant_id = tbl_applicant_personal_details.applicant_personal_id
        left join tbl_leads on tbl_applicant_personal_details.user_id = tbl_leads.user_id
        left join tbl_process_status  on tbl_banking_documents.applicant_id=tbl_process_status.applicant_id 
		left join tbl_countries  on tbl_banking_documents.place_of_issue=tbl_countries.countrie_id 
        left join tbl_address_proof_types  on tbl_banking_documents.address_proof_type_id=tbl_address_proof_types.address_proof_types_id 
        where tbl_banking_documents.applicant_id=? and process_id=?`;
    const customer_banking_documents = await mysqlquery(
      customer_banking_document,
      [req.body.applicant_id, req.body.process_id]
    );
    let applicant_id = req.body.applicant_id;
    let user_sql = `SELECT * FROM ${db_table.applicant_persional_details} WHERE applicant_personal_id=?`;
    let user_result = await mysqlquery(user_sql, [applicant_id]);

    let user_id = user_result[0].user_id;

    let lead_status_sql = `SELECT lead_status FROM ${db_table.leads} WHERE user_id=? `;
    var lead_result = await mysqlquery(lead_status_sql, [user_id]);

    var user_lead_status = lead_result[0].lead_status;
    var comments_approved_result = "";
    if (user_lead_status == "agent_review") {
      let lead_id = req.body.lead_id;
      let process_id = req.body.process_id;
      var comments_approved_result = await get_customer_forms_comments_approved(
        applicant_id,
        lead_id,
        process_id
      );
      // var comments_data = await get_customer_forms_comments_approved()

      // var comments__approved_data = [comments_approved_result]

      var comments__approved_data = comments_approved_result;
    }
    customer_banking_documents.forEach((application) => {
      let process_id = application.process_id;
      var process_data_id = customer_forms;

      var customer_process = process_data_id.find(
        (item) => item.process_id === process_id
      );
      var process_type = customer_process.form_name;

      application["process_name"] = process_type;
    });

    res.status(200).json({
      data: customer_banking_documents,
      agent_feedback: comments__approved_data,
    });
  } catch (error) {
    res.status(400).json({
      msg: error.message ? error.message : error,
    });
  }
};

module.exports.get_nominee_details = async (req, res) => {
  try {
    let get_nominee_details = `SELECT tbl_nominations.nomination_id,tbl_nominations.applicant_id,
        tbl_nominations.is_opted,tbl_nominations.nominee_title,
        tbl_nominations.nominee_first_name,tbl_nominations.nominee_middle_name,
        tbl_nominations.nominee_last_name,tbl_nominations.nominee_address_type,
        tbl_nominations.nominee_house_number,tbl_nominations.nominee_house_or_building_name,
        tbl_nominations.nominee_road_or_street_name,tbl_nominations.nominee_landkmark,
        tbl_nominations.nominee_state,tbl_nominations.nominee_city, tbl_nominations.nominee_country_id,
        tbl_countries.countrie_name nominee_country,
        tbl_nominations.nominee_pincode,tbl_nominations.relationship,
        tbl_nominations.nominee_date_of_birth,
        tbl_process_status.process_id,
        tbl_leads.lead_status
        FROM tbl_nominations
        inner join tbl_applicant_personal_details on tbl_nominations.applicant_id = tbl_applicant_personal_details.applicant_personal_id
        left join tbl_leads on tbl_applicant_personal_details.user_id = tbl_leads.user_id
        left join tbl_process_status  on tbl_nominations.applicant_id=tbl_process_status.applicant_id 
		left join tbl_countries  on tbl_nominations.nominee_country_id=tbl_countries.countrie_id 
        where tbl_nominations.applicant_id=? and process_id=?`;
    const nominee_details = await mysqlquery(get_nominee_details, [
      req.body.applicant_id,
      req.body.process_id,
    ]);
    let applicant_id = req.body.applicant_id;
    let user_sql = `SELECT * FROM ${db_table.applicant_persional_details} WHERE applicant_personal_id=?`;
    let user_result = await mysqlquery(user_sql, [applicant_id]);
    let user_id = user_result[0].user_id;

    let lead_status_sql = `SELECT lead_status FROM ${db_table.leads} WHERE user_id=? `;
    var lead_result = await mysqlquery(lead_status_sql, [user_id]);

    var user_lead_status = lead_result[0].lead_status;
    var comments_approved_result = "";
    if (user_lead_status == "agent_review") {
      let lead_id = req.body.lead_id;
      let process_id = req.body.process_id;
      var comments_approved_result = await get_customer_forms_comments_approved(
        applicant_id,
        lead_id,
        process_id
      );
      // var comments_data = await get_customer_forms_comments_approved()

      // var comments__approved_data = [comments_approved_result]

      var comments__approved_data = comments_approved_result;
    }
    nominee_details.forEach((application) => {
      var opted = application.is_opted;
      if (opted == 0) {
        opted_is = "no";
      }
      if (opted == 1) {
        opted_is = "yes";
      }
      if (opted == null) {
        opted_is = "";
      }

      application["is_opted_value"] = opted_is;
      let process_id = application.process_id;
      var process_data_id = customer_forms;

      var customer_process = process_data_id.find(
        (item) => item.process_id === process_id
      );
      var process_type = customer_process.form_name;

      application["process_name"] = process_type;
    });

    res.status(200).json({
      data: nominee_details,
      agent_feedback: comments__approved_data,
    });
  } catch (error) {
    res.status(400).json({
      msg: error.message ? error.message : error,
    });
  }
};

module.exports.get_gaurdian_details = async (req, res) => {
  try {
    let get_gaurdian_details = `SELECT tbl_nominations.nomination_id,tbl_nominations.applicant_id,
        tbl_nominations.nominee_age_in_year,tbl_nominations.nominee_age_in_month,
        tbl_nominations.gaurdian_title,tbl_nominations.gaurdian_first_name,
        tbl_nominations.gaurdian_middle_name,tbl_nominations.gaurdian_last_name,
        tbl_process_status.process_id,tbl_leads.lead_status  FROM tbl_nominations
        inner join tbl_applicant_personal_details on tbl_nominations.applicant_id = tbl_applicant_personal_details.applicant_personal_id
        left join tbl_leads on tbl_applicant_personal_details.user_id = tbl_leads.user_id
        left join tbl_process_status  on tbl_nominations.applicant_id=tbl_process_status.applicant_id
        where tbl_nominations.applicant_id=? and process_id=?`;
    const gaurdian_details = await mysqlquery(get_gaurdian_details, [
      req.body.applicant_id,
      req.body.process_id,
    ]);
    let applicant_id = req.body.applicant_id;
    let user_sql = `SELECT * FROM ${db_table.applicant_persional_details} WHERE applicant_personal_id=?`;
    let user_result = await mysqlquery(user_sql, [applicant_id]);

    let user_id = user_result[0].user_id;

    let lead_status_sql = `SELECT lead_status FROM ${db_table.leads} WHERE user_id=? `;
    var lead_result = await mysqlquery(lead_status_sql, [user_id]);

    var user_lead_status = lead_result[0].lead_status;
    var comments_approved_result = "";
    if (user_lead_status == "agent_review") {
      let lead_id = req.body.lead_id;
      let process_id = req.body.process_id;
      var comments_approved_result = await get_customer_forms_comments_approved(
        applicant_id,
        lead_id,
        process_id
      );
      // var comments_data = await get_customer_forms_comments_approved()

      // var comments__approved_data = [comments_approved_result]

      var comments__approved_data = comments_approved_result;
    }
    gaurdian_details.forEach((application) => {
      let process_id = application.process_id;
      var process_data_id = customer_forms;
      var customer_process = process_data_id.find(
        (item) => item.process_id === process_id
      );
      var process_type = customer_process.form_name;
      application["process_name"] = process_type;
    });

    res.status(200).json({
      data: gaurdian_details,
      agent_feedback: comments__approved_data,
    });
  } catch (error) {
    res.status(400).json({
      msg: error.message ? error.message : error,
    });
  }
};

module.exports.get_consent_declared = async (req, res) => {
  try {
    let get_gaurdian_details = `SELECT personal_detail.applicant_personal_id,personal_detail.is_consent_declared,personal_detail.is_info_consent_declared,
        tbl_process_status.process_id,tbl_leads.lead_status  FROM tbl_applicant_personal_details personal_detail
        left join tbl_leads on personal_detail.user_id = tbl_leads.user_id
        left join tbl_process_status  on personal_detail.applicant_personal_id=tbl_process_status.applicant_id
        where  personal_detail.applicant_personal_id=?  and process_id=?`;
    const gaurdian_details = await mysqlquery(get_gaurdian_details, [
      req.body.applicant_id,
      req.body.process_id,
    ]);
    let applicant_id = req.body.applicant_id;
    let user_sql = `SELECT * FROM ${db_table.applicant_persional_details} WHERE applicant_personal_id=?`;
    let user_result = await mysqlquery(user_sql, [applicant_id]);

    let user_id = user_result[0].user_id;
    let lead_status_sql = `SELECT lead_status FROM ${db_table.leads} WHERE user_id=? `;
    var lead_result = await mysqlquery(lead_status_sql, [user_id]);

    var user_lead_status = lead_result[0].lead_status;
    var comments_approved_result = "";
    if (user_lead_status == "agent_review") {
      let lead_id = req.body.lead_id;
      let process_id = req.body.process_id;
      var comments_approved_result = await get_customer_forms_comments_approved(
        applicant_id,
        lead_id,
        process_id
      );
      // var comments_data = await get_customer_forms_comments_approved()

      // var comments__approved_data = [comments_approved_result]

      var comments__approved_data = comments_approved_result;
    }
    gaurdian_details.forEach((application) => {
      let process_id = application.process_id;
      var process_data_id = customer_forms;
      var customer_process = process_data_id.find(
        (item) => item.process_id === process_id
      );
      var process_type = customer_process.form_name;
      application["process_name"] = process_type;
    });
    res.status(200).json({
      data: gaurdian_details,
      agent_feedback: comments__approved_data,
    });
  } catch (error) {
    res.status(400).json({
      msg: error.message ? error.message : error,
    });
  }
};

module.exports.get_guardian_details = async (req, res) => {
  try {
    let customer_personal_details = `SELECT personal_detail.applicant_personal_id,
        personal_detail.applicant_title,personal_detail.applicant_first_name,
        personal_detail.applicant_middle_name,personal_detail.applicant_last_name,
        personal_detail.guardian_relation, personal_detail.guardian_customer_id,
        personal_detail.date_of_birth,personal_detail.marital_status,
        personal_detail.gender,tbl_process_status.process_id,tbl_leads.lead_status  FROM tbl_applicant_personal_details personal_detail 
        left join tbl_leads on tbl_applicant_personal_details.user_id = tbl_leads.user_id
        left join tbl_process_status on personal_detail.applicant_personal_id=tbl_process_status.applicant_id 
        left join tbl_users on personal_detail.user_id=tbl_users.user_id  where personal_detail.applicant_personal_id=? and process_id=? `;
    const get_customer_personal_deatil = await mysqlquery(
      customer_personal_details,
      [req.body.applicant_id, req.body.process_id]
    );
    let applicant_id = req.body.applicant_id;
    let user_sql = `SELECT * FROM ${db_table.applicant_persional_details} WHERE applicant_personal_id=?`;
    let user_result = await mysqlquery(user_sql, [applicant_id]);

    let user_id = user_result[0].user_id;

    let lead_status_sql = `SELECT lead_status FROM ${db_table.leads} WHERE user_id=? `;
    var lead_result = await mysqlquery(lead_status_sql, [user_id]);

    var user_lead_status = lead_result[0].lead_status;
    var comments_approved_result = "";
    if (user_lead_status == "agent_review") {
      let lead_id = req.body.lead_id;
      let process_id = req.body.process_id;
      var comments_approved_result = await get_customer_forms_comments_approved(
        applicant_id,
        lead_id,
        process_id
      );
      // var comments_data = await get_customer_forms_comments_approved()

      // var comments__approved_data = [comments_approved_result]

      var comments__approved_data = comments_approved_result;
    }
    get_customer_personal_deatil.forEach((application) => {
      let applicant_tit = application.applicant_title;
      var data = titles_json;

      var applicant_title = data.find(
        (item) => item.title_id === applicant_tit
      );
      var title = applicant_title.title_name;

      application["applicant_title_name"] = title;

      let process_id = application.process_id;
      var process_data_id = customer_forms;

      var customer_process = process_data_id.find(
        (item) => item.process_id === process_id
      );
      var process_type = customer_process.form_name;

      application["process_name"] = process_type;
    });

    res.status(200).json({
      data: get_customer_personal_deatil,
      agent_feedback: comments__approved_data,
    });
  } catch (error) {
    res.status(400).json({
      msg: error.message ? error.message : error,
    });
  }
};

module.exports.get_relative_details = async (req, res) => {
  try {
    let customer_relative_details = `SELECT app_relative.applicant_relative_id,app_relative.applicant_id,
	    app_relative.declarant_title,app_relative.declarant_first_name,
        app_relative.declarant_middle_name,app_relative.declarant_last_name,
        app_relative.declarant_house_number,app_relative.declarant_house_and_building_name,
        app_relative.declarant_road_or_street_name,app_relative.declarant_landmark,
        app_relative.declarant_state,app_relative.declarant_city,
        app_relative.declarant_country_id,app_relative.declarant_pincode,
        app_relative.declarant_relation,tbl_countri.countrie_name,tbl_process_status.process_id,tbl_leads.lead_status  
        FROM  tbl_applicant_relatives app_relative
        inner join tbl_applicant_personal_details on app_relative.applicant_id = tbl_applicant_personal_details.applicant_personal_id
        left join tbl_leads on tbl_applicant_personal_details.user_id = tbl_leads.user_id
        left join tbl_countries tbl_countri on app_relative.declarant_country_id=tbl_countri.countrie_id
        left join tbl_process_status  on app_relative.applicant_id=tbl_process_status.applicant_id 
        where app_relative.applicant_id=? group by app_relative.applicant_relative_id`;
    const get_customer_relative_deatil = await mysqlquery(
      customer_relative_details,
      [req.body.applicant_id]
    );
    let applicant_id = req.body.applicant_id;
    let user_sql = `SELECT * FROM ${db_table.applicant_persional_details} WHERE applicant_personal_id=?`;
    let user_result = await mysqlquery(user_sql, [applicant_id]);

    let user_id = user_result[0].user_id;

    let lead_status_sql = `SELECT lead_status,lead_id FROM ${db_table.leads} WHERE user_id=? `;
    var lead_result = await mysqlquery(lead_status_sql, [user_id]);
    var user_lead_status = lead_result[0].lead_status;
    var comments_approved_result = "";
    if (user_lead_status == "agent_review") {
      let lead_id = lead_result[0].lead_id;
      let process_id = req.body.process_id;
      console.log("user_lead_status", {
        applicant_id,
        lead_id,
        process_id,
      });
      var comments_approved_result = await get_customer_forms_comments_approved(
        applicant_id,
        lead_id,
        process_id
      );
      console.log("hoo");

      // var comments_data = await get_customer_forms_comments_approved()

      // var comments__approved_data = [comments_approved_result]

      var comments__approved_data = comments_approved_result;
    }
    get_customer_relative_deatil.forEach((application) => {
      let process_id = application.process_id;
      var process_data_id = customer_forms;

      var customer_process = process_data_id.find(
        (item) => item.process_id === process_id
      );
      var process_type = customer_process.form_name;

      application["process_name"] = process_type;
    });
    res.status(200).json({
      data: get_customer_relative_deatil,
      agent_feedback: comments__approved_data,
    });
  } catch (error) {
    console.log(error);
    res.status(400).json({
      msg: error.message ? error.message : error,
    });
  }
};

module.exports.selected_account_type = async (req, res) => {
  try {
    let account = account_json;
    const sql = `select account_type_id,saving_account from ${db_table.applicant_persional_details}
         where applicant_personal_id = ?`;
    const result = await mysqlquery(sql, [req.body.applicant_id]);
    account_id = result[0].account_type_id;
    const newarr = [];
    const finalresult = account.find((a) => {
      if (a.account_type_id == account_id) {
        newarr.push(a.account_type);
      }
    });
    res.status(200).json({
      data: newarr,
      saving_account: result[0]?.saving_account,
    });
  } catch (error) {
    res.status(400).json({
      msg: error.message ? error.message : error,
    });
  }
};

module.exports.get_all_documents = async (req, res) => {
  try {
    const sql = `SELECT * FROM tbl_kyc_details WHERE applicant_id = ?`;
    const QueryResult = await mysqlquery(sql, [req.body.applicant_id]);

    const sql1 = `SELECT * FROM tbl_kyc_pio_declarations WHERE applicant_id = ?`;
    const QueryResult1 = await mysqlquery(sql1, [req.body.applicant_id]);

    const address_proof = `SELECT address_proof_type_id  FROM ${db_table.banking_document} WHERE applicant_id = ?`;
    const add_result = await mysqlquery(address_proof, [req.body.applicant_id]);

    if (add_result.length > 0) {
      const address_id = Object.values(add_result[0])[0];
      if (QueryResult[0].is_other_than_indian_passport === 1) {
        QueryResult[0].is_pio = 1;
        QueryResult[0].address_proof_id = address_id;
      } else {
        QueryResult[0].visa_type;
        QueryResult[0].address_proof_id = address_id;
        QueryResult[0].is_resident_permit;
      }
      res.status(200).json({
        data: QueryResult,
      });
    } else {
      if (QueryResult[0].is_other_than_indian_passport === 1) {
        QueryResult[0].is_pio = 1;
        QueryResult[0].address_proof_id = 0;
      } else {
        QueryResult[0].visa_type;
        QueryResult[0].address_proof_id = 0;
        QueryResult[0].is_resident_permit;
      }
      res.status(200).json({
        data: QueryResult,
      });
    }

    //  const arr = []
    //  let obj = QueryResult1[0]
    //   Object.keys(obj).map(c => {
    //     if(obj[c] == 1) {
    //         var key = "is_pio";
    //         QueryResult.map(a=>{
    //         const maindata = {
    //         is_other_than_indian_passport : a.is_other_than_indian_passport,
    //         is_form_60 : a.is_form_60,
    //         visa_type : a.visa_type,
    //         is_resident_permit : a.is_resident_permit,
    //         address_proof_id
    //         }
    //        if(maindata.visa_type > 0){
    //            maindata[key] = 0;
    //        }else{
    //         maindata[key] = 1;
    //        }
    //        arr.push(maindata)
    //     })
    // }
    // })
    // if(QueryResult.length > 0){
    //     res.status(200).json({
    //         data:emtarr
    //     })
    // }else{
    //     res.status(400).json({
    //      message:'data not found for that applicant_id'
    //     })
    // }
  } catch (error) {
    res.status(400).json({
      msg: error.message ? error.message : error,
    });
  }
};

// module.exports.get_all_data = async (req, res) => {
//   try {
//     const userId = req.body.user_id;

//     let sql = `SELECT u.user_id,u.role_id,
//         apd.applicant_personal_id,apd.country_id,
//         apd.account_type_id,apd.is_consent_declared,
//         adrs.*,
//         bdi.banking_doc_id,
//         bf.banking_facilities_id,
//         cd.contact_details_id,cp.customer_profile_id, f.fatca_id, kd.kyc_details_id, kpd.kyc_pio_dec_id, n.nomination_id,
//         l.lead_status
//         FROM tbl_users AS u
//         LEFT JOIN tbl_applicant_personal_details AS apd
//         ON apd.user_id = u.user_id
//         LEFT JOIN tbl_address_details AS adrs
//         ON adrs.applicant_id = apd.applicant_personal_id
//         LEFT JOIN tbl_banking_documents AS bdi
//         ON bdi.applicant_id = apd.applicant_personal_id
//         LEFT JOIN tbl_banking_facilities AS bf
//         ON bf.applicant_id = apd.applicant_personal_id
//         LEFT JOIN tbl_contact_details AS cd
//         ON cd.applicant_id = apd.applicant_personal_id
//         LEFT JOIN tbl_customer_profilers AS cp
//         ON cp.applicant_id = apd.applicant_personal_id
//         LEFT JOIN tbl_fatcas AS f
//         ON f.applicant_id = apd.applicant_personal_id
//         LEFT JOIN tbl_kyc_details AS kd
//         ON kd.applicant_id = apd.applicant_personal_id
//         LEFT JOIN tbl_kyc_pio_declarations AS kpd
//         ON kpd.applicant_id = apd.applicant_personal_id
//         LEFT JOIN tbl_nominations AS n
//         ON n.applicant_id = apd.applicant_personal_id
//         LEFT JOIN tbl_leads AS l
//         ON l.user_id = u.user_id
//         WHERE u.user_id = ? GROUP BY apd.applicant_personal_id`;

//     const result = await mysqlquery(sql, userId);
//     res.status(200).json({ data: result });
//   } catch (err) {
//     res.status(400).json({
//       msg: err.message ? err.message : err,
//     });
//   }
// };

module.exports.same_as_address = async (req, res) => {
  try {
    var sql1 =
      "SELECT address_id FROM `tbl_address_details` WHERE applicant_id = ?";
    let getAddressid = await mysqlquery(sql1, [req.body.applicant_id]);
    let addressId = getAddressid.length > 0 ? getAddressid[0].address_id : 0;
    const search_address = `select current_address_type,current_house_number,current_house_or_building_name,current_road_or_street_name,current_landmark,current_state,current_city,current_country_id,current_pincode,overseas_address_type,overseas_house_number,overseas_house_or_building_name,overseas_road_or_street_name,overseas_landmark,overseas_state,overseas_city,overseas_country_id,overseas_pincode from ${db_table.address_details} where address_id = ? and applicant_id = ?`;
    const address_result = await mysqlquery(search_address, [
      addressId,
      req.body.applicant_id,
    ]);
    if (address_result.length > 0) {
      res.status(200).json({
        data: address_result,
      });
    }
  } catch (error) {
    res.status(400).json({
      msg: error.message ? error.message : error,
    });
  }
};
// module.exports.get_lead_comments = async (req, res) => {
//     try {
//         let get_comments = `select * from tbl_comments where applicant_id=? and  process_id=?`
//         const comments_details = await mysqlquery(get_comments, [req.body.applicant_id, req.body.process_id]);
//         comments_details.forEach(application => {
//             let process_id = application.process_id;
//             var process_data_id = customer_forms;
//             var customer_process = process_data_id.find(item => item.process_id === process_id)
//             var process_type = customer_process.form_name;
//             application['process_name'] = process_type;
//         })

//         res.status(200).json({
//             data: comments_details
//         })
//     } catch (error) {
//         res.status(400).json({
//             msg: error
//         })

//     }
// }

module.exports.get_lead_comments = async (req, res) => {
  try {
    let get_comments = `SELECT * FROM ${db_table.comment} WHERE applicant_id=?`;
    const comments_details = await mysqlquery(get_comments, [
      req.body.applicant_id,
    ]);
    const lead_id = comments_details[0].lead_id;
    const get_lead_id = `SELECT comm.*, CONCAT(applicant_first_name,' ', applicant_middle_name,' ',applicant_last_name) AS applicant_name
        FROM tbl_applicant_personal_details AS apd
        LEFT JOIN tbl_comments AS comm 
        ON apd.applicant_personal_id = comm.applicant_id WHERE comm.lead_id = ?
        ORDER BY comm.comment_id`;
    const lead_details = await mysqlquery(get_lead_id, lead_id);

    lead_details.forEach((application) => {
      let process_id = application.process_id;
      var process_data_id = customer_forms;
      var customer_process = process_data_id.find(
        (item) => item.process_id === process_id
      );
      var process_type = customer_process.form_name;
      application["process_name"] = process_type;
    });
    const id = [];
    lead_details.map((a) => {
      if (!id.includes(a.applicant_id)) {
        id.push(a.applicant_id);
      }
    });
    let finalresult = {};
    id.map((i, c) => {
      const data1 = lead_details.filter((d) => i == d.applicant_id);
      Object.assign(finalresult, { [`applicant_${c + 1}`]: data1 });
    });
    res.status(200).json({
      data: finalresult,
    });
  } catch (error) {
    res.status(400).json({
      msg: error.message ? error.message : error,
    });
  }
};

// Minor flow

//personal detail 1.1 and 1.2
module.exports.minor_personal_detail = async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      res.status(409).json({ errors: errors.array() });
    } else {
      let data = [];
      if (req.body.applicant_id != undefined && req.body.applicant_id != "") {
        let applicant_id = req.body.applicant_id;
        delete req.body.applicant_id;
        let process_id = req.body.process_id;

        if (req.body.date_of_birth != undefined) {
          var birth_date = req.body.date_of_birth;
          req.body.date_of_birth = birth_date.slice(0, 10);
        }

        if (req.body.date_of_becoming_nri != undefined) {
          var date_of_becoming_nri = req.body.date_of_becoming_nri;
          req.body.date_of_becoming_nri = date_of_becoming_nri.slice(0, 10);
        }

        if (req.body.in_relation_first_name != undefined) {
          req.body.in_relation_type = "father";
          req.body.in_relation_title = "mr";
        }

        delete req.body.process_id;
        let applicant_details = await get_applicant_details(applicant_id);
        if (applicant_details.length != 0) {
          data = [req.body, applicant_id];
          let sql = `UPDATE ${db_table.applicant_persional_details} SET ? WHERE applicant_personal_id = ?`;
          const result = await mysqlquery(sql, data);
          if (result.affectedRows > 0) {
            let process_data = {
              applicant_id: applicant_id,
              process_id: process_id,
            };
            await update_process_status(process_data);

            let user_sql = `SELECT * FROM ${db_table.applicant_persional_details} WHERE applicant_personal_id=${applicant_id}`;
            let user_result = await mysqlquery(user_sql, [applicant_id]);

            const user_id = user_result[0].user_id;
            const sqli = `select lead_status from ${db_table.leads} where user_id=?`;
            const sqli_result = await mysqlquery(sqli, user_id);

            if (sqli_result[0].lead_status === "agent_review") {
              let get_status = `update ${db_table.comment} SET status = 'replied' WHERE applicant_id = ${applicant_id} and process_id = ${process_id}`;
              const status_query = await mysqlquery(get_status);
              const check_all_status = `SELECT status FROM ${db_table.comment} WHERE applicant_id = ? AND STATUS != 'replied'`;
              const status_check_all_status = await mysqlquery(
                check_all_status,
                applicant_id
              );

              if (status_check_all_status?.length >= 0) {
                let find_user = `SELECT * FROM ${db_table.applicant_persional_details} WHERE user_id=? `;
                let userfind = await mysqlquery(find_user, user_id);
                var in_query = "";
                userfind.forEach((uf) => {
                  in_query += uf.applicant_personal_id + ",";
                });
                if (in_query != "") {
                  in_query = in_query.substring(0, in_query.length - 1);
                  const check_all_status = `SELECT status FROM ${db_table.comment} WHERE applicant_id IN (${in_query}) AND STATUS = 'added'`;
                  const status_result = await mysqlquery(check_all_status);

                  const lead_id = `SELECT lead_id FROM ${db_table.comment} WHERE applicant_id = ?`;
                  const result = await mysqlquery(lead_id, applicant_id);

                  if (status_result.length === 0) {
                    const update_status = `update ${db_table.leads} set lead_status = 'agent_process' where lead_id = ?`;
                    const results = await mysqlquery(
                      update_status,
                      result[0].lead_id
                    );
                  }
                }
              }
            }
            res.status(200).json({
              msg: "Updated successfully",
              applicant_id: applicant_id,
            });
          } else {
            res.status(400).json({
              msg: "bad request",
            });
          }
        } else {
          res.status(400).json({
            msg: "bad request",
          });
        }
      } else {
        res.status(400).json({
          msg: "bad request",
        });
      }
    }
  } catch (error) {
    res.status(400).json({
      msg: error.message ? error.message : error,
    });
  }
};
//personal detail 1.1 and 1.2
//guardian details

const get_applicant_details = async (applicant_id) => {
  let sql = `SELECT * , if (p.aadhaar_number = 0, "", p.aadhaar_number) as aadhaar_number
    FROM ${db_table.applicant_persional_details} as p WHERE applicant_personal_id=?`;
  let applicant_details = await mysqlquery(sql, [applicant_id]);
  return applicant_details;
};

const update_process_status = async (params) => {
  var sql = `DELETE FROM  ${db_table.process_status} WHERE applicant_id=? and process_id=?`;
  await mysqlquery(sql, [params.applicant_id, params.process_id]);

  const submit_process_data = {
    applicant_id: params.applicant_id,
    process_id: params.process_id,
  };

  if (params.agent_status != undefined) {
    submit_process_data.agent_status = params.agent_status;
  }

  var sql = `INSERT INTO ${db_table.process_status} SET ? `;
  await mysqlquery(sql, submit_process_data);
};

const store_file = async (file_path, data) => {
  try {
    await fsPromises.writeFile(file_path, data, {
      encoding: "base64",
      flag: "w",
      mode: 0o666,
    });
    return {
      status: true,
      message: "Document saved successfully",
    };
  } catch (err) {
    return {
      status: false,
      message: "Unable to save document, please try again",
    };
  }
};

const is_document_exists = async (applicant_id) => {
  try {
    const document_exists_sql = `SELECT banking_doc_id FROM ${db_table.banking_document} WHERE applicant_Id = ?`;
    const document_exists_res = await mysqlquery(document_exists_sql, [
      applicant_id,
    ]);
    return document_exists_res;
  } catch (error) {
    res.status(400).json({
      msg: error.message ? error.message : error,
    });
  }
};

const insert_process = async (applicant_id, process_id) => {
  try {
    const sql = `SELECT process_status_id FROM ${db_table.process_status} WHERE applicant_Id = ? and process_id = ?`;
    const result = await mysqlquery(sql, [applicant_id, process_id]);
    if (result.length == 0) {
      const data = {
        applicant_id: applicant_id,
        process_id: process_id,
      };
      let insert_sql = `INSERT INTO ${db_table.process_status} SET ? `;
      await mysqlquery(insert_sql, data);
    }
  } catch (error) {
    res.status(400).json({
      msg: error.message ? error.message : error,
    });
  }
};

module.exports.minor_gaurdian_detail = async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      res.status(409).json({ errors: errors.array() });
    } else {
      let data = [];
      if (req.body.user_id != undefined && req.body.user_id != "") {
        let applicant_id = req.body.applicant_id;
        delete req.body.applicant_id;
        let process_id = req.body.process_id;
        delete req.body.process_id;
        let applicant_details = await get_applicant_details(applicant_id);
        req.body.applicant_serial_number = 2;
        if (applicant_details.length != 0) {
          data = [req.body, applicant_id];
          let sql = `UPDATE ${db_table.applicant_persional_details} SET ? WHERE applicant_personal_id = ?`;
          const result = await mysqlquery(sql, data);
          if (result.affectedRows > 0) {
            let process_data = {
              applicant_id: applicant_id,
              process_id: process_id,
            };
            await update_process_status(process_data);
            res.status(200).json({
              msg: "Updated successfully",
              applicant_id: applicant_id,
              applicant_serial_num: 2,
            });
          } else {
            res.status(400).json({
              msg: "bad request",
            });
          }
        } else {
          data = [req.body];
          let sql = `INSERT INTO ${db_table.applicant_persional_details} SET ?`;
          const result = await mysqlquery(sql, data);
          // for guardian process id  store 1 in db//
          const searchUser = `select applicant_personal_id from ${db_table.applicant_persional_details} where user_id = ?`;
          const searchResult = await mysqlquery(searchUser, [req.body.user_id]);
          const insert_status = `INSERT INTO tbl_process_status (applicant_id, process_id)  VALUES (?,?)`;
          await mysqlquery(insert_status, [
            searchResult[1].applicant_personal_id,
            1,
          ]);
          res.status(200).json({
            msg: "Inserted successfully",
            applicant_id: result.insertId,
            applicant_serial_num: 2,
          });
        }
      } else {
        res.status(400).json({
          msg: "bad request",
        });
      }
    }
  } catch (error) {
    res.status(400).json({
      msg: error.message ? error.message : error,
    });
  }
};
module.exports.fetch_minor_gaurdian_detail = async (req, res) => {
  try {
    if (req.body.applicant_id != undefined) {
      let applicant_id = req.body.applicant_id;
      var applicant_details = await get_applicant_details(applicant_id);
      data = [];
      if (applicant_details[0].applicant_serial_number == 2) {
        data = applicant_details;
      }
      console.log(data);
      res.status(200).json({
        msg: "Fetched successfully",
        data: data,
      });
    } else {
      if (req.body.user_id) {
        const minor_dob = `SELECT date_of_birth FROM ${db_table.applicant_persional_details} WHERE user_id = ? AND applicant_serial_number = ?`;
        const dob_result = await mysqlquery(minor_dob, [req.body.user_id, 1]);
        const min_dob = moment(dob_result[0].date_of_birth).format(
          "YYYY-MM-DD"
        );
        if (dob_result.length > 0) {
          res.status(200).json({
            minor_dob: min_dob,
          });
        }
      }
    }
  } catch (error) {
    res.status(400).json({
      msg: error.message ? error.message : error,
    });
  }
};
//fetch gurdian details

//fetch gurdian details
//guardian details

// Minor flow

module.exports.get_applicant_details = async (req, res) => {
  try {
    if (req.body.applicant_id != undefined) {
      var query = `select 
                p.applicant_personal_id,
                l.lead_status,
                l.lead_number
            from
                tbl_applicant_personal_details p
            inner join
                tbl_users u on p.user_id = u.user_id
            left join
                tbl_leads l on u.user_id = l.user_id
            where ?`;
      var result = await mysqlquery(query, {
        "p.applicant_personal_id": req.body.applicant_id,
      });
      if (result.length != 0) {
        res.status(200).json({
          msg: "Fetched successfully",
          data: result,
        });
      } else {
        res.status(400).json({
          msg: "Applicant did not found",
        });
      }
    }
  } catch (error) {
    res.status(400).json({
      msg: error.message ? error.message : error,
    });
  }
};

module.exports.fetch_joints_data = async (req, res) => {
  try {
    if (req.body.user_id) {
      const searchApplicant = `select applicant_title, applicant_first_name,applicant_middle_name,applicant_last_name from ${db_table.applicant_persional_details} where user_id = ? `;
      const result = await mysqlquery(searchApplicant, [req.body.user_id]);
      if (result[0].applicant_first_name == null) {
        const searchApplicant = `select title, first_name,middle_name,last_name from ${db_table.users} where user_id = ? `;
        const result = await mysqlquery(searchApplicant, [req.body.user_id]);
        const data = {
          applicant_title: result[0].title,
          applicant_first_name: result[0].first_name,
          applicant_middle_name: result[0].middle_name,
          applicant_last_name: result[0].last_name,
        };
        res.status(200).json({ message: "user fetch successfullly", data });
      } else {
        res.status(200).json({ message: "user fetch successfullly", result });
      }
    } else {
      res.json({ message: "data not found" });
    }
  } catch (error) {
    res.status(400).json({
      msg: error.message ? error.message : error,
    });
  }
};

get_customer_forms_comments_approved = async (
  applicant_id,
  lead_id,
  process_id
) => {
  try {
    let get_approved_sql = `SELECT * FROM ${db_table.process_status} WHERE applicant_id=? and process_id=?`;
    const approved_result = await mysqlquery(get_approved_sql, [
      applicant_id,
      process_id,
    ]);
    var approved_data = approved_result[0]?.agent_status;
    if (approved_data == "approved") {
      let form_result = "approved by agent";
      return form_result;
    } else {
      let get_comments_sql = `SELECT * FROM ${db_table.comment} WHERE applicant_id=? and lead_id=? and process_id=?`;
      const comments_details = await mysqlquery(get_comments_sql, [
        applicant_id,
        lead_id,
        process_id,
      ]);
      comments_details.forEach((application) => {
        let process_id = application.process_id;
        var process_data_id = customer_forms;
        var customer_process = process_data_id.find(
          (item) => item.process_id === process_id
        );
        var process_type = customer_process.form_name;
        application["process_name"] = process_type;
      });
      return comments_details;
    }
  } catch (error) {
    res.status(400).json({
      msg: error.message ? error.message : error,
    });
  }
};

// module.exports.get_applicant_data = async (req,res) =>{
// try {
//     const sql = `select applicant_title , applicant_first_name , applicant_middle_name ,applicant_last_name from ${db_table.applicant_persional_details} where applicant_personal_id = ? `
//     const result = await mysqlquery(sql,[req.body.applicant_id])
//     if(result.length > 0){
//     res.status(200).json({message:"user fetch successfullly",result})
//     }
// } catch (error) {
//     res.status(400).json({
//         msg: error.message ? error.message : error
//     })
// }
// }

module.exports.get_applicant_name = async (req, res) => {
  try {
    const sql = `select CONCAT(applicant_first_name,' ',applicant_last_name) as applicant_name from ${db_table.applicant_persional_details} where user_id = ? `;
    const result = await mysqlquery(sql, [req.body.user_id]);
    arr = [];
    const mainresult = result[0];
    arr.push(mainresult);
    if (result.length > 0) {
      res
        .status(200)
        .json({ message: "user fetch successfullly", result: arr });
    } else {
      res.status(400).json({ message: "user not found" });
    }
  } catch (error) {
    res.status(400).json({
      msg: error.message ? error.message : error,
    });
  }
};

module.exports.get_address_proof_type = async (req, res) => {
  try {
    const applicant_id = req.body.applicant_id;
    const address_proof = `SELECT address_proof_type_id  FROM ${db_table.banking_document} WHERE applicant_id = ?`;
    const add_result = await mysqlquery(address_proof, applicant_id);
    if (add_result.length > 0) {
      res.status(200).json({
        data: add_result,
      });
    } else {
      res.status(400).json({
        message: "address_proof not fetch",
      });
    }
  } catch (error) {
    res.status(400).json({
      msg: error.message ? error.message : error,
    });
  }
};
module.exports.get_user_serial_no = async (req, res) => {
  try {
    const data = {
      applicant_id: "",
      serial_no: "",
    };
    const applicant_id = req.body.applicant_id;
    const sql =
      "SELECT user_id FROM `tbl_applicant_personal_details` WHERE  applicant_personal_id = ? ";
    const result = await mysqlquery(sql, applicant_id);

    if (result.length > 0) {
      const userId = result[0].user_id;
      const sql1 =
        "SELECT applicant_personal_id,applicant_serial_number FROM `tbl_applicant_personal_details` WHERE  user_id = ? AND applicant_personal_id < ? ORDER BY applicant_personal_id DESC LIMIT 1 ";
      const userResult = await mysqlquery(sql1, [userId, applicant_id]);
      data["applicant_id"] =
        userResult.length > 0 ? userResult[0].applicant_personal_id : "";
      data["serial_no"] =
        userResult.length > 0 ? userResult[0].applicant_serial_number : "";
    }
    res.status(200).json(data);
  } catch (error) {
    res.status(400).json({
      msg: error.message ? error.message : error,
    });
  }
};
