var mysqlconn = require('../../../../../db/mysqlconn');
const query = require('../../../../../db/query.json')
const util = require('util');
const excel = require("exceljs");
var PDFDocument = require("pdfkit");
const path = require("path");
var fs = require("fs");
var pdf = require('html-pdf');
const mysqlquery = util.promisify(mysqlconn.query).bind(mysqlconn);


countRBlagent = async (req, res) => {
  try {
    const countRBlagent = await mysqlquery(query.select.countRBlagent, ['agent']);
    res.status(200).json({
      msg: countRBlagent
    })
  } catch (error) {
    res.status(400).json({
      msg: error
    })

  }
}


countRblitteamuser = async (req, res) => {
  try {
    const countRblitteamuser = await mysqlquery(query.select.countRblitteamuser, ['rblitteamuser']);
    res.status(200).json({
      msg: countRblitteamuser
    })
  } catch (error) {
    res.status(400).json({
      msg: error
    })

  }
}

allRblagent = async (req, res) => {
  try {
    const allagent = await mysqlquery(query.select.allagent, ['agent']);
    res.status(200).json({
      msg: allagent
    })
  } catch (error) {
    res.status(400).json({
      msg: error
    })

  }
}

allRblitteamuser = async (req, res) => {
  try {
    const allRblitteamuser = await mysqlquery(query.select.allRblitteamuser, ['rblitteamuser']);
    res.status(200).json({
      msg: allRblitteamuser
    })
  } catch (error) {
    res.status(400).json({
      msg: error
    })

  }
}


// all_newleads = async (req, res) => {
//   try {
//     const newlead = await mysqlquery(query.select.getall_newleads, ["new"]);
//     let workbook = new excel.Workbook();
//     let worksheet = workbook.addWorksheet("newlead");
//     const result = JSON.parse(JSON.stringify(newlead));
//     let arr_data = [];
//     result.forEach((element) => {
//       arr_data.push(Object.values(element));
//     });

//     let arr_datas = JSON.parse(JSON.stringify(arr_data));
//     if (arr_data.length == 0) {

//       arr_datas = [arr_datas]
//     }

//     worksheet.addTable({
//       name: 'MyTable',
//       ref: 'A1',
//       headerRow: true,
//       totalsRow: true,
//       style: {
//         theme: 'TableStyleDark10',
//         showRowStripes: true,
//       },
//       columns: [
//         { name: 'lead_Reference_no', totalsRowLabel: 'Total-new-leads =', filterButton: true, },
//         { name: 'account_type', totalsRowFunction: 'count', filterButton: true, },
//         { name: 'customer_title', filterButton: true, },
//         { name: 'firstname', filterButton: true, width: 30 },
//         { name: 'middlename', filterButton: true, width: 30 },
//         { name: 'lastname', filterButton: true, width: 30 },
//         { name: 'material_status', filterButton: true, width: 30 },
//         { name: 'addhar_no', filterButton: true, width: 30 },
//         { name: 'religion_name', filterButton: true, width: 30 },
//         { name: 'other_religion', filterButton: true, width: 30 },
//         { name: 'category_name', filterButton: true, width: 30 },
//         { name: 'other_category', filterButton: true, width: 30 },
//         { name: 'aadhar_KYC_dtls', filterButton: true, width: 30 },
//         { name: 'politically_exposed', filterButton: true, width: 30 },
//         { name: 'maiden_title', filterButton: true, width: 30 },
//         { name: 'maiden_firstname', filterButton: true, width: 30 },
//         { name: 'maiden_middlename', filterButton: true, width: 30 },
//         { name: 'maiden_lastname', filterButton: true, width: 30 },
//         { name: 'mothers_title', filterButton: true, width: 30 },
//         { name: 'mothers_firstname', filterButton: true, width: 30 },
//         { name: 'mothers_middlename', filterButton: true, width: 30 },
//         { name: 'mothers_lastname', filterButton: true, width: 30 },
//         { name: 'dob', filterButton: true, width: 30 },
//         { name: 'gender', filterButton: true, width: 30 },
//         { name: 'nationality', filterButton: true, width: 30 },
//         { name: 'date_of_becoming_nri', filterButton: true, width: 30 },
//         { name: 'father_or_spouseoptn', filterButton: true, width: 30 },
//         { name: 'farther_or_spouce_title', filterButton: true, width: 30 },
//         { name: 'farther_or_spouce_firstname', filterButton: true, width: 30 },
//         { name: 'farther_or_spouce_middlename', filterButton: true, width: 30 },
//         { name: 'farther_or_spouce_lastname', filterButton: true, width: 30 },
//         { name: 'facta_dec', filterButton: true, width: 30 },
//         { name: 'tin_no', filterButton: true, width: 30 },
//         { name: 'tin_discription', filterButton: true, width: 30 },
//         { name: 'country_taxjusidtn', filterButton: true, width: 30 },
//         { name: 'tin_Issue_country', filterButton: true, width: 30 },
//         { name: 'city_of_birth', filterButton: true, width: 30 },
//         { name: 'country_of_birth', filterButton: true, width: 30 },
//         { name: 'passport', filterButton: true, width: 30 },
//         { name: 'passport_no', filterButton: true, width: 30 },
//         { name: 'passport_issue_date', filterButton: true, width: 30 },
//         { name: 'passport_expiry_date', filterButton: true, width: 30 },
//         { name: 'passport_issue_authority', filterButton: true, width: 30 },
//         { name: 'passport_place_of_issue', filterButton: true, width: 30 },
//         { name: 'visa_type_name', filterButton: true, width: 30 },
//         { name: 'visa_expiry', filterButton: true, width: 30 },
//         { name: 'pan_cardno', filterButton: true, width: 30 },
//         { name: 'address_proof', filterButton: true, width: 30 },
//         { name: 'address_prof_file', filterButton: true, width: 30 },
//         { name: 'address_prof_authority', filterButton: true, width: 30 },
//         { name: 'address_prof_doc_type', filterButton: true, width: 30 },
//         { name: 'address_prof_place_Issue', filterButton: true, width: 30 },
//         { name: 'address_prof_doc_no', filterButton: true, width: 30 },
//         { name: 'address_prof_doc_issuedate', filterButton: true, width: 30 },
//         { name: 'address_prof_doc_expirydate', filterButton: true, width: 30 },
//         { name: 'temporary_visa_chk', filterButton: true, width: 30 },
//         { name: 'temp_dec_visa_issuedate', filterButton: true, width: 30 },
//         { name: 'temp_dec_visa_expirydate', filterButton: true, width: 30 },
//         { name: 'temp_furnish_threemonth_visachk', filterButton: true, width: 30 },
//         { name: 'office_cntry_code', filterButton: true, width: 30 },
//         { name: 'office_std_code', filterButton: true, width: 30 },
//         { name: 'office_tel_code', filterButton: true, width: 30 },
//         { name: 'residence_cntry_code', filterButton: true, width: 30 },
//         { name: 'residence_std_code', filterButton: true, width: 30 },
//         { name: 'residence_tel_code', filterButton: true, width: 30 },
//         { name: 'mob_cntry_code', filterButton: true, width: 30 },
//         { name: 'mob_std_code', filterButton: true, width: 30 },
//         { name: 'mob_tel_code', filterButton: true, width: 30 },
//         { name: 'fax_cntry_code', filterButton: true, width: 30 },
//         { name: 'fax_std_code', filterButton: true, width: 30 },
//         { name: 'fax_tel_code', filterButton: true, width: 30 },
//         { name: 'email', filterButton: true, width: 30 },
//         { name: 'same_address_ovd', filterButton: true, width: 30 },
//         { name: 'deemed_ovd_dll', filterButton: true, width: 30 },
//         { name: 'overseas_address_type', filterButton: true, width: 30 },
//         { name: 'overseas_address_house_no', filterButton: true, width: 30 },
//         { name: 'overseas_address_house_name', filterButton: true, width: 30 },
//         { name: 'overseas_address_house_road', filterButton: true, width: 30 },
//         { name: 'overseas_address_house_landmark', filterButton: true, width: 30 },
//         { name: 'overseas_address_state', filterButton: true, width: 30 },
//         { name: 'overseas_address_city', filterButton: true, width: 30 },
//         { name: 'overseas_address_country', filterButton: true, width: 30 },
//         { name: 'overseas_address_pin', filterButton: true, width: 30 },
//         { name: 'permanent_address_type', filterButton: true, width: 30 },
//         { name: 'permanent_address_house_no', filterButton: true, width: 30 },
//         { name: 'permanent_address_house_name', filterButton: true, width: 30 },
//         { name: 'permanent_address_house_road', filterButton: true, width: 30 },
//         { name: 'permanent_address_house_landmark', filterButton: true, width: 30 },
//         { name: 'permanent_address_state', filterButton: true, width: 30 },
//         { name: 'permanent_address_city', filterButton: true, width: 30 },
//         { name: 'permanent_address_country', filterButton: true, width: 30 },
//         { name: 'permanent_address_pin', filterButton: true, width: 30 },
//         { name: 'mailing_sameperm_or_overseas', filterButton: true, width: 30 },
//         { name: 'mailing_address_type', filterButton: true, width: 30 },
//         { name: 'mailing_address_house_no', filterButton: true, width: 30 },
//         { name: 'mailing_address_house_name', filterButton: true, width: 30 },
//         { name: 'mailing_address_house_road', filterButton: true, width: 30 },
//         { name: 'mailing_address_house_landmark', filterButton: true, width: 30 },
//         { name: 'mailing_address_state', filterButton: true, width: 30 },
//         { name: 'mailing_address_city', filterButton: true, width: 30 },
//         { name: 'mailing_address_country', filterButton: true, width: 30 },
//         { name: 'mailing_address_pin', filterButton: true, width: 30 },
//         { name: 'jurisdiction_address_type', filterButton: true, width: 30 },
//         { name: 'jurisdiction_address_house_no', filterButton: true, width: 30 },
//         { name: 'jurisdiction_address_house_name', filterButton: true, width: 30 },
//         { name: 'jurisdiction_address_house_road', filterButton: true, width: 30 },
//         { name: 'jurisdiction_address_house_landmark', filterButton: true, width: 30 },
//         { name: 'jurisdiction_address_state', filterButton: true, width: 30 },
//         { name: 'jurisdiction_address_city', filterButton: true, width: 30 },
//         { name: 'jurisdiction_address_country', filterButton: true, width: 30 },
//         { name: 'jurisdiction_address_pin', filterButton: true, width: 30 },
//         { name: 'educational_qualification', filterButton: true, width: 30 },
//         { name: 'employment_type', filterButton: true, width: 30 },
//         { name: 'occupation_type', filterButton: true, width: 30 },
//         { name: 'income_source_type', filterButton: true, width: 30 },
//         { name: 'gross_annual_income_type', filterButton: true, width: 30 },
//         { name: 'industry_type', filterButton: true, width: 30 },
//         { name: 'banking_type', filterButton: true, width: 30 },
//         { name: 'debit_card_type', filterButton: true, width: 30 },
//         { name: 'debit_card_variant_type', filterButton: true, width: 30 },
//         { name: 'cnp', filterButton: true, width: 30 },
//         { name: 'contactless_transactions', filterButton: true, width: 30 },
//         { name: 'nomination_chk', filterButton: true, width: 30 },
//         { name: 'relationship_nominee', filterButton: true, width: 30 },
//         { name: 'dob_nominee', filterButton: true, width: 30 },
//         { name: 'age_nominee', filterButton: true, width: 30 },
//         { name: 'nominee_guardian_title', filterButton: true, width: 30 },
//         { name: 'nominee_guardian_firstname', filterButton: true, width: 30 },
//         { name: 'nominee_guardian_middlename', filterButton: true, width: 30 },
//         { name: 'nominee_guardian_lastname', filterButton: true, width: 30 },
//         { name: 'consent_chk', filterButton: true, width: 30 },
//         { name: 'lead_status', filterButton: true, width: 30 },
//         { name: 'poi_dec_id', filterButton: true, width: 30 },
//         { name: 'nomination_facility', filterButton: true, width: 30 },
//         { name: 'temporary_visa_dec_chk1_text', filterButton: true, width: 30 },
//         { name: 'temporary_visa_dec_chk2_text', filterButton: true, width: 30 },
//         { name: 'created_at', filterButton: true, width: 30 },
//         { name: 'is_active', filterButton: true, width: 30 },
//         { name: 'agent_fullname', filterButton: true, width: 30 },
//         { name: 'customer_fullname', filterButton: true, width: 30 },
//         { name: 'customer_email', filterButton: true, width: 30 }
//       ],

//       rows: arr_datas,
//     });

//     for (const row of newlead) {
//       worksheet.addRow(row);
//     }
//     worksheet.autoFilter = 'A1:D1';
//     worksheet.eachRow({ includeEmpty: true }, (row, rowNumber) => {

//       row.eachCell({ includeEmpty: true }, (cell, colNumber) => {
//         if (rowNumber == 1) {
//           cell.fill = {
//             type: 'pattern',
//             pattern: 'solid',
//             fgColor: { argb: 'f5b914' }
//           };
//         };
//         cell.border = {
//           top: { style: 'thin' },
//           left: { style: 'thin' },
//           bottom: { style: 'thin' },
//           right: { style: 'thin' }
//         };
//       })
//       row.commit();
//     });


//     for (let i = 0; i < worksheet?.columns.length; i += 1) {
//       let dataMax = 0;
//       const column = worksheet?.columns[i];
//       for (let j = 1; j < column?.values.length; j += 1) {
//         const columnLength = column.values[j]?.length;
//         if (columnLength > dataMax) {
//           dataMax = columnLength;
//         }
//       }
//       column.width = dataMax < 15 ? 15 : dataMax;
//     }
//     res.setHeader(
//       "Content-Type",
//       "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
//     );
//     res.setHeader(
//       "Content-Disposition",
//       "attachment; filename=" + `newleads_${Date.now()}.xlsx`
//     );

//     return workbook.xlsx.write(res).then(function () {
//       res.status(200).end();
//     });
//   } catch (error) {
//     res.status(400).json({
//       msg: error
//     })

//   }
// }



// all_processleads = async (req, res) => {
//   try {
//     const getall_processlead = await mysqlquery(query.select.all_processlead, ["process"]);
//     let workbook = new excel.Workbook();
//     let worksheet = workbook.addWorksheet("getall_processlead");
//     const result = JSON.parse(JSON.stringify(getall_processlead));
//     let arr_data = [];
//     result.forEach((element) => {
//       arr_data.push(Object.values(element));
//     });

//     let arr_datas = JSON.parse(JSON.stringify(arr_data));
//     if (arr_data.length == 0) {

//       arr_datas = [arr_datas]
//     }

//     worksheet.addTable({
//       name: 'MyTable',
//       ref: 'A1',
//       headerRow: true,
//       totalsRow: true,
//       style: {
//         theme: 'TableStyleDark10',
//         showRowStripes: true,
//       },
//       columns: [
//         { name: 'lead_Reference_no', totalsRowLabel: 'Total-process-leads =', filterButton: true, },
//         { name: 'account_type', totalsRowFunction: 'count', filterButton: true, },
//         { name: 'customer_title', filterButton: true, },
//         { name: 'firstname', filterButton: true, width: 30 },
//         { name: 'middlename', filterButton: true, width: 30 },
//         { name: 'lastname', filterButton: true, width: 30 },
//         { name: 'material_status', filterButton: true, width: 30 },
//         { name: 'addhar_no', filterButton: true, width: 30 },
//         { name: 'religion_name', filterButton: true, width: 30 },
//         { name: 'other_religion', filterButton: true, width: 30 },
//         { name: 'category_name', filterButton: true, width: 30 },
//         { name: 'other_category', filterButton: true, width: 30 },
//         { name: 'aadhar_KYC_dtls', filterButton: true, width: 30 },
//         { name: 'politically_exposed', filterButton: true, width: 30 },
//         { name: 'maiden_title', filterButton: true, width: 30 },
//         { name: 'maiden_firstname', filterButton: true, width: 30 },
//         { name: 'maiden_middlename', filterButton: true, width: 30 },
//         { name: 'maiden_lastname', filterButton: true, width: 30 },
//         { name: 'mothers_title', filterButton: true, width: 30 },
//         { name: 'mothers_firstname', filterButton: true, width: 30 },
//         { name: 'mothers_middlename', filterButton: true, width: 30 },
//         { name: 'mothers_lastname', filterButton: true, width: 30 },
//         { name: 'dob', filterButton: true, width: 30 },
//         { name: 'gender', filterButton: true, width: 30 },
//         { name: 'nationality', filterButton: true, width: 30 },
//         { name: 'date_of_becoming_nri', filterButton: true, width: 30 },
//         { name: 'father_or_spouseoptn', filterButton: true, width: 30 },
//         { name: 'farther_or_spouce_title', filterButton: true, width: 30 },
//         { name: 'farther_or_spouce_firstname', filterButton: true, width: 30 },
//         { name: 'farther_or_spouce_middlename', filterButton: true, width: 30 },
//         { name: 'farther_or_spouce_lastname', filterButton: true, width: 30 },
//         { name: 'facta_dec', filterButton: true, width: 30 },
//         { name: 'tin_no', filterButton: true, width: 30 },
//         { name: 'tin_discription', filterButton: true, width: 30 },
//         { name: 'country_taxjusidtn', filterButton: true, width: 30 },
//         { name: 'tin_Issue_country', filterButton: true, width: 30 },
//         { name: 'city_of_birth', filterButton: true, width: 30 },
//         { name: 'country_of_birth', filterButton: true, width: 30 },
//         { name: 'passport', filterButton: true, width: 30 },
//         { name: 'passport_no', filterButton: true, width: 30 },
//         { name: 'passport_issue_date', filterButton: true, width: 30 },
//         { name: 'passport_expiry_date', filterButton: true, width: 30 },
//         { name: 'passport_issue_authority', filterButton: true, width: 30 },
//         { name: 'passport_place_of_issue', filterButton: true, width: 30 },
//         { name: 'visa_type_name', filterButton: true, width: 30 },
//         { name: 'visa_expiry', filterButton: true, width: 30 },
//         { name: 'pan_cardno', filterButton: true, width: 30 },
//         { name: 'address_proof', filterButton: true, width: 30 },
//         { name: 'address_prof_file', filterButton: true, width: 30 },
//         { name: 'address_prof_authority', filterButton: true, width: 30 },
//         { name: 'address_prof_doc_type', filterButton: true, width: 30 },
//         { name: 'address_prof_place_Issue', filterButton: true, width: 30 },
//         { name: 'address_prof_doc_no', filterButton: true, width: 30 },
//         { name: 'address_prof_doc_issuedate', filterButton: true, width: 30 },
//         { name: 'address_prof_doc_expirydate', filterButton: true, width: 30 },
//         { name: 'temporary_visa_chk', filterButton: true, width: 30 },
//         { name: 'temp_dec_visa_issuedate', filterButton: true, width: 30 },
//         { name: 'temp_dec_visa_expirydate', filterButton: true, width: 30 },
//         { name: 'temp_furnish_threemonth_visachk', filterButton: true, width: 30 },
//         { name: 'office_cntry_code', filterButton: true, width: 30 },
//         { name: 'office_std_code', filterButton: true, width: 30 },
//         { name: 'office_tel_code', filterButton: true, width: 30 },
//         { name: 'residence_cntry_code', filterButton: true, width: 30 },
//         { name: 'residence_std_code', filterButton: true, width: 30 },
//         { name: 'residence_tel_code', filterButton: true, width: 30 },
//         { name: 'mob_cntry_code', filterButton: true, width: 30 },
//         { name: 'mob_std_code', filterButton: true, width: 30 },
//         { name: 'mob_tel_code', filterButton: true, width: 30 },
//         { name: 'fax_cntry_code', filterButton: true, width: 30 },
//         { name: 'fax_std_code', filterButton: true, width: 30 },
//         { name: 'fax_tel_code', filterButton: true, width: 30 },
//         { name: 'email', filterButton: true, width: 30 },
//         { name: 'same_address_ovd', filterButton: true, width: 30 },
//         { name: 'deemed_ovd_dll', filterButton: true, width: 30 },
//         { name: 'overseas_address_type', filterButton: true, width: 30 },
//         { name: 'overseas_address_house_no', filterButton: true, width: 30 },
//         { name: 'overseas_address_house_name', filterButton: true, width: 30 },
//         { name: 'overseas_address_house_road', filterButton: true, width: 30 },
//         { name: 'overseas_address_house_landmark', filterButton: true, width: 30 },
//         { name: 'overseas_address_state', filterButton: true, width: 30 },
//         { name: 'overseas_address_city', filterButton: true, width: 30 },
//         { name: 'overseas_address_country', filterButton: true, width: 30 },
//         { name: 'overseas_address_pin', filterButton: true, width: 30 },
//         { name: 'permanent_address_type', filterButton: true, width: 30 },
//         { name: 'permanent_address_house_no', filterButton: true, width: 30 },
//         { name: 'permanent_address_house_name', filterButton: true, width: 30 },
//         { name: 'permanent_address_house_road', filterButton: true, width: 30 },
//         { name: 'permanent_address_house_landmark', filterButton: true, width: 30 },
//         { name: 'permanent_address_state', filterButton: true, width: 30 },
//         { name: 'permanent_address_city', filterButton: true, width: 30 },
//         { name: 'permanent_address_country', filterButton: true, width: 30 },
//         { name: 'permanent_address_pin', filterButton: true, width: 30 },
//         { name: 'mailing_sameperm_or_overseas', filterButton: true, width: 30 },
//         { name: 'mailing_address_type', filterButton: true, width: 30 },
//         { name: 'mailing_address_house_no', filterButton: true, width: 30 },
//         { name: 'mailing_address_house_name', filterButton: true, width: 30 },
//         { name: 'mailing_address_house_road', filterButton: true, width: 30 },
//         { name: 'mailing_address_house_landmark', filterButton: true, width: 30 },
//         { name: 'mailing_address_state', filterButton: true, width: 30 },
//         { name: 'mailing_address_city', filterButton: true, width: 30 },
//         { name: 'mailing_address_country', filterButton: true, width: 30 },
//         { name: 'mailing_address_pin', filterButton: true, width: 30 },
//         { name: 'jurisdiction_address_type', filterButton: true, width: 30 },
//         { name: 'jurisdiction_address_house_no', filterButton: true, width: 30 },
//         { name: 'jurisdiction_address_house_name', filterButton: true, width: 30 },
//         { name: 'jurisdiction_address_house_road', filterButton: true, width: 30 },
//         { name: 'jurisdiction_address_house_landmark', filterButton: true, width: 30 },
//         { name: 'jurisdiction_address_state', filterButton: true, width: 30 },
//         { name: 'jurisdiction_address_city', filterButton: true, width: 30 },
//         { name: 'jurisdiction_address_country', filterButton: true, width: 30 },
//         { name: 'jurisdiction_address_pin', filterButton: true, width: 30 },
//         { name: 'educational_qualification', filterButton: true, width: 30 },
//         { name: 'employment_type', filterButton: true, width: 30 },
//         { name: 'occupation_type', filterButton: true, width: 30 },
//         { name: 'income_source_type', filterButton: true, width: 30 },
//         { name: 'gross_annual_income_type', filterButton: true, width: 30 },
//         { name: 'industry_type', filterButton: true, width: 30 },
//         { name: 'banking_type', filterButton: true, width: 30 },
//         { name: 'debit_card_type', filterButton: true, width: 30 },
//         { name: 'debit_card_variant_type', filterButton: true, width: 30 },
//         { name: 'cnp', filterButton: true, width: 30 },
//         { name: 'contactless_transactions', filterButton: true, width: 30 },
//         { name: 'nomination_chk', filterButton: true, width: 30 },
//         { name: 'relationship_nominee', filterButton: true, width: 30 },
//         { name: 'dob_nominee', filterButton: true, width: 30 },
//         { name: 'age_nominee', filterButton: true, width: 30 },
//         { name: 'nominee_guardian_title', filterButton: true, width: 30 },
//         { name: 'nominee_guardian_firstname', filterButton: true, width: 30 },
//         { name: 'nominee_guardian_middlename', filterButton: true, width: 30 },
//         { name: 'nominee_guardian_lastname', filterButton: true, width: 30 },
//         { name: 'consent_chk', filterButton: true, width: 30 },
//         { name: 'lead_status', filterButton: true, width: 30 },
//         { name: 'poi_dec_id', filterButton: true, width: 30 },
//         { name: 'nomination_facility', filterButton: true, width: 30 },
//         { name: 'temporary_visa_dec_chk1_text', filterButton: true, width: 30 },
//         { name: 'temporary_visa_dec_chk2_text', filterButton: true, width: 30 },
//         { name: 'created_at', filterButton: true, width: 30 },
//         { name: 'is_active', filterButton: true, width: 30 },
//         { name: 'agent_fullname', filterButton: true, width: 30 },
//         { name: 'customer_fullname', filterButton: true, width: 30 },
//         { name: 'customer_email', filterButton: true, width: 30 }
//       ],
//       rows: arr_datas,
//     });


//     for (const row of getall_processlead) {
//       worksheet.addRow(row);
//     }

//     worksheet.autoFilter = 'A1:D1';

//     worksheet.eachRow({ includeEmpty: true }, (row, rowNumber) => {

//       row.eachCell({ includeEmpty: true }, (cell, colNumber) => {
//         if (rowNumber == 1) {
//           cell.fill = {
//             type: 'pattern',
//             pattern: 'solid',
//             fgColor: { argb: 'f5b914' }
//           };
//         };
//         cell.border = {
//           top: { style: 'thin' },
//           left: { style: 'thin' },
//           bottom: { style: 'thin' },
//           right: { style: 'thin' }
//         };
//       })
//       row.commit();
//     });


//     for (let i = 0; i < worksheet?.columns.length; i += 1) {
//       let dataMax = 0;
//       const column = worksheet?.columns[i];
//       for (let j = 1; j < column?.values.length; j += 1) {
//         const columnLength = column.values[j]?.length;
//         if (columnLength > dataMax) {
//           dataMax = columnLength;
//         }
//       }
//       column.width = dataMax < 15 ? 15 : dataMax;
//     }
//     res.setHeader(
//       "Content-Type",
//       "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
//     );
//     res.setHeader(
//       "Content-Disposition",
//       "attachment; filename=" + `processleads_${Date.now()}.xlsx`
//     );

//     return workbook.xlsx.write(res).then(function () {
//       res.status(200).end();
//     });
//   } catch (error) {
//     res.status(400).json({
//       msg: error
//     })

//   }
// }


// all_approvedleads = async (req, res) => {
//   try {
//     const getall_approvedleads = await mysqlquery(query.select.all_approvedleads, ['approved']);
//     let workbook = new excel.Workbook();
//     let worksheet = workbook.addWorksheet("getall_approvedleads");
//     const result = JSON.parse(JSON.stringify(getall_approvedleads));
//     let arr_data = [];
//     result.forEach((element) => {
//       arr_data.push(Object.values(element));
//     });

//     let arr_datas = JSON.parse(JSON.stringify(arr_data));
//     if (arr_data.length == 0) {

//       arr_datas = [arr_datas]
//     }

//     worksheet.addTable({
//       name: 'MyTable',
//       ref: 'A1',
//       headerRow: true,
//       totalsRow: true,
//       style: {
//         theme: 'TableStyleDark9',
//         showRowStripes: true,
//       },
//       columns: [
//         { name: 'lead_Reference_no', totalsRowLabel: 'Total-approved-leads =', filterButton: true, },
//         { name: 'account_type', totalsRowFunction: 'count', filterButton: true, },
//         { name: 'customer_title', filterButton: true, },
//         { name: 'firstname', filterButton: true, width: 30 },
//         { name: 'middlename', filterButton: true, width: 30 },
//         { name: 'lastname', filterButton: true, width: 30 },
//         { name: 'material_status', filterButton: true, width: 30 },
//         { name: 'addhar_no', filterButton: true, width: 30 },
//         { name: 'religion_name', filterButton: true, width: 30 },
//         { name: 'other_religion', filterButton: true, width: 30 },
//         { name: 'category_name', filterButton: true, width: 30 },
//         { name: 'other_category', filterButton: true, width: 30 },
//         { name: 'aadhar_KYC_dtls', filterButton: true, width: 30 },
//         { name: 'politically_exposed', filterButton: true, width: 30 },
//         { name: 'maiden_title', filterButton: true, width: 30 },
//         { name: 'maiden_firstname', filterButton: true, width: 30 },
//         { name: 'maiden_middlename', filterButton: true, width: 30 },
//         { name: 'maiden_lastname', filterButton: true, width: 30 },
//         { name: 'mothers_title', filterButton: true, width: 30 },
//         { name: 'mothers_firstname', filterButton: true, width: 30 },
//         { name: 'mothers_middlename', filterButton: true, width: 30 },
//         { name: 'mothers_lastname', filterButton: true, width: 30 },
//         { name: 'dob', filterButton: true, width: 30 },
//         { name: 'gender', filterButton: true, width: 30 },
//         { name: 'nationality', filterButton: true, width: 30 },
//         { name: 'date_of_becoming_nri', filterButton: true, width: 30 },
//         { name: 'father_or_spouseoptn', filterButton: true, width: 30 },
//         { name: 'farther_or_spouce_title', filterButton: true, width: 30 },
//         { name: 'farther_or_spouce_firstname', filterButton: true, width: 30 },
//         { name: 'farther_or_spouce_middlename', filterButton: true, width: 30 },
//         { name: 'farther_or_spouce_lastname', filterButton: true, width: 30 },
//         { name: 'facta_dec', filterButton: true, width: 30 },
//         { name: 'tin_no', filterButton: true, width: 30 },
//         { name: 'tin_discription', filterButton: true, width: 30 },
//         { name: 'country_taxjusidtn', filterButton: true, width: 30 },
//         { name: 'tin_Issue_country', filterButton: true, width: 30 },
//         { name: 'city_of_birth', filterButton: true, width: 30 },
//         { name: 'country_of_birth', filterButton: true, width: 30 },
//         { name: 'passport', filterButton: true, width: 30 },
//         { name: 'passport_no', filterButton: true, width: 30 },
//         { name: 'passport_issue_date', filterButton: true, width: 30 },
//         { name: 'passport_expiry_date', filterButton: true, width: 30 },
//         { name: 'passport_issue_authority', filterButton: true, width: 30 },
//         { name: 'passport_place_of_issue', filterButton: true, width: 30 },
//         { name: 'visa_type_name', filterButton: true, width: 30 },
//         { name: 'visa_expiry', filterButton: true, width: 30 },
//         { name: 'pan_cardno', filterButton: true, width: 30 },
//         { name: 'address_proof', filterButton: true, width: 30 },
//         { name: 'address_prof_file', filterButton: true, width: 30 },
//         { name: 'address_prof_authority', filterButton: true, width: 30 },
//         { name: 'address_prof_doc_type', filterButton: true, width: 30 },
//         { name: 'address_prof_place_Issue', filterButton: true, width: 30 },
//         { name: 'address_prof_doc_no', filterButton: true, width: 30 },
//         { name: 'address_prof_doc_issuedate', filterButton: true, width: 30 },
//         { name: 'address_prof_doc_expirydate', filterButton: true, width: 30 },
//         { name: 'temporary_visa_chk', filterButton: true, width: 30 },
//         { name: 'temp_dec_visa_issuedate', filterButton: true, width: 30 },
//         { name: 'temp_dec_visa_expirydate', filterButton: true, width: 30 },
//         { name: 'temp_furnish_threemonth_visachk', filterButton: true, width: 30 },
//         { name: 'office_cntry_code', filterButton: true, width: 30 },
//         { name: 'office_std_code', filterButton: true, width: 30 },
//         { name: 'office_tel_code', filterButton: true, width: 30 },
//         { name: 'residence_cntry_code', filterButton: true, width: 30 },
//         { name: 'residence_std_code', filterButton: true, width: 30 },
//         { name: 'residence_tel_code', filterButton: true, width: 30 },
//         { name: 'mob_cntry_code', filterButton: true, width: 30 },
//         { name: 'mob_std_code', filterButton: true, width: 30 },
//         { name: 'mob_tel_code', filterButton: true, width: 30 },
//         { name: 'fax_cntry_code', filterButton: true, width: 30 },
//         { name: 'fax_std_code', filterButton: true, width: 30 },
//         { name: 'fax_tel_code', filterButton: true, width: 30 },
//         { name: 'email', filterButton: true, width: 30 },
//         { name: 'same_address_ovd', filterButton: true, width: 30 },
//         { name: 'deemed_ovd_dll', filterButton: true, width: 30 },
//         { name: 'overseas_address_type', filterButton: true, width: 30 },
//         { name: 'overseas_address_house_no', filterButton: true, width: 30 },
//         { name: 'overseas_address_house_name', filterButton: true, width: 30 },
//         { name: 'overseas_address_house_road', filterButton: true, width: 30 },
//         { name: 'overseas_address_house_landmark', filterButton: true, width: 30 },
//         { name: 'overseas_address_state', filterButton: true, width: 30 },
//         { name: 'overseas_address_city', filterButton: true, width: 30 },
//         { name: 'overseas_address_country', filterButton: true, width: 30 },
//         { name: 'overseas_address_pin', filterButton: true, width: 30 },
//         { name: 'permanent_address_type', filterButton: true, width: 30 },
//         { name: 'permanent_address_house_no', filterButton: true, width: 30 },
//         { name: 'permanent_address_house_name', filterButton: true, width: 30 },
//         { name: 'permanent_address_house_road', filterButton: true, width: 30 },
//         { name: 'permanent_address_house_landmark', filterButton: true, width: 30 },
//         { name: 'permanent_address_state', filterButton: true, width: 30 },
//         { name: 'permanent_address_city', filterButton: true, width: 30 },
//         { name: 'permanent_address_country', filterButton: true, width: 30 },
//         { name: 'permanent_address_pin', filterButton: true, width: 30 },
//         { name: 'mailing_sameperm_or_overseas', filterButton: true, width: 30 },
//         { name: 'mailing_address_type', filterButton: true, width: 30 },
//         { name: 'mailing_address_house_no', filterButton: true, width: 30 },
//         { name: 'mailing_address_house_name', filterButton: true, width: 30 },
//         { name: 'mailing_address_house_road', filterButton: true, width: 30 },
//         { name: 'mailing_address_house_landmark', filterButton: true, width: 30 },
//         { name: 'mailing_address_state', filterButton: true, width: 30 },
//         { name: 'mailing_address_city', filterButton: true, width: 30 },
//         { name: 'mailing_address_country', filterButton: true, width: 30 },
//         { name: 'mailing_address_pin', filterButton: true, width: 30 },
//         { name: 'jurisdiction_address_type', filterButton: true, width: 30 },
//         { name: 'jurisdiction_address_house_no', filterButton: true, width: 30 },
//         { name: 'jurisdiction_address_house_name', filterButton: true, width: 30 },
//         { name: 'jurisdiction_address_house_road', filterButton: true, width: 30 },
//         { name: 'jurisdiction_address_house_landmark', filterButton: true, width: 30 },
//         { name: 'jurisdiction_address_state', filterButton: true, width: 30 },
//         { name: 'jurisdiction_address_city', filterButton: true, width: 30 },
//         { name: 'jurisdiction_address_country', filterButton: true, width: 30 },
//         { name: 'jurisdiction_address_pin', filterButton: true, width: 30 },
//         { name: 'educational_qualification', filterButton: true, width: 30 },
//         { name: 'employment_type', filterButton: true, width: 30 },
//         { name: 'occupation_type', filterButton: true, width: 30 },
//         { name: 'income_source_type', filterButton: true, width: 30 },
//         { name: 'gross_annual_income_type', filterButton: true, width: 30 },
//         { name: 'industry_type', filterButton: true, width: 30 },
//         { name: 'banking_type', filterButton: true, width: 30 },
//         { name: 'debit_card_type', filterButton: true, width: 30 },
//         { name: 'debit_card_variant_type', filterButton: true, width: 30 },
//         { name: 'cnp', filterButton: true, width: 30 },
//         { name: 'contactless_transactions', filterButton: true, width: 30 },
//         { name: 'nomination_chk', filterButton: true, width: 30 },
//         { name: 'relationship_nominee', filterButton: true, width: 30 },
//         { name: 'dob_nominee', filterButton: true, width: 30 },
//         { name: 'age_nominee', filterButton: true, width: 30 },
//         { name: 'nominee_guardian_title', filterButton: true, width: 30 },
//         { name: 'nominee_guardian_firstname', filterButton: true, width: 30 },
//         { name: 'nominee_guardian_middlename', filterButton: true, width: 30 },
//         { name: 'nominee_guardian_lastname', filterButton: true, width: 30 },
//         { name: 'consent_chk', filterButton: true, width: 30 },
//         { name: 'lead_status', filterButton: true, width: 30 },
//         { name: 'poi_dec_id', filterButton: true, width: 30 },
//         { name: 'nomination_facility', filterButton: true, width: 30 },
//         { name: 'temporary_visa_dec_chk1_text', filterButton: true, width: 30 },
//         { name: 'temporary_visa_dec_chk2_text', filterButton: true, width: 30 },
//         { name: 'created_at', filterButton: true, width: 30 },
//         { name: 'is_active', filterButton: true, width: 30 },
//         { name: 'agent_fullname', filterButton: true, width: 30 },
//         { name: 'customer_fullname', filterButton: true, width: 30 },
//         { name: 'customer_email', filterButton: true, width: 30 }
//       ],
//       rows: arr_datas,
//     });

//     for (const row of getall_approvedleads) {
//       worksheet.addRow(row);
//     }
//     worksheet.autoFilter = 'A1:D1';

//     worksheet.eachRow({ includeEmpty: true }, (row, rowNumber) => {

//       row.eachCell({ includeEmpty: true }, (cell, colNumber) => {
//         if (rowNumber == 1) {
//           cell.fill = {
//             type: 'pattern',
//             pattern: 'solid',
//             fgColor: { argb: 'f5b914' }
//           };
//         };
//         cell.border = {
//           top: { style: 'thin' },
//           left: { style: 'thin' },
//           bottom: { style: 'thin' },
//           right: { style: 'thin' }
//         };
//       })
//       row.commit();
//     });


//     for (let i = 0; i < worksheet?.columns.length; i += 1) {
//       let dataMax = 0;
//       const column = worksheet?.columns[i];
//       for (let j = 1; j < column?.values.length; j += 1) {
//         const columnLength = column.values[j]?.length;
//         if (columnLength > dataMax) {
//           dataMax = columnLength;
//         }
//       }
//       column.width = dataMax < 15 ? 15 : dataMax;
//     }
//     res.setHeader(
//       "Content-Type",
//       "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
//     );
//     res.setHeader(
//       "Content-Disposition",
//       "attachment; filename=" + `approvedleads_${Date.now()}.xlsx`
//     );

//     return workbook.xlsx.write(res).then(function () {
//       res.status(200).end();
//     });
//   } catch (error) {
//     console.log(error)
//     res.status(400).json({
//       msg: error
//     })

//   }
// }



// all_rejectedleads = async (req, res) => {
//   try {
//     const getall_rejectedleads = await mysqlquery(query.select.all_rejectedleads, ['rejected']);
//     let workbook = new excel.Workbook();
//     let worksheet = workbook.addWorksheet("getall_rejectedleads");
//     const result = JSON.parse(JSON.stringify(getall_rejectedleads));
//     let arr_data = [];
//     result.forEach((element) => {
//       arr_data.push(Object.values(element));
//     });

//     let arr_datas = JSON.parse(JSON.stringify(arr_data));
//     if (arr_data.length == 0) {

//       arr_datas = [arr_datas]
//     }

//     worksheet.addTable({
//       name: 'MyTable',
//       ref: 'A1',
//       headerRow: true,
//       totalsRow: true,
//       style: {
//         theme: 'TableStyleDark8',
//         showRowStripes: true,
//       },
//       columns: [
//         { name: 'lead_Reference_no', totalsRowLabel: 'Total-approved-leads =', filterButton: true, },
//         { name: 'account_type', totalsRowFunction: 'count', filterButton: true, },
//         { name: 'customer_title', filterButton: true, },
//         { name: 'firstname', filterButton: true, width: 30 },
//         { name: 'middlename', filterButton: true, width: 30 },
//         { name: 'lastname', filterButton: true, width: 30 },
//         { name: 'material_status', filterButton: true, width: 30 },
//         { name: 'addhar_no', filterButton: true, width: 30 },
//         { name: 'religion_name', filterButton: true, width: 30 },
//         { name: 'other_religion', filterButton: true, width: 30 },
//         { name: 'category_name', filterButton: true, width: 30 },
//         { name: 'other_category', filterButton: true, width: 30 },
//         { name: 'aadhar_KYC_dtls', filterButton: true, width: 30 },
//         { name: 'politically_exposed', filterButton: true, width: 30 },
//         { name: 'maiden_title', filterButton: true, width: 30 },
//         { name: 'maiden_firstname', filterButton: true, width: 30 },
//         { name: 'maiden_middlename', filterButton: true, width: 30 },
//         { name: 'maiden_lastname', filterButton: true, width: 30 },
//         { name: 'mothers_title', filterButton: true, width: 30 },
//         { name: 'mothers_firstname', filterButton: true, width: 30 },
//         { name: 'mothers_middlename', filterButton: true, width: 30 },
//         { name: 'mothers_lastname', filterButton: true, width: 30 },
//         { name: 'dob', filterButton: true, width: 30 },
//         { name: 'gender', filterButton: true, width: 30 },
//         { name: 'nationality', filterButton: true, width: 30 },
//         { name: 'date_of_becoming_nri', filterButton: true, width: 30 },
//         { name: 'father_or_spouseoptn', filterButton: true, width: 30 },
//         { name: 'farther_or_spouce_title', filterButton: true, width: 30 },
//         { name: 'farther_or_spouce_firstname', filterButton: true, width: 30 },
//         { name: 'farther_or_spouce_middlename', filterButton: true, width: 30 },
//         { name: 'farther_or_spouce_lastname', filterButton: true, width: 30 },
//         { name: 'facta_dec', filterButton: true, width: 30 },
//         { name: 'tin_no', filterButton: true, width: 30 },
//         { name: 'tin_discription', filterButton: true, width: 30 },
//         { name: 'country_taxjusidtn', filterButton: true, width: 30 },
//         { name: 'tin_Issue_country', filterButton: true, width: 30 },
//         { name: 'city_of_birth', filterButton: true, width: 30 },
//         { name: 'country_of_birth', filterButton: true, width: 30 },
//         { name: 'passport', filterButton: true, width: 30 },
//         { name: 'passport_no', filterButton: true, width: 30 },
//         { name: 'passport_issue_date', filterButton: true, width: 30 },
//         { name: 'passport_expiry_date', filterButton: true, width: 30 },
//         { name: 'passport_issue_authority', filterButton: true, width: 30 },
//         { name: 'passport_place_of_issue', filterButton: true, width: 30 },
//         { name: 'visa_type_name', filterButton: true, width: 30 },
//         { name: 'visa_expiry', filterButton: true, width: 30 },
//         { name: 'pan_cardno', filterButton: true, width: 30 },
//         { name: 'address_proof', filterButton: true, width: 30 },
//         { name: 'address_prof_file', filterButton: true, width: 30 },
//         { name: 'address_prof_authority', filterButton: true, width: 30 },
//         { name: 'address_prof_doc_type', filterButton: true, width: 30 },
//         { name: 'address_prof_place_Issue', filterButton: true, width: 30 },
//         { name: 'address_prof_doc_no', filterButton: true, width: 30 },
//         { name: 'address_prof_doc_issuedate', filterButton: true, width: 30 },
//         { name: 'address_prof_doc_expirydate', filterButton: true, width: 30 },
//         { name: 'temporary_visa_chk', filterButton: true, width: 30 },
//         { name: 'temp_dec_visa_issuedate', filterButton: true, width: 30 },
//         { name: 'temp_dec_visa_expirydate', filterButton: true, width: 30 },
//         { name: 'temp_furnish_threemonth_visachk', filterButton: true, width: 30 },
//         { name: 'office_cntry_code', filterButton: true, width: 30 },
//         { name: 'office_std_code', filterButton: true, width: 30 },
//         { name: 'office_tel_code', filterButton: true, width: 30 },
//         { name: 'residence_cntry_code', filterButton: true, width: 30 },
//         { name: 'residence_std_code', filterButton: true, width: 30 },
//         { name: 'residence_tel_code', filterButton: true, width: 30 },
//         { name: 'mob_cntry_code', filterButton: true, width: 30 },
//         { name: 'mob_std_code', filterButton: true, width: 30 },
//         { name: 'mob_tel_code', filterButton: true, width: 30 },
//         { name: 'fax_cntry_code', filterButton: true, width: 30 },
//         { name: 'fax_std_code', filterButton: true, width: 30 },
//         { name: 'fax_tel_code', filterButton: true, width: 30 },
//         { name: 'email', filterButton: true, width: 30 },
//         { name: 'same_address_ovd', filterButton: true, width: 30 },
//         { name: 'deemed_ovd_dll', filterButton: true, width: 30 },
//         { name: 'overseas_address_type', filterButton: true, width: 30 },
//         { name: 'overseas_address_house_no', filterButton: true, width: 30 },
//         { name: 'overseas_address_house_name', filterButton: true, width: 30 },
//         { name: 'overseas_address_house_road', filterButton: true, width: 30 },
//         { name: 'overseas_address_house_landmark', filterButton: true, width: 30 },
//         { name: 'overseas_address_state', filterButton: true, width: 30 },
//         { name: 'overseas_address_city', filterButton: true, width: 30 },
//         { name: 'overseas_address_country', filterButton: true, width: 30 },
//         { name: 'overseas_address_pin', filterButton: true, width: 30 },
//         { name: 'permanent_address_type', filterButton: true, width: 30 },
//         { name: 'permanent_address_house_no', filterButton: true, width: 30 },
//         { name: 'permanent_address_house_name', filterButton: true, width: 30 },
//         { name: 'permanent_address_house_road', filterButton: true, width: 30 },
//         { name: 'permanent_address_house_landmark', filterButton: true, width: 30 },
//         { name: 'permanent_address_state', filterButton: true, width: 30 },
//         { name: 'permanent_address_city', filterButton: true, width: 30 },
//         { name: 'permanent_address_country', filterButton: true, width: 30 },
//         { name: 'permanent_address_pin', filterButton: true, width: 30 },
//         { name: 'mailing_sameperm_or_overseas', filterButton: true, width: 30 },
//         { name: 'mailing_address_type', filterButton: true, width: 30 },
//         { name: 'mailing_address_house_no', filterButton: true, width: 30 },
//         { name: 'mailing_address_house_name', filterButton: true, width: 30 },
//         { name: 'mailing_address_house_road', filterButton: true, width: 30 },
//         { name: 'mailing_address_house_landmark', filterButton: true, width: 30 },
//         { name: 'mailing_address_state', filterButton: true, width: 30 },
//         { name: 'mailing_address_city', filterButton: true, width: 30 },
//         { name: 'mailing_address_country', filterButton: true, width: 30 },
//         { name: 'mailing_address_pin', filterButton: true, width: 30 },
//         { name: 'jurisdiction_address_type', filterButton: true, width: 30 },
//         { name: 'jurisdiction_address_house_no', filterButton: true, width: 30 },
//         { name: 'jurisdiction_address_house_name', filterButton: true, width: 30 },
//         { name: 'jurisdiction_address_house_road', filterButton: true, width: 30 },
//         { name: 'jurisdiction_address_house_landmark', filterButton: true, width: 30 },
//         { name: 'jurisdiction_address_state', filterButton: true, width: 30 },
//         { name: 'jurisdiction_address_city', filterButton: true, width: 30 },
//         { name: 'jurisdiction_address_country', filterButton: true, width: 30 },
//         { name: 'jurisdiction_address_pin', filterButton: true, width: 30 },
//         { name: 'educational_qualification', filterButton: true, width: 30 },
//         { name: 'employment_type', filterButton: true, width: 30 },
//         { name: 'occupation_type', filterButton: true, width: 30 },
//         { name: 'income_source_type', filterButton: true, width: 30 },
//         { name: 'gross_annual_income_type', filterButton: true, width: 30 },
//         { name: 'industry_type', filterButton: true, width: 30 },
//         { name: 'banking_type', filterButton: true, width: 30 },
//         { name: 'debit_card_type', filterButton: true, width: 30 },
//         { name: 'debit_card_variant_type', filterButton: true, width: 30 },
//         { name: 'cnp', filterButton: true, width: 30 },
//         { name: 'contactless_transactions', filterButton: true, width: 30 },
//         { name: 'nomination_chk', filterButton: true, width: 30 },
//         { name: 'relationship_nominee', filterButton: true, width: 30 },
//         { name: 'dob_nominee', filterButton: true, width: 30 },
//         { name: 'age_nominee', filterButton: true, width: 30 },
//         { name: 'nominee_guardian_title', filterButton: true, width: 30 },
//         { name: 'nominee_guardian_firstname', filterButton: true, width: 30 },
//         { name: 'nominee_guardian_middlename', filterButton: true, width: 30 },
//         { name: 'nominee_guardian_lastname', filterButton: true, width: 30 },
//         { name: 'consent_chk', filterButton: true, width: 30 },
//         { name: 'lead_status', filterButton: true, width: 30 },
//         { name: 'poi_dec_id', filterButton: true, width: 30 },
//         { name: 'nomination_facility', filterButton: true, width: 30 },
//         { name: 'temporary_visa_dec_chk1_text', filterButton: true, width: 30 },
//         { name: 'temporary_visa_dec_chk2_text', filterButton: true, width: 30 },
//         { name: 'created_at', filterButton: true, width: 30 },
//         { name: 'is_active', filterButton: true, width: 30 },
//         { name: 'agent_fullname', filterButton: true, width: 30 },
//         { name: 'customer_fullname', filterButton: true, width: 30 },
//         { name: 'customer_email', filterButton: true, width: 30 }
//       ],
//       rows: arr_datas,
//     });

//     for (const row of getall_rejectedleads) {
//       worksheet.addRow(row);
//     }

//     worksheet.autoFilter = 'A1:D1';

//     worksheet.eachRow({ includeEmpty: true }, (row, rowNumber) => {

//       row.eachCell({ includeEmpty: true }, (cell, colNumber) => {
//         if (rowNumber == 1) {
//           cell.fill = {
//             type: 'pattern',
//             pattern: 'solid',
//             fgColor: { argb: 'f5b914' }
//           };
//         };
//         cell.border = {
//           top: { style: 'thin' },
//           left: { style: 'thin' },
//           bottom: { style: 'thin' },
//           right: { style: 'thin' }
//         };
//       })
//       row.commit();
//     });


//     for (let i = 0; i < worksheet?.columns.length; i += 1) {
//       let dataMax = 0;
//       const column = worksheet?.columns[i];
//       for (let j = 1; j < column?.values.length; j += 1) {
//         const columnLength = column.values[j]?.length;
//         if (columnLength > dataMax) {
//           dataMax = columnLength;
//         }
//       }
//       column.width = dataMax < 15 ? 15 : dataMax;
//     }
//     res.setHeader(
//       "Content-Type",
//       "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
//     );
//     res.setHeader(
//       "Content-Disposition",
//       "attachment; filename=" + `rejectedleads_${Date.now()}.xlsx`
//     );

//     return workbook.xlsx.write(res).then(function () {
//       res.status(200).end();
//     });
//   } catch (error) {
//     res.status(400).json({
//       msg: error
//     })

//   }
// }



// all_newleads = async(req,res)=>{
//     try{
//         const newlead = await mysqlquery(query.select.getall_newleads,[""]);
//             let workbook = new excel.Workbook();
//             let worksheet = workbook.addWorksheet('newlead'); 
//             console.log(newlead)
//             //  WorkSheet Header
//             worksheet.columns = [
//               { header: 'lead Reference No', key: 'lead_Reference_no', width: 30 },
//               { header: 'FirstName', key: 'firstname', width: 30 },
//               { header: 'Middlename', key: 'middlename', width: 30},
//               { header: 'LastName', key: 'lastname', width: 30},
//               { header: 'Account Type', key: 'account_type', width: 30 },
//               { header: 'Addhar No', key: 'addhar_no', width: 30 },
//               { header: 'Address proof Doc', key: 'address_proof_doc', width: 30},
//               { header: 'Address proof  Doc Expiry Date', key: 'address_proof_doc_expiry_date', width: 30},
//               { header: 'address_proof_doc_issue_date', key: 'address_proof_doc_issue_date', width: 30 },
//               { header: 'address_proof_doc_type', key: 'address_proof_doc_type', width: 30 },
//               { header: 'address_proof_issue_date', key: 'address_proof_issue_date', width: 30},
//               { header: 'address_proof_issuing_authority', key: 'address_proof_issuing_authority', width: 30},
//               { header: 'address_proof_type', key: 'address_proof_type', width: 30 },
//               { header: 'banking_type', key: 'banking_type', width: 30},
//               { header: 'category_name', key: 'category_name', width: 30 },
//               { header: 'consent', key: 'consent', width: 30},
//               { header: 'created_at', key: 'created_at', width: 30},
//               { header: 'current_adrs_same_ovd', key: 'current_adrs_same_ovd', width: 30 },
//               { header: 'customer_address_type', key: 'customer_address_type', width: 30 },
//               { header: 'customer_email', key: 'customer_email', width: 30},
//               { header: 'customer_fullname', key: 'customer_fullname', width: 30},
//               { header: 'customer_title', key: 'customer_title', width: 30 },
//               { header: 'debit_card_type', key: 'debit_card_type', width: 30},
//               { header: 'debit_card_variant_type', key: 'debit_card_variant_type', width: 30 },
//               { header: 'educational_qualification', key: 'educational_qualification', width: 30},
//               { header: 'employment_type', key: 'employment_type', width: 30},
//               { header: 'fatca_residence_tax', key: 'fatca_residence_tax', width: 30 },
//               { header: 'fax_country_code', key: 'fax_country_code', width: 30 },
//               { header: 'fax_std_code', key: 'fax_std_code', width: 30},
//               { header: 'fax_tel_code', key: 'fax_tel_code', width: 30},
//               { header: 'fullname_matched_addhar_kyc', key: 'fullname_matched_addhar_kyc', width: 30 },
//               { header: 'gross_annual_income_type', key: 'gross_annual_income_type', width: 30},
//               { header: 'income_source_type', key: 'income_source_type', width: 30 },
//               { header: 'industry_type', key: 'industry_type', width: 30},
//               { header: 'is_active', key: 'is_active', width: 30},
//               { header: 'lead_status', key: 'lead_status', width: 30 },
//               { header: 'mailing_address_type', key: 'mailing_address_type', width: 30 },
//               { header: 'material_status', key: 'material_status', width: 30},
//               { header: 'mob_no', key: 'mob_no', width: 30},
//               { header: 'mob_no_country_code', key: 'mob_no_country_code', width: 30 },
//               { header: 'nomination_facility_do_not_require', key: 'nomination_facility_do_not_require', width: 30},
//               { header: 'nomination_facility_id', key: 'nomination_facility_id', width: 30 },
//               { header: 'nomination_facility_require', key: 'nomination_facility_require', width: 30},
//               { header: 'nominee_address_bulding_no', key: 'nominee_address_bulding_no', width: 30},
//               { header: 'nominee_address_city', key: 'nominee_address_city', width: 30 },
//               { header: 'nominee_address_country', key: 'nominee_address_country', width: 30 },
//               { header: 'nominee_address_house_no', key: 'nominee_address_house_no', width: 30},
//               { header: 'nominee_address_landmark', key: 'nominee_address_landmark', width: 30},
//               { header: 'nominee_address_pin_code', key: 'nominee_address_pin_code', width: 30 },
//               { header: 'nominee_address_state', key: 'nominee_address_state', width: 30},
//               { header: 'nominee_address_street_name', key: 'nominee_address_street_name', width: 30 },
//               { header: 'nominee_address_type', key: 'nominee_address_type', width: 30},
//               { header: 'nominee_age_month', key: 'nominee_age_month', width: 30},
//               { header: 'nominee_age_years', key: 'nominee_age_years', width: 30 },
//               { header: 'nominee_dob', key: 'nominee_dob', width: 30 },
//               { header: 'nominee_guardian_title', key: 'nominee_guardian_title', width: 30 },
//               { header: 'nominee_guardian_firstname', key: 'nominee_guardian_firstname', width: 30},
//               { header: 'nominee_guardian_middlename', key: 'nominee_guardian_middlename', width: 30},
//               { header: 'nominee_guardian_lastname', key: 'nominee_guardian_lastname', width: 30 },
//               { header: 'nominee_title', key: 'nominee_title', width: 30 },
//               { header: 'nominee_firstname', key: 'nominee_firstname', width: 30},
//               { header: 'nominee_middlename', key: 'nominee_middlename', width: 30},
//               { header: 'nominee_lastname', key: 'nominee_lastname', width: 30},
//               { header: 'nominee_relation_depositor', key: 'nominee_relation_depositor', width: 30 },
//               { header: 'occupation_type', key: 'occupation_type', width: 30},
//               { header: 'office_country_code', key: 'office_country_code', width: 30},
//               { header: 'office_std_code', key: 'office_std_code', width: 30 },
//               { header: 'office_tel_code', key: 'office_tel_code', width: 30},
//               { header: 'other_passport', key: 'other_passport', width: 30 },
//               { header: 'overseas_address_bulding_no', key: 'overseas_address_bulding_no', width: 30},
//               { header: 'overseas_address_city', key: 'overseas_address_city', width: 30},
//               { header: 'overseas_address_country', key: 'overseas_address_country', width: 30},
//               { header: 'overseas_address_house_no', key: 'overseas_address_house_no', width: 30},
//               { header: 'overseas_address_landmark', key: 'overseas_address_landmark', width: 30 },
//               { header: 'overseas_address_pin_code', key: 'overseas_address_pin_code', width: 30},
//               { header: 'overseas_address_state', key: 'overseas_address_state', width: 30 },
//               { header: 'overseas_address_street_name', key: 'overseas_address_street_name', width: 30},
//               { header: 'pan_card', key: 'pan_card', width: 30},
//               { header: 'passport_expiry_date', key: 'passport_expiry_date', width: 30},
//               { header: 'passport_issue_date', key: 'passport_issue_date', width: 30},
//               { header: 'passport_issuing_authority', key: 'passport_issuing_authority', width: 30},
//               { header: 'passport_number', key: 'passport_number', width: 30},
//               { header: 'passport_place_issue', key: 'passport_place_issue', width: 30 },
//               { header: 'permanent_address_bulding_no', key: 'permanent_address_bulding_no', width: 30},
//               { header: 'permanent_address_city', key: 'permanent_address_city', width: 30 },
//               { header: 'permanent_address_country', key: 'permanent_address_country', width: 30},
//               { header: 'permanent_address_house_no', key: 'permanent_address_house_no', width: 30},
//               { header: 'permanent_address_landmark', key: 'permanent_address_landmark', width: 30},
//               { header: 'permanent_address_pin_code', key: 'permanent_address_pin_code', width: 30},
//               { header: 'permanent_address_state', key: 'permanent_address_state', width: 30},
//               { header: 'permanent_address_street_name', key: 'permanent_address_street_name', width: 30 },
//               { header: 'permanent_address_type', key: 'permanent_address_type', width: 30},
//               { header: 'pio_dec_id', key: 'pio_dec_id', width: 30},
//               { header: 'politically_exposed_person', key: 'politically_exposed_person', width: 30 },
//               { header: 'prefered_mail_address_bulding_no', key: 'prefered_mail_address_bulding_no', width: 30 },
//               { header: 'prefered_mail_address_city', key: 'prefered_mail_address_city', width: 30},
//               { header: 'prefered_mail_address_country', key: 'prefered_mail_address_country', width: 30},
//               { header: 'prefered_mail_address_house_no', key: 'prefered_mail_address_house_no', width: 30 },
//               { header: 'prefered_mail_address_landmark', key: 'prefered_mail_address_landmark', width: 30},
//               { header: 'prefered_mail_address_pin_code', key: 'prefered_mail_address_pin_code', width: 30 },
//               { header: 'prefered_mail_address_same_as', key: 'prefered_mail_address_same_as', width: 30},
//               { header: 'prefered_mail_address_state', key: 'prefered_mail_address_state', width: 30},
//               { header: 'prefered_mail_address_street_name', key: 'prefered_mail_address_street_name', width: 30 },
//               { header: 'religion_name', key: 'religion_name', width: 30 },
//               { header: 'residence_country_code', key: 'residence_country_code', width: 30},
//               { header: 'residence_std_code', key: 'residence_std_code', width: 30 },
//               { header: 'residence_tel_code', key: 'residence_tel_code', width: 30},
//               { header: 'tem_visa_dec_chk1_id', key: 'tem_visa_dec_chk1_id', width: 30 },
//               { header: 'tem_visa_dec_chk2_id', key: 'tem_visa_dec_chk2_id', width: 30},
//               { header: 'transaction_contactless_transaction', key: 'transaction_contactless_transaction', width: 30},
//               { header: 'transaction_online', key: 'transaction_online', width: 30 },
//               { header: 'transaction_platform_atm_activated', key: 'transaction_platform_atm_activated', width: 30},
//               { header: 'transaction_pos_activated', key: 'transaction_pos_activated', width: 30},
//               { header: 'visa_permity_expiry_date', key: 'visa_permity_expiry_date', width: 30},
//               { header: 'visa_type_name', key: 'visa_type_name', width: 30 },
//             ];

//             for (const row of newlead) {
//             worksheet.addRow(row);
//         }

//          worksheet.autoFilter = 'A1:DL1';

//         worksheet.eachRow(function (row, rowNumber) {

//             row.eachCell((cell, colNumber) => {
//                 if (rowNumber == 1) {
//                     cell.fill = {
//                         type: 'pattern',
//                         pattern: 'solid',
//                         fgColor: { argb: 'f5b914' }
//                     }
//                 }

//                 cell.border = {
//                     top: { style: 'thin' },
//                     left: { style: 'thin' },
//                     bottom: { style: 'thin' },
//                     right: { style: 'thin' }
//                 };
//             })

//             row.commit();
//         });

//     const account_type = worksheet.getColumn('account_type')
//     account_type.eachCell((cell, rowNumber) => {
//         if (cell.row >=2) {
//             cell.fill = {
//                 type: 'gradient',
//                 gradient: 'angle',
//                 degree: 0,
//                 stops: [
//                     { position: 0, color: { argb: 'ffffff' } },
//                     { position: 0.5, color: { argb: 'cc8188' } },
//                     { position: 1, color: { argb: 'fa071e' } }
//                      ]
//                 };
//             }
//          });
//             res.setHeader(
//               "Content-Type",
//               "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
//             );
//             res.setHeader(
//               "Content-Disposition",
//               "attachment; filename=" + `newleads_${Date.now()}.xlsx`
//             );

//             return workbook.xlsx.write(res).then(function () {
//               res.status(200).end();
//             });
//         }catch(error) {
//             res.json({
//                 status:400,
//                 msg:error
//             })
//         }    
//     }



// all_newleads=async(req,res)=>{
//     try {
//         const newlead = await mysqlquery(query.select.getall_newleads,[""]);
//         res.json({
//             status:200,
//             msg:newlead
//         })
//       } catch(error) {
//           res.json({
//               status:400,
//               msg:error
//           })

//       }
// }  


// all_processlead=async(req,res)=>{
//     try {
//         const getall_processlead = await mysqlquery(query.select.all_processlead,["process"]);
//         res.json({
//             status:200,
//             msg:getall_processlead
//         })
//       } catch(error) {
//           res.json({
//               status:400,
//               msg:error
//           })

//       }
//     }   


// all_approvedleads=async(req,res)=>{
//     try {
//         const getall_approvedleads = await mysqlquery(query.select.all_approvedleads,['approved']);
//         res.json({
//             status:200,
//             msg:getall_approvedleads
//         })
//       } catch(error) {
//           res.json({
//               status:400,
//               msg:error
//           })

//       }
//     } 


// all_rejectedleads=async(req,res)=>{
//     try {
//         const getall_rejectedleads = await mysqlquery(query.select.all_rejectedleads,['rejected']);
//         res.json({
//             status:200,
//             msg:getall_rejectedleads
//         })
//       } catch(error) {
//           res.json({
//               status:400,
//               msg:error
//           })

//       }
//     }  

// newleadspdf = async (req, res) => {
//   try {
//     const newlead = await mysqlquery(query.select.getall_newleads, ["new"]);
//     const newleads = JSON.parse(JSON.stringify(newlead));
//     console.log(newleads);

//     var result = newleads;
//     var table
//     table += "<tr>";
//     table += "<table  border='1' style='width:100%;word-break:break-word;'>";
//     table += "<th>lead_Reference_no</th>";
//     table += "<th>account_type";
//     table += "<th>customer_title";
//     table += "<th>firstname";
//     table += "<th>middlename";
//     table += "<th>lastname";
//     table += "<th>material_status";
//     table += "<th>addhar_no";
//     table += "<th>religion_name";
//     table += "<th>category_name";
//     table += "<th>politically_exposed";
//     table += "<th>aadhar_KYC_dtls";
//     table += "<th >passport_no";
//     table += "</tr>";
//     result.forEach(function (row) {
//       table += "<tr>";
//       table += "<td>" + row.lead_Reference_no + "</td>";
//       table += "<td>" + row.account_type + "</td>";
//       table += "<td>" + row.customer_title + "</td>";
//       table += "<td>" + row.firstname + "</td>";
//       table += "<td>" + row.middlename + "</td>";
//       table += "<td>" + row.lastname + "</td>";
//       table += "<td>" + row.material_status + "</td>";
//       table += "<td>" + row.addhar_no + "</td>";
//       table += "<td>" + row.religion_name + "</td>";
//       table += "<td>" + row.category_name + "</td>";
//       table += "<td>" + row.politically_exposed + "</td>";
//       table += "<td>" + row.aadhar_KYC_dtls + "</td>";
//       table += "<td>" + row.passport_no + "</td>";
//       table += "</tr>";
//     });
//     table += "</table>";
//     var options = {
//       format: "A2",
//       orientation: "portrait",
//       border: "10mm",
//       header: {
//         height: "20mm",
//         contents: '<div style="text-align: center;">New Leads</div>'
//       },
//       footer: {
//         height: "28mm",
//         contents: {

//           2: 'Second page',
//           default: '<span style="color: #444;">{{page}}</span>/<span>{{pages}}</span>',
//           last: 'Last Page'
//         }
//       }
//     };

//     pdf.create(table, options).toFile('Documents/pdf/newleads.pdf', function (err, result) {
//       if (err) return console.log(err);
//       console.log("pdf create");
//       res.download('Documents/pdf/newleads.pdf');
//     });
//   } catch (error) {
//     res.status(400).json({
//       msg: error
//     })
//   }
// }




// agent pagination
allRblagents_perpage = async (req, res) => {
  let pageno = 0;
  req.body.pageno === undefined ? pageno = 1 : pageno = req.body.pageno;
  offset = 5 * (pageno - 1);
  try {
    const allRblagents_perpage = await mysqlquery(query.select.allRblagents_perpage, ['agent', offset]);
    res.status(200).json({
      msg: allRblagents_perpage
    })
  } catch (error) {
    res.status(400).json({
      msg: error
    })

  }
}


agent_no_of_buttons = async (req, res) => {
  try {
    const allagents = await mysqlquery(query.select.countRBlagent, ['agent']);
    const allagen = JSON.stringify(allagents);
    const allagent = JSON.parse(allagen);
    var total = allagent.map(function (obj) {
      return obj.totalagents;
    });

    var iterator = total.values();
    var totalagents = iterator.next().value;

    var total_button = totalagents / 5;
    var agent_buttons = Math.ceil(total_button);

    res.status(200).json({
      data: agent_buttons
    })
  } catch (error) {
    res.status(400).json({
      msg: error
    })

  }
}

agent_next_page = async (req, res) => {
  try {
    const allagents = await mysqlquery(query.select.countRBlagent, ['agent']);
    const allagen = JSON.stringify(allagents);
    const allagent = JSON.parse(allagen);
    var total = allagent.map(function (obj) {
      return obj.totalagents;
    });

    var iterator = total.values();
    var totalagents = iterator.next().value;
    var total_button = totalagents / 5;
    var agent_buttons = Math.ceil(total_button);

    if (req.body.pageno >= 1, req.body.pageno <= agent_buttons) {

      var pageno = req.body.pageno;
      offset = 5 * ((pageno + 1) - 1);

      const allRblagents_perpage = await mysqlquery(query.select.allRblagents_perpage, ['agent', offset]);
      res.status(200).json({
        data: allRblagents_perpage
      })
    } else {
      res.status(400).json({
        msg: "bad request"
      })
    }
  } catch (error) {
    res.status(400).json({
      msg: error
    })

  }
}


agent_previous_page = async (req, res) => {
  try {
    const allagents = await mysqlquery(query.select.countRBlagent, ['agent']);
    const allagen = JSON.stringify(allagents);
    const allagent = JSON.parse(allagen);
    var total = allagent.map(function (obj) {
      return obj.totalagents;
    });

    var iterator = total.values();
    var totalagents = iterator.next().value;
    var total_button = totalagents / 5;
    var agent_buttons = Math.ceil(total_button);

    if (req.body.pageno >= 1, req.body.pageno <= agent_buttons) {

      var pageno = req.body.pageno;
      offset = 5 * ((pageno - 1) - 1);

      const allRblagents_perpage = await mysqlquery(query.select.allRblagents_perpage, ['agent', offset]);
      res.status(200).json({
        data: allRblagents_perpage
      })
    } else {
      res.status(400).json({
        msg: "bad request"
      })
    }
  } catch (error) {
    res.status(400).json({
      msg: error
    })
  }
}

// IT Team pagination
allRblteamuser_perpage = async (req, res) => {
  let pageno = 0;
  req.body.pageno === undefined ? pageno = 1 : pageno = req.body.pageno;
  offset = 5 * (pageno - 1);
  try {
    const allRblteamuser_perpage = await mysqlquery(query.select.allRblitteamuser_perpage, ['rblitteamuser', offset]);
    res.status(200).json({
      data: allRblteamuser_perpage
    })
  } catch (error) {
    res.status(400).json({
      msg: error
    })

  }
}


rblitteam_no_of_buttons = async (req, res) => {
  try {
    const allRblitteamuser = await mysqlquery(query.select.countRblitteamuser, ['rblitteamuser']);
    const allrblItuser = JSON.stringify(allRblitteamuser);
    const allrblItusers = JSON.parse(allrblItuser);
    var total = allrblItusers.map(function (obj) {
      return obj.totalItTeamuser;
    });

    var iterator = total.values();
    var totalItusers = iterator.next().value;

    var total_button = totalItusers / 5;
    var Rbluser_buttons = Math.ceil(total_button);

    res.status(200).json({
      data: Rbluser_buttons
    })

  } catch (error) {
    res.status(400).json({
      msg: error
    })

  }
}

rbluser_next_page = async (req, res) => {
  try {
    const allRblitteamuser = await mysqlquery(query.select.countRblitteamuser, ['rblitteamuser']);
    const allrblItuser = JSON.stringify(allRblitteamuser);
    const allrblItusers = JSON.parse(allrblItuser);
    var total = allrblItusers.map(function (obj) {
      return obj.totalItTeamuser;
    });
    var iterator = total.values();
    var totalItusers = iterator.next().value;
    var total_button = totalItusers / 5;
    var Rbluser_buttons = Math.ceil(total_button);
    if (req.body.pageno >= 1, req.body.pageno <= Rbluser_buttons) {
      var pageno = req.body.pageno;
      offset = 5 * ((pageno + 1) - 1);

      const allrblusers_perpage = await mysqlquery(query.select.allRblitteamuser_perpage, ['rblitteamuser', offset]);
      res.status(200).json({
        data: allrblusers_perpage
      })
    } else {
      res.status(400).json({
        msg: "bad request"
      })
    }
  } catch (error) {
    res.status(400).json({
      msg: error
    })

  }
}


rbluser_previous_page = async (req, res) => {
  try {
    const allRblitteamuser = await mysqlquery(query.select.countRblitteamuser, ['rblitteamuser']);
    const allrblItuser = JSON.stringify(allRblitteamuser);
    const allrblItusers = JSON.parse(allrblItuser);
    var total = allrblItusers.map(function (obj) {
      return obj.totalItTeamuser;
    });
    var iterator = total.values();
    var totalItusers = iterator.next().value;
    var total_button = totalItusers / 5;
    var Rbluser_buttons = Math.ceil(total_button);
    if (req.body.pageno >= 1 && req.body.pageno <= Rbluser_buttons) {
      var pageno = req.body.pageno;
      offset = 5 * ((pageno - 1) - 1);

      const allrblusers_perpage = await mysqlquery(query.select.allRblitteamuser_perpage, ['rblitteamuser', offset]);
      res.status(200).json({
        data: allrblusers_perpage
      })
    } else {
      res.status(400).json({
        msg: "bad request"
      })
    }
  } catch (error) {
    res.status(400).json({
      msg: error
    })
  }
}

module.exports = {
  countRBlagent,
  countRblitteamuser,
  allRblagent,
  allRblitteamuser,
  // all_newleads,
  // all_processleads,
  // all_approvedleads,
  // all_rejectedleads,
  // newleadspdf,
  allRblagents_perpage,
  agent_no_of_buttons,
  agent_next_page,
  agent_previous_page,
  allRblteamuser_perpage,
  rblitteam_no_of_buttons,
  rbluser_next_page,
  rbluser_previous_page
}