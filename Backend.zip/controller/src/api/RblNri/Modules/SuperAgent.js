var mysqlconn = require('../../../../../db/mysqlconn');
const query = require('../../../../../db/query.json')
var notification_function = require('../../../../../utils/function');
const util = require('util');
const mysqlquery = util.promisify(mysqlconn.query).bind(mysqlconn);

const account_forms = require('../../../../../json/account.json')

const db_table = require('../../../../../db_manipulation/db_constant');

const path = require("path");
var fs = require("fs");
var pdf = require('html-pdf');

module.exports.get_agent_list=async(req,res)=>{
  try{
    var agent_list_query = `select reporting_manager,email_address, user_id as agent_id,concat(first_name,' ',last_name) as name from tbl_users where role_id=3 and status='active'`;
    var agent_list_result = await mysqlquery(agent_list_query);
    let final_agent_list = agent_list_result.filter(item => item.email_address.endsWith('@rblbank.com'))
    let agentData = final_agent_list.filter(item => item.reporting_manager == req.params.agent_id)

    res.status(200).json({
      agent_list:agentData,
    })
  }catch(error){
    res.status(400).json({
      msg:error.message?error.message:error
    })
  }
}

module.exports.get_lead_count=async(req,res)=>{
  try {
    var leads_query =`select user.user_id, user.first_name,user.last_name,personal_detail.account_type_id as account_type from tbl_agent_leads
    left join tbl_leads on tbl_leads.lead_id = tbl_agent_leads.lead_id
    left join tbl_users user on user.user_id=tbl_leads.user_id
    left join tbl_applicant_personal_details personal_detail on personal_detail.user_id=tbl_leads.user_id
    where  tbl_leads.lead_status='lead' group by user_id`;
    var leads = await mysqlquery(leads_query,[req.body.agent_id]);
    var lead_ids = leads.map(function (el) { return el.user_id; });
    var agent_lead = `SELECT * FROM ${db_table.agent_leads}`
    var agent_lads = await mysqlquery(agent_lead);
    var agent_lead_ids = agent_lads.map(function (el) { return el.lead_id; });

    if(lead_ids.length > agent_lead_ids.length){
      var LeadsIdArray = lead_ids.filter(val => !agent_lead_ids.includes(val));
      var result = leads.filter(({user_id}) => !agent_lead_ids.some(o => o === user_id));
    }else{
     var LeadsIdArray = agent_lead_ids.filter(val => !lead_ids.includes(val));
     var result = leads.filter(({user_id}) => !agent_lead_ids.some(o => o === user_id));
   }

   if(result){
    var lead_count = result.length;
    res.status(200).json({
      lead_count:lead_count,
    })
  }else{
    res.status(400).json({
      msg:'bad request'
    })
  }
} catch(error) {
  res.status(400).json({
    msg:error.message?error.message:error
  })

}
}

module.exports.lead_list=async(req,res)=>{
  try {
    var leads_query =`select
    l.lead_id,
    l.user_id,
    l.lead_status,
    al.agent_id,
    u.title,
    u.first_name,
    u.middle_name,
    u.last_name,
    d.account_type_id as account_type
    from
    tbl_leads l
    left join tbl_agent_leads al on l.lead_id = al.lead_id
    left join tbl_users u on l.user_id = u.user_id
    left join tbl_applicant_personal_details d on u.user_id = d.user_id
    where
    l.lead_status = 'lead'
    and al.agent_id is null`;
    var leads = await mysqlquery(leads_query,[req.body.agent_id]);
    var lead_ids = leads.map(function (el) { return el.user_id; });
    var agent_lead = `SELECT * FROM ${db_table.agent_leads}`
    var agent_lads = await mysqlquery(agent_lead);
    var agent_lead_ids = agent_lads.map(function (el) { return el.lead_id; });

    if(lead_ids.length > agent_lead_ids.length){
      var LeadsIdArray = lead_ids.filter(val => !agent_lead_ids.includes(val));
      var result = leads.filter(({user_id}) => !agent_lead_ids.some(o => o === user_id));
    }else{
     var LeadsIdArray = agent_lead_ids.filter(val => !lead_ids.includes(val));
     var result = leads.filter(({user_id}) => !agent_lead_ids.some(o => o === user_id));
   }
   result.forEach(application => {
    var account_type = '';
    if(account_type > 0){
      let account_id = application.account_type;
      var account_form = account_forms;

      var account_type_name = account_form.find(item => item.account_type_id === account_id)
      var account_type = account_type_name.account_type;

      application['account_type'] = account_type;
    }

    delete application['account_type_id'];

  })
   res.status(200).json({
    data:result
  })
 } catch(error) {
  res.status(400).json({
    msg:error.message?error.message:error
  })

}
}


module.exports.assigen_leads=async(req,res)=>{
  try {

    let accept_agent_lead = {
      agent_id:req.body.agent_id, lead_id: req.body.lead_id, 
    };
    let sql = `INSERT INTO ${db_table.agent_leads} SET ? `;
    const agent_accept_lead = await mysqlquery(sql, accept_agent_lead);

    if(agent_accept_lead.insertId>0){
      res.status(200).json({
        msg:'assigen lead to agent successfully'
      })
    }else{
      res.status(400).json({
        msg:'bad request'
      })
    }

  } catch(error) {
    res.status(400).json({
      msg:error.message?error.message:error
    })

  }
}




module.exports.get_assigned_lead_count=async(req,res)=>{
  try {
    var agent_lead = `SELECT * FROM ${db_table.agent_leads}`
    var agent_lads = await mysqlquery(agent_lead);
    var agent_lead_ids = agent_lads.map(function (el) { return el.lead_id; });

    var agent_lead 

    if(lead_ids.length > agent_lead_ids.length){
      var LeadsIdArray = lead_ids.filter(val => !agent_lead_ids.includes(val));
      var result = leads.filter(({user_id}) => !agent_lead_ids.some(o => o === user_id));
    }else{
      var LeadsIdArray = agent_lead_ids.filter(val => !lead_ids.includes(val));
      var result = leads.filter(({user_id}) => !agent_lead_ids.some(o => o === user_id));
    }

   if(result){
    var lead_count = result.length;
    res.status(200).json({
      lead_count:lead_count,
    })
  }else{
    res.status(400).json({
      msg:'bad request'
    })
  }
} catch(error) {
  res.status(400).json({
    msg:error.message?error.message:error
  })

}
}

module.exports.assigen_lead_list=async(req,res)=>{
  try {
    var leads_query =`select tbl_users.first_name,tbl_users.last_name,agent_lead.lead_id from tbl_agent_leads agent_lead
    left join tbl_leads on agent_lead.lead_id=tbl_leads.lead_id
    left join tbl_users on tbl_users.user_id=tbl_leads.user_id`;
    const assigen_leads = await mysqlquery(leads_query);
    res.status(200).json({
      data:assigen_leads
    })
  } catch(error) {
    res.status(400).json({
      msg:error.message?error.message:error
    })

  }
}

//pradeep
module.exports.lead_count_new = async(req, res)=>{
  try{
    var lead_type_condition = '';
    var lead_status = '';
    if(req.params.lead_type!=undefined){
      var lead_type = req.params.lead_type;
      switch(lead_type){
        case 'new':
          lead_type_condition = '';
          lead_status = 'lead';
        break;
        case 'assigned':
          lead_type_condition = 'NOT';
          lead_status = 'lead';
        break;
        case 'reviewed':
          lead_type_condition = 'NOT';
          lead_status = 'agent_review';
        break;
        default:
          lead_type_condition = '';
          lead_status = '';
        break;
      }
    }
    var result = [];
    if(lead_status!=''){
        var query = `SELECT 
          l.lead_id,
          a.applicant_personal_id,
          CONCAT(a.applicant_first_name,' ', COALESCE(a.applicant_middle_name, ''),' ',COALESCE(a.applicant_last_name, '')) AS applicant_name,
          CASE
              WHEN a.account_type_id = 1 THEN "Individual"
              WHEN a.account_type_id = 2 THEN "Joint"
              WHEN a.account_type_id = 3 THEN "Minor"
          END AS account_type,
          l.lead_status,
          CONCAT (ag.first_name,' ',COALESCE(ag.last_name, '')) AS agent_name
          FROM 
            tbl_applicant_personal_details  AS a
          INNER JOIN  tbl_users AS u ON a.user_id = u.user_id
          LEFT JOIN tbl_leads AS l ON a.user_id = l.user_id
          LEFT JOIN tbl_agent_leads AS al ON l.lead_id = al.lead_id
          LEFT JOIN tbl_users AS ag ON al.agent_id = ag.user_id
          WHERE a.applicant_serial_number = 1
          AND l.lead_status = '${lead_status}'
          AND ag.user_id IS ${lead_type_condition} NULL
          GROUP BY a.applicant_personal_id
          ORDER BY a.applicant_personal_id DESC`;
        result = await mysqlquery(query);
    }
    res.status(200).json({
      data:result.length
    })
  }catch(error){
    res.status(400).json({
      msg:error.message?error.message:error
    });
  }
}

module.exports.lead_list_new = async(req, res)=>{
  try{
    var lead_type_condition = '';
    var lead_status = '';
    
    
    if(req.params.lead_type!=undefined){
      var lead_type = req.params.lead_type;
      switch(lead_type){
        case 'new':
          lead_type_condition = '';
          lead_status = 'lead';
        break;
        case 'under_process':
          lead_type_condition = 'NOT';
          lead_status = 'agent_process';
        break;
        case 'assigned':
          lead_type_condition = 'NOT';
          lead_status = 'lead';
        break;
        case 'reviewed':
          lead_type_condition = 'NOT';
          lead_status = 'agent_review';
        break;
        case 'rejected':
          lead_type_condition = 'NOT';
          lead_status = 'rejected';
        break;
        case 'approved':
          lead_type_condition = 'NOT';
          lead_status = 'approved';
        break;
        default:
          lead_type_condition = ' ';
          lead_status = ' ';
        break;
      }
    }
    var result = [];
    if(lead_status!=''){
        var query = `SELECT 
          l.lead_id,l.lead_number,l.reject_reason,
          a.applicant_personal_id,
          CONCAT(a.applicant_first_name,' ', COALESCE(a.applicant_middle_name, ''),' ', COALESCE(a.applicant_last_name, '')) AS applicant_name,
          CASE
              WHEN a.account_type_id = 1 THEN "Individual"
              WHEN a.account_type_id = 2 THEN "Joint"
              WHEN a.account_type_id = 3 THEN "Minor"
          END AS account_type,
          l.lead_status,
          CONCAT (ag.first_name,' ',COALESCE(ag.last_name, '')) AS agent_name
          FROM 
            tbl_applicant_personal_details  AS a
          INNER JOIN  tbl_users AS u ON a.user_id = u.user_id
          LEFT JOIN tbl_leads AS l ON a.user_id = l.user_id
          LEFT JOIN tbl_agent_leads AS al ON l.lead_id = al.lead_id
          LEFT JOIN tbl_users AS ag ON al.agent_id = ag.user_id
          WHERE a.applicant_serial_number = 1
          AND l.lead_status = '${lead_status}'
          GROUP BY a.user_id
          ORDER BY a.applicant_personal_id DESC`;
        result = await mysqlquery(query);
    }
    res.status(200).json({
      data:result
    })
  }catch(error){
    res.status(400).json({
      msg:error.message?error.message:error
    });
  }
}


module.exports.reassign_leads=async(req,res)=>{
  try {
    if(req.body.agent_id!=undefined && req.body.lead_id!=undefined){
      // delete req.body.lead_id;
      const agent_id = req.body.agent_id
      const lead_id = req.body.lead_id
      let sql = `UPDATE ${db_table.agent_leads} SET agent_id = ? WHERE lead_id = ?`;
      const reassign_agent_lead = await mysqlquery(sql, [agent_id,lead_id]);
      if(reassign_agent_lead.affectedRows>0){
        res.status(200).json({
          msg:'Reassigen lead to agent successfully'
        })
      }else{
        res.status(400).json({
          msg:'Something went wrong'
        })
      }
    }else{
      res.status(400).json({
        msg:'bad request'
      })
    }

  } catch(error) {
    res.status(400).json({
      msg:error.message?error.message:error
    })

  }
}



//pradeep