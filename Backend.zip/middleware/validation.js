const { check } = require('express-validator');
signup_Validation = [
  check('first_name').isLength({ min: 3, max: 15 }).withMessage('firstname should be minimum 3 characters and maximum 15 characters.').not().isEmpty().withMessage('firstname is require')
    .matches(/^[A-Za-z\s]+$/).withMessage('firstname must be alphabetic.'),
  check('last_name').isLength({ min: 3, max: 15 }).withMessage('lastname should be minimum 3 characters and maximum 15 characters').not().isEmpty().withMessage('lastname is require')
    .matches(/^[A-Za-z\s]+$/).withMessage('lastname must be alphabetic.'),
  check('mobile_no').isNumeric().withMessage('should enter only digits').not().isEmpty().withMessage('phone_no is require'),
  // check('username', 'username is requied').not().isEmpty(),
  check('email_address').matches(/^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/).withMessage('Please include a valid email'),
  check('password').matches(/^(?=.*[0-9])(?=.*[!@#$%^&*])[0-9a-zA-Z!@#$%^&*]{6,16}$/).withMessage('use at least a number, and at least a special character, one capital character').isLength({ min: 8 }).withMessage(' minimum password length is 8').not().isEmpty().withMessage('password is require'),
],

  registeritmemberagents = [
    check('first_name').isLength({ min: 3, max: 15 }).withMessage('first name should be minimum 3 characters and maximum 15 characters.').not().isEmpty().withMessage('first name is require')
      .matches(/^[A-Za-z\s]+$/).withMessage('firs tname must be alphabetic.'),
    check('middle_name').isLength({ min: 3, max: 15 }).withMessage('middle name should be minimum 3 characters and maximum 15 characters.').not().isEmpty().withMessage('middle name is require')
      .matches(/^[A-Za-z\s]+$/).withMessage('middle name must be alphabetic.'),
    check('last_name').isLength({ min: 3, max: 15 }).withMessage('last name should be minimum 3 characters and maximum 15 characters.').not().isEmpty().withMessage('last name is require')
      .matches(/^[A-Za-z\s]+$/).withMessage('last name must be alphabetic.'),
    check('mobile_no', 'should enter only digits').isNumeric().not().isEmpty().withMessage('mobile no is require'),
    // check('username', 'username is requied').not().isEmpty(),
    check('email_address').matches(/^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/).withMessage('Please include a valid email'),
  ],

  customer_signup_validation =
  [
    check('first_name').isLength({ min: 3, max: 15 }).withMessage('first name should be minimum 3 characters and maximum 15 characters.').not().isEmpty().withMessage('first name is require')
      .matches(/^[A-Za-z\s]+$/).withMessage('firs tname must be alphabetic.'),
    // check('middle_name').isLength({min:3,max:15}).withMessage('middle name should be minimum 3 characters and maximum 15 characters.').not().isEmpty().withMessage('middle name is require')
    // .matches(/^[A-Za-z\s]+$/).withMessage('middle name must be alphabetic.'),
    check('last_name').isLength({ min: 3, max: 15 }).withMessage('last name should be minimum 3 characters and maximum 15 characters.').not().isEmpty().withMessage('last name is require')
      .matches(/^[A-Za-z\s]+$/).withMessage('last name must be alphabetic.'),
    check('mobile_no').not().isEmpty().withMessage('mobile no is require').isLength({ min: 7, max: 25 }).withMessage('enter minimum 7 digits or maximum 25 digit'),
    // check('username', 'username is requied').not().isEmpty(),
    check('email_address').not().isEmpty().withMessage('email is require').matches(/^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/).withMessage('Please include a valid email'),
    /* check('isd_code').not().isEmpty().withMessage('isd_code is require').matches(/\+[0-9]{2}/).withMessage('Please include a valid isd_code'), */
    check('isd_code').not().isEmpty().withMessage('isd_code is require').withMessage('Please include a valid isd_code'),
  ],

  applicant_validation_form_1 = [
    check('first_name').isLength({ min: 3, max: 15 }).withMessage('firstname should be minimum 3 characters and maximum 15 characters.').not().isEmpty().withMessage('firstname is require')
      .matches(/^[A-Za-z\s]+$/).withMessage('firstname must be alphabetic.'),
    check('middle_name').isLength({ min: 3, max: 15 }).withMessage('middlename should be minimum 3 characters and maximum 15 characters').not().isEmpty().withMessage('middlename is require')
      .matches(/^[A-Za-z\s]+$/).withMessage('middlename must be alphabetic.'),
    check('last_name').isLength({ min: 3, max: 15 }).withMessage('lastname should be minimum 3 characters and maximum 15 characters.').not().isEmpty().withMessage('lastname is require')
      .matches(/^[A-Za-z\s]+$/).withMessage('lastname must be alphabetic.'),
    check('addhar_no').not().isEmpty().withMessage('addhar_no is require').matches(/^[2-9]{1}[0-9]{3}\s[0-9]{4}\s[0-9]{4}$/).withMessage('invalid addhar_no.'),

  ],


  applicant_validation_form_2 = [
    check('maiden_first_name').isLength({ min: 3, max: 15 }).withMessage('maiden first name should be minimum 3 characters and maximum 15 characters.').not().isEmpty().withMessage('firstname is require')
      .matches(/^[A-Za-z\s]+$/).withMessage('maiden first name must be alphabetic.'),
    check('maiden_middle_name').isLength({ min: 3, max: 15 }).withMessage('maiden middle name should be minimum 3 characters and maximum 15 characters').not().isEmpty().withMessage('middlename is require')
      .matches(/^[A-Za-z\s]+$/).withMessage('maiden middle name must be alphabetic.'),
    check('maiden_last_name').isLength({ min: 3, max: 15 }).withMessage('maiden last name should be minimum 3 characters and maximum 15 characters.').not().isEmpty().withMessage('lastname is require')
      .matches(/^[A-Za-z\s]+$/).withMessage('maiden last name must be alphabetic.'),
    check('mother_first_name').isLength({ min: 3, max: 15 }).withMessage('mother first name should be minimum 3 characters and maximum 15 characters.').not().isEmpty().withMessage('firstname is require')
      .matches(/^[A-Za-z\s]+$/).withMessage('mother first name must be alphabetic.'),
    check('mother_middle_name').isLength({ min: 3, max: 15 }).withMessage('mother middle name should be minimum 3 characters and maximum 15 characters').not().isEmpty().withMessage('middlename is require')
      .matches(/^[A-Za-z\s]+$/).withMessage('mother middle name must be alphabetic.'),
    check('mother_last_name').isLength({ min: 3, max: 15 }).withMessage('mother last name should be minimum 3 characters and maximum 15 characters.').not().isEmpty().withMessage('lastname is require')
      .matches(/^[A-Za-z\s]+$/).withMessage('mother last name must be alphabetic.'),
    check('in_relation_first_name').isLength({ min: 3, max: 15 }).withMessage('relation first name should be minimum 3 characters and maximum 15 characters.').not().isEmpty().withMessage('nominee_firstname is require')
      .matches(/^[A-Za-z\s]+$/).withMessage('relation first name must be alphabetic.'),
    check('in_relation_middle_name').isLength({ min: 3, max: 15 }).withMessage('relation middle name should be minimum 3 characters and maximum 15 characters').not().isEmpty().withMessage('nominee_middlename is require')
      .matches(/^[A-Za-z\s]+$/).withMessage('relation middle name must be alphabetic.'),
    check('in_relation_last_name').isLength({ min: 3, max: 15 }).withMessage('relation last name should be minimum 3 characters and maximum 15 characters.').not().isEmpty().withMessage('nominee_lastname is require')
      .matches(/^[A-Za-z\s]+$/).withMessage('relation last name must be alphabetic.'),
  ],



  forgot_change_password = [
    check('new_password').matches(/^(?=.*[0-9])(?=.*[!@#$%^&*])[0-9a-zA-Z!@#$%^&*]{6,16}$/).withMessage('use at least a number, and at least a special character, one capital character').isLength({ min: 8 }).withMessage(' minimum password length is 8').not().isEmpty().withMessage('password is require'),
  ],

  factas_validation = [

    check('applicant_id').isNumeric().not().isEmpty().withMessage('applicant id is require'),
    check('is_residence_for_tax').isNumeric().not().isEmpty().withMessage('residence for tax is require')
  ],

  kyc_details_validation = [
    check('applicant_id').isNumeric().not().isEmpty().withMessage('applicant id is require'),
    check('issueing_authority').not().isEmpty().withMessage('issueing authority is require'),
    check('is_other_than_indian_passport').isNumeric().not().isEmpty().withMessage('other than indian passport for tax is require'),
    check('passport_number').not().isEmpty().withMessage('passport number name is require')
      .matches(/^[a-zA-Z0-9-]+$/).withMessage('please enter valid passport number'),
    check('pan_number').not().isEmpty().withMessage('pan_card is require').isLength({ min: 10, max: 10 }).withMessage(' require pan card length is 10').matches(/^([A-Z]){5}([0-9]){4}([A-Z]){1}?$/).withMessage('invalid pan_card no.'),
  ],


  contact_details_validation = [
    check('mobile_number').isNumeric().not().isEmpty().withMessage('mobile number is require').isLength({ min: 10, max: 10 }).withMessage('enter 10 digits'),
    check('email_address').not().isEmpty().withMessage('email is require').matches(/^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/).withMessage('Please include a valid email'),

  ]

address_details_validation_forms_1 = [
  check('applicant_id').isNumeric().not().isEmpty().withMessage('applicant id is require'),
  check('current_address_type').isNumeric().not().isEmpty().withMessage('current address type is require'),
  check('current_house_number').not().isEmpty().withMessage('current house number is require'),
  check('current_house_or_building_name').not().isEmpty().withMessage('current house or building name is require'),
  check('current_road_or_street_name').not().isEmpty().withMessage('current road or street name is require'),
  check('current_state').not().isEmpty().withMessage('current state is require'),
  check('current_city').not().isEmpty().withMessage('current city is require'),
  check('current_country_id').isNumeric().not().isEmpty().withMessage('current country is require'),
  check('current_pincode').not().isEmpty().withMessage('current pincode is require'),
  check('overseas_address_type').isNumeric().not().isEmpty().withMessage('overseas address type is require'),
  check('overseas_house_number').not().isEmpty().withMessage('overseas house number is require'),
  check('overseas_house_or_building_name').not().isEmpty().withMessage('overseas house or building name is require'),
  check('overseas_road_or_street_name').not().isEmpty().withMessage('overseas road or street name is require'),
  check('overseas_state').not().isEmpty().withMessage('overseas state is require'),
  check('overseas_city').not().isEmpty().withMessage('overseas city is require'),
  check('overseas_country_id').isNumeric().not().isEmpty().withMessage('overseas country is require'),
  check('overseas_pincode').not().isEmpty().withMessage('overseas pincode is require'),

]

address_details_validation_forms_2 = [
  check('permenant_address_type').isNumeric().not().isEmpty().withMessage('permenant address type is require'),
  check('permenant_house_number').not().isEmpty().withMessage('permenant house number is require'),
  check('permenant_house_or_building_name').not().isEmpty().withMessage('permenant house or building name is require'),
  check('permenant_road_or_street_name').not().isEmpty().withMessage('permenant road or street name is require'),
  check('permenant_state').not().isEmpty().withMessage('permenant state is require'),
  check('permenant_city').not().isEmpty().withMessage('permenant city is require'),
  check('permenant_country_id').isNumeric().not().isEmpty().withMessage('permenant country id is require'),
  check('permenant_pincode').not().isEmpty().withMessage('permenant pincode is require'),
  check('jurisdiction_address_type').isNumeric().not().isEmpty().withMessage('jurisdiction address type is require'),
  check('jurisdiction_house_number').not().isEmpty().withMessage('jurisdiction house number is require'),
  check('jurisdiction_house_or_building_name').not().isEmpty().withMessage('jurisdiction house or building name is require'),
  check('jurisdiction_road_or_street_name').not().isEmpty().withMessage('jurisdiction road or street name is require'),
  check('jurisdiction_state').not().isEmpty().withMessage('jurisdiction state is require'),
  check('jurisdiction_city').not().isEmpty().withMessage('jurisdiction city is require'),
  check('jurisdiction_country_id').isNumeric().not().isEmpty().withMessage('jurisdiction country id is require'),
  check('jurisdiction_pincode').not().isEmpty().withMessage('jurisdiction pincode is require'),
  check('preffered_mailing').not().isEmpty().withMessage('preffered mailing is require')
]

customer_profilers_validation = [
  check('applicant_id').isNumeric().not().isEmpty().withMessage('applicant id is require'),
  check('qualification').not().isEmpty().withMessage('qualification is require'),
  check('employment_type_id').isNumeric().not().isEmpty().withMessage('employment_type is require'),
  check('occupation_id').isNumeric().not().isEmpty().withMessage('occupation is require'),
  check('source_income').not().isEmpty().withMessage('source_ income is require'),
  check('gross_annual_income').isNumeric().not().isEmpty().withMessage('gross annual income is require'),
  check('industry_type_id').isNumeric().not().isEmpty().withMessage('industry type  is require')
]

banking_facilities_validation = [
  check('applicant_id').isNumeric().not().isEmpty().withMessage('applicant id is require'),
  check('debit_card_type').not().isEmpty().withMessage('debit card type is require'),
  check('card_variant').not().isEmpty().withMessage('card variant is require')
]

nominations_details_validation_forms_1 = [
  check('applicant_id').isNumeric().not().isEmpty().withMessage('applicant id is require'),
  check('nominee_address_type').not().isEmpty().withMessage('nominee address type is require'),
  check('nominee_house_number').not().isEmpty().withMessage('nominee house number is require'),
  check('nominee_house_or_building_name').not().isEmpty().withMessage('nominee house or building name is require'),
  check('nominee_road_or_street_name').not().isEmpty().withMessage('nominee road or street name is require'),
  check('nominee_state').not().isEmpty().withMessage('nominee state is require'),
  check('nominee_city').not().isEmpty().withMessage('nominee city is require'),
  check('nominee_country_id').isNumeric().not().isEmpty().withMessage('nominee country is require'),
  check('nominee_pincode').not().isEmpty().withMessage('nominee pincode is require'),
  check('nominee_date_of_birth').not().isEmpty().withMessage('nominee date of birth is require'),
  check('nominee_age_in_year').isNumeric().not().isEmpty().withMessage('nominee age in year is require'),
  check('nominee_pincode').not().isEmpty().withMessage('nominee pincode is require').matches(/[0-9]{6}/).isLength({ min: 6, max: 6 }).withMessage('enter 6 digits'),
  check('nominee_first_name').isLength({ min: 3, max: 15 }).withMessage('nominee first name should be minimum 3 characters and maximum 15 characters.').not().isEmpty().withMessage('nominee first name is require')
    .matches(/^[A-Za-z\s]+$/).withMessage('firstname must be alphabetic.'),
  check('nominee_middle_name').isLength({ min: 3, max: 15 }).withMessage('nominee middle name should be minimum 3 characters and maximum 15 characters').not().isEmpty().withMessage('nominee middle name is require')
    .matches(/^[A-Za-z\s]+$/).withMessage('middlename must be alphabetic.'),
  check('nominee_last_name').isLength({ min: 3, max: 15 }).withMessage('nominee last name should be minimum 3 characters and maximum 15 characters.').not().isEmpty().withMessage('nominee last name is require')
    .matches(/^[A-Za-z\s]+$/).withMessage('lastname must be alphabetic.'),
  check('gaurdian_first_name').isLength({ min: 3, max: 15 }).withMessage('gaurdian first name should be minimum 3 characters and maximum 15 characters.').not().isEmpty().withMessage('gaurdian first name is require')
    .matches(/^[A-Za-z\s]+$/).withMessage('firstname must be alphabetic.'),
  check('gaurdian_middle_name').isLength({ min: 3, max: 15 }).withMessage('gaurdian middle name should be minimum 3 characters and maximum 15 characters').not().isEmpty().withMessage('gaurdian middle name is require')
    .matches(/^[A-Za-z\s]+$/).withMessage('middlename must be alphabetic.'),
  check('gaurdian_last_name').isLength({ min: 3, max: 15 }).withMessage('gaurdian last name should be minimum 3 characters and maximum 15 characters.').not().isEmpty().withMessage('gaurdian last name is require')
    .matches(/^[A-Za-z\s]+$/).withMessage('last must be alphabetic.'),
]

nominations_details_validation_forms_2 = [
  check('gaurdian_first_name').isLength({ min: 3, max: 15 }).withMessage('gaurdian first name should be minimum 3 characters and maximum 15 characters.').not().isEmpty().withMessage('gaurdian first name is require')
    .matches(/^[A-Za-z\s]+$/).withMessage('firstname must be alphabetic.'),
  check('gaurdian_middle_name').isLength({ min: 3, max: 15 }).withMessage('gaurdian middle name should be minimum 3 characters and maximum 15 characters').not().isEmpty().withMessage('gaurdian middle name is require')
    .matches(/^[A-Za-z\s]+$/).withMessage('middlename must be alphabetic.'),
  check('gaurdian_last_name').isLength({ min: 3, max: 15 }).withMessage('gaurdian last name should be minimum 3 characters and maximum 15 characters.').not().isEmpty().withMessage('gaurdian last name is require')
    .matches(/^[A-Za-z\s]+$/).withMessage('last must be alphabetic.'),
]
send_email_otp_validation = [
  check('otp_type').not().isEmpty().withMessage('otp type  is require'),
]

send_mobile_otp_validation = [
  check('otp_type').not().isEmpty().withMessage('otp type  is require'),
]
email_verify_otp_validation = [
  check('email_otp').isLength({ min: 6, max: 6 }).withMessage('please enter otp 6 didgit').isNumeric().not().isEmpty().withMessage('email otp is require')
]

mobile_verify_otp_validation = [
  check('mobile_otp').isLength({ min: 6, max: 6 }).withMessage('please enter otp 6 didgit').isNumeric().not().isEmpty().withMessage('email otp is require')
]

module.exports = {
  signup_Validation,
  registeritmemberagents,
  customer_signup_validation,
  applicant_validation_form_1,
  applicant_validation_form_2,
  ///customer_formvalidation,
  forgot_change_password,
  factas_validation,
  kyc_details_validation,
  contact_details_validation,
  address_details_validation_forms_1,
  address_details_validation_forms_2,
  customer_profilers_validation,
  banking_facilities_validation,
  nominations_details_validation_forms_1,
  nominations_details_validation_forms_2,
  send_email_otp_validation,
  send_mobile_otp_validation,
  email_verify_otp_validation,
  mobile_verify_otp_validation
}