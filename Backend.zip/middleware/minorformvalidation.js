const { check } = require('express-validator');

minor_personal_detail_one_validation = [
    check('applicant_title')
        .not().isEmpty().withMessage('Title is require'),
    check('applicant_first_name')
        .not().isEmpty().withMessage('First name is require')
        .isLength({ min: 2, max: 15 }).withMessage('First name must be 2-15 character long')
        .matches(/^[A-Za-z\s]+$/).withMessage('First name must be alphabetic'),
    check('applicant_middle_name')
        .not().isEmpty().withMessage('Middle name is require')
        .isLength({ min: 2, max: 15 }).withMessage('Middle name must be 2-15 character long')
        .matches(/^[A-Za-z\s]+$/).withMessage('Middle name must be alphabetic'),
    check('applicant_last_name')
        .not().isEmpty().withMessage('Last name is require')
        .isLength({ min: 2, max: 15 }).withMessage('Last name must be 2-15 character long')
        .matches(/^[A-Za-z\s]+$/).withMessage('Last name must be alphabetic'),
    check('aadhaar_number')
        .not().isEmpty().withMessage('Adhaar number is require')
        .matches(/^[2-9]{1}[0-9]{3}\s[0-9]{4}\s[0-9]{4}$/).withMessage('Adhaar number is invalid'),
    check('religion_id')
        .not().isEmpty().withMessage('Religion is require'),
    check('religion_category_id')
        .not().isEmpty().withMessage('Religion category is require'),
    check('date_of_birth')
        .not().isEmpty().withMessage('Date of birth is require'),
    check('gender')
        .not().isEmpty().withMessage('Gender is require'),
]


minor_personal_detail_two_validation = [
    check('mother_first_name')
        .not().isEmpty().withMessage('Mother first name is require')
        .isLength({ min: 2, max: 15 }).withMessage('Mother first name must be 2-15 character long')
        .matches(/^[A-Za-z\s]+$/).withMessage('Mother first name must be alphabetic'),
    // check('mother_middle_name')
    //     .not().isEmpty().withMessage('Mother middle name is require')
    //     .isLength({ min: 2, max: 15 }).withMessage('Mother middle name must be 2-15 character long')
    //     .matches(/^[A-Za-z\s]+$/).withMessage('Mother middle name must be alphabetic'),
    // check('mother_last_name')
    //     .not().isEmpty().withMessage('Mother last name is require')
    //     .isLength({ min: 2, max: 15 }).withMessage('Mother last name must be 2-15 character long')
    //     .matches(/^[A-Za-z\s]+$/).withMessage('Mother last name must be alphabetic'),
    check('in_relation_first_name')
        .not().isEmpty().withMessage('Father first name is require')
        .isLength({ min: 2, max: 15 }).withMessage('Father first name must be 2-15 character long')
        .matches(/^[A-Za-z\s]+$/).withMessage('Father first name must be alphabetic'),
    // check('in_relation_middle_name')
    //     .not().isEmpty().withMessage('Father middle name is require')
    //     .isLength({ min: 2, max: 15 }).withMessage('Father middle name must be 2-15 character long')
    //     .matches(/^[A-Za-z\s]+$/).withMessage('Father middle name must be alphabetic'),
    // check('in_relation_last_name')
    //     .not().isEmpty().withMessage('Father last name is require')
    //     .isLength({ min: 2, max: 15 }).withMessage('Father last name must be 2-15 character long')
    //     .matches(/^[A-Za-z\s]+$/).withMessage('Father last name must be alphabetic'),
    check('nationality')
        .not().isEmpty().withMessage('Date of becoming NRI is require'),
    check('date_of_becoming_nri')
        .not().isEmpty().withMessage('Date of becoming NRI is require')
]

minor_gaurdian_detail_validation = [
    check('applicant_title')
        .not().isEmpty().withMessage('Title is require'),
    check('applicant_first_name')
        .not().isEmpty().withMessage('First name is require')
        .isLength({ min: 2, max: 15 }).withMessage('First name must be 2-15 character long')
        .matches(/^[A-Za-z\s]+$/).withMessage('First name must be alphabetic'),
    // check('applicant_middle_name')
    //     .not().isEmpty().withMessage('Middle name is require')
    //     .isLength({ min: 2, max: 15 }).withMessage('Middle name must be 2-15 character long')
    //     .matches(/^[A-Za-z\s]+$/).withMessage('Middle name must be alphabetic'),
    // check('applicant_last_name')
    //     .not().isEmpty().withMessage('Last name is require')
    //     .isLength({ min: 2, max: 15 }).withMessage('Last name must be 2-15 character long')
    //     .matches(/^[A-Za-z\s]+$/).withMessage('Last name must be alphabetic'),
    check('guardian_relation')
        .not().isEmpty().withMessage('Relationship with minor is require')

]

module.exports = {
    minor_personal_detail_one_validation,
    minor_personal_detail_two_validation,
    minor_gaurdian_detail_validation
}