const jwt = require('jsonwebtoken');
const jwtexpirationtime = require('../config/auth.config')
require('dotenv').config()
var mysqlconn = require('../db/mysqlconn');
const util = require('util');
const mysqlquery = util.promisify(mysqlconn.query).bind(mysqlconn);
const db_table = require('../db_manipulation/db_constant');
const customer_forms = require('../json/customer_forms.json');
module.exports = {
  set_jwt_auth: async function (doc, res) {
    //console.log(doc);
    try {

      if(doc[0].role_id!=4){
        return res.status(200).json({
          message: "Logged in successfully",
          user: doc[0],
          agent_id: doc[0].user_id,
          role_id:doc[0].role_id,
          user_verify: true
        });
      }else{
        // console.log(doc[0].user_id)
        let email_verify = [doc[0].is_email_verify]
        let user_email_verify = email_verify[0]==null?0:1;
        let mobile_verify = [doc[0].is_mobile_verify]
        let user_mobile_verify = mobile_verify[0]==null?0:1;
        let applicant_query = `SELECT * FROM ${db_table.applicant_persional_details} WHERE user_id=? ORDER BY applicant_personal_id DESC`;
        let find_userid = await mysqlquery(applicant_query, [doc[0].user_id])
        let lead_status_sql = `SELECT lead_status FROM ${db_table.leads} WHERE user_id=?`;
        let lead_result = await mysqlquery(lead_status_sql, [doc[0].user_id])
        let nomini_sql = `SELECT nomination_id FROM ${db_table.nominations} WHERE applicant_id=?`;
        let nomini_result = await mysqlquery(nomini_sql, [find_userid[0]?.applicant_personal_id])

        
        var lead_status = lead_result[0].lead_status;

        if (find_userid.length > 0) {
          var find_applicant_query = find_userid[0]?.applicant_personal_id;
          var find_account_type = find_userid[0]?.account_type_id;
      

          var process_query = `SELECT * FROM ${db_table.process_status} WHERE applicant_id=? ORDER BY process_id DESC`

          var find_applicant_process = await mysqlquery(process_query, [find_applicant_query])
          // console.log("find_applicant_process",find_applicant_process);

          var process_id = find_applicant_process[0]?.process_id;
          console.log('process id',process_id);

          var current_process_id = 30
          try {
            console.log("Customer Forms Length >> ", customer_forms.length)
            customer_forms.forEach(function (element, i) {
              // console.log(element);
              if (process_id !== 30) {
                if (element.process_id == process_id) {
                  // console.log("Customer Process Id >> ", process_id);
                  // console.log("Json Process Id >> ", element.process_id);
                  // console.log("Index >> ", i);
                  // console.log("Customer Forms Process >> ", customer_forms[(i + 1)])
                  if(customer_forms.length == 72){
                    current_process_id = customer_forms[(i+1)]?.process_id;
                  }else{
                    current_process_id = customer_forms[(i)]?.process_id;
                  }
                  throw 'Break';
                }
              }else{
                current_process_id = 30
              }
            })

          } catch (e) {
            if (e !== 'Break') throw e
          }

        } else {
          var find_applicant_query = null;
        }


        const token = jwt.sign({ user_id: doc[0].user_id }, process.env.API_KEY, { expiresIn: jwtexpirationtime.jwtAccessExpiration });
        const refreshToken = jwt.sign({}, process.env.API_KEY, { expiresIn: jwtexpirationtime.jwtRefreshExpiration });
        res.cookie("accessToken", token, { httpOnly: true })
        //Refresh Token
        res.cookie("refreshToken", refreshToken, { httpOnly: true });

        let loginotp_delete = `DELETE FROM ${db_table.otps} WHERE user_id=? `
        var deleteotp = await mysqlquery(loginotp_delete, [doc[0].user_id])
        return res.status(200).json({
          message: "Logged in successfully",
          user: doc[0],
          applicant_id: find_applicant_query,
          current_process_id: current_process_id,
          account_type: find_account_type,
          user_verify: true,
          user_email_verify: user_email_verify,
          user_mobile_verify: user_mobile_verify,
          lead_status : lead_status,
          nomination_id:nomini_result[0]?.nomination_id
        });
      }

    } catch (error) {
      console.log("Error JWT : ",error,"===============");
      res.status(400).json({
        msg: 'bad request'
      })
    }
  }
}