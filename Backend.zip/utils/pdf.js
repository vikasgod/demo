const puppeteer = require('puppeteer')
const ejs = require('ejs')
const { json } = require('body-parser')
const moment = require('moment')

const createPdf = async (final_result) => {
    try {
        const browser = await puppeteer.launch({
		headless : true,
		args : ['--no-sandbox']
	})
        const page = await browser.newPage()
        let applicant1 = final_result.applicant_1
        let applicant2 = final_result.applicant_2
        let applicant3 = final_result.applicant_3
        applicant1.acc_type = final_result.account_type

        const filename = applicant1.lead_number
        
        const options = {
            path: `./public/forms/${filename}.pdf`,
            format : 'Legal', // A4
            margin : {
                top : '10px',
                right : '10px',
                bottom : '10px',
                left : '10px'
            },
            printBackground : true
        }

        // Add Not Available for null and empty values
        Object.keys(applicant1).forEach(d => {
            if(applicant1[d] === null || applicant1[d] === '') {
                applicant1[d] = 'NA'
            }
        })

    if(applicant2){
        Object.keys(applicant2).forEach(d => {
            if(applicant2[d] === null || applicant2[d] === '') {
                applicant2[d] = 'NA'
            }
        })
    }

    if(applicant3){
        Object.keys(applicant3).forEach(d => {
            if(applicant3[d] === null || applicant3[d] === '') {
                applicant3[d] = 'NA'
            }
        })
    }

        let today = new Date()

        // Format date into DD-MM-YYYY
   
            applicant1.date_of_birth = moment(applicant1.date_of_birth).format('DD-MM-YYYY')
            applicant1.date_of_becoming_nri = moment(applicant1.date_of_becoming_nri).format('DD-MM-YYYY')
            applicant1.issue_date = applicant1.issue_date != 'NA' ? moment(applicant1.issue_date).format('DD-MM-YYYY') : 'NA'
            applicant1.expiry_date = moment(applicant1.expiry_date).format('DD-MM-YYYY')
            applicant1.visa_permit_expiry_date = moment(applicant1.visa_permit_expiry_date).format('DD-MM-YYYY')
            applicant1.created_on = moment(applicant1.created_on).format('DD-MM-YYYY')
            applicant1.date_now = moment(today).format('DD-MM-YYYY')
            if(applicant1.nominee_date_of_birth != 'NA'){
                applicant1.nominee_date_of_birth = moment(applicant1.nominee_date_of_birth).format('DD-MM-YYYY')
            }

            if(applicant2){
            applicant2.date_of_birth = moment(applicant2.date_of_birth).format('DD-MM-YYYY')
            applicant2.date_of_becoming_nri = moment(applicant2.date_of_becoming_nri).format('DD-MM-YYYY')
            applicant2.issue_date =  applicant2.issue_date  != 'NA' ? moment(applicant2.issue_date).format('DD-MM-YYYY')  : 'NA'
            applicant2.expiry_date = moment(applicant2.expiry_date).format('DD-MM-YYYY')
            applicant2.visa_permit_expiry_date = moment(applicant2.visa_permit_expiry_date).format('DD-MM-YYYY')
            applicant2.created_on = moment(applicant2.created_on).format('DD-MM-YYYY')
            applicant2.date_now = moment(today).format('DD-MM-YYYY')
            if(applicant2.nominee_date_of_birth != 'NA'){
                applicant2.nominee_date_of_birth = moment(applicant2.nominee_date_of_birth).format('DD-MM-YYYY')
            }
            } 

            if(applicant3){
            applicant3.date_of_birth = moment(applicant3.date_of_birth).format('DD-MM-YYYY')
            applicant3.date_of_becoming_nri = moment(applicant3.date_of_becoming_nri).format('DD-MM-YYYY')
            applicant3.issue_date = applicant3.issue_date != 'NA' ? moment(applicant3.issue_date).format('DD-MM-YYYY') : 'NA'
            applicant3.expiry_date = moment(applicant3.expiry_date).format('DD-MM-YYYY')
            applicant3.visa_permit_expiry_date = moment(applicant3.visa_permit_expiry_date).format('DD-MM-YYYY')
            applicant3.created_on = moment(applicant3.created_on).format('DD-MM-YYYY')
            applicant3.date_now = moment(today).format('DD-MM-YYYY')
            if(applicant3.nominee_date_of_birth != 'NA'){
                applicant3.nominee_date_of_birth = moment(applicant3.nominee_date_of_birth).format('DD-MM-YYYY')
            }
            }

        let htmlData = '';
        let form_applicant_data = []

        if((applicant1)){

            first_applicant_details = {
                first_name  : applicant1.applicant_first_name,
                middle_name : applicant1.applicant_middle_name,
                last_name : applicant1.applicant_last_name
            }
            form_applicant_data.first_applicant_name = first_applicant_details
        }

        if((applicant2)){
            second_applicant_details = {
                first_name  : applicant2.applicant_first_name,
                middle_name : applicant2.applicant_middle_name,
                last_name : applicant2.applicant_last_name
            }
            form_applicant_data.second_applicant_name = second_applicant_details
        }
        if((applicant3)){
            third_applicant_details = {
                first_name  : applicant3.applicant_first_name ? applicant3.applicant_first_name : 'NA',
                middle_name : applicant3.applicant_middle_name ? applicant3.applicant_middle_name : 'NA',
                last_name : applicant3.applicant_last_name ? applicant3.applicant_last_name : 'NA'
            }
            form_applicant_data.third_applicant_name = third_applicant_details
        }

        if(applicant1){
       
            htmlData += await ejs.renderFile('./views/form.ejs', {app1: applicant1,fad : form_applicant_data})
        }
        if(applicant2){
            htmlData += await ejs.renderFile('./views/form.ejs', {app1: applicant2, fad : form_applicant_data})
        }
        if(applicant3){
            htmlData += await ejs.renderFile('./views/form.ejs', {app1: applicant3, fad : form_applicant_data})
        }
        

        await page.setContent(htmlData)
    
        await page.pdf(options)

        await browser.close()

    } catch (error) {
        console.log(error)
    }
}

module.exports = createPdf
