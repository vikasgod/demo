var moment = require('moment');
var fs = require('fs');
var path = require('path');
var root_path = path.dirname(require.main.filename);
var mysqlconn = require('../db/mysqlconn');
const query = require('../db/query.json')

module.exports = {
    notification: function (action, notification_data, userId, url_data, query_params) {
        //TODO insert into the db
        var today = Date.now();
        let newnotification = { action: action, notification_data: notification_data, UserID: userId, url_data: url_data, query_params: query_params, read_notification: "false", delete_notification: "false", createdOn: new Date() };
        mysqlconn.query(query.insert.create_notification, newnotification, function (err, result) {
            if (err) {
                console.error(err);
            } else {

            }
        })
    },
};