const sgMail = require("@sendgrid/mail");
const nodemailer = require("nodemailer");
const sendGridAPIKey =
  "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";

// const transporter = nodemailer.createTransport({
//     host: 'smtp.gmail.com',
//     port: 587,
//     auth: {
//         user: 'mayur.b@fortune4.in',
//         pass: 'kxhyoynbpoqdgcym',
//     },
// });

const transporter = nodemailer.createTransport({
  host: "10.80.45.52",
  port: 25,
  secure: false,
  tls: { rejectUnauthorized: false },
  logger: true,
});

module.exports = {
  registration_email_agent_it_users: async function (otp_params) {
    sgMail.setApiKey(sendGridAPIKey);
    const msg = {
      to: otp_params.username,
      from: "ninad.rane@rblbank.com",
      subject: "registration successfull",
      html: `<!DOCTYPE html> <html>
                    <head>
                        <link rel="preconnect" href="https://fonts.googleapis.com">
                    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
                    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@300&display=swap" rel="stylesheet">
                    <style> 
                    body{
                        font-family: 'Open Sans', sans-serif;
                    }
                    .emailtemp {
                        width: 600px;
                        margin: 0 auto;
                        text-align: center;
                    }
                    
                    .div1 {
                        padding: 40px 20px;
                        border: 1px solid #ccc;
                    }
                    
                    h2{margin-top: 30px;}
                    span{ font-size: 40px;background: #e0e7ff;}
                    p{text-align: left;}
                    </style>
                    </head>
                    <body>
                    <div class="emailtemp">
                    <h1>Welcome</h1>
                    
                    <div class="div1">
                        <h2>Dear ${otp_params.name},</h2>
                        <p>Greetings from RBL Bank.<br>
                        We would like you to inform that you have successfully registered for Online NRI Account Opening application. Your Login ID is your registered email ID ${otp_params.username}<br>
                        
                        Looking forward to more opportunities to be of service to you.<br>
                        Sincerely,<br>
                        RBL Bank Limited</p>
                    </div>
                    <p>This is auto generated e-mail. Please do not reply</p>
                    
                    </div>
                    
                    </body>
                    </html>`,
    };
    await transporter.sendMail(msg);
  },

  customer_Emailverify: async function (otp_params) {
    sgMail.setApiKey(sendGridAPIKey);
    const msg = {
      to: otp_params.email_address,
      from: "noreply@rblbank.com",
      subject: "Verification Code for Registration",
      html: `<!DOCTYPE html
            PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
        <html xmlns:v="urn:schemas-microsoft-com:vml">
        
        <head>
            <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
            <meta name="viewport" content="width=device-width; initial-scale=1.0; maximum-scale=1.0;">
            <!--[if !mso]-->
            <!-- -->
            <link href="https://fonts.googleapis.com/css?family=Work+Sans:300,400,500,600,700" rel="stylesheet">
            <link href="https://fonts.googleapis.com/css?family=Quicksand:300,400,700" rel="stylesheet">
            <!-- <![endif]-->
        
            <title>OTP Template</title>
        
            <style type="text/css">
                body {
                    width: 100%;
                    background-color: #ffffff;
                    margin: 0;
                    padding: 0;
                    -webkit-font-smoothing: antialiased;
                    mso-margin-top-alt: 0px;
                    mso-margin-bottom-alt: 0px;
                    mso-padding-alt: 0px 0px 0px 0px;
                }
        
                p,
                h1,
                h2,
                h3,
                h4 {
                    margin-top: 0;
                    margin-bottom: 0;
                    padding-top: 0;
                    padding-bottom: 0;
                }
        
                span.preheader {
                    display: none;
                    font-size: 1px;
                }
        
                html {
                    width: 100%;
                }
        
                table {
                    font-size: 14px;
                    border: 0;
                }
        
                /* ----------- responsivity ----------- */
        
                @media only screen and (max-width: 640px) {
        
                    /*------ top header ------ */
                    .main-header {
                        font-size: 20px !important;
                    }
        
                    .main-section-header {
                        font-size: 28px !important;
                    }
        
                    .show {
                        display: block !important;
                    }
        
                    .hide {
                        display: none !important;
                    }
        
                    .align-center {
                        text-align: center !important;
                    }
        
                    .no-bg {
                        background: none !important;
                    }
        
                    /*----- main image -------*/
                    .main-image img {
                        width: 440px !important;
                        height: auto !important;
                    }
        
                    /* ====== divider ====== */
                    .divider img {
                        width: 440px !important;
                    }
        
                    /*-------- container --------*/
                    .container590 {
                        width: 440px !important;
                    }
        
                    .container580 {
                        width: 400px !important;
                    }
        
                    .main-button {
                        width: 220px !important;
                    }
        
                    /*-------- secions ----------*/
                    .section-img img {
                        width: 320px !important;
                        height: auto !important;
                    }
        
                    .team-img img {
                        width: 100% !important;
                        height: auto !important;
                    }
                }
        
                @media only screen and (max-width: 479px) {
        
                    /*------ top header ------ */
                    .main-header {
                        font-size: 18px !important;
                    }
        
                    .main-section-header {
                        font-size: 26px !important;
                    }
        
                    /* ====== divider ====== */
                    .divider img {
                        width: 280px !important;
                    }
        
                    /*-------- container --------*/
                    .container590 {
                        width: 280px !important;
                    }
        
                    .container590 {
                        width: 280px !important;
                    }
        
                    .container580 {
                        width: 260px !important;
                    }
        
                    /*-------- secions ----------*/
                    .section-img img {
                        width: 280px !important;
                        height: auto !important;
                    }
                }
            </style>
            <!-- [if gte mso 9]><style type=”text/css”>
                    body {
                    font-family: arial, sans-serif!important;
                    }
                    </style>
                <![endif]-->
        </head>
        
        
        <body class="respond" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
            <!-- pre-header -->
            <table style="display:none!important;">
                <tbody>
                    <tr>
                        <td>
                            <div
                                style="overflow:hidden;display:none;font-size:1px;color:#ffffff;line-height:1px;font-family:Arial;maxheight:0px;max-width:0px;opacity:0;">
                                Pre-header for the newsletter template
                            </div>
                        </td>
                    </tr>
                </tbody>
            </table>
            <!-- pre-header end -->
            <!-- header -->
            <table border="0" width="100%" cellpadding="0" cellspacing="0" bgcolor="ffffff">
        
                <tbody>
                    <tr>
                        <td align="center">
                            <table border="0" align="center" width="590" cellpadding="0" cellspacing="0" class="container590">
        
                                <tbody>
                                    <tr>
                                        <td height="25" style="font-size: 25px; line-height: 25px;">&nbsp;</td>
                                    </tr>
        
                                    <tr>
                                        <td align="center">
        
                                            <table border="0" align="center" width="590" cellpadding="0" cellspacing="0"
                                                class="container590">
        
                                                <tbody>
                                                    <tr>
                                                        <td align="center" height="70" style="height:70px;">
                                                            <a href=""
                                                                style="display: block; border-style: none !important; border: 0 !important;"><img
                                                                    width="100" border="0" style="display: block; width: 100px;"
                                                                    src="${otp_params.image}/logo.png"
                                                                    alt=""></a>
                                                        </td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </td>
                                    </tr>
        
                                    <tr>
                                        <td height="25" style="font-size: 25px; line-height: 25px;">&nbsp;</td>
                                    </tr>
        
                                </tbody>
                            </table>
                        </td>
                    </tr>
                </tbody>
            </table>
            <!-- end header -->
        
            <!-- big image section -->
            <table border="0" width="100%" cellpadding="0" cellspacing="0" bgcolor="ffffff" class="bg_color">
        
                <tbody>
                    <tr>
                        <td align="center">
                            <table border="0" align="center" width="590" cellpadding="0" cellspacing="0" class="container590">
                                <tbody>
                                    <td align="center"
                                            style="color: #343434; font-size: 24px; font-family: Quicksand, Calibri, sans-serif; font-weight:700;letter-spacing: 3px; line-height: 35px;"
                                            class="main-header">
        
                                            <span style="color: #4759bb;">Dear ${otp_params.name},</span> </td>
                                    <tr>
                                        <td align="center"
                                        style="color: #888888; font-size: 18px; font-family: 'Work Sans', Calibri, sans-serif; line-height: 24px;"
                                        class="main-header">
                                        
                                        <div>Greetings from RBL Bank!</div>
                                            <div>Your verification code for <br>
                                                "Digital NR Account Opening" is:
                                            </div>
                                        </td>
                                    </tr>
                                    <tr>
        
                                        <td align="center"
                                            style="color: #343434; font-size: 24px; font-family: Quicksand, Calibri, sans-serif; font-weight:700;letter-spacing: 3px; line-height: 35px;"
                                            class="main-header">
        
                                            ${otp_params.otp} </td>
                                    </tr>
                                    
                                    <tr>
                                        <td align="center">
                                            <table border="0" width="400" align="center" cellpadding="0" cellspacing="0"
                                                class="container590">
                                                <tbody>
                                                    <tr>
                                                        <td align="center"
                                                            style="color: #888888; font-size: 16px; font-family: 'Work Sans', Calibri, sans-serif; line-height: 24px;">
        
                                                            <br>
                                                            <div style="line-height: 24px">The verification code will be valid
                                                                for 2 minutes. DO NOT SHARE OTP WITH ANYONE</div>
                                                            <div>Assuring you of our best services, at all times</div>
                                                            <br>
                                                            Kind Regards,<br>
                                                            RBL Bank <br>
                                                            
                                                        </td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </td>
                                    </tr>
        
                                    <tr>
                                        <td height="25" style="font-size: 25px; line-height: 25px;">&nbsp;</td>
                                    </tr>
        
        
        
        
                                </tbody>
                            </table>
        
                        </td>
                    </tr>
        
                </tbody>
            </table>
        
            <table border="0" width="100%" cellpadding="0" cellspacing="0" bgcolor="f4f4f4">
        
                <tbody>
                    <tr>
                        <td height="25" style="font-size: 25px; line-height: 25px;">&nbsp;</td>
                    </tr>
        
                    <tr>
                        <td align="center">
        
                            <table border="0" align="center" width="auto" cellpadding="0" cellspacing="0" class="container590">
        
                                <tbody>
                                    <tr>
                                        <td>
                                            <table border="0" align="left" cellpadding="0" cellspacing="0"
                                                style="border-collapse:collapse; mso-table-lspace:0pt; mso-table-rspace:0pt;"
                                                class="container590">
                                                <tbody>
                                                    <tr>
                                                        <td align="left"
                                                            style="color: #aaaaaa; font-size: 14px; font-family: 'Work Sans', Calibri, sans-serif; line-height: 24px;">
                                                            <div style="line-height: 24px;">
        
                                                                <span style="color: #333333;">This is auto generated e-mail. Please do not reply</span>
        
                                                            </div>
                                                        </td>
                                                    </tr>
                                                </tbody>
                                            </table>
        
                                            <table border="0" align="left" width="5" cellpadding="0" cellspacing="0"
                                                style="border-collapse:collapse; mso-table-lspace:0pt; mso-table-rspace:0pt;"
                                                class="container590">
                                                <tbody>
                                                    <tr>
                                                        <td height="20" width="5" style="font-size: 20px; line-height: 20px;">
                                                            &nbsp;</td>
                                                    </tr>
                                                </tbody>
                                            </table>
        
        
                                        </td>
                                    </tr>
        
                                </tbody>
                            </table>
                        </td>
                    </tr>
        
                    <tr>
                        <td height="25" style="font-size: 25px; line-height: 25px;">&nbsp;</td>
                    </tr>
        
                </tbody>
            </table>
        
        </body>
        
        </html>`,
    };
    await transporter.sendMail(msg);
  },

  customer_Mobileverify: async function (otp_params) {
    sgMail.setApiKey(sendGridAPIKey);
    const msg = {
      to: otp_params.email_address,
      from: "noreply@rblbank.com",
      subject: "Verification Code for Registration",
      html: `<!DOCTYPE html
            PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
        <html xmlns:v="urn:schemas-microsoft-com:vml">
        
        <head>
            <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
            <meta name="viewport" content="width=device-width; initial-scale=1.0; maximum-scale=1.0;">
            <!--[if !mso]-->
            <!-- -->
            <link href="https://fonts.googleapis.com/css?family=Work+Sans:300,400,500,600,700" rel="stylesheet">
            <link href="https://fonts.googleapis.com/css?family=Quicksand:300,400,700" rel="stylesheet">
            <!-- <![endif]-->
        
            <title>OTP Template</title>
        
            <style type="text/css">
                body {
                    width: 100%;
                    background-color: #ffffff;
                    margin: 0;
                    padding: 0;
                    -webkit-font-smoothing: antialiased;
                    mso-margin-top-alt: 0px;
                    mso-margin-bottom-alt: 0px;
                    mso-padding-alt: 0px 0px 0px 0px;
                }
        
                p,
                h1,
                h2,
                h3,
                h4 {
                    margin-top: 0;
                    margin-bottom: 0;
                    padding-top: 0;
                    padding-bottom: 0;
                }
        
                span.preheader {
                    display: none;
                    font-size: 1px;
                }
        
                html {
                    width: 100%;
                }
        
                table {
                    font-size: 14px;
                    border: 0;
                }
        
                /* ----------- responsivity ----------- */
        
                @media only screen and (max-width: 640px) {
        
                    /*------ top header ------ */
                    .main-header {
                        font-size: 20px !important;
                    }
        
                    .main-section-header {
                        font-size: 28px !important;
                    }
        
                    .show {
                        display: block !important;
                    }
        
                    .hide {
                        display: none !important;
                    }
        
                    .align-center {
                        text-align: center !important;
                    }
        
                    .no-bg {
                        background: none !important;
                    }
        
                    /*----- main image -------*/
                    .main-image img {
                        width: 440px !important;
                        height: auto !important;
                    }
        
                    /* ====== divider ====== */
                    .divider img {
                        width: 440px !important;
                    }
        
                    /*-------- container --------*/
                    .container590 {
                        width: 440px !important;
                    }
        
                    .container580 {
                        width: 400px !important;
                    }
        
                    .main-button {
                        width: 220px !important;
                    }
        
                    /*-------- secions ----------*/
                    .section-img img {
                        width: 320px !important;
                        height: auto !important;
                    }
        
                    .team-img img {
                        width: 100% !important;
                        height: auto !important;
                    }
                }
        
                @media only screen and (max-width: 479px) {
        
                    /*------ top header ------ */
                    .main-header {
                        font-size: 18px !important;
                    }
        
                    .main-section-header {
                        font-size: 26px !important;
                    }
        
                    /* ====== divider ====== */
                    .divider img {
                        width: 280px !important;
                    }
        
                    /*-------- container --------*/
                    .container590 {
                        width: 280px !important;
                    }
        
                    .container590 {
                        width: 280px !important;
                    }
        
                    .container580 {
                        width: 260px !important;
                    }
        
                    /*-------- secions ----------*/
                    .section-img img {
                        width: 280px !important;
                        height: auto !important;
                    }
                }
            </style>
            <!-- [if gte mso 9]><style type=”text/css”>
                    body {
                    font-family: arial, sans-serif!important;
                    }
                    </style>
                <![endif]-->
        </head>
        
        
        <body class="respond" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
            <!-- pre-header -->
            <table style="display:none!important;">
                <tbody>
                    <tr>
                        <td>
                            <div
                                style="overflow:hidden;display:none;font-size:1px;color:#ffffff;line-height:1px;font-family:Arial;maxheight:0px;max-width:0px;opacity:0;">
                                Pre-header for the newsletter template
                            </div>
                        </td>
                    </tr>
                </tbody>
            </table>
            <!-- pre-header end -->
            <!-- header -->
            <table border="0" width="100%" cellpadding="0" cellspacing="0" bgcolor="ffffff">
        
                <tbody>
                    <tr>
                        <td align="center">
                            <table border="0" align="center" width="590" cellpadding="0" cellspacing="0" class="container590">
        
                                <tbody>
                                    <tr>
                                        <td height="25" style="font-size: 25px; line-height: 25px;">&nbsp;</td>
                                    </tr>
        
                                    <tr>
                                        <td align="center">
        
                                            <table border="0" align="center" width="590" cellpadding="0" cellspacing="0"
                                                class="container590">
        
                                                <tbody>
                                                    <tr>
                                                        <td align="center" height="70" style="height:70px;">
                                                            <a href=""
                                                                style="display: block; border-style: none !important; border: 0 !important;"><img
                                                                    width="100" border="0" style="display: block; width: 100px;"
                                                                    src="${otp_params.image}/logo.png"
                                                                    alt=""></a>
                                                        </td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </td>
                                    </tr>
        
                                    <tr>
                                        <td height="25" style="font-size: 25px; line-height: 25px;">&nbsp;</td>
                                    </tr>
        
                                </tbody>
                            </table>
                        </td>
                    </tr>
                </tbody>
            </table>
            <!-- end header -->
        
            <!-- big image section -->
            <table border="0" width="100%" cellpadding="0" cellspacing="0" bgcolor="ffffff" class="bg_color">
        
                <tbody>
                    <tr>
                        <td align="center">
                            <table border="0" align="center" width="590" cellpadding="0" cellspacing="0" class="container590">
                                <tbody>
                                    <td align="center"
                                            style="color: #343434; font-size: 24px; font-family: Quicksand, Calibri, sans-serif; font-weight:700;letter-spacing: 3px; line-height: 35px;"
                                            class="main-header">
        
                                            <span style="color: #4759bb;">Dear ${otp_params.name},</span> </td>
                                    <tr>
                                        <td align="center"
                                        style="color: #888888; font-size: 18px; font-family: 'Work Sans', Calibri, sans-serif; line-height: 24px;"
                                        class="main-header">
                                        
                                        <div>Greetings from RBL Bank!</div>
                                            <div>Your verification code for <br>
                                                "Digital NR Account Opening" is:
                                            </div>
                                        </td>
                                    </tr>
                                    <tr>
        
                                        <td align="center"
                                            style="color: #343434; font-size: 24px; font-family: Quicksand, Calibri, sans-serif; font-weight:700;letter-spacing: 3px; line-height: 35px;"
                                            class="main-header">
        
                                            ${otp_params.otp} </td>
                                    </tr>
                                    
                                    <tr>
                                        <td align="center">
                                            <table border="0" width="400" align="center" cellpadding="0" cellspacing="0"
                                                class="container590">
                                                <tbody>
                                                    <tr>
                                                        <td align="center"
                                                            style="color: #888888; font-size: 16px; font-family: 'Work Sans', Calibri, sans-serif; line-height: 24px;">
        
                                                            <br>
                                                            <div style="line-height: 24px">The verification code will be valid
                                                                for 2 minutes. DO NOT SHARE OTP WITH ANYONE</div>
                                                            <div>Assuring you of our best services, at all times</div>
                                                            <br>
                                                            Kind Regards,<br>
                                                            RBL Bank <br>
                                                            
                                                        </td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </td>
                                    </tr>
        
                                    <tr>
                                        <td height="25" style="font-size: 25px; line-height: 25px;">&nbsp;</td>
                                    </tr>
        
        
        
        
                                </tbody>
                            </table>
        
                        </td>
                    </tr>
        
                </tbody>
            </table>
        
            <table border="0" width="100%" cellpadding="0" cellspacing="0" bgcolor="f4f4f4">
        
                <tbody>
                    <tr>
                        <td height="25" style="font-size: 25px; line-height: 25px;">&nbsp;</td>
                    </tr>
        
                    <tr>
                        <td align="center">
        
                            <table border="0" align="center" width="auto" cellpadding="0" cellspacing="0" class="container590">
        
                                <tbody>
                                    <tr>
                                        <td>
                                            <table border="0" align="left" cellpadding="0" cellspacing="0"
                                                style="border-collapse:collapse; mso-table-lspace:0pt; mso-table-rspace:0pt;"
                                                class="container590">
                                                <tbody>
                                                    <tr>
                                                        <td align="left"
                                                            style="color: #aaaaaa; font-size: 14px; font-family: 'Work Sans', Calibri, sans-serif; line-height: 24px;">
                                                            <div style="line-height: 24px;">
        
                                                                <span style="color: #333333;">This is auto generated e-mail. Please do not reply</span>
        
                                                            </div>
                                                        </td>
                                                    </tr>
                                                </tbody>
                                            </table>
        
                                            <table border="0" align="left" width="5" cellpadding="0" cellspacing="0"
                                                style="border-collapse:collapse; mso-table-lspace:0pt; mso-table-rspace:0pt;"
                                                class="container590">
                                                <tbody>
                                                    <tr>
                                                        <td height="20" width="5" style="font-size: 20px; line-height: 20px;">
                                                            &nbsp;</td>
                                                    </tr>
                                                </tbody>
                                            </table>
        
        
                                        </td>
                                    </tr>
        
                                </tbody>
                            </table>
                        </td>
                    </tr>
        
                    <tr>
                        <td height="25" style="font-size: 25px; line-height: 25px;">&nbsp;</td>
                    </tr>
        
                </tbody>
            </table>
        
        </body>
        
        </html>`,
    };
    await transporter.sendMail(msg);
  },

  //  customer_Emailverify:async function(email_address, email_otp, name) {
  //     try{
  //    const transporter = nodemailer.createTransport({

  //       host: 'smtp.gmail.com',
  //       port: 587,
  //       auth: {
  //         user: 'ramdas.j@fortune4.in',
  //         pass: 'ramdasfortune4@12345',
  //       },

  //     });
  //     var mailOptions={
  //       from: '"RBL BANK" <ramdas.j@fortune4.in>',
  //       to:email_address,
  //       subject: "Email Verification ",

  //       html:`<!DOCTYPE html> <html>
  //       <head>
  //           <link rel="preconnect" href="https://fonts.googleapis.com">
  //       <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  //       <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@300&display=swap" rel="stylesheet">
  //       <style>
  //       body{
  //           font-family: 'Open Sans', sans-serif;
  //       }
  //       .emailtemp {
  //           width: 600px;
  //           margin: 0 auto;
  //           text-align: center;
  //       }

  //       .div1 {
  //           padding: 40px 20px;
  //           border: 1px solid #ccc;
  //       }

  //       h2{margin-top: 30px;}
  //       span{ font-size: 40px;background: #e0e7ff;}
  //       p{text-align: left;}
  //       </style>
  //       </head>
  //       <body>
  //       <div class="emailtemp">
  //       <h1>Verification Code</h1>

  //       <div class="div1">
  //           <h2>Dear ${name}, Your verification code:</h2>
  //           <span>${email_otp}</span>
  //       </div>
  //       <p> The verification code will be valid for 30 minutes. Please do not share this code with anyone</p>

  //       </div>

  //       </body>
  //       </html>`

  //    }
  //   //let smtpresult = await transporter.sendMail(mailOptions)

  //     //console.log(smtpresult)
  //   }catch(error){
  //      console.log(error);
  //      res.status(400).json({
  //         error
  //      })
  //   }

  // },

  /* after agent review form */
  feedback_Email: async function (otp_params) {
    sgMail.setApiKey(sendGridAPIKey);
    const msg = {
      to: otp_params.email_address,
      from: "ninad.rane@rblbank.com",
      subject: "Feedback",
      html: `<!DOCTYPE html> <html>
              <head>
                  <link rel="preconnect" href="https://fonts.googleapis.com">
              <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
              <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@300&display=swap" rel="stylesheet">
              <style> 
              body{
                  font-family: 'Open Sans', sans-serif;
              }
              .emailtemp {
                  width: 600px;
                  margin: 0 auto;
                  text-align: center;
              }
              
              .div1 {
                  padding: 40px 20px;
                  border: 1px solid #ccc;
              }
              
              h2{margin-top: 30px;}
              span{ font-size: 40px;background: #e0e7ff;}
              p{text-align: left;}
              </style>
              </head>
              <body>
              <div class="emailtemp">
              <h1>Feedback</h1>
              
              <div class="div1">
                  <h2>Dear ${otp_params.name},</h2>
                  <p>Greetings from RBL Bank.<br>
                  We would like you to inform that your application has been reviewed by our agent. We request you to check the feedback given & kindly update the reqiured information.<br> 
          
                  Sincerely,<br>
                  RBL Bank Limited<br>
              </div>
              <p>This is auto generated e-mail. Please do not reply</p>
              
              </div>
              
              </body>
              </html>`,
    };
    await transporter.sendMail(msg);
  },

  /* after agent approve form */
  send_pdf_mail: async function (params) {
    sgMail.setApiKey(sendGridAPIKey);
    console.log(params);
    const msg = {
      to: params.email,
      from: "RBLAlerts@rblbank.com",
      subject:
        "Your NR Digital Account Application has been accepted for activation.",
      html: `<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
  <head>
    <meta charset="utf-8" content="text/html;" http-equiv="Content-Type" />
    <meta name="viewport" content="width=device-width" />
    <title>RBL Bank</title>
    <style type="text/css">
      .container {
        width: 700px !important;
      }
      @media only screen and (max-width: 706px) {
        /*default*/
        .container {
          width: 100% !important;
          max-width: 100% !important;
        } /*default*/
      }
      @media only screen and (max-width: 667px) {
        .two-col5 {
          max-width: 44% !important;
          padding: 2% 1% !important;
        } /*default*/
        .mob-hide {
          display: none !important;
        } /*default*/
      }
      @media only screen and (max-width: 480px) {
        .fulltdfooter {
          display: inline-block;
          width: 100% !important;
        }
        .rblLogo {
          width: 120px !important;
          max-width: 154px;
        }
        .bluebg {
          border-bottom: 5px solid #ffffff !important;
        }
        .fulltablefooter {
          text-align: center !important;
          padding-left: 10px;
        }
        .fulltablefooter img {
          padding-right: 5px;
          padding-left: 5px;
        }
        .redbg {
          padding: 5px 0px !important;
        }
        .mob-hide-foot {
          display: none !important;
        }
      }
      @media only screen and (max-width: 360px) {
        .rblbajajLogo {
          width: 100% !important;
        }
        .two-col5 {
          max-width: 40% !important;
          padding: 2% 1% !important;
          background: #391118;
        }
      }
    </style>
  </head>
  <body bgcolor="#eeeeee">
    <table
      class="container"
      width="700"
      cellpadding="0"
      cellspacing="0"
      style="max-width: 700px"
      align="center"
    >
      <tr>
        <td style="background-color: #ffffff; border: solid 1px #cccccc">
          <table border="0" cellpadding="0" cellspacing="0" width="100%">
            <tr>
              <td align="left">
                <table width="100%" border="0" cellspacing="0" cellpadding="0">
                  <tr>
                    <td
                      height="10"
                      width="74"
                      align="left"
                      bgcolor="#2B387E"
                      style="width: 74% !important; height: 10px !important"
                    ></td>
                    <td
                      height="10"
                      width="1"
                      align="left"
                      bgcolor="#FFFFFF"
                      style="width: 1% !important; height: 10px !important"
                    ></td>
                    <td
                      height="10"
                      width="25"
                      align="left"
                      bgcolor="#E3212A"
                      style="width: 25% !important; height: 10px !important"
                    ></td>
                  </tr>
                </table>
              </td>
            </tr>
            <tr>
              <td align="left" style="border-bottom: solid 1px #cccccc">
                <table width="100%" border="0" cellspacing="0" cellpadding="0">
                  <tr>
                    <td
                      width="10"
                      align="left"
                      valign="top"
                      bgcolor="#FFFFFF"
                      class="mob-hide"
                      style="width: 10px"
                    ></td>
                    <td align="center" valign="top">
                      <table
                        width="100%"
                        border="0"
                        cellspacing="0"
                        cellpadding="0"
                      >
                        <tr>
                          <td
                            width="10"
                            align="left"
                            valign="top"
                            bgcolor="#FFFFFF"
                            style="width: 10px"
                          ></td>
                          <td align="center" valign="top">
                            <table
                              width="100%"
                              border="0"
                              cellspacing="0"
                              cellpadding="0"
                            >
                              <tr>
                                <td
                                  height="10"
                                  align="left"
                                  valign="top"
                                  style="height: 10px"
                                ></td>
                              </tr>
                              <tr>
                                <td align="left" valign="top">
                                  <table
                                    width="100%"
                                    border="0"
                                    cellspacing="0"
                                    cellpadding="0"
                                  >
                                    <tr>
                                      <td
                                        width="154"
                                        align="right"
                                        valign="middle"
                                        style="line-height: 0px !important"
                                      >
                                        <a
                                          href="http://www.rblbank.com"
                                          target="_blank"
                                          style="
                                            color: #2b387e;
                                            text-decoration: none;
                                          "
                                          ><img
                                            border="0"
                                            src="https://rblcccamp.s3.ap-south-1.amazonaws.com/rbl_logo.jpg"
                                            alt="RBL - Bank"
                                            style="border: 0"
                                            class="rblLogo"
                                        /></a>
                                      </td>
                                    </tr>
                                  </table>
                                </td>
                              </tr>
                              <tr>
                                <td
                                  height="10"
                                  align="left"
                                  valign="top"
                                  style="height: 10px"
                                ></td>
                              </tr>
                            </table>
                          </td>
                          <td
                            width="10"
                            align="right"
                            valign="top"
                            bgcolor="#FFFFFF"
                            style="width: 10px"
                          ></td>
                        </tr>
                      </table>
                    </td>
                    <td
                      width="10"
                      align="right"
                      valign="top"
                      bgcolor="#FFFFFF"
                      class="mob-hide"
                      style="width: 10px"
                    ></td>
                  </tr>
                </table>
              </td>
            </tr>
            <tr>
              <td align="left"></td>
            </tr>
            <!-- contents -->
            <tr>
              <td align="left" valign="top">
                <table
                  width="100%"
                  align="center"
                  cellpadding="0"
                  cellspacing="0"
                  border="0"
                >
                  <tr>
                    <td width="10" class="mob-hide"></td>
                    <td>
                      <table
                        width="100%"
                        align="center"
                        cellpadding="0"
                        cellspacing="0"
                        border="0"
                      >
                        <tr>
                          <td width="10"></td>
                          <td>
                            <table
                              width="100%"
                              border="0"
                              cellspacing="0"
                              cellpadding="0"
                            >
                              <!-- contents -->
                              <tr>
                                <td height="30" align="left" valign="top"></td>
                              </tr>
                              <tr>
                                <td
                                  style="
                                    font-family: 'Calibri';
                                    font-size: 16px;
                                    color: #333333;
                                    text-align: left;
                                  "
                                >
                                  <strong>Dear,</strong>
                                </td>
                              </tr>
                              <tr>
                                <td height="10" align="left" valign="top"></td>
                              </tr>
                              <tr>
                                <td
                                  style="
                                    font-family: 'Calibri';
                                    font-size: 16px;
                                    color: #333333;
                                    text-align: left;
                                  "
                                >
                                  Greetings from RBL Bank!
                                </td>
                              </tr>
                              <tr>
                                <td height="10" align="left" valign="top"></td>
                              </tr>
                              <tr>
                                <td
                                  style="
                                    font-family: 'Calibri';
                                    font-size: 16px;
                                    color: #333333;
                                    text-align: left;
                                  "
                                >
                                  Congratulations! Your NR Digital Account
                                  Application has been accepted. You will need
                                  to submit the physical documents.
                                </td>
                              </tr>
                              <tr>
                                <td height="10" align="left" valign="top"></td>
                              </tr>
                              <tr>
                                <td
                                  style="
                                    font-family: 'Calibri';
                                    font-size: 16px;
                                    color: #333333;
                                    text-align: left;
                                  "
                                >
                                  Our representative will contact you to arrange
                                  a free pickup from your residence to collect
                                  the documents.
                                </td>
                              </tr>
                              <tr>
                                <td
                                  style="
                                    font-family: 'Calibri';
                                    font-size: 16px;
                                    color: #333333;
                                    text-align: left;
                                  "
                                >
                                <div style="line-height: 26px;">
                                  <a href="${params.url}"
                                      style="text-decoration: none;">Download</a>
                              </div>
                                </td>
                              </tr>
                              <tr>
                                <td height="10" align="left" valign="top"></td>
                              </tr>
                              <tr>
                                <td
                                  style="
                                    font-family: 'Calibri';
                                    font-size: 16px;
                                    color: #333333;
                                    text-align: left;
                                  "
                                >
                                  Assuring you of our best services, at all
                                  times.
                                </td>
                              </tr>
                              <tr>
                                <td height="20" align="left" valign="top"></td>
                              </tr>
                              <tr>
                                <td
                                  style="
                                    font-family: 'Calibri';
                                    font-size: 16px;
                                    color: #333333;
                                    text-align: left;
                                  "
                                >
                                  Kind Regards,
                                </td>
                              </tr>
                              <tr>
                                <td height="5" align="left" valign="top"></td>
                              </tr>
                              <tr>
                                <td
                                  style="
                                    font-family: 'Calibri';
                                    font-size: 16px;
                                    color: #333333;
                                    text-align: left;
                                  "
                                >
                                  RBL Bank
                                </td>
                              </tr>
                              <tr>
                                <td height="30" align="left" valign="top"></td>
                              </tr>
                              <!-- contents -->
                            </table>
                          </td>
                          <td width="10"></td>
                        </tr>
                      </table>
                    </td>
                    <td width="15" class="mob-hide"></td>
                  </tr>
                </table>
              </td>
            </tr>
            <!-- contents -->
            <tr>
              <td align="left" bgcolor="#232c60">
                <table width="100%" border="0" cellspacing="0" cellpadding="0">
                  <tr>
                    <td
                      class="fulltdfooter bluebg"
                      width="74%"
                      align="left"
                      bgcolor="#2B387E"
                      style="width: 74%; padding-top: 1px !important"
                    >
                      <table
                        class="fulltablefooter"
                        width="100%"
                        border="0"
                        align="left"
                        cellpadding="0"
                        cellspacing="0"
                      >
                        <tr>
                          <td>
                            <table
                              class="tablefootercenter"
                              width="auto"
                              border="0"
                              cellpadding="0"
                              cellspacing="0"
                            >
                              <tr>
                                <td
                                  width="20"
                                  valign="middle"
                                  class="mob-hide-foot"
                                ></td>
                                <td
                                  style="
                                    font-family: 'Calibri';
                                    font-size: 14px;
                                    color: #ffffff;
                                    text-align: left;
                                  "
                                >
                                  Follow us:
                                </td>
                                <td
                                  width="5"
                                  align="center"
                                  valign="middle"
                                ></td>
                                <td align="center" valign="middle">
                                  <a
                                    href="https://www.facebook.com/TheRBLBank"
                                    target="_blank"
                                    style="border: none; text-decoration: none"
                                    ><img
                                      src="https://rblcccamp.s3.ap-south-1.amazonaws.com/facebook_icon.png"
                                      alt="facebook"
                                      style="border: 0"
                                  /></a>
                                </td>
                                <td
                                  width="5"
                                  align="center"
                                  valign="middle"
                                ></td>
                                <td
                                  align="center"
                                  style="border: 0px"
                                  valign="middle"
                                >
                                  <a
                                    href="https://www.linkedin.com/company/rbl-bank"
                                    target="_blank"
                                    style="border: none; text-decoration: none"
                                    ><img
                                      src="https://rblcccamp.s3.ap-south-1.amazonaws.com/linkedin_icon.png"
                                      alt="linkedin"
                                      style="border: 0"
                                  /></a>
                                </td>
                                <td
                                  width="5"
                                  align="center"
                                  valign="middle"
                                ></td>
                                <td
                                  align="center"
                                  style="border: 0px"
                                  valign="middle"
                                >
                                  <a
                                    href="https://twitter.com/rblbank"
                                    target="_blank"
                                    style="border: none; text-decoration: none"
                                    ><img
                                      src="https://rblcccamp.s3.ap-south-1.amazonaws.com/twitter_icon.png"
                                      alt="Twitter"
                                      style="border: 0"
                                  /></a>
                                </td>
                                <td
                                  width="5"
                                  align="center"
                                  valign="middle"
                                ></td>
                                <td
                                  align="center"
                                  style="border: 0px"
                                  valign="middle"
                                >
                                  <a
                                    href="https://www.youtube.com/c/RBLBankofficial"
                                    target="_blank"
                                    style="border: none; text-decoration: none"
                                    ><img
                                      src="https://rblcccamp.s3.ap-south-1.amazonaws.com/youtube_icon.png"
                                      alt="youtube"
                                      style="border: 0"
                                  /></a>
                                </td>
                              </tr>
                            </table>
                          </td>
                        </tr>
                      </table>
                    </td>
                    <td
                      class="mob-hide-foot"
                      width="1%"
                      height="5"
                      align="left"
                      bgcolor="#FFFFFF"
                      style="width: 1%; height: 5px !important"
                    ></td>
                    <td
                      class="fulltdfooter redbg"
                      width="25%"
                      align="left"
                      bgcolor="#E3212A"
                      style="width: 25%; text-align: center"
                    >
                      <a
                        href="http://www.rblbank.com"
                        target="_blank"
                        style="
                          font-family: 'Calibri';
                          font-size: 14px;
                          color: #ffffff;
                          text-decoration: none;
                        "
                        >www.rblbank.com</a
                      >
                    </td>
                  </tr>
                </table>
              </td>
            </tr>
          </table>
        </td>
      </tr>
      <tr></tr>
      <tr>
        <td height="10"></td>
      </tr>
    </table>
    <!--[if (gte mso 9)|(IE)]> </td> </tr> </table> <![endif]-->
  </body>
      </html>`,
    };
    await transporter.sendMail(msg);
  },

  account_opening_submition: async function (otp_params) {
    sgMail.setApiKey(sendGridAPIKey);
    const msg = {
      to: otp_params.email_address,
      from: "RBLAlerts@rblbank.com",
      subject: "NR Digital Account - Confirmation of Application Request",
      html: `<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
  <head>
    <meta charset="utf-8" content="text/html;" http-equiv="Content-Type" />
    <meta name="viewport" content="width=device-width" />
    <title>RBL Bank</title>
    <!--[if gte mso 9]>
      <style type="text/css">
        .columncontainer {
          width: 100% !important;
        }
      </style>
    <![endif]-->
    <style type="text/css">
      .container {
        width: 700px !important;
      }
      @media only screen and (max-width: 706px) {
        /*default*/
        .container {
          width: 100% !important;
          max-width: 100% !important;
        } /*default*/
      }
      @media only screen and (max-width: 667px) {
        .two-col5 {
          max-width: 44% !important;
          padding: 2% 1% !important;
        } /*default*/
        .mob-hide {
          display: none !important;
        } /*default*/
      }
      @media only screen and (max-width: 480px) {
        .fulltdfooter {
          display: inline-block;
          width: 100% !important;
        }
        .rblLogo {
          width: 120px !important;
          max-width: 154px;
        }
        .bluebg {
          border-bottom: 5px solid #ffffff !important;
        }
        .fulltablefooter {
          text-align: center !important;
          padding-left: 10px;
        }
        .fulltablefooter img {
          padding-right: 5px;
          padding-left: 5px;
        }
        .redbg {
          padding: 5px 0px !important;
        }
        .mob-hide-foot {
          display: none !important;
        }
      }
      @media only screen and (max-width: 360px) {
        .rblbajajLogo {
          width: 100% !important;
        }
        .two-col5 {
          max-width: 40% !important;
          padding: 2% 1% !important;
          background: #391118;
        }
      }
    </style>
  </head>
  <body bgcolor="#eeeeee">
    <!--[if (gte mso 9)|(IE)]> <table width="700" align="center" cellpadding="0" cellspacing="0" border="0"> <tr> <td> <![endif]-->
    <table
      class="container"
      width="700"
      cellpadding="0"
      cellspacing="0"
      style="max-width: 700px"
      align="center"
    >
      <tr>
        <td style="background-color: #ffffff; border: solid 1px #cccccc">
          <table border="0" cellpadding="0" cellspacing="0" width="100%">
            <tr>
              <td align="left">
                <table width="100%" border="0" cellspacing="0" cellpadding="0">
                  <tr>
                    <td
                      height="10"
                      width="74"
                      align="left"
                      bgcolor="#2B387E"
                      style="width: 74% !important; height: 10px !important"
                    ></td>
                    <td
                      height="10"
                      width="1"
                      align="left"
                      bgcolor="#FFFFFF"
                      style="width: 1% !important; height: 10px !important"
                    ></td>
                    <td
                      height="10"
                      width="25"
                      align="left"
                      bgcolor="#E3212A"
                      style="width: 25% !important; height: 10px !important"
                    ></td>
                  </tr>
                </table>
              </td>
            </tr>
            <tr>
              <td align="left" style="border-bottom: solid 1px #cccccc">
                <table width="100%" border="0" cellspacing="0" cellpadding="0">
                  <tr>
                    <td
                      width="10"
                      align="left"
                      valign="top"
                      bgcolor="#FFFFFF"
                      class="mob-hide"
                      style="width: 10px"
                    ></td>
                    <td align="center" valign="top">
                      <table
                        width="100%"
                        border="0"
                        cellspacing="0"
                        cellpadding="0"
                      >
                        <tr>
                          <td
                            width="10"
                            align="left"
                            valign="top"
                            bgcolor="#FFFFFF"
                            style="width: 10px"
                          ></td>
                          <td align="center" valign="top">
                            <table
                              width="100%"
                              border="0"
                              cellspacing="0"
                              cellpadding="0"
                            >
                              <tr>
                                <td
                                  height="10"
                                  align="left"
                                  valign="top"
                                  style="height: 10px"
                                ></td>
                              </tr>
                              <tr>
                                <td align="left" valign="top">
                                  <table
                                    width="100%"
                                    border="0"
                                    cellspacing="0"
                                    cellpadding="0"
                                  >
                                    <tr>
                                      <td
                                        width="154"
                                        align="right"
                                        valign="middle"
                                        style="line-height: 0px !important"
                                      >
                                        <a
                                          href="http://www.rblbank.com"
                                          target="_blank"
                                          style="
                                            color: #2b387e;
                                            text-decoration: none;
                                          "
                                          ><img
                                            border="0"
                                            src="https://rblcccamp.s3.ap-south-1.amazonaws.com/rbl_logo.jpg"
                                            alt="RBL - Bank"
                                            style="border: 0"
                                            class="rblLogo"
                                        /></a>
                                      </td>
                                    </tr>
                                  </table>
                                </td>
                              </tr>
                              <tr>
                                <td
                                  height="10"
                                  align="left"
                                  valign="top"
                                  style="height: 10px"
                                ></td>
                              </tr>
                            </table>
                          </td>
                          <td
                            width="10"
                            align="right"
                            valign="top"
                            bgcolor="#FFFFFF"
                            style="width: 10px"
                          ></td>
                        </tr>
                      </table>
                    </td>
                    <td
                      width="10"
                      align="right"
                      valign="top"
                      bgcolor="#FFFFFF"
                      class="mob-hide"
                      style="width: 10px"
                    ></td>
                  </tr>
                </table>
              </td>
            </tr>
            <tr>
              <td align="left"></td>
            </tr>
            <!-- contents -->
            <tr>
              <td align="left" valign="top">
                <table
                  width="100%"
                  align="center"
                  cellpadding="0"
                  cellspacing="0"
                  border="0"
                >
                  <tr>
                    <td width="10" class="mob-hide"></td>
                    <td>
                      <table
                        width="100%"
                        align="center"
                        cellpadding="0"
                        cellspacing="0"
                        border="0"
                      >
                        <tr>
                          <td width="10"></td>
                          <td>
                            <table
                              width="100%"
                              border="0"
                              cellspacing="0"
                              cellpadding="0"
                            >
                              <!-- contents -->
                              <tr>
                                <td height="30" align="left" valign="top"></td>
                              </tr>
                              <tr>
                                <td
                                  style="
                                    font-family: 'Calibri';
                                    font-size: 16px;
                                    color: #333333;
                                    text-align: left;
                                  "
                                >
                                  <strong>Dear ${otp_params.name},</strong>
                                </td>
                              </tr>
                              <tr>
                                <td height="10" align="left" valign="top"></td>
                              </tr>
                              <tr>
                                <td
                                  style="
                                    font-family: 'Calibri';
                                    font-size: 16px;
                                    color: #333333;
                                    text-align: left;
                                  "
                                >
                                  Greetings from RBL Bank!
                                </td>
                              </tr>
                              <tr>
                                <td height="10" align="left" valign="top"></td>
                              </tr>
                              <tr>
                                <td
                                  style="
                                    font-family: 'Calibri';
                                    font-size: 16px;
                                    color: #333333;
                                    text-align: left;
                                  "
                                >
                                  We confirm receipt of your application for NR
                                  Digital Account.
                                </td>
                              </tr>
                              <tr>
                                <td height="10" align="left" valign="top"></td>
                              </tr>
                              <tr>
                                <td
                                  style="
                                    font-family: 'Calibri';
                                    font-size: 16px;
                                    color: #333333;
                                    text-align: left;
                                  "
                                >
                                  Our representative will review the documents
                                  and contact you within 2 business days.
                                </td>
                              </tr>
                              <tr>
                                <td height="10" align="left" valign="top"></td>
                              </tr>
                              <tr>
                                <td
                                  style="
                                    font-family: 'Calibri';
                                    font-size: 16px;
                                    color: #333333;
                                    text-align: left;
                                  "
                                >
                                  To view the application status, click here:
                                  <a
                                    href="${otp_params.login}"
                                    target="_blank"
                                    data-saferedirecturl="https://www.google.com/url?q=http://www.rblbank.com/&source=gmail&ust=1633696715309000&usg=AFQjCNGiHszbWRlEwHTfHrWfEI-FTBKg3w"
                                    >${otp_params.login}</a
                                  >
                                </td>
                              </tr>
                              <tr>
                                <td height="10" align="left" valign="top"></td>
                              </tr>
                              <tr>
                                <td
                                  style="
                                    font-family: 'Calibri';
                                    font-size: 16px;
                                    color: #333333;
                                    text-align: left;
                                  "
                                >
                                  Assuring you of our best services, at all
                                  times.
                                </td>
                              </tr>
                              <tr>
                                <td height="20" align="left" valign="top"></td>
                              </tr>
                              <tr>
                                <td
                                  style="
                                    font-family: 'Calibri';
                                    font-size: 16px;
                                    color: #333333;
                                    text-align: left;
                                  "
                                >
                                  Kind Regards,
                                </td>
                              </tr>
                              <tr>
                                <td height="5" align="left" valign="top"></td>
                              </tr>
                              <tr>
                                <td
                                  style="
                                    font-family: 'Calibri';
                                    font-size: 16px;
                                    color: #333333;
                                    text-align: left;
                                  "
                                >
                                  RBL Bank
                                </td>
                              </tr>
                              <tr>
                                <td height="30" align="left" valign="top"></td>
                              </tr>
                              <!-- contents -->
                            </table>
                          </td>
                          <td width="10"></td>
                        </tr>
                      </table>
                    </td>
                    <td width="15" class="mob-hide"></td>
                  </tr>
                </table>
              </td>
            </tr>
            <!-- contents -->
            <tr>
              <td align="left" bgcolor="#232c60">
                <table width="100%" border="0" cellspacing="0" cellpadding="0">
                  <tr>
                    <td
                      class="fulltdfooter bluebg"
                      width="74%"
                      align="left"
                      bgcolor="#2B387E"
                      style="width: 74%; padding-top: 1px !important"
                    >
                      <table
                        class="fulltablefooter"
                        width="100%"
                        border="0"
                        align="left"
                        cellpadding="0"
                        cellspacing="0"
                      >
                        <tr>
                          <td>
                            <table
                              class="tablefootercenter"
                              width="auto"
                              border="0"
                              cellpadding="0"
                              cellspacing="0"
                            >
                              <tr>
                                <td
                                  width="20"
                                  valign="middle"
                                  class="mob-hide-foot"
                                ></td>
                                <td
                                  style="
                                    font-family: 'Calibri';
                                    font-size: 14px;
                                    color: #ffffff;
                                    text-align: left;
                                  "
                                >
                                  Follow us:
                                </td>
                                <td
                                  width="5"
                                  align="center"
                                  valign="middle"
                                ></td>
                                <td align="center" valign="middle">
                                  <a
                                    href="https://www.facebook.com/TheRBLBank"
                                    target="_blank"
                                    style="border: none; text-decoration: none"
                                    ><img
                                      src="https://rblcccamp.s3.ap-south-1.amazonaws.com/facebook_icon.png"
                                      alt="facebook"
                                      style="border: 0"
                                  /></a>
                                </td>
                                <td
                                  width="5"
                                  align="center"
                                  valign="middle"
                                ></td>
                                <td
                                  align="center"
                                  style="border: 0px"
                                  valign="middle"
                                >
                                  <a
                                    href="https://www.linkedin.com/company/rbl-bank"
                                    target="_blank"
                                    style="border: none; text-decoration: none"
                                    ><img
                                      src="https://rblcccamp.s3.ap-south-1.amazonaws.com/linkedin_icon.png"
                                      alt="linkedin"
                                      style="border: 0"
                                  /></a>
                                </td>
                                <td
                                  width="5"
                                  align="center"
                                  valign="middle"
                                ></td>
                                <td
                                  align="center"
                                  style="border: 0px"
                                  valign="middle"
                                >
                                  <a
                                    href="https://twitter.com/rblbank"
                                    target="_blank"
                                    style="border: none; text-decoration: none"
                                    ><img
                                      src="https://rblcccamp.s3.ap-south-1.amazonaws.com/twitter_icon.png"
                                      alt="Twitter"
                                      style="border: 0"
                                  /></a>
                                </td>
                                <td
                                  width="5"
                                  align="center"
                                  valign="middle"
                                ></td>
                                <td
                                  align="center"
                                  style="border: 0px"
                                  valign="middle"
                                >
                                  <a
                                    href="https://www.youtube.com/c/RBLBankofficial"
                                    target="_blank"
                                    style="border: none; text-decoration: none"
                                    ><img
                                      src="https://rblcccamp.s3.ap-south-1.amazonaws.com/youtube_icon.png"
                                      alt="youtube"
                                      style="border: 0"
                                  /></a>
                                </td>
                              </tr>
                            </table>
                          </td>
                        </tr>
                      </table>
                    </td>
                    <td
                      class="mob-hide-foot"
                      width="1%"
                      height="5"
                      align="left"
                      bgcolor="#FFFFFF"
                      style="width: 1%; height: 5px !important"
                    ></td>
                    <td
                      class="fulltdfooter redbg"
                      width="25%"
                      align="left"
                      bgcolor="#E3212A"
                      style="width: 25%; text-align: center"
                    >
                      <a
                        href="http://www.rblbank.com"
                        target="_blank"
                        style="
                          font-family: 'Calibri';
                          font-size: 14px;
                          color: #ffffff;
                          text-decoration: none;
                        "
                        >www.rblbank.com</a
                      >
                    </td>
                  </tr>
                </table>
              </td>
            </tr>
          </table>
        </td>
      </tr>
      <tr></tr>
      <tr>
        <td height="10"></td>
      </tr>
    </table>
    <!--[if (gte mso 9)|(IE)]> </td> </tr> </table> <![endif]-->
  </body>
</html>
`,
    };
    await transporter.sendMail(msg);
  },

  account_reviwed: async function (params) {
    sgMail.setApiKey(sendGridAPIKey);
    const msg = {
      to: params.email,
      from: "RBLAlerts@rblbank.com",
      subject: "Action Required  for NR Digital Account Application.",
      html: `<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
  <head>
    <meta charset="utf-8" content="text/html;" http-equiv="Content-Type" />
    <meta name="viewport" content="width=device-width" />
    <title>RBL Bank</title>
    <!--[if gte mso 9]>
      <style type="text/css">
        .columncontainer {
          width: 100% !important;
        }
      </style>
    <![endif]-->
    <style type="text/css">
      .container {
        width: 700px !important;
      }
      @media only screen and (max-width: 706px) {
        /*default*/
        .container {
          width: 100% !important;
          max-width: 100% !important;
        } /*default*/
      }
      @media only screen and (max-width: 667px) {
        .two-col5 {
          max-width: 44% !important;
          padding: 2% 1% !important;
        } /*default*/
        .mob-hide {
          display: none !important;
        } /*default*/
      }
      @media only screen and (max-width: 480px) {
        .fulltdfooter {
          display: inline-block;
          width: 100% !important;
        }
        .rblLogo {
          width: 120px !important;
          max-width: 154px;
        }
        .bluebg {
          border-bottom: 5px solid #ffffff !important;
        }
        .fulltablefooter {
          text-align: center !important;
          padding-left: 10px;
        }
        .fulltablefooter img {
          padding-right: 5px;
          padding-left: 5px;
        }
        .redbg {
          padding: 5px 0px !important;
        }
        .mob-hide-foot {
          display: none !important;
        }
      }
      @media only screen and (max-width: 360px) {
        .rblbajajLogo {
          width: 100% !important;
        }
        .two-col5 {
          max-width: 40% !important;
          padding: 2% 1% !important;
          background: #391118;
        }
      }
    </style>
  </head>
  <body bgcolor="#eeeeee">
    <!--[if (gte mso 9)|(IE)]> <table width="700" align="center" cellpadding="0" cellspacing="0" border="0"> <tr> <td> <![endif]-->
    <table
      class="container"
      width="700"
      cellpadding="0"
      cellspacing="0"
      style="max-width: 700px"
      align="center"
    >
      <tr>
        <td style="background-color: #ffffff; border: solid 1px #cccccc">
          <table border="0" cellpadding="0" cellspacing="0" width="100%">
            <tr>
              <td align="left">
                <table width="100%" border="0" cellspacing="0" cellpadding="0">
                  <tr>
                    <td
                      height="10"
                      width="74"
                      align="left"
                      bgcolor="#2B387E"
                      style="width: 74% !important; height: 10px !important"
                    ></td>
                    <td
                      height="10"
                      width="1"
                      align="left"
                      bgcolor="#FFFFFF"
                      style="width: 1% !important; height: 10px !important"
                    ></td>
                    <td
                      height="10"
                      width="25"
                      align="left"
                      bgcolor="#E3212A"
                      style="width: 25% !important; height: 10px !important"
                    ></td>
                  </tr>
                </table>
              </td>
            </tr>
            <tr>
              <td align="left" style="border-bottom: solid 1px #cccccc">
                <table width="100%" border="0" cellspacing="0" cellpadding="0">
                  <tr>
                    <td
                      width="10"
                      align="left"
                      valign="top"
                      bgcolor="#FFFFFF"
                      class="mob-hide"
                      style="width: 10px"
                    ></td>
                    <td align="center" valign="top">
                      <table
                        width="100%"
                        border="0"
                        cellspacing="0"
                        cellpadding="0"
                      >
                        <tr>
                          <td
                            width="10"
                            align="left"
                            valign="top"
                            bgcolor="#FFFFFF"
                            style="width: 10px"
                          ></td>
                          <td align="center" valign="top">
                            <table
                              width="100%"
                              border="0"
                              cellspacing="0"
                              cellpadding="0"
                            >
                              <tr>
                                <td
                                  height="10"
                                  align="left"
                                  valign="top"
                                  style="height: 10px"
                                ></td>
                              </tr>
                              <tr>
                                <td align="left" valign="top">
                                  <table
                                    width="100%"
                                    border="0"
                                    cellspacing="0"
                                    cellpadding="0"
                                  >
                                    <tr>
                                      <td
                                        width="154"
                                        align="right"
                                        valign="middle"
                                        style="line-height: 0px !important"
                                      >
                                        <a
                                          href="http://www.rblbank.com"
                                          target="_blank"
                                          style="
                                            color: #2b387e;
                                            text-decoration: none;
                                          "
                                          ><img
                                            border="0"
                                            src="https://rblcccamp.s3.ap-south-1.amazonaws.com/rbl_logo.jpg"
                                            alt="RBL - Bank"
                                            style="border: 0"
                                            class="rblLogo"
                                        /></a>
                                      </td>
                                    </tr>
                                  </table>
                                </td>
                              </tr>
                              <tr>
                                <td
                                  height="10"
                                  align="left"
                                  valign="top"
                                  style="height: 10px"
                                ></td>
                              </tr>
                            </table>
                          </td>
                          <td
                            width="10"
                            align="right"
                            valign="top"
                            bgcolor="#FFFFFF"
                            style="width: 10px"
                          ></td>
                        </tr>
                      </table>
                    </td>
                    <td
                      width="10"
                      align="right"
                      valign="top"
                      bgcolor="#FFFFFF"
                      class="mob-hide"
                      style="width: 10px"
                    ></td>
                  </tr>
                </table>
              </td>
            </tr>
            <tr>
              <td align="left"></td>
            </tr>
            <!-- contents -->
            <tr>
              <td align="left" valign="top">
                <table
                  width="100%"
                  align="center"
                  cellpadding="0"
                  cellspacing="0"
                  border="0"
                >
                  <tr>
                    <td width="10" class="mob-hide"></td>
                    <td>
                      <table
                        width="100%"
                        align="center"
                        cellpadding="0"
                        cellspacing="0"
                        border="0"
                      >
                        <tr>
                          <td width="10"></td>
                          <td>
                            <table
                              width="100%"
                              border="0"
                              cellspacing="0"
                              cellpadding="0"
                            >
                              <!-- contents -->
                              <tr>
                                <td height="30" align="left" valign="top"></td>
                              </tr>
                              <tr>
                                <td
                                  style="
                                    font-family: 'Calibri';
                                    font-size: 16px;
                                    color: #333333;
                                    text-align: left;
                                  "
                                >
                                  <strong>Dear ${params.name},</strong>
                                </td>
                              </tr>
                              <tr>
                                <td height="10" align="left" valign="top"></td>
                              </tr>
                              <tr>
                                <td
                                  style="
                                    font-family: 'Calibri';
                                    font-size: 16px;
                                    color: #333333;
                                    text-align: left;
                                  "
                                >
                                  Greetings from RBL Bank!
                                </td>
                              </tr>
                              <tr>
                                <td height="10" align="left" valign="top"></td>
                              </tr>
                              <tr>
                                <td
                                  style="
                                    font-family: 'Calibri';
                                    font-size: 16px;
                                    color: #333333;
                                    text-align: left;
                                  "
                                >
                                  Our representative has shared feedback on your
                                  NR Digital Account Application.
                                </td>
                              </tr>
                              <tr>
                                <td height="10" align="left" valign="top"></td>
                              </tr>
                              <tr></tr>
                              <tr>
                                <td
                                  style="
                                    font-family: 'Calibri';
                                    font-size: 16px;
                                    color: #333333;
                                    text-align: left;
                                  "
                                >
                                  To view the feedback and fill-in the required
                                  details, click here
                                  <a
                                    href="${params.url}/feedback/feedback-summary"
                                    target="_blank"
                                    data-saferedirecturl="https://www.google.com/url?q=http://www.rblbank.com/&source=gmail&ust=1633696715309000&usg=AFQjCNGiHszbWRlEwHTfHrWfEI-FTBKg3w"
                                    >${params.url}/feedback/feedback-summary</a
                                  >
                                </td>
                              </tr>
                              <tr>
                                <td height="10" align="left" valign="top"></td>
                              </tr>
                              <tr>
                                <td
                                  style="
                                    font-family: 'Calibri';
                                    font-size: 16px;
                                    color: #333333;
                                    text-align: left;
                                  "
                                >
                                  Assuring you of our best services, at all
                                  times.
                                </td>
                              </tr>
                              <tr>
                                <td height="20" align="left" valign="top"></td>
                              </tr>
                              <tr>
                                <td
                                  style="
                                    font-family: 'Calibri';
                                    font-size: 16px;
                                    color: #333333;
                                    text-align: left;
                                  "
                                >
                                  Kind Regards,
                                </td>
                              </tr>
                              <tr>
                                <td height="5" align="left" valign="top"></td>
                              </tr>
                              <tr>
                                <td
                                  style="
                                    font-family: 'Calibri';
                                    font-size: 16px;
                                    color: #333333;
                                    text-align: left;
                                  "
                                >
                                  RBL Bank
                                </td>
                              </tr>
                              <tr>
                                <td height="30" align="left" valign="top"></td>
                              </tr>
                              <!-- contents -->
                            </table>
                          </td>
                          <td width="10"></td>
                        </tr>
                      </table>
                    </td>
                    <td width="15" class="mob-hide"></td>
                  </tr>
                </table>
              </td>
            </tr>
            <!-- contents -->
            <tr>
              <td align="left" bgcolor="#232c60">
                <table width="100%" border="0" cellspacing="0" cellpadding="0">
                  <tr>
                    <td
                      class="fulltdfooter bluebg"
                      width="74%"
                      align="left"
                      bgcolor="#2B387E"
                      style="width: 74%; padding-top: 1px !important"
                    >
                      <table
                        class="fulltablefooter"
                        width="100%"
                        border="0"
                        align="left"
                        cellpadding="0"
                        cellspacing="0"
                      >
                        <tr>
                          <td>
                            <table
                              class="tablefootercenter"
                              width="auto"
                              border="0"
                              cellpadding="0"
                              cellspacing="0"
                            >
                              <tr>
                                <td
                                  width="20"
                                  valign="middle"
                                  class="mob-hide-foot"
                                ></td>
                                <td
                                  style="
                                    font-family: 'Calibri';
                                    font-size: 14px;
                                    color: #ffffff;
                                    text-align: left;
                                  "
                                >
                                  Follow us:
                                </td>
                                <td
                                  width="5"
                                  align="center"
                                  valign="middle"
                                ></td>
                                <td align="center" valign="middle">
                                  <a
                                    href="https://www.facebook.com/TheRBLBank"
                                    target="_blank"
                                    style="border: none; text-decoration: none"
                                    ><img
                                      src="https://rblcccamp.s3.ap-south-1.amazonaws.com/facebook_icon.png"
                                      alt="facebook"
                                      style="border: 0"
                                  /></a>
                                </td>
                                <td
                                  width="5"
                                  align="center"
                                  valign="middle"
                                ></td>
                                <td
                                  align="center"
                                  style="border: 0px"
                                  valign="middle"
                                >
                                  <a
                                    href="https://www.linkedin.com/company/rbl-bank"
                                    target="_blank"
                                    style="border: none; text-decoration: none"
                                    ><img
                                      src="https://rblcccamp.s3.ap-south-1.amazonaws.com/linkedin_icon.png"
                                      alt="linkedin"
                                      style="border: 0"
                                  /></a>
                                </td>
                                <td
                                  width="5"
                                  align="center"
                                  valign="middle"
                                ></td>
                                <td
                                  align="center"
                                  style="border: 0px"
                                  valign="middle"
                                >
                                  <a
                                    href="https://twitter.com/rblbank"
                                    target="_blank"
                                    style="border: none; text-decoration: none"
                                    ><img
                                      src="https://rblcccamp.s3.ap-south-1.amazonaws.com/twitter_icon.png"
                                      alt="Twitter"
                                      style="border: 0"
                                  /></a>
                                </td>
                                <td
                                  width="5"
                                  align="center"
                                  valign="middle"
                                ></td>
                                <td
                                  align="center"
                                  style="border: 0px"
                                  valign="middle"
                                >
                                  <a
                                    href="https://www.youtube.com/c/RBLBankofficial"
                                    target="_blank"
                                    style="border: none; text-decoration: none"
                                    ><img
                                      src="https://rblcccamp.s3.ap-south-1.amazonaws.com/youtube_icon.png"
                                      alt="youtube"
                                      style="border: 0"
                                  /></a>
                                </td>
                              </tr>
                            </table>
                          </td>
                        </tr>
                      </table>
                    </td>
                    <td
                      class="mob-hide-foot"
                      width="1%"
                      height="5"
                      align="left"
                      bgcolor="#FFFFFF"
                      style="width: 1%; height: 5px !important"
                    ></td>
                    <td
                      class="fulltdfooter redbg"
                      width="25%"
                      align="left"
                      bgcolor="#E3212A"
                      style="width: 25%; text-align: center"
                    >
                      <a
                        href="http://www.rblbank.com"
                        target="_blank"
                        style="
                          font-family: 'Calibri';
                          font-size: 14px;
                          color: #ffffff;
                          text-decoration: none;
                        "
                        >www.rblbank.com</a
                      >
                    </td>
                  </tr>
                </table>
              </td>
            </tr>
          </table>
        </td>
      </tr>
      <tr></tr>
      <tr>
        <td height="10"></td>
      </tr>
    </table>
    <!--[if (gte mso 9)|(IE)]> </td> </tr> </table> <![endif]-->
  </body>
</html>
`,
    };
    await transporter.sendMail(msg);
  },

  account_opening_status: async function (otp_params) {
    sgMail.setApiKey(sendGridAPIKey);
    const msg = {
      to: otp_params.email_address,
      from: "RBLAlerts@rblbank.com",
      subject:
        "Your NR Digital Account Application has been accepted for activation.",
      html: `<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
  <head>
    <meta charset="utf-8" content="text/html;" http-equiv="Content-Type" />
    <meta name="viewport" content="width=device-width" />
    <title>RBL Bank</title>
    <!--[if gte mso 9]>
      <style type="text/css">
        .columncontainer {
          width: 100% !important;
        }
      </style>
    <![endif]-->
    <style type="text/css">
      .container {
        width: 700px !important;
      }
      @media only screen and (max-width: 706px) {
        /*default*/
        .container {
          width: 100% !important;
          max-width: 100% !important;
        } /*default*/
      }
      @media only screen and (max-width: 667px) {
        .two-col5 {
          max-width: 44% !important;
          padding: 2% 1% !important;
        } /*default*/
        .mob-hide {
          display: none !important;
        } /*default*/
      }
      @media only screen and (max-width: 480px) {
        .fulltdfooter {
          display: inline-block;
          width: 100% !important;
        }
        .rblLogo {
          width: 120px !important;
          max-width: 154px;
        }
        .bluebg {
          border-bottom: 5px solid #ffffff !important;
        }
        .fulltablefooter {
          text-align: center !important;
          padding-left: 10px;
        }
        .fulltablefooter img {
          padding-right: 5px;
          padding-left: 5px;
        }
        .redbg {
          padding: 5px 0px !important;
        }
        .mob-hide-foot {
          display: none !important;
        }
      }
      @media only screen and (max-width: 360px) {
        .rblbajajLogo {
          width: 100% !important;
        }
        .two-col5 {
          max-width: 40% !important;
          padding: 2% 1% !important;
          background: #391118;
        }
      }
    </style>
  </head>
  <body bgcolor="#eeeeee">
    <!--[if (gte mso 9)|(IE)]> <table width="700" align="center" cellpadding="0" cellspacing="0" border="0"> <tr> <td> <![endif]-->
    <table
      class="container"
      width="700"
      cellpadding="0"
      cellspacing="0"
      style="max-width: 700px"
      align="center"
    >
      <tr>
        <td style="background-color: #ffffff; border: solid 1px #cccccc">
          <table border="0" cellpadding="0" cellspacing="0" width="100%">
            <tr>
              <td align="left">
                <table width="100%" border="0" cellspacing="0" cellpadding="0">
                  <tr>
                    <td
                      height="10"
                      width="74"
                      align="left"
                      bgcolor="#2B387E"
                      style="width: 74% !important; height: 10px !important"
                    ></td>
                    <td
                      height="10"
                      width="1"
                      align="left"
                      bgcolor="#FFFFFF"
                      style="width: 1% !important; height: 10px !important"
                    ></td>
                    <td
                      height="10"
                      width="25"
                      align="left"
                      bgcolor="#E3212A"
                      style="width: 25% !important; height: 10px !important"
                    ></td>
                  </tr>
                </table>
              </td>
            </tr>
            <tr>
              <td align="left" style="border-bottom: solid 1px #cccccc">
                <table width="100%" border="0" cellspacing="0" cellpadding="0">
                  <tr>
                    <td
                      width="10"
                      align="left"
                      valign="top"
                      bgcolor="#FFFFFF"
                      class="mob-hide"
                      style="width: 10px"
                    ></td>
                    <td align="center" valign="top">
                      <table
                        width="100%"
                        border="0"
                        cellspacing="0"
                        cellpadding="0"
                      >
                        <tr>
                          <td
                            width="10"
                            align="left"
                            valign="top"
                            bgcolor="#FFFFFF"
                            style="width: 10px"
                          ></td>
                          <td align="center" valign="top">
                            <table
                              width="100%"
                              border="0"
                              cellspacing="0"
                              cellpadding="0"
                            >
                              <tr>
                                <td
                                  height="10"
                                  align="left"
                                  valign="top"
                                  style="height: 10px"
                                ></td>
                              </tr>
                              <tr>
                                <td align="left" valign="top">
                                  <table
                                    width="100%"
                                    border="0"
                                    cellspacing="0"
                                    cellpadding="0"
                                  >
                                    <tr>
                                      <td
                                        width="154"
                                        align="right"
                                        valign="middle"
                                        style="line-height: 0px !important"
                                      >
                                        <a
                                          href="http://www.rblbank.com"
                                          target="_blank"
                                          style="
                                            color: #2b387e;
                                            text-decoration: none;
                                          "
                                          ><img
                                            border="0"
                                            src="https://rblcccamp.s3.ap-south-1.amazonaws.com/rbl_logo.jpg"
                                            alt="RBL - Bank"
                                            style="border: 0"
                                            class="rblLogo"
                                        /></a>
                                      </td>
                                    </tr>
                                  </table>
                                </td>
                              </tr>
                              <tr>
                                <td
                                  height="10"
                                  align="left"
                                  valign="top"
                                  style="height: 10px"
                                ></td>
                              </tr>
                            </table>
                          </td>
                          <td
                            width="10"
                            align="right"
                            valign="top"
                            bgcolor="#FFFFFF"
                            style="width: 10px"
                          ></td>
                        </tr>
                      </table>
                    </td>
                    <td
                      width="10"
                      align="right"
                      valign="top"
                      bgcolor="#FFFFFF"
                      class="mob-hide"
                      style="width: 10px"
                    ></td>
                  </tr>
                </table>
              </td>
            </tr>
            <tr>
              <td align="left"></td>
            </tr>
            <!-- contents -->
            <tr>
              <td align="left" valign="top">
                <table
                  width="100%"
                  align="center"
                  cellpadding="0"
                  cellspacing="0"
                  border="0"
                >
                  <tr>
                    <td width="10" class="mob-hide"></td>
                    <td>
                      <table
                        width="100%"
                        align="center"
                        cellpadding="0"
                        cellspacing="0"
                        border="0"
                      >
                        <tr>
                          <td width="10"></td>
                          <td>
                            <table
                              width="100%"
                              border="0"
                              cellspacing="0"
                              cellpadding="0"
                            >
                              <!-- contents -->
                              <tr>
                                <td height="30" align="left" valign="top"></td>
                              </tr>
                              <tr>
                                <td
                                  style="
                                    font-family: 'Calibri';
                                    font-size: 16px;
                                    color: #333333;
                                    text-align: left;
                                  "
                                >
                                  <strong>Dear ${otp_params.name},</strong>
                                </td>
                              </tr>
                              <tr>
                                <td height="10" align="left" valign="top"></td>
                              </tr>
                              <tr>
                                <td
                                  style="
                                    font-family: 'Calibri';
                                    font-size: 16px;
                                    color: #333333;
                                    text-align: left;
                                  "
                                >
                                  Greetings from RBL Bank!
                                </td>
                              </tr>
                              <tr>
                                <td height="10" align="left" valign="top"></td>
                              </tr>
                              <tr>
                                <td
                                  style="
                                    font-family: 'Calibri';
                                    font-size: 16px;
                                    color: #333333;
                                    text-align: left;
                                  "
                                >
                                  Congratulations! Your NR Digital Account
                                  Application has been accepted. You will need
                                  to submit the physical documents.
                                </td>
                              </tr>
                              <tr>
                                <td height="10" align="left" valign="top"></td>
                              </tr>
                              <tr>
                                <td
                                  style="
                                    font-family: 'Calibri';
                                    font-size: 16px;
                                    color: #333333;
                                    text-align: left;
                                  "
                                >
                                  Our representative will contact you to arrange
                                  a free pickup from your residence to collect
                                  the documents.
                                </td>
                              </tr>
                              <tr>
                                <td height="10" align="left" valign="top"></td>
                              </tr>
                              <tr>
                                <td
                                  style="
                                    font-family: 'Calibri';
                                    font-size: 16px;
                                    color: #333333;
                                    text-align: left;
                                  "
                                >
                                  Assuring you of our best services, at all
                                  times.
                                </td>
                              </tr>
                              <tr>
                                <td height="20" align="left" valign="top"></td>
                              </tr>
                              <tr>
                                <td
                                  style="
                                    font-family: 'Calibri';
                                    font-size: 16px;
                                    color: #333333;
                                    text-align: left;
                                  "
                                >
                                  Kind Regards,
                                </td>
                              </tr>
                              <tr>
                                <td height="5" align="left" valign="top"></td>
                              </tr>
                              <tr>
                                <td
                                  style="
                                    font-family: 'Calibri';
                                    font-size: 16px;
                                    color: #333333;
                                    text-align: left;
                                  "
                                >
                                  RBL Bank
                                </td>
                              </tr>
                              <tr>
                                <td height="30" align="left" valign="top"></td>
                              </tr>
                              <!-- contents -->
                            </table>
                          </td>
                          <td width="10"></td>
                        </tr>
                      </table>
                    </td>
                    <td width="15" class="mob-hide"></td>
                  </tr>
                </table>
              </td>
            </tr>
            <!-- contents -->
            <tr>
              <td align="left" bgcolor="#232c60">
                <table width="100%" border="0" cellspacing="0" cellpadding="0">
                  <tr>
                    <td
                      class="fulltdfooter bluebg"
                      width="74%"
                      align="left"
                      bgcolor="#2B387E"
                      style="width: 74%; padding-top: 1px !important"
                    >
                      <table
                        class="fulltablefooter"
                        width="100%"
                        border="0"
                        align="left"
                        cellpadding="0"
                        cellspacing="0"
                      >
                        <tr>
                          <td>
                            <table
                              class="tablefootercenter"
                              width="auto"
                              border="0"
                              cellpadding="0"
                              cellspacing="0"
                            >
                              <tr>
                                <td
                                  width="20"
                                  valign="middle"
                                  class="mob-hide-foot"
                                ></td>
                                <td
                                  style="
                                    font-family: 'Calibri';
                                    font-size: 14px;
                                    color: #ffffff;
                                    text-align: left;
                                  "
                                >
                                  Follow us:
                                </td>
                                <td
                                  width="5"
                                  align="center"
                                  valign="middle"
                                ></td>
                                <td align="center" valign="middle">
                                  <a
                                    href="https://www.facebook.com/TheRBLBank"
                                    target="_blank"
                                    style="border: none; text-decoration: none"
                                    ><img
                                      src="https://rblcccamp.s3.ap-south-1.amazonaws.com/facebook_icon.png"
                                      alt="facebook"
                                      style="border: 0"
                                  /></a>
                                </td>
                                <td
                                  width="5"
                                  align="center"
                                  valign="middle"
                                ></td>
                                <td
                                  align="center"
                                  style="border: 0px"
                                  valign="middle"
                                >
                                  <a
                                    href="https://www.linkedin.com/company/rbl-bank"
                                    target="_blank"
                                    style="border: none; text-decoration: none"
                                    ><img
                                      src="https://rblcccamp.s3.ap-south-1.amazonaws.com/linkedin_icon.png"
                                      alt="linkedin"
                                      style="border: 0"
                                  /></a>
                                </td>
                                <td
                                  width="5"
                                  align="center"
                                  valign="middle"
                                ></td>
                                <td
                                  align="center"
                                  style="border: 0px"
                                  valign="middle"
                                >
                                  <a
                                    href="https://twitter.com/rblbank"
                                    target="_blank"
                                    style="border: none; text-decoration: none"
                                    ><img
                                      src="https://rblcccamp.s3.ap-south-1.amazonaws.com/twitter_icon.png"
                                      alt="Twitter"
                                      style="border: 0"
                                  /></a>
                                </td>
                                <td
                                  width="5"
                                  align="center"
                                  valign="middle"
                                ></td>
                                <td
                                  align="center"
                                  style="border: 0px"
                                  valign="middle"
                                >
                                  <a
                                    href="https://www.youtube.com/c/RBLBankofficial"
                                    target="_blank"
                                    style="border: none; text-decoration: none"
                                    ><img
                                      src="https://rblcccamp.s3.ap-south-1.amazonaws.com/youtube_icon.png"
                                      alt="youtube"
                                      style="border: 0"
                                  /></a>
                                </td>
                              </tr>
                            </table>
                          </td>
                        </tr>
                      </table>
                    </td>
                    <td
                      class="mob-hide-foot"
                      width="1%"
                      height="5"
                      align="left"
                      bgcolor="#FFFFFF"
                      style="width: 1%; height: 5px !important"
                    ></td>
                    <td
                      class="fulltdfooter redbg"
                      width="25%"
                      align="left"
                      bgcolor="#E3212A"
                      style="width: 25%; text-align: center"
                    >
                      <a
                        href="http://www.rblbank.com"
                        target="_blank"
                        style="
                          font-family: 'Calibri';
                          font-size: 14px;
                          color: #ffffff;
                          text-decoration: none;
                        "
                        >www.rblbank.com</a
                      >
                    </td>
                  </tr>
                </table>
              </td>
            </tr>
          </table>
        </td>
      </tr>
      <tr></tr>
      <tr>
        <td height="10"></td>
      </tr>
    </table>
    <!--[if (gte mso 9)|(IE)]> </td> </tr> </table> <![endif]-->
  </body>
</html>
`,
    };
    await transporter.sendMail(msg);
  },
};
