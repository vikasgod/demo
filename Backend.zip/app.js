var express = require('express');
var session = require('express-session');
const bodyParser = require('body-parser');
var mysql = require('./db/mysqlconn');
var cookieParser = require('cookie-parser');
var cors = require('cors');
const os = require("os")
const path = require('path');
const cluster = require("cluster");
const port = process.env.PORT || 3232;
var app = express();

// app.use(cors({origin:['http://localhost:3232','http://localhost:4200'],credentials:true}))
// app.use(bodyParser.json({ limit: '50mb' }));
// app.use(express.json({ limit: '50mb' }))
// app.use(cookieParser());
// app.use(express.static(__dirname + '/public'));

app.use(express.json({ limit: "50mb" }));
app.use(express.urlencoded({ extended: true }));
// app.use(bodyParser.json());

app.use(session({
  secret: 'testing demo rbl',
  resave: true,
  saveUninitialized: true,
  // cookie  : { secure:false,maxAge:3600000 }
}))
app.use(cors());
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));

require("./router/usertemplate")(app);
require("./router/RblITTeam")(app);
require("./router/customertemp")(app);
require("./router/SuperAgent")(app);
require("./router/Agent")(app);
require("./router/Notification")(app);
require('./router/Admin')(app)

app.use('/uploads', express.static('uploads'));
// Set view file
app.set('views', path.join(__dirname, 'views'));
// Set view engine
app.set('view engine', 'ejs');

app.listen(port, '0.0.0.0', function () {
  console.log('Listening to port: ' + port);
});







