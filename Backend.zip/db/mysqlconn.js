require('dotenv').config()
var mysql = require('mysql2');
var mysqlconn = mysql.createConnection({
    host:process.env.DB_HOST,
    user:process.env.DB_USER,
    password:process.env.DB_PASS,
    database :process.env.DB_DATABSE,
})
mysqlconn.connect((err) =>{
    if(err) throw err;
    console.log('mysql connected '+process.env.DB_USER);
})
module.exports=mysqlconn;
