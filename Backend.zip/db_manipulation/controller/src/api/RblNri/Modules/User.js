require("dotenv").config();
var mysqlconn = require("../../../../../db/mysqlconn");
var config = require("../../../../../config/auth.config");
const { validationResult } = require("express-validator");
const bcrypt = require("bcryptjs");
const crypto = require("crypto");
var Convert = require("xml2js");
const { v4: uuidv4 } = require("uuid");
var fs = require("fs");
const path = require("path");
var async = require("async");
var randtoken = require("rand-token");
var flash = require("connect-flash");
// const { domain } =('frontEnd');
const sgMail = require("@sendgrid/mail");
var passport = require("passport");
const fast2sms = require("fast-two-sms");
const registration_email = require("../../../../../utils/emailService");
const authorization = require("../../../../../utils/smsService");
const query = require("../../../../../db/query.json");
const util = require("util");
const mysqlquery = util.promisify(mysqlconn.query).bind(mysqlconn);
const db_table = require("../../../../../db_manipulation/db_constant");
const set_jwt = require("../../../../../utils/jwt");
const create_pdf = require("../../../../../utils/pdf");
const account_json = require("../../../../../json/account.json");
const { now } = require("moment");
const { exit } = require("process");
const { default: axios } = require("axios");
const https = require("https");

module.exports.send_test_mail = async (req, res) => {
  const otp_params = {
    username: req.body.username,
    name: req.body.name,
  };
  const resp = await registration_email.registration_email_agent_it_users(
    otp_params
  );
  res.status(200).json({ msg: "Mail sent successfully" });
};

// Post route for generating PDF
module.exports.generate_pdf = async (req, res) => {
  if (req.body.email_address) {
    let sql = `select user_id from tbl_users where email_address=?`;
    const accountDetails = await mysqlquery(sql, [req.body.email_address]);
    let userId = accountDetails.map((x) => x["user_id"]);
    let accountData = await customerAccountInfo(userId);
    let account = account_json.find(
      (item) => item.account_type_id === accountData[0].account_type_id
    );
    let accountType = account.account_type;

    let final_result = {
      account_type: accountType,
    };

    accountData.forEach((element, index) => {
      final_result["applicant_" + (index + 1)] = element;
    });

    if (accountData.length > 0) {
      await create_pdf(final_result);
      res.status(200).json({ msg: "PDF generated successfully" });
    }
  } else {
    res.status(401).json({ msg: "User not found for this email" });
  }
};

// Database query
async function customerAccountInfo(userId) {
  let sql = `SELECT users.user_id,applicant.*,fatca.*,customerprofile.*,addressdetail.*,contactdetail.*,kycdetail.*,kycpio.*,bankfaciliti.*,nominations.*,leads.*, `;
  sql += `(SELECT countrie_name FROM ${db_table.countires} c WHERE FIND_IN_SET(c.countrie_id,applicant.country_id)) country_name, `;
  sql += `(SELECT countrie_name FROM ${db_table.countires} c WHERE FIND_IN_SET(c.countrie_id,applicant.nationality)) nationality_name, `;
  sql += `(SELECT countrie_name FROM ${db_table.countires} c WHERE FIND_IN_SET(c.countrie_id,fatca.tin_country_id)) tin_country_name, `;
  sql += `(SELECT countrie_name FROM ${db_table.countires} c WHERE FIND_IN_SET(c.countrie_id,fatca.tin_issue_county_id)) tin_issue_country_name, `;
  sql += `(SELECT countrie_name FROM ${db_table.countires} c WHERE FIND_IN_SET(c.countrie_id,fatca.birth_county_id)) birth_country_name, `;
  sql += `(SELECT religion_name FROM ${db_table.religions} r WHERE FIND_IN_SET(r.religion_id,applicant.religion_id)) religion_name, `;
  sql += `(SELECT employment_types_name FROM ${db_table.employment_types} e WHERE FIND_IN_SET(e.employment_types_id,customerprofile.employment_type_id)) employment_type, `;
  sql += `(SELECT industrie_name FROM ${db_table.industries} i WHERE FIND_IN_SET(i.industrie_id,customerprofile.industry_type_id)) industrie_name, `;
  sql += `(SELECT address_type_name  FROM ${db_table.address_type} address WHERE FIND_IN_SET(address.address_type_id,addressdetail.current_address_type)) address_type, `;
  sql += `(SELECT countrie_name FROM ${db_table.countires} c WHERE FIND_IN_SET(c.countrie_id,addressdetail.current_country_id)) current_country_name, `;
  sql += `(SELECT address_type_name  FROM ${db_table.address_type} address WHERE FIND_IN_SET(address.address_type_id,addressdetail.overseas_address_type)) overseas_type_address, `;
  sql += `(SELECT countrie_name FROM ${db_table.countires} c WHERE FIND_IN_SET(c.countrie_id,addressdetail.overseas_country_id)) overseas_country, `;
  sql += `(SELECT address_type_name  FROM ${db_table.address_type} address WHERE FIND_IN_SET(address.address_type_id,addressdetail.permenant_address_type)) permenant_type_address, `;
  sql += `(SELECT countrie_name FROM ${db_table.countires} c WHERE FIND_IN_SET(c.countrie_id,addressdetail.permenant_country_id)) permenant_country, `;
  sql += `(SELECT address_type_name  FROM ${db_table.address_type} address WHERE FIND_IN_SET(address.address_type_id,addressdetail.jurisdiction_address_type)) jurisdiction_type_address, `;
  sql += `(SELECT countrie_name FROM ${db_table.countires} c WHERE FIND_IN_SET(c.countrie_id,addressdetail.jurisdiction_country_id)) jurisdiction_country, `;
  sql += `(SELECT visa_type_name FROM ${db_table.visa_type} v WHERE FIND_IN_SET(v.visa_type_id,kycdetail.visa_type)) visa_type_name `;
  sql += `FROM tbl_users as users `;
  sql += `LEFT JOIN ${db_table.applicant_persional_details} as applicant on applicant.user_id=users.user_id `;
  sql += `LEFT JOIN ${db_table.customer_profilers} as customerprofile on  applicant.applicant_personal_id=customerprofile.applicant_id `;
  sql += `LEFT JOIN ${db_table.address_details} as addressdetail on applicant.applicant_personal_id=addressdetail.applicant_id `;
  sql += `LEFT JOIN ${db_table.factas} as fatca on applicant.applicant_personal_id=fatca.applicant_id `;
  sql += `LEFT JOIN ${db_table.contact_details} as contactdetail on applicant.applicant_personal_id=contactdetail.applicant_id `;
  sql += `LEFT JOIN ${db_table.kyc_details} as kycdetail on applicant.applicant_personal_id=kycdetail.applicant_id `;
  sql += `LEFT JOIN ${db_table.kyc_pio_declarations} as kycpio on applicant.applicant_personal_id=kycpio.applicant_id `;
  sql += `LEFT JOIN ${db_table.banking_facilities} as bankfaciliti on applicant.applicant_personal_id=bankfaciliti.applicant_id `;
  sql += `LEFT JOIN ${db_table.nominations} as nominations on applicant.applicant_personal_id=nominations.applicant_id `;
  sql += `LEFT JOIN ${db_table.leads} as leads on leads.user_id=users.user_id `;
  sql += `WHERE users.user_id=?`;

  return await mysqlquery(sql, [userId]);
}

module.exports.techadmin_signup = async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }
    let userGet = `SELECT * FROM ${db_table.users} WHERE LOWER(email_address) =? `;
    var result = await mysqlquery(userGet, [req.body.email_address]);
    if (result.length) {
      return res.status(409).send({
        msg: "This email is already in use!",
      });
    } else {
      var hash = await bcrypt.hash(req.body.password, 10);
      let sql = `INSERT INTO ${db_table.users} SET ? `;
      var userdata = {
        first_name: req.body.first_name,
        middle_name: req.body.middle_name,
        last_name: req.body.last_name,
        mobile_no: req.body.mobile_no,
        email_address: req.body.email_address,
        password: hash,
        role_id: 1,
        status: "active",
        created_by: 1,
      };
      var signupdata = await mysqlquery(sql, userdata);
      if (signupdata.insertId > 0) {
        res.status(200).json({
          msg: "The user has been registerd with us!",
        });
      } else {
        res.status(400).json({
          msg: "bad request",
        });
      }
    }
  } catch (error) {
    res.status(400).json({
      msg: error.message ? error.message : error,
    });
  }
};

module.exports.register_it_agent_users = async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }
    let userGet = `SELECT * FROM ${db_table.users} WHERE LOWER(email_address) =? `;
    var result = await mysqlquery(userGet, [req.body.email_address]);
    if (result.length > 0) {
      return res.status(409).send({
        msg: "This email is already in use!",
      });
    } else {
      var password = Math.random().toString(36).slice(-8);
      var hash = await bcrypt.hash(password, 10);
      let sql = `INSERT INTO ${db_table.users} SET ? `;
      var username = req.body.email_address;
      role_id = 0;
      if (req.body.user_type == "it") {
        role_id = 2;
      }

      if (req.body.user_type == "agent") {
        role_id = 3;
      }
      var userdata = {
        first_name: req.body.first_name,
        middle_name: req.body.middle_name,
        last_name: req.body.last_name,
        mobile_no: req.body.mobile_no,
        email_address: req.body.email_address,
        password: hash,
        role_id: role_id,
        created_by: req.body.user_id,
        status: "active",
      };
      var register_it_agent = await mysqlquery(sql, userdata);
      registration_email.registration_email_agent_it_users(username, password);
      if (register_it_agent.insertId > 0) {
        res.status(200).json({
          msg: "The user has been registerd with us!",
        });
      } else {
        res.status(400).json({
          msg: "bad request",
        });
      }
    }
  } catch (error) {
    res.status(400).json({
      msg: error.message ? error.message : error,
    });
  }
};

//customer signup-login

module.exports.customer_signup = async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }
    let userGet = `SELECT * FROM ${db_table.users} WHERE LOWER(email_address) = ? `;
    var result = await mysqlquery(userGet, [req.body.email_address]);
    
    if (result.length) {
      return res.status(409).send({
        msg: "This Email id is already in use!",
      });
    } else {
      let sql = `INSERT INTO ${db_table.users} SET ? `;
      var userdata = {
        first_name: req.body.first_name,
        middle_name: req.body.middle_name,
        last_name: req.body.last_name,
        isd_code: req.body.isd_code,
        mobile_no: req.body.mobile_no,
        email_address: req.body.email_address,
        role_id: 4,
        created_by: 0,
        status: "active",
      };
      
     
      var customer_registration = await mysqlquery(sql, userdata);
      const now = Date.now();
       
var leaddata = {
        user_id: customer_registration.insertId,
        lead_number: `RBLNRI${now}`,
        lead_status: "customer_process",
      };
      let leadsql = `INSERT INTO ${db_table.leads} SET ?`;
      const submit_lead_details = await mysqlquery(leadsql, leaddata);

      if (customer_registration.insertId > 0) {
        res.status(200).json({
          msg: "The user has been registerd with us!",
          user_id: customer_registration.insertId,
          email_address: req.body.email_address,
          mobile_no: req.body.mobile_no,
        });
      } else {
        res.status(400).json({
          msg: "bad request",
        });
      }
    }
  } catch (error) {
    res.status(400).json({
      msg: error.message ? error.message : error,
    });
  }
};

// module.exports.send_email_otp = async (req, res) => {
//   try {
//     const errors = validationResult(req);
//     if (!errors.isEmpty()) {
//       return res.status(400).json({ errors: errors.array() });
//     }
//     if (req.body.email_address) {
//       is_otp_send = false;
//       var user_query = `SELECT * FROM ${db_table.users} WHERE email_address=?`;
//       var user_result = await mysqlquery(user_query, [req.body.email_address]);
//       if (user_result.length > 0) {
//         const user_data = Object.values(user_result);
//         const user_id = user_data[0].user_id;
//         const name = user_data[0].first_name + " " + user_data[0].last_name;
//         var otp = Math.floor(100000 + Math.random() * 900000);
//         let otp_params = {
//           user_id: user_id,
//           otp_type: "email",
//           email_address: req.body.email_address,
//           otp: otp,
//           name: name,
//           image:process.env.URL
//         };
//         let user_otp_query = `SELECT * FROM ${db_table.otps} WHERE otp_type=? and User_ID=?`;
//         let users_otp_result = await mysqlquery(user_otp_query, [
//           "email",
//           user_id,
//         ]);
//         if (users_otp_result.length != 0) {
//           const user_otp_data = Object.values(users_otp_result);
//           const expire_on = user_otp_data[0].expire_on;
//           let current_date = new Date();
//           d = new Date(expire_on);
//           d.setMinutes(d.getMinutes() - 10);
//           d.setMinutes(d.getMinutes() + 2);
//           if (current_date > d) {
//             is_otp_send = generate_otp(otp_params);
//           } else {
//             return res
//               .status(401)
//               .json({ msg: "OTP already send please try again 2 minutes" });
//           }
//         } else {
//           is_otp_send = generate_otp(otp_params);
//         }
//         if (is_otp_send) {
//           return res.status(200).json({
//             msg: "OTP has been send to your email address",
//             otp: otp,
//           });
//         } else {
//           return res.status(401).json({
//             msg: "unable to generate OTP please try again",
//           });
//         }
//       } else {
//         return res.status(401).json({ msg: "User not found for this email" });
//       }
//     }
//   } catch (error) {
//     res.status(400).json({
//       msg: error.message ? error.message : error,
//     });
//   }
// };

get_token = async (req) => {
  try {
    let payload = {
      getToken: {
        RequestHeader: {
          MessageKey: {
            RequestUUID: uuidv4(),
            ServiceRequestId: "GETTOKEN",
            ServiceRequestVersion: "1.0",
            ChannelId: "",
          },
          RequestMessageInfo: {
            BankId: "",
            TimeZone: "",
            MessageDateTime: "",
          },
          Security: {
            Token: {
              Certificate: "",
              MessageHashKey: "",
              MessageIndex: "",
              PasswordToken: {
                UserId: "",
                Password: "",
              },
            },
          },
          DeviceInfo: {
            DeviceFamily: "",
            DeviceFormat: "",
            DeviceType: "",
            DeviceName: "",
            DeviceIMEI: "",
            DeviceID: "",
            DeviceVersion: "",
            AppVersion: "",
            DeviceOS: "",
            DeviceIp: process.env.RBL_DEVICE_IP,
          },
          AdditionalInfo: {
            JourneyId: "",
            LanguageId: "",
            SVersion: "",
            SessionId: "",
          },
        },
        RequestBody: {
          getTokenRequestBody: {
            clientId: process.env.RBL_CLIENT_ID,
            clientSecret: process.env.RBL_SECRET_ID,
          },
        },
      },
    };
  
    const agent = new https.Agent({
      rejectUnauthorized: false,
    });
    const axiosConfig = {
      httpsAgent: agent,
    };
    const response = await axios.post(
      `${process.env.RBL_SENTINAL_URL}/api/v1/OAUTH/get-token`,
      payload,
      axiosConfig
    );
    let responseData = response.data.generateTokenResponse.Status.StatusCode == "0"
    if(responseData){
      req.session.token = responseData.generateTokenResponse?.ResponseBody?.generateTokenResponseBody?.access_token
      req.session.expires_in = Date.now() + (responseData.generateTokenResponse?.ResponseBody?.generateTokenResponseBody?.expires_in * 1000)
    }else{
      console.log('something went wrong')
    }
  } catch (error) {
    console.error("Getting error while generate the token",error)
  }
};
// intradx API
module.exports.send_email_otp = async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }
    if (req.body.email_address) {
      var user_query = `SELECT * FROM ${db_table.users} WHERE email_address=?`;
      var user_result = await mysqlquery(user_query, [req.body.email_address]);
      if (user_result.length > 0) {
        if(!req?.session?.token){
          await get_token(req)
        }else if(Date.now() > req.session.expires_in){
          await get_token(req)
        }
        var data = JSON.stringify({
          "OTPGeneration": {
            "RequestBody": {
              "OTPGenerationRequestBody": {
                "requestId":uuidv4().replace(/-/g, '').substring(0,24),
                "email": req.body.email_address,
                "mobileno": `${user_result[0]?.mobile_no}`,
                "channelId": "ABACUS",
                "deliveryFlag": "E",
                "serviceType": "N",
                "IsNRI": "N",
                "checksum": "",
                "customerName": user_result[0].first_name,
                "optionalField1": "IMPS",
                "optionalField2": "100.0",
                "optionalField3": "RUTVIJ",
                "optionalField4": "",
                "optionalField5": "",
                "TransactionRefID": ""
              }
            },
            "RequestHeader": {
              "Security": {
                "Token": {
                  "MessageHashKey": "",
                  "MessageIndex": "",
                  "PasswordToken": {
                    "Password": "",
                    "UserId": "1012"
                  },
                  "Certificate": ""
                }
              },
              "AdditionalInfo": {
                "SessionId": "",
                "JourneyId": "",
                "LanguageId": "",
                "SVersion": ""
              },
              "DeviceInfo": {
                "DeviceName": "",
                "DeviceVersion": "",
                "DeviceID": "",
                "DeviceOS": "",
                "AppVersion": "",
                "DeviceFormat": "",
                "DeviceFamily": "",
                "DeviceType": "",
                "DeviceIp": "",
                "DeviceIMEI": ""
              },
              "RequestMessageInfo": {
                "MessageDateTime": "2022-02-18T12:48:49.034",
                "BankId": "01",
                "TimeZone": "GMT+05:00"
              },
              "MessageKey": {
                "ChannelId": "ABACUS",
                "RequestUUID": "1645168729035",
                "ServiceRequestId": "GENOTP",
                "ServiceRequestVersion": "1"
              }
            }
          }
        });
        const agent = new https.Agent({rejectUnauthorized: false});
        var config = {
          method: 'post',
          url: 'https://uatcluster2.ratnakarbank.in/otp/api/v1/generateOtp',
          headers: { 
            'x-rbl-auth': `Bearer ${req.session.token}`, 
            'x-api-key': 'gKZNiD0J4FAM68peiNZsw594sztYOnZb', 
            'Content-Type': 'application/json'
          },
          data : data,
          httpsAgent: agent,
        };
         
        axios(config)
        .then(function (response) {
         return res.status(200).json({
            msg: "OTP has been send to your email address",
            data:response.data.OTPGenerationResponse.ResponseBody.OTPGenerationResponseBody.otpKey
          })
        })
        .catch(function (error) {
          console.log(error);
        });  
      } else {
        return res.status(401).json({ msg: "User not found for this email" });
      }
    }
  } catch (error) {
    res.status(400).json({
      msg: error.message ? error.message : error,
    });
  }
};   

generate_otp = async (otp_params) => {
  let otp_delete_query = `DELETE FROM ${db_table.otps} WHERE User_ID=? `;
  var deleteotp = await mysqlquery(otp_delete_query, [otp_params.user_id]);

  let email_tem_sql = `SELECT email_template FROM ${db_table.email_temp}`;
  let email_temp_result = await mysqlquery(email_tem_sql);

  var email_tempmplate_data = email_temp_result[0].email_template;

  const current_time = new Date();
  current_time.setMinutes(current_time.getMinutes() + 2);
  var userdata = {
    User_ID: otp_params.user_id,
    otp_type: otp_params.otp_type,
    otp: otp_params.otp,
    expire_on: current_time,
  };
  let insert_otp_query = `INSERT INTO ${db_table.otps} SET ? `;
  var insert_otp_result = await mysqlquery(insert_otp_query, userdata);
  if (insert_otp_result.insertId != 0) {
    if (otp_params.otp_type == "email") {
      registration_email.customer_Emailverify(otp_params);
    } else if (otp_params.otp_type == "mobile") {
      registration_email.customer_Mobileverify(otp_params);
    }
  }
  return true;
};

// module.exports.email_verify_otp = async (req, res) => {
//   try {
//     const errors = validationResult(req);
//     if (!errors.isEmpty()) {
//       return res.status(400).json({ errors: errors.array() });
//     }

//     let user_otp_verify = `SELECT * FROM ${db_table.otps} where expire_on > now() and otp_type=? and otp=?`;
//     var user = await mysqlquery(user_otp_verify, ["email", req.body.email_otp]);
//     if (user == 0) {
//       return res.status(401).json({ msg: "OTP is invalid" });
//     }

//     let eamil_address = `SELECT * FROM ${db_table.users} where email_address=?`;
//     var doc = await mysqlquery(eamil_address, [req.body.email_address]);
//     if (doc == 0) {
//       return res.status(401).json({ msg: "user not found this email" });
//     }

//     const userotp = JSON.stringify(user);
//     const UserOtp = JSON.parse(userotp);

//     var OTP = UserOtp.map(function (obj) {
//       return obj.otp;
//     });

//     var iterator = OTP.values();
//     var otpvalue = iterator.next().value;

//     var otp = parseInt(otpvalue);
//     var email_otp = parseInt(req.body.email_otp);

//     if (email_otp == otp) {
//       if (req.body.rt == "customer/login") {
//         return set_jwt.set_jwt_auth(doc, res);
//       }

//       let otp_delete = `DELETE FROM ${db_table.otps} WHERE User_ID=? `;
//       var deleteotp = await mysqlquery(otp_delete, [doc[0].user_id]);

//       let is_email_verify = 1;
//       const update_useremail_verify = [is_email_verify, [doc[0].user_id]];
//       let sql = `update ${db_table.users} SET is_email_verify=? WHERE user_id=?`;
//       const update_user_verify = await mysqlquery(sql, update_useremail_verify);

//       res.status(200).json({
//         msg: "user verified in this emailid",
//       });
//     } else {
//       res.status(401).json({
//         msg: "otp do not match.",
//       });
//     }
//   } catch (error) {
//     res.status(400).json({
//       msg: error.message ? error.message : error,
//     });
//   }
// };

module.exports.email_verify_otp = async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }
    const hashedOTP=crypto.createHash("sha256").update(req.body.email_otp).digest("base64")

    let payload = {
      OTPValidation: {
        RequestBody: {
          OTPValidationRequestBody: {
            requestId: req.body.requestId,
            otp: `${hashedOTP}`,
            channelId: "ABACUS",
          },
        },
        RequestHeader: {
          MessageKey: {
            RequestUUID: uuidv4(),
            ServiceRequestId: "VALOTP",
            ServiceRequestVersion: "1.0",
            ChannelId: "ABACUS",
          },
          RequestMessageInfo: {
            BankId: "",
            TimeZone: "",
            MessageDateTime: new Date(),
          },
          Security: {
            Token: {
              Certificate: "",
              MessageHashKey: "",
              MessageIndex: "",
              PasswordToken: {
                UserId: "",
                Password: "",
              },
            },
          },
          DeviceInfo: {
            DeviceFamily: "",
            DeviceFormat: "",
            DeviceType: "",
            DeviceName: "",
            DeviceIMEI: "",
            DeviceID: "",
            DeviceVersion: "12",
            AppVersion: "3.102",
            DeviceOS: "Android",
            DeviceIp: "",
          },
          AdditionalInfo: {
            SessionId:
              "",
            LanguageId: "1",
            JourneyId: "",
            SVersion: "1.9",
          },
        },
      },
    };
    const agent = new https.Agent({
      rejectUnauthorized: false,
    });
    let header = {
      "x-rbl-auth":req.session.token,
      "x-api-key":process.env.RBL_API_KEY
    }
    const axiosConfig = {
      httpsAgent: agent,
      headers:header
    };
    const response = await axios.post(
      `https://uatcluster2.ratnakarbank.in/otp/api/v1/ValidateOtp`,
      payload,
      axiosConfig
    );
    let responseData = response.data.OTPValidationResponse;
    
    if(responseData.Status.StatusCode == "0"){
      res.status(200).json({
        msg: "user verified in this emailid",
      })
    }else{
      res.status(401).json({
        msg: "OTP do not match.",
      });
    }
  } catch (error) {
    console.log("dshgfdhf error")
    res.status(400).json({
      msg: error.message ? error.message : error,
    });
  }
};


// module.exports.send_mobile_otp = async (req, res) => {
//   try {
//     const errors = validationResult(req);
//     if (!errors.isEmpty()) {
//       return res.status(400).json({ errors: errors.array() });
//     }
//     if (req.body.mobile_no) {
//       is_otp_send = false;
//       var user_query = `SELECT * FROM ${db_table.users} WHERE mobile_no=?`;
//       var user_result = await mysqlquery(user_query, [req.body.mobile_no]);
//       if (user_result.length > 0) {
//         const user_data = Object.values(user_result);
//         const user_id = user_data[0].user_id;
//         let name = user_result[0].first_name + " " + user_result[0].last_name;
//         let email = user_result[0].email_address;
//         var otp = Math.floor(100000 + Math.random() * 900000);
//         let otp_params = {
//           user_id: user_id,
//           otp_type: "mobile",
//           email_address: email,
//           otp: otp,
//           name: name,
//           image:process.env.URL
//         };
//         let user_otp_query = `SELECT * FROM ${db_table.otps} WHERE otp_type=? and User_ID=?`;
//         let users_otp_result = await mysqlquery(user_otp_query, [
//           "mobile",
//           user_id,
//         ]);
//         if (users_otp_result.length != 0) {
//           const user_otp_data = Object.values(users_otp_result);
//           const expire_on = user_otp_data[0].expire_on;
//           let current_date = new Date();
//           d = new Date(expire_on);
//           d.setMinutes(d.getMinutes() - 10);
//           d.setMinutes(d.getMinutes() + 2);
//           if (current_date > d) {
//             is_otp_send = generate_otp(otp_params);
//           } else {
//             return res
//               .status(401)
//               .json({ msg: "OTP already send please try again 2 minutes" });
//           }
//         } else {
//           is_otp_send = generate_otp(otp_params);
//         }
//         if (is_otp_send) {
//           return res.status(200).json({
//             msg: `OTP has been send to your ${email} email address`,
//             otp: otp,
//           });
//         } else {
//           return res.status(401).json({
//             msg: "unable to generate otp please try again",
//           });
//         }
//       } else {
//         return res
//           .status(401)
//           .json({ msg: "User not found for this mobile no" });
//       }
//     }
//   } catch (error) {
//     res.status(400).json({
//       msg: error.message ? error.message : error,
//     });
//   }
// };


// intradx api
module.exports.send_mobile_otp = async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }
    if (req.body.mobile_no) {
      var user_query = `SELECT * FROM ${db_table.users} WHERE mobile_no=?`;
      var user_result = await mysqlquery(user_query, [req.body.mobile_no]);
      if (user_result.length > 0){
        if(!req?.session?.token){
          await get_token(req)
        }else if(Date.now() > req.session.expires_in){
          await get_token(req)
        }
        var data = JSON.stringify({
          "OTPGeneration": {
            "RequestBody": {
              "OTPGenerationRequestBody": {
                "requestId":uuidv4().replace(/-/g, '').substring(0,24),
                "email": `${user_result[0]?.email_address}`,
                "mobileno": req.body.mobile_no,
                "channelId": "ABACUS",
                "deliveryFlag": "E",
                "serviceType": "N",
                "IsNRI": "N",
                "checksum": "",
                "customerName": user_result[0].first_name,
                "optionalField1": "IMPS",
                "optionalField2": "100.0",
                "optionalField3": "RUTVIJ",
                "optionalField4": "",
                "optionalField5": "",
                "TransactionRefID": ""
              }
            },
            "RequestHeader": {
              "Security": {
                "Token": {
                  "MessageHashKey": "",
                  "MessageIndex": "",
                  "PasswordToken": {
                    "Password": "",
                    "UserId": "1012"
                  },
                  "Certificate": ""
                }
              },
              "AdditionalInfo": {
                "SessionId": "",
                "JourneyId": "",
                "LanguageId": "",
                "SVersion": ""
              },
              "DeviceInfo": {
                "DeviceName": "",
                "DeviceVersion": "",
                "DeviceID": "",
                "DeviceOS": "",
                "AppVersion": "",
                "DeviceFormat": "",
                "DeviceFamily": "",
                "DeviceType": "",
                "DeviceIp": "",
                "DeviceIMEI": ""
              },
              "RequestMessageInfo": {
                "MessageDateTime": "2022-02-18T12:48:49.034",
                "BankId": "01",
                "TimeZone": "GMT+05:00"
              },
              "MessageKey": {
                "ChannelId": "ABACUS",
                "RequestUUID": "1645168729035",
                "ServiceRequestId": "GENOTP",
                "ServiceRequestVersion": "1"
              }
            }
          }
        });
        const agent = new https.Agent({rejectUnauthorized: false});
        var config = {
          method: 'post',
          url: 'https://uatcluster2.ratnakarbank.in/otp/api/v1/generateOtp',
          headers: { 
            'x-rbl-auth': `Bearer ${req.session.token}`, 
            'x-api-key': process.env.RBL_API_KEY, 
            'Content-Type': 'application/json'
          },
          data : data,
          httpsAgent: agent,
        };
         
        axios(config)
        .then(function (response) {
         return res.status(200).json({
            msg: "OTP has been send to your email address",
            data:response.data.OTPGenerationResponse.ResponseBody.OTPGenerationResponseBody.otpKey
          })
        })
        .catch(function (error) {
          console.log(error);
        });
      } else {
        return res
          .status(401)
          .json({ msg: "User not found for this mobile no" });
      }
    }
  } catch (error) {
    res.status(400).json({
      msg: error.message ? error.message : error,
    });
  }
};

module.exports.process_jwt = async (req, res) => {
  try {
    let user_find = `SELECT * FROM ${db_table.users} WHERE user_id=?`;
    var doc = await mysqlquery(user_find, [req.body.user_id]);
    if (doc == 0) {
      return res.status(404).json({ msg: "User not found for this ID." });
    } else {
      return set_jwt.set_jwt_auth(doc, res);
    }
  } catch (error) {
    res.status(400).json({
      msg: error.message ? error.message : error,
    });
  }
};

// module.exports.mobile_no_verifyotp = async (req, res) => {
//   try {
//     const errors = validationResult(req);
//     if (!errors.isEmpty()) {
//       return res.status(400).json({ errors: errors.array() });
//     }
//     let user_find = `SELECT * FROM ${db_table.users} WHERE mobile_no=?`;
//     var doc = await mysqlquery(user_find, [req.body.mobile_no]);
//     if (doc == 0) {
//       return res
//         .status(404)
//         .json({ msg: "User not found for this mobile no." });
//     }
//     let user_otp_verify = `SELECT * FROM ${db_table.otps} where expire_on > now() and otp_type=? and otp=?`;
//     var user = await mysqlquery(user_otp_verify, [
//       "mobile",
//       req.body.mobile_otp,
//     ]);
//     if (user == 0) {
//       return res.status(401).json({ msg: "OTP is invalid" });
//     }

//     const userotp = JSON.stringify(user);
//     const UserOtp = JSON.parse(userotp);

//     var OTP = UserOtp.map(function (obj) {
//       return obj.otp;
//     });

//     var iterator = OTP.values();
//     var otpvalue = iterator.next().value;

//     if (req.body.mobile_otp === otpvalue) {
//       let otp_delete = `DELETE FROM ${db_table.otps} WHERE User_ID=? `;
//       var deleteotp = await mysqlquery(otp_delete, [doc[0].user_id]);

//       let is_mobile_verify = 1;
//       const update_usermobile_verify = [is_mobile_verify, [doc[0].user_id]];
//       let sql = `update ${db_table.users} SET is_mobile_verify=? WHERE user_id=?`;
//       const update_user_verify = await mysqlquery(
//         sql,
//         update_usermobile_verify
//       );

//       res.status(200).json({
//         msg: "user verified in this mobile_no",
//       });
//     } else {
//       res.status(401).json({
//         msg: "OTP do not match.",
//       });
//     }
//   } catch (error) {
//     res.status(400).json({
//       msg: error.message ? error.message : error,
//     });
//   }
// };

module.exports.mobile_no_verifyotp = async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }
    const hashedOTP=crypto.createHash("sha256").update(req.body.mobile_otp).digest("base64")

    let payload = {
      OTPValidation: {
        RequestBody: {
          OTPValidationRequestBody: {
            requestId: req.body.requestId,
            otp: `${hashedOTP}`,
            channelId: "ABACUS",
          },
        },
        RequestHeader: {
          MessageKey: {
            RequestUUID: uuidv4(),
            ServiceRequestId: "VALOTP",
            ServiceRequestVersion: "1.0",
            ChannelId: "ABACUS",
          },
          RequestMessageInfo: {
            BankId: "",
            TimeZone: "",
            MessageDateTime: new Date(),
          },
          Security: {
            Token: {
              Certificate: "",
              MessageHashKey: "",
              MessageIndex: "",
              PasswordToken: {
                UserId: "",
                Password: "",
              },
            },
          },
          DeviceInfo: {
            DeviceFamily: "",
            DeviceFormat: "",
            DeviceType: "",
            DeviceName: "",
            DeviceIMEI: "",
            DeviceID: "",
            DeviceVersion: "12",
            AppVersion: "3.102",
            DeviceOS: "Android",
            DeviceIp: "",
          },
          AdditionalInfo: {
            SessionId:
              "",
            LanguageId: "1",
            JourneyId: "",
            SVersion: "1.9",
          },
        },
      },
    };
    const agent = new https.Agent({
      rejectUnauthorized: false,
    });
    let header = {
      "x-rbl-auth":req.session.token,
      "x-api-key":process.env.RBL_API_KEY
    }
    const axiosConfig = {
      httpsAgent: agent,
      headers:header
    };
    const response = await axios.post(
      `https://uatcluster2.ratnakarbank.in/otp/api/v1/ValidateOtp`,
      payload,
      axiosConfig
    );
    let responseData = response.data.OTPValidationResponse;
    
    if(responseData.Status.StatusCode == "0"){
      res.status(200).json({
        msg: "user verified in this emailid",
      })
    }else{
      res.status(401).json({
        msg: "OTP do not match.",
      });
    }
  } catch (error) {
    res.status(400).json({
      msg: error.message ? error.message : error,
    });
  }
};

/////customer end

// module.exports.login = async (req, res) => {
//   try {
//     await get_token(req)
//     let sql = `SELECT * FROM  ${db_table.users} WHERE username ='${req.body.username}'`;
//     let doc = await mysqlquery(sql);
//     if (!doc.length) {
//       res.status(201).send({
//         msg: "User not have permission",
//       });
//     } else {
//       let data = {
//         LdapDtls: {
//           Request: {
//             UserId: req.body.username,
//             ChlId: "IIB",
//             DeviceFamily: "",
//             DeviceFormat: "",
//             OperationId: "123",
//             LoginPwd: req.body.password,
//             ClientAPIVer: "1.0",
//             SessionId: "1999769OKDDP",
//             TransSeq: "01",
//           },
//         },
//       };
//       var builder = new Convert.Builder();
//       var xml = builder.buildObject(data);
//       const agent = new https.Agent({
//         rejectUnauthorized: false,
//       });
//       const axiosConfig = {
//         httpsAgent: agent,
//       };
//       const response = await axios.post(
//         `${process.env.RBL_URL}/rbl/esb/ldapdetails`,
//         xml,
//         axiosConfig
//       );
//       let user = await response.data;
//       Convert.parseString(user, async (err, result) => {
//         if (err) {
//           console.error(err);
//           return;
//         }
//         let resultData = result.LdapDtls;
//         if (resultData.Response[0]?.Status[0] === "SUCCESS") {
//           let sql = `SELECT email_address from ${db_table.users} WHERE username = '${req.body.username}'`;
//           let sqlData = await mysqlquery(sql);
//           if (sqlData[0].eamil_address === undefined) {
//             let sqlEmail = `UPDATE ${
//               db_table.users
//             } SET email_address = '${resultData.Response[0].Email[0].replace(
//               /\s+/g,
//               ""
//             )}' WHERE username = '${req.body.username}'`;
//             await mysqlquery(sqlEmail);
//             return set_jwt.set_jwt_auth(doc, res);
//           } else {
//             return set_jwt.set_jwt_auth(doc, res);
//           }
//         } else {
//           res.status(201).send({
//             msg: "Password incorrect !",
//           });
//         }
//       });
//     }
//   } catch (error) {
//     res.status(400).json({
//       msg: error,
//     });
//   }
// };

module.exports.login = async (req, res) => {
  try {
    
    let sql = `SELECT * FROM  ${db_table.users} WHERE username ='${req.body.username}'`;
    let doc = await mysqlquery(sql);
    if (!doc.length) {
      res.status(201).send({
        msg: "User not have permission",
      });
    } else {
        try {
          let payload = {
            getToken: {
              RequestHeader: {
                MessageKey: {
                  RequestUUID: uuidv4(),
                  ServiceRequestId: "GETTOKEN",
                  ServiceRequestVersion: "1.0",
                  ChannelId: "",
                },
                RequestMessageInfo: {
                  BankId: "",
                  TimeZone: "",
                  MessageDateTime: "",
                },
                Security: {
                  Token: {
                    Certificate: "",
                    MessageHashKey: "",
                    MessageIndex: "",
                    PasswordToken: {
                      UserId: "",
                      Password: "",
                    },
                  },
                },
                DeviceInfo: {
                  DeviceFamily: "",
                  DeviceFormat: "",
                  DeviceType: "",
                  DeviceName: "",
                  DeviceIMEI: "",
                  DeviceID: "",
                  DeviceVersion: "",
                  AppVersion: "",
                  DeviceOS: "",
                  DeviceIp: process.env.RBL_DEVICE_IP,
                },
                AdditionalInfo: {
                  JourneyId: "",
                  LanguageId: "",
                  SVersion: "",
                  SessionId: "",
                },
              },
              RequestBody: {
                getTokenRequestBody: {
                  clientId: process.env.RBL_CLIENT_ID,
                  clientSecret: process.env.RBL_SECRET_ID,
                },
              },
            },
          };
        
          const agent = new https.Agent({
            rejectUnauthorized: false,
          });
          const axiosConfig = {
            httpsAgent: agent,
          };
          const response = await axios.post(
            `${process.env.RBL_SENTINAL_URL}/api/v1/OAUTH/get-token`,
            payload,
            axiosConfig
          );
          let responseData = response.data
          if(responseData){
            req.session.token = responseData.generateTokenResponse.ResponseBody.generateTokenResponseBody.access_token
            req.session.expires_in = Date.now() + (responseData.generateTokenResponse.ResponseBody.generateTokenResponseBody.expires_in * 1000)
          } 
        } catch (error) {
          console.error("Getting error while generate the token",error)
        }
      let data = {
        LdapDtls: {
          Request: {
            UserId: req.body.username,
            ChlId: "IIB",
            DeviceFamily: "",
            DeviceFormat: "",
            OperationId: "123",
            LoginPwd: req.body.password,
            ClientAPIVer: "1.0",
            SessionId: "1999769OKDDP",
            TransSeq: "01",
          },
        },
      };
      var builder = new Convert.Builder();
      var xml = builder.buildObject(data);
      const agent = new https.Agent({
        rejectUnauthorized: false,
      });
      let header = {
        "x-rbl-auth": `Bearer ${req.session.token}`,
        "x-api-key": process.env.RBL_API_KEY,
      };
      const axiosConfig = {
        httpsAgent: agent,
        headers: header,
      };
      const response = await axios.post(
        `${process.env.RBL_URL}/rbl/esb/ldapdetails`,
        xml,
        axiosConfig
      );
      let user = await response.data;
      Convert.parseString(user, async (err, result) => {
        if (err) {
          console.error(err);
          return;
        }
        let resultData = result.LdapDtls;
        if (resultData.Response[0]?.Status[0] === "SUCCESS") {
          let sql = `SELECT email_address from ${db_table.users} WHERE username = '${req.body.username}'`;
          let sqlData = await mysqlquery(sql);
          if (sqlData[0].eamil_address === undefined) {
            let sqlEmail = `UPDATE ${
              db_table.users
            } SET email_address = '${resultData.Response[0].Email[0].replace(
              /\s+/g,
              ""
            )}' WHERE username = '${req.body.username}'`;
            await mysqlquery(sqlEmail);
            return set_jwt.set_jwt_auth(doc, res);
          } else {
            return set_jwt.set_jwt_auth(doc, res);
          }
        } else {
          res.status(201).send({
            msg: "Password incorrect !",
          });
        }
      });
    }
  } catch (error) {
    res.status(400).json({
      msg: error,
    });
  }
};

module.exports.logout = (req, res) => {
  try {
    return res
      .clearCookie("accessToken")
      .status(200)
      .json({ msg: "Successfully logged out 😏 🍀" });
  } catch (error) {
    res.status(400).json({
      msg: error.message ? error.message : error,
    });
  }
};

module.exports.refreshaccesstoken = function (req, res) {
  try {
    const refreshToken = req.cookies.refreshToken;
    if (refreshToken) {
      jwt.verify(refreshToken, process.env.API_KEY, function (err, user) {
        if (!err) {
          console.log(user);
          const token = jwt.sign({ id: user.id }, process.env.API_KEY, {
            expiresIn: jwtexpirationtime.jwtAccessExpiration,
          });
          res.cookie("accessToken", token, { httpOnly: true });
          res.status(200).json({ msg: "user refresh authenticate" });
        } else {
          console.log(err);
          res.status(401).json({ msg: "Token Expired" });
          //res.status(400).json({message:"user not authenticate"})
        }
      });
    } else {
      res.status(401).json({ msg: "Token Expired" });
      //res.status(400).json({message:"user not authenticate"})
    }
  } catch (error) {
    res.status(400).json({
      msg: error.message ? error.message : error,
    });
  }
};

module.exports.getallusers = async (req, res) => {
  try {
    let users = `SELECT * FROM ${db_table.users}`;
    const getAllUsers = await mysqlquery(users);
    res.status(200).json({
      data: getAllUsers,
    });
  } catch (error) {
    res.status(400).json({
      msg: error.message ? error.message : error,
    });
  }
};

module.exports.resetpasswordemail = async (req, res) => {
  try {
    let sql1 = `SELECT * FROM ${db_table.users} WHERE email_address = ?`;
    var result = await mysqlquery(sql1, [req.body.email_address]);
    if (result == 0) {
      res.status(404).json({
        msg: "No account with that email address exists.",
      });
    } else {
      var token = randtoken.generate(20);
      var email_address = req.body.email_address;
      const myDate = new Date();
      myDate.setHours(myDate.getHours() + 1);
      var data = [token, myDate, email_address];

      var resetpassword = `UPDATE ${db_table.users} SET reset_password_token=?, reset_password_expires=? WHERE email_address =?`;
      var resetpass = await mysqlquery(resetpassword, data);
      registration_email.sendEmail(email_address, token);

      if (resetpass.affectedRows > 0) {
        res.status(200).json({
          msg: "reset password link send in our emailid",
        });
      } else {
        res.status(400).json({
          msg: "bad request",
        });
      }
    }
  } catch (error) {
    res.status(400).json({
      msg: error.message ? error.message : error,
    });
  }
};

module.exports.resetpassword = async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }
    var new_password = req.body.new_password;
    var reenter_password = req.body.reenter_password;
    var findreset_passwordexpire = `SELECT * FROM ${db_table.users} WHERE reset_password_expires > now() and reset_password_token =?`;
    var result = await mysqlquery(findreset_passwordexpire, [
      req.body.reset_password_token,
    ]);
    if (result == 0) {
      res.status(401).json({ msg: "invalid resetpassword token" });
    } else {
      if (new_password == reenter_password) {
        var saltRounds = 10;
        var password = req.body.new_password;
        // var hash = bcrypt.hash(password, saltRounds);
        var salt = await bcrypt.genSalt(saltRounds);
        var hash = await bcrypt.hash(password, salt);
        var data = [hash, result[0].email_address];
        var rsetpass = `UPDATE ${db_table.users} SET password=? WHERE email_address = ? `;
        var resetpassword = await mysqlquery(rsetpass, data);
        if (resetpassword.affectedRows > 0) {
          res.status(200).json({
            msg: "reset password link send in our emailid",
          });
        } else {
          res.status(401).json({
            msg: "bad request",
          });
        }
      } else {
        res.status(400).json({
          msg: "new password and reenter password do not match",
        });
      }
    }
  } catch (error) {
    res.status(400).json({
      msg: error.message ? error.message : error,
    });
  }
};

module.exports.changepassword = async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(409).json({ errors: errors.array() });
    }
    var data = [req.body.user_id];
    var changepassuserid = `SELECT  * FROM ${db_table.users} WHERE user_id=?`;
    var result = await mysqlquery(changepassuserid, data);
    if (result == 0) {
      return res.status(404).send({
        msg: "user not found",
      });
    } else {
      var bResult = await bcrypt.compare(
        req.body.old_password,
        result[0]["password"]
      );
      // wrong password
      if (bResult == false) {
        return res.status(401).send({
          msg: "old password is incorrect!",
        });
      } else {
        var password = req.body.new_password;
        var saltRounds = 10;
        // var hash = bcrypt.hash(password, saltRounds);
        var salt = await bcrypt.genSalt(saltRounds);
        var hash = await bcrypt.hash(password, salt);
        var data = [hash, result[0].email_address];
        var sqlquery = `UPDATE ${db_table.users} SET password=? WHERE email_address=?`;
        var cahngepassword = await mysqlquery(sqlquery, data);

        if (cahngepassword.affectedRows > 0) {
          res.status(200).json({
            msg: "change password successfully'",
          });
        } else {
          res.status(401).json({
            msg: "bad request",
          });
        }
      }
    }
  } catch (error) {
    res.status(400).json({
      msg: error.message ? error.message : error,
    });
  }
};

module.exports.updateuser = async (req, res) => {
  try {
    var user = [
      req.body.first_name,
      req.body.middle_name,
      req.body.last_name,
      req.body.email_address,
      req.body.mobile_no,
      req.params.user_id,
    ];
    var upadateuserdata = `UPDATE ${db_table.users} SET first_name=?, middle_name=?,last_name=?,email_address=?,mobile_no=? WHERE user_id=?`;
    var userdata = await mysqlquery(upadateuserdata, user);
    if (userdata.affectedRows > 0) {
      res.status(200).json({
        msg: "user update successfully'",
      });
    } else {
      res.status(401).json({
        msg: "bad request",
      });
    }
  } catch (error) {
    res.status(400).json({
      msg: error.message ? error.message : error,
    });
  }
};

module.exports.getuser = async (req, res) => {
  try {
    var getuser = `SELECT * FROM ${db_table.users} WHERE user_id=?`;
    var getuser = await mysqlquery(getuser, [req.body.user_id]);
    res.status(200).json({
      data: getuser,
    });
  } catch (error) {
    res.status(400).json({
      msg: error.message ? error.message : error,
    });
  }
};

// module.exports.userstatusinactive = async (req, res) => {
//   try {
//     var changestatus = await mysqlquery(query.update.changestatus, ["inactive", req.body.id])
//     res.status(200).json({
//       data: "change status successfully "
//     })
//   } catch (error) {
//     res.status(400).json({
//       msg: error
//     })
//   }
// }

module.exports.deleteuser = async (req, res) => {
  try {
    var deleteuserid = `DELETE FROM ${db_table.users} WHERE user_id=?`;
    var deleteuser = await mysqlquery(deleteuserid, [req.body.user_id]);
    if (deleteuser.affectedRows > 0) {
      res.status(200).json({
        msg: "delete user successfully",
      });
    } else {
      res.status(401).json({
        msg: "bad request",
      });
    }
  } catch (error) {
    res.status(400).json({
      msg: error.message ? error.message : error,
    });
  }
};

module.exports.send_feedback_notification = async (req, res) => {
  if (req.body.email_address) {
    let user_query = `SELECT * FROM ${db_table.users} WHERE email_address=?`;
    let user_result = await mysqlquery(user_query, [req.body.email_address]);

    if (user_result.length > 0) {
      const user_data = Object.values(user_result);
      const name = user_data[0].first_name;
      let otp_params = {
        email_address: req.body.email_address,
        name: name,
      };
      const result = await registration_email.feedback_Email(otp_params);
      res.status(200).json({ msg: "Mail send successfully" });
    }
  } else {
    res.status(200).json({ msg: "Please provide email" });
  }
};

module.exports.account_opening_submition_mail = async (req, res) => {
  if (req.body.email_address) {
    let user_query = `SELECT * FROM ${db_table.users} WHERE email_address=?`;
    let user_result = await mysqlquery(user_query, [req.body.email_address]);

    if (user_result.length > 0) {
      const user_data = Object.values(user_result);
      const name = user_data[0].first_name;
      if(!req?.session?.token){
        await get_token(req)
      }else if(Date.now() > req.session.expires_in){
        await get_token(req)
      }
      let otp_params = {
        email_address: req.body.email_address,
        name: name,
        login:`${process.env.CustomerURL}/login`,
        image:process.env.URL
      };
      let data = {
        sendMessage:{
          version:"1.0",
          appID:"FINACLE",
          topicName:"nriactcnf",
          recipient:{
            subscriber:{
              customerID:"",
              accountNo:"",
              contact:{
                emailID:req.body.email_address,
                mobileNo:""
              }
            }
          },
          mergeVarArray:{
            mergeVar:{
              name:"CUSTNAME",
              content:{
                stringContent:name
              }
            },
            mergeVar:{
              name:"URL",
              content:{
                stringContent:`${process.env.CustomerURL}/login`
              }
            }
          },
          referenceNo:`nriactcnf_ + ${new Date().getSeconds() * new Date().getMilliseconds()}`
        }
      }

      var builder = new Convert.Builder();
      var xml = builder.buildObject(data);
      const agent = new https.Agent({
        rejectUnauthorized: false,
      });
      let header = {
        "x-rbl-auth": `Bearer ${req.session.token}`,
        "x-api-key": process.env.RBL_API_KEY,
      };
      const axiosConfig = {
        httpsAgent: agent,
        headers: header,
      };
      await axios.post(
        `${process.env.RBL_URL}/ralert/alrt`,
        xml,
        axiosConfig
      );
      // const result = await registration_email.account_opening_submition(
      //   otp_params
      // );
      res.status(200).json({ msg: "Mail send successfully" });
    }
  } else {
    res.status(401).json({ msg: "User not found for this email" });
  }
};

module.exports.success_account_opening = async (req, res) => {
  if (req.body.email_address) {
    let user_query = `SELECT * FROM ${db_table.users} WHERE email_address=?`;
    let user_result = await mysqlquery(user_query, [req.body.email_address]);

    if (user_result.length > 0) {
      const user_data = Object.values(user_result);
      const name = user_data[0].first_name;
      // let otp_params = {
      //   email_address: req.body.email_address,
      //   name: name,
      // };
      let data = {
        sendMessage:{
          version:"1.0",
          appID:"FINACLE",
          topicName:"nriactacpt",
          recipient:{
            subscriber:{
              customerID:"",
              accountNo:"",
              contact:{
                emailID:req.body.email_address,
                mobileNo:""
              }
            }
          },
          mergeVarArray:{
            mergeVar:{
              name:"CUSTNAME",
              content:{
                stringContent:name
              }
            },
            mergeVar:{
              name:"URL",
              content:{
                stringContent:process.env.CustomerURL
              }
            }
          },
          referenceNo:`${nriactcnf_} + ${new Date().getSeconds() * new Date().getMilliseconds()}`
        }
      }

      var builder = new Convert.Builder();
      var xml = builder.buildObject(data);
      const agent = new https.Agent({
        rejectUnauthorized: false,
      });
      let header = {
        "x-rbl-auth": `Bearer ${req.session.token}`,
        "x-api-key": process.env.RBL_API_KEY,
      };
      const axiosConfig = {
        httpsAgent: agent,
        headers: header,
      };
      await axios.post(
        `${process.env.RBL_URL}/ralert/alrt`,
        xml,
        axiosConfig
      );
      // let user = await response.data;
      // const result = await registration_email.account_opening_status(
      //   otp_params
      // );
      res.status(200).json({ msg: "Mail send successfully" });
    }
  } else {
    res.status(401).json({ msg: "User not found for this email" });
  }
};

/* download pdf */
module.exports.download_pdf = async (req, res) => {
  const userId = req.body.user_id;
  let sql = `select u.email_address,l.lead_number from tbl_users as u
            left join tbl_leads as l on l.user_id = u.user_id 
            where u.user_id = ?`;
  const result = await mysqlquery(sql, userId);

  if (result.length > 0) {
    const url = `${process.env.URL}/forms/${result[0].lead_number}.pdf`;
    let params = {
      email: result[0].email_address,
      lead_number: result[0].lead_number,
      url: url,
      image:process.env.URL
    };
    if (url) {
      await registration_email.send_pdf_mail(params);
      res.status(200).json({ msg: "Mail send" });
    } else {
      res.status(400).json({ msg: "Pdf not found" });
    }
  } else {
    res.status(401).json({ msg: "User not found" });
  }
};

module.exports.is_both_otp_verify = async (req, res) => {
  try {
    if (req.body.user_id) {
      const check_otp = `select is_email_verify,is_mobile_verify from ${db_table.users} where user_id = ?`;
      const otp_result = await mysqlquery(check_otp, req.body.user_id);
      const emtarr = [];
      otp_result.map((a) => {
        const data = {
          is_email_verify: a.is_email_verify != null ? a.is_email_verify : 0,
          is_mobile_verify: a.is_mobile_verify != null ? a.is_mobile_verify : 0,
        };
        emtarr.push(data);
      });
      if (otp_result.length > 0) {
        res.status(200).json({
          data: emtarr,
        });
      }
    } else {
      res.status(401).json({ msg: "User not found" });
    }
  } catch (error) {
    res.status(400).json({
      msg: error.message ? error.message : error,
    });
  }
};
